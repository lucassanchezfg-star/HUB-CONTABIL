# Contabilizador de Cartao (GetNet / Rede)

App web **local** que le relatorios de **vendas de cartao** (GetNet e Rede) e gera um
**CSV de lancamentos contabeis** pronto para importacao. E **reutilizavel por empresa**:
as contas contabeis ficam num cadastro editavel (`dados/config.json` + tela `/cadastro`),
nunca hardcoded no codigo.

Roda 100% em `http://127.0.0.1:5000` — nada e enviado para a internet.

---

## Como iniciar

1. De **duplo clique em `Iniciar.bat`**.
2. O navegador abre sozinho em `http://127.0.0.1:5000`. A janela preta some
   sozinha depois de uns segundos — **o sistema continua no ar**.
3. Para encerrar, use o botao **⏻ Encerrar**, no canto direito do menu do site.

**Por que a janela nao derruba mais o sistema.** O servidor sobe no
`pythonw.exe` (sem console) e num processo proprio (`start`), solto do
`Iniciar.bat` — fechar a janela sem querer nao tira mais o site do ar. Como
nao ha console, o que o servidor imprime vai para `dados\servidor.log`.

Fechar a **aba** do navegador tambem nao desliga nada, e de proposito: o
navegador manda o mesmo sinal ao atualizar a pagina ou trocar de tela, entao
desligar por ai derrubaria o sistema no meio do trabalho. Quem desliga e o
botao. Rodar o `Iniciar.bat` com o sistema ja no ar **nao sobe um segundo
servidor**: ele so reabre o navegador.

Requisito: **Python 3** instalado. Se nao houver, o `Iniciar.bat` **instala
automaticamente** (via `winget`, sem precisar de admin) na primeira vez — leva 1-2 min.
Se a maquina nao tiver `winget`, instale manualmente em
<https://www.python.org/downloads/> marcando *"Add python.exe to PATH"*.

> **Dependencias:** nenhuma. O app usa **somente a biblioteca padrao do Python 3**
> (`http.server`, `zipfile`, `xml.etree`). Nao precisa de `pip install`.

---

## Como levar para OUTRA maquina

1. **Copie a pasta inteira** `ContabilizadorCartao` (pendrive, rede, e-mail em .zip etc.)
   para a outra maquina. Nao precisa copiar `dados/config.json` se a empresa for
   diferente — ele e recriado do `seed.json` na primeira execucao (ou copie tambem se
   quiser levar o cadastro ja preenchido).
2. **De duplo clique em `Iniciar.bat`** na maquina de destino.
   - Se a maquina **ja tiver Python 3**, o app abre direto.
   - Se **nao tiver**, o `.bat` roda `winget install Python.Python.3.12` sozinho
     (nao pede senha de administrador) e depois abre o app. Isso funciona mesmo em
     redes com proxy corporativo que bloqueia o `pip` — o `winget` usa um caminho de
     rede diferente que normalmente nao e bloqueado.
   - Se a instalacao automatica falhar (empresa sem `winget`, rede muito restrita),
     instale o Python manualmente em <https://www.python.org/downloads/> (marcando
     *"Add python.exe to PATH"*) e rode `Iniciar.bat` de novo.
3. Pronto — o app abre em `http://127.0.0.1:5000` **naquela** maquina, isolado; nao
   depende do computador onde foi criado.

### Por que nao usa Flask/openpyxl?
A especificacao previa Flask + openpyxl. No ambiente onde foi montado, o **proxy
corporativo autenticado bloqueia o `pip install`** (erro `407 Proxy Authentication
Required`), o que impediria instalar essas bibliotecas — e a mesma trava atingiria o
`Iniciar.bat`. Para o app **sempre rodar sem instalar nada**, o servidor web foi feito
com `http.server` e a leitura do `.xlsx` da Rede foi feita direto do XML (o mesmo
metodo ja necessario para o GetNet). A arquitetura, as rotas e o resultado sao os
mesmos previstos para Flask. Se um dia o `pip` funcionar, os arquivos `parsers.py`,
`core_cartao.py` e `store.py` servem a uma versao Flask sem alteracao.

---

## Como usar

1. Abra **"Vendas de Cartao"** (`/cartao`).
2. **Arraste os relatorios** `.xlsx` (GetNet e/ou Rede) para a area pontilhada.
   Pode soltar **os dois juntos** — a operadora e detectada automaticamente.
3. Escolha o **codigo da conta** no CSV: *Reduzido* (nº do plano) ou
   *Classificacao completa* (mascara `1.1.02.02.0001`).
4. Clique em **Gerar CSV**. Aparece o resumo por operadora (dias, bruto, tarifa,
   liquido, periodo) e a previa das primeiras linhas.
5. Clique em **Baixar CSV**.

Somente vendas com **status aprovado** entram. Conferencia: `bruto - tarifa = liquido`.

---

## Regras contabeis

Para **cada dia** de venda, por operadora, sao gerados **2 lancamentos**:

| Lancamento  | Debito                     | Credito                    | Historico                                        |
|-------------|----------------------------|----------------------------|--------------------------------------------------|
| Venda bruta | Conta do cartao (operadora)| Conta de Clientes          | `RECEBIMENTO VENDA CARTAO <OPERADORA> <data>`    |
| Tarifa      | Despesa c/ tarifa bancaria | Conta do cartao (operadora)| `TARIFA CARTAO <OPERADORA> <data>`               |

`<OPERADORA>` = `GETNET`, `REDE`, `CIELO` ou `STONE`. Historicos sempre em **MAIUSCULO**.
O **texto** do historico varia por operadora — ver "Perfil de saida por operadora".

### Layout do CSV (fixo)
Separador `;`, uma linha por lancamento. Gravado com **BOM UTF-8** (abre certo no
Excel PT-BR).

```
Data;Debito;Credito;Valor;;Historico
```

| Col | Conteudo                                  |
|-----|-------------------------------------------|
| A   | Data (`dd/mm/aaaa`)                       |
| B   | Debito (codigo da conta)                  |
| C   | Credito (codigo da conta)                 |
| D   | Valor (virgula decimal, sem milhar)       |
| E   | **VAZIA** (em branco de proposito)        |
| F   | Historico (MAIUSCULO)                     |

Exemplo:
```
02/01/2026;1101;1103;3790,00;;RECEBIMENTO VENDA CARTAO GETNET 02/01/2026
```

---

## Cadastro por empresa (o que torna reutilizavel)

Tela **"Cadastro de Contas"** (`/cadastro`) — salva em `dados/config.json`:

- Conta do cartao **GETNET** (codigo + nome)
- Conta do cartao **REDE**
- Conta do cartao **CIELO**
- Conta do cartao **STONE**
- Conta de **Clientes**
- Conta de **Despesa c/ tarifa bancaria**

Se alguma conta necessaria estiver **em branco**, a tela avisa ao processar — sem isso o
CSV sairia com o codigo da conta vazio e a importacao quebraria silenciosamente.

### Para usar em uma NOVA empresa
Basta **trocar esses codigos** em `/cadastro` (ou editar `dados/config.json`).
O motor e os leitores **nao mudam**. O plano de contas de cada empresa entra por aqui.

> `dados/config.json` e criado na primeira execucao a partir de `seed.json`
> (contas de fabrica). Para "zerar", apague `dados/config.json` e reinicie.

---

## Formato dos relatorios (deteccao automatica)

Todos sao `.xlsx`. A operadora e detectada pela **aba** em `xl/workbook.xml`:

- Aba contendo **`CIELO`** (ex.: `vendas_cielo_historico_detalhe1`) -> **CIELO**
- Aba **`CARTOES`** (`CARTÕES`) -> **GETNET**
- Aba **`vendas`** -> **REDE**
- Aba **`Report`** + colunas do Stone -> **STONE**

> A Cielo e testada **primeiro** porque o nome da aba dela contem `vendas`, que tambem e
> o nome exato da aba da Rede. O Stone e testado **por ultimo** e ainda confirma pelas
> colunas, porque `Report` e um nome de aba generico.

**REDE** (aba `vendas`): linha 1 = titulo, linha 2 = cabecalho, dados a partir da
linha 3. Colunas mapeadas **pelo nome** do cabecalho (robusto a mudanca de ordem):
`data da venda`, `status da venda` (== `aprovada`), `valor da venda original`,
`valor total das taxas descontadas (MDR+recebimento automatico)`, `valor liquido`.

**GETNET** (aba `CARTOES`): o `.xlsx` vem com `<dimension ref="A1"/>` **invalido** e
strings **inline** (`t="inlineStr"`), o que faz o openpyxl ler a planilha como vazia.
Por isso o GetNet e lido **direto do XML** (`zipfile` + `xml.etree`), ignorando o
`dimension` e varrendo todos os `<row>`. Cabecalho na linha 8, dados a partir da 9.
Colunas: `DATA/HORA DA VENDA` (pega os 10 primeiros = `dd/mm/aaaa`),
`STATUS DA TRANSACAO` (== `Aprovada`), `VALOR BRUTO`, `VALOR TAXA` (vem **negativo**,
usa o valor absoluto), `VALOR LIQUIDO`.

**CIELO** (aba `vendas_cielo_historico_detalhe1`): detectada por conter `CIELO` no
nome da aba. Antes do cabecalho existe um **preambulo** (dados do estabelecimento,
filtros e um bloco `Totalizador`), por isso a linha do cabecalho **nao e fixa** — ela e
localizada procurando as colunas `DATA DA VENDA`, `VALOR BRUTO`, `TAXA/TARIFA` e
`STATUS DA VENDA`. Colunas: `DATA DA VENDA` (`dd/mm/aaaa`), `STATUS DA VENDA`
(== `Aprovada`), `VALOR BRUTO`, `TAXA/TARIFA` (vem **negativa**, usa o valor
absoluto), `VALOR LIQUIDO`.

> **Pix no relatorio Cielo:** a Cielo entrega o Pix **junto** com as vendas de cartao
> (coluna `FORMA DE PAGAMENTO`). Entram **todas** as formas aprovadas, para que o total
> feche exatamente com o `Totalizador` do proprio arquivo. Se um dia for preciso separar
> o Pix, basta filtrar `FORMA DE PAGAMENTO != PIX` em `parse_cielo` (`parsers.py`).

**STONE** (aba `Report`): cabecalho na linha 1, dados a partir da 2. **Duas armadilhas:**
o xlsx vem **sem `<dimension>`** e **sem o atributo `r` nas celulas** (`<c t="inlineStr">`),
entao `_linhas_xml` usa a **posicao** da linha/celula quando o `r` falta. Colunas:
`DATA DA VENDA` (vem `"dd/mm/aaaa hh:mm"` -> **usa so os 10 primeiros**, descartando a
hora; sem isso cada horario viraria um "dia" diferente), `ULTIMO STATUS` (== `Aprovada`),
`VALOR BRUTO`, e a tarifa e a **soma dos tres descontos** `DESCONTO DE MDR` +
`DESCONTO DE ANTECIPACAO` + `DESCONTO UNIFICADO` (vem negativos -> valor absoluto).
Confere: `bruto - tarifa = VALOR LIQUIDO`.

### Perfil de saida por operadora (`core_cartao.PERFIS`)
Cada operadora pode ter seu proprio modelo de importacao. Hoje:

| | GetNet / Rede / Cielo | Stone |
|---|---|---|
| Cabecalho `Data;Debito;...` | **sim** | **nao** |
| Historico | `RECEBIMENTO VENDA CARTAO <OP> <dd/mm/aaaa>` | `TRANSFERÊNCIA P/ CARTÃO STONE <mm/aaaa>` |
| Historico da tarifa | `TARIFA CARTAO <OP> <dd/mm/aaaa>` | `DESCONTOS (MDR/ANTECIPAÇÃO/UNIFICADO) CARTÃO STONE <mm/aaaa>` |
| Acentos no historico | removidos | **preservados** |
| Valor | sempre 2 casas (`1234,50`) | formato "geral", sem zeros a direita (`5582,9`, `2325`) |

Para mudar o modelo de uma operadora, edite `PERFIS` em `core_cartao.py` — os parsers e
o resto do motor nao mudam.

Numeros aceitam `398.0` (ponto) e `1.234,56` / `1234,56` (virgula BR).
Comparacoes de texto (status/cabecalho) sao feitas em maiusculas e sem acento.

---

## Modulo EXTRATO BANCARIO (Itau e Santander, PDF)

Le o extrato em **PDF** e gera o CSV **no mesmo layout do cartao**.

### Regra contabil (o banco e conta do ATIVO)

| No extrato | Debito | Credito | Historico |
|---|---|---|---|
| **Entrou** dinheiro (debita o banco) | conta do banco | De-Para, ou **Clientes** | `RECEBIMENTO <NOME>` |
| **Saiu** dinheiro (credita o banco) | De-Para, ou **Pendencia** | conta do banco | `PAGAMENTO <NOME>` |

Historico sempre em **MAIUSCULO** e sem acento. `<NOME>` e o nome cadastrado no
De-Para; sem casamento, e a descricao do extrato sem os prefixos genericos
(`PIX RECEBIDO`, `PAGAMENTO DE BOLETO OUTROS BANCOS`...).

> **Saldos NUNCA entram no CSV.** Saldo anterior, saldo final e a conferencia
> aparecem **so na tela**, como verificacao.

### Os dois modulos de cadastro que o extrato usa

**REGRA** (`/regra`) — o banco e **fixo**: agencia, numero da conta e a **conta do
banco no plano de contas**. O extrato e casado por esta lista pelo numero da
conta (comparando so os digitos, ignorando ponto/hifen/zeros a esquerda).
Guarda tambem as duas contas padrao: **Clientes** (entrada nao identificada) e
**Pendencia/Reclassificar** (saida nao identificada).

**DE-PARA** (`/depara`) — liga um **padrao de texto do extrato** a uma
contrapartida do plano de contas, com o nome que vai no historico.
Casamento em maiusculo sem acento, por "contem"; os padroes **mais longos** sao
testados primeiro, para que `DECO` nao roube o casamento de `DECOPLAST`.

> Pagamento que nao casa nenhum padrao vai para a conta de **pendencia**
> (na Callix, `670 RECLASSIFICAR`). A conta de **Fornecedores Diversos** nao
> participa do de-para, por decisao do escritorio.

### Como o PDF e lido (sem pypdf)

`pdftexto.py`, so biblioteca padrao:

1. Descomprime os streams **FlateDecode** com `zlib`.
2. Interpreta os operadores de texto (`BT/ET`, `Tm`, `Td`, `TD`, `T*`, `Tj`, `TJ`)
   guardando a **posicao (x, y)** de cada pedaco.
3. Agrupa por linha (mesmo `y`) e ordena por `x`.
4. **Itau**: fonte CID com strings em hex -> decodifica pelo **ToUnicode CMap**
   embutido. **Santander**: strings literais legiveis.

**A armadilha das linhas.** Quando a celula do historico tem duas linhas, o PDF
entrega **tres** linhas, com a que tem data+valor **no meio**:

```
Pagamento De Boleto Outros Bancos     <- fragmento (acima)
19/06/2026 -3.850,60 -522,24          <- ANCORA (data + valor + saldo)
GRUPO TOTAL BRASIL IND DE             <- fragmento (abaixo)
```

O parser acha as ancoras (linha que comeca com data e tem valor) e cola os
fragmentos vizinhos. **A politica difere por banco:**

- **Itau** — `Razao Social` e uma coluna separada que quebra sozinha: sempre cola.
- **Santander** — o historico e uma coluna so: **so cola quando a ancora nao tem
  nenhuma letra no meio** (pode ter apenas o numero do documento). Sem essa
  distincao, um `Pix Enviado` completo absorveria o `Pagamento De Boleto` do
  lancamento seguinte.

Valor monetario exige **virgula + 2 decimais** — assim CPF/CNPJ
(`161.801.568-08`) e numero de documento (`15050488`) nao viram valor.
Com 2+ valores na linha, o **ultimo e o saldo** e o penultimo e o valor.

### Conferencia

`saldo anterior + movimento = saldo final do extrato`. Validado no Itau
06/2026 da Callix: `-59.368,36 + 72.204,82 = 12.836,46` (diferenca 0,00).

### Subir o Plano de Contas (dentro da tela De-Para)

Em `/depara` tem um upload para o **PDF do plano de contas** do escritorio.
Ao subir, o sistema:

1. Le TODAS as contas do plano (codigo, classificacao, nome).
2. **Corrige de uma vez** o nome de toda regra de De-Para ja cadastrada cujo
   codigo exista no plano (mostra antes/depois de cada correcao).
3. Avisa quais regras tem um codigo que **nao existe** no plano enviado.
4. Passa a **autocompletar o nome** ao digitar/escolher um codigo novo.

Isso resolveu um problema real: os nomes cadastrados a mao (por interpretacao
do plano em PDF) tinham 9 pequenas divergencias (faltava "LTDA", etc.) — a
correcao automatica ajustou todas de uma vez, sem digitar nada.

> **Por decisao do escritorio, isso NAO existe na tela Regra** (bancos) —
> aquele cadastro e feito manualmente.

**Armadilha nova, especifica deste PDF:** ele usa DUAS fontes CID (Tahoma
normal e Tahoma Bold), cada uma com seu proprio CMap `/ToUnicode`. Mesclar os
dois CMaps num so dict (o que `pdftexto.py` fazia antes) troca caracteres,
porque o mesmo codigo numerico significa letras DIFERENTES em cada fonte —
o texto sai "embaralhado" de um jeito consistente (nao aleatorio), facil de
confundir com "fonte nao suportada". A correcao: manter os CMaps **separados**
e, ao decodificar cada string, testar contra todos e usar o que acerta mais
codigos — sem depender de resolver `/Font`/`Tf` (que variam demais de
estrutura entre geradores de PDF).

Este mesmo PDF tambem grava o content stream **sem compressao** (sem
`FlateDecode`) — outro motivo pelo qual ficava ilegivel antes da correcao.

**Armadilha do PDF em DUAS REVISOES.** Um PDF pode guardar mais de uma versao
dentro do mesmo arquivo: os objetos antigos continuam la e o trailer novo
aponta para os novos. Varrer todo `stream` do arquivo (o que `pdftexto.py`
fazia) le as DUAS revisoes e **duplica o documento inteiro** — visto num
extrato Bradesco, onde cada lancamento aparecia 2x, e no proprio Plano de
Contas (1344 linhas lidas para 727 contas reais). Como o texto duplicado e
plausivel, o erro nao aparece: so **dobra a soma**, em silencio. A leitura
correta segue `/Root -> /Pages -> /Kids` da **ultima** revisao, lendo cada
pagina exatamente uma vez. De quebra, a pagina traz o proprio
`/Resources /Font`, que responde com exatidao "qual fonte e este `/F1`" —
melhor que o palpite por proximidade de offset no arquivo.

**Espaco entre palavras: limiar ADAPTATIVO.** Geradores diferem muito. Alguns
desenham a palavra inteira num `Tj`; outros desenham **caractere por
caractere** (num extrato, o gap ENTRE LETRAS da mesma palavra era de 5 a 8,5
unidades, e entre campos, 150+). Nenhum limiar fixo serve para os dois: um
valor baixo transforma `SANTANDER` em `S A N T A N D E R` (derruba ate a
deteccao do banco); um valor alto cola palavras no outro documento. Por isso
`linhas_do_pdf` faz **duas passadas**: mede a distribuicao real de gaps
daquele documento, acha o "salto" natural entre gaps intra-campo e
inter-campo, e so entao junta as linhas com esse limiar.

---

## Modulo ROTINAS — Receita Financeira

Tela `/receita_financeira`. Solta-se a pilha de arquivos do mes e ele apura as
quatro rubricas. **O tipo e reconhecido pelo CONTEUDO, nao pelo nome do
arquivo** (o nome nao e confiavel: a matriz sai como `MATRIZ.csv` mas o
sistema a chama de `SANTA ROSA`).

| Fonte | Rubrica | De onde sai o numero |
|---|---|---|
| Titulos pagos por empresa (.csv/.xlsx) | Descontos obtidos | rodape `TOTAL DOS DESCONTOS` |
| Titulos recebidos (.csv/.xlsx) | Juros ativos | coluna `VR.JUROS`, **todas** as modalidades |
| Extrato Itau (.pdf) | Rendimento + IRRF | linha `total` da secao *movimentacao – aplicacoes/resgates*: 3o numero = rendimento bruto, 5o = IRRF |
| Extrato Bradesco (.pdf) | Rendimento | creditos `RENTAB.INVEST FACILCRED` (penultimo numero da linha) |

Detalhes que evitam erro de apuracao:

- **O IRRF nao entra no total.** E imposto retido, informado em coluna
  separada no relatorio do fiscal; soma-lo inflaria a receita e contaria o
  rendimento duas vezes (o IRRF ja esta dentro do rendimento bruto).
- **`SALDO INVEST FACIL` nao e rendimento**, e saldo — somar essas linhas
  dobraria a rubrica do Bradesco.
- **Rubrica sem nenhum arquivo sai ZERADA e o CSV nao denuncia.** Por isso a
  tela avisa, por rubrica, quando nao entrou nenhum arquivo.
- **Competencias misturadas** na mesma pilha geram aviso. A competencia sai de
  um rotulo explicito (`resumo - mes 10/2025`, `out 2025`) antes de cair na
  contagem de datas: no extrato do Itau a data de EMISSAO se repete no rodape
  das 42 paginas e ganharia de qualquer data do mes de referencia.
- Conta **sem aplicacao no mes** (ex.: conta garantida) nao e erro: entra com
  zero e aparece na composicao com o aviso.
- **Ficam manuais** (a tela lembra): distribuicao de sobras Sicredi e
  rendimento de aplicacao de outros bancos.

A tela mostra o conteudo exato do CSV **e** a composicao ("de onde veio cada
valor", arquivo por arquivo). O CSV baixado leva so as rubricas.

---

## Modulo ROTINAS — Estoque Citel

Tela `/estoque_citel`. Entram os **inventarios fisicos** do sistema Citel (um
por filial, `.xlsx` ou `.csv`) e sai a planilha **CONTABILIZACAO ESTOQUE**, no
mesmo desenho do modelo que o escritorio ja usava:

- aba **CONSOLIDACAO**: `CONTA | FILIAL | TOTAL ESTOQUE (R$)`, uma linha por
  filial com a formula `=SUM('<FILIAL>'!H25:H1048576)`, e `TOTAL CONSOLIDADO`;
- uma **aba por filial** com o inventario inteiro (~41 mil linhas cada).

O cadastro `filial -> conta contabil` fica em `/estoque_contas`, na lateral do
modulo. **A ordem do cadastro e a ordem das abas e das linhas** do consolidado.

### O que evita erro de contabilizacao aqui

- **A filial nao esta na linha 1 nem no nome do arquivo.** A linha 1 traz
  sempre a empresa que EMITIU (`SANTA ROSA`) — em todos os arquivos, inclusive
  no da Enseada. Quem identifica e a linha `Empresa : 005-...`; e o casamento
  com o cadastro tenta primeiro o **codigo** (`005`), so depois o nome, porque
  a matriz aparece ora como `SANTA ROSA`, ora como `MATRIZ`.
- **O cabecalho nao esta numa linha fixa** — antes dele vem a lista de filtros
  da emissao, que muda. Ele e procurado pelas colunas, e a linha onde cair
  define o inicio da faixa da formula. Por isso a planilha serve a qualquer mes
  sem ajuste.
- **Todo valor chega como TEXTO** (`"184,0400"`), mesmo no `.xlsx` (celulas
  `inlineStr`). Repassado assim, a formula de soma devolveria **zero com a
  planilha parecendo certa**. As colunas numericas viram numero de verdade — e
  sao escolhidas pelo NOME da coluna, nao pela posicao.
- **O total vai como formula, nao como numero pronto** (o numero tambem e
  calculado, para a tela conferir). Assim quem recebe clica na celula e vai ate
  a linha na aba da filial.
- **A tela e a planilha tem que dar o mesmo numero.** O consolidado soma os
  totais **sem arredondar** e arredonda uma vez so — que e o que a formula do
  Excel faz. Somar os totais ja arredondados dava 1 centavo de diferenca entre
  a tela e o arquivo baixado.
- **Filial sem cadastro entra na planilha assim mesmo**, com a conta em branco
  e aviso: some do cadastro, nunca do total.
- **Filial repetida na mesma pilha gera aviso** — dois arquivos da mesma
  empresa contam o estoque duas vezes.

O `.xlsx` e gerado por `xlsxescreve.py` (so biblioteca padrao, ver "Por que nao
usa Flask/openpyxl"), gravando aba por aba direto no zip: sao ~167 mil linhas,
e monta-las todas na memoria antes de salvar custaria centenas de MB.

---

## Arquitetura de arquivos

```
app.py             -> servidor web (rotas dos dois departamentos)
parsers.py         -> cartao: deteccao + GetNet/Rede/Cielo/Stone -> [{data, bruto, tarifa}]
core_cartao.py     -> cartao: regras contabeis + perfis de saida + geracao do CSV
pdftexto.py        -> extracao de texto de PDF SEM pypdf (so biblioteca padrao)
parsers_extrato.py -> extrato: deteccao Itau/Santander + leitura -> [{data,historico,valor}]
parsers_plano.py   -> plano de contas: PDF -> [{codigo,classificacao,nome}]
core_extrato.py    -> extrato: regra contabil (banco/de-para/pendencia) + CSV
parsers_fiscal.py  -> ROTINAS: titulos pagos/recebidos + extrato Itau/Bradesco -> rubricas
core_fiscal.py     -> ROTINAS: soma das rubricas + CSV da receita financeira
parsers_estoque.py -> ROTINAS: inventario fisico do Citel -> filial + linhas + total
core_estoque.py    -> ROTINAS: monta a planilha de contabilizacao do estoque
parsers_balancete.py     -> AUDITORIA: leitura generica do Balancete (reaproveitavel)
parsers_depreciacao.py   -> AUDITORIA: leitura do Resumo da Depreciacao Fiscal
core_auditoria_depreciacao.py -> AUDITORIA: confronto Resumo x Balancete + planilha
xlsxescreve.py     -> gera .xlsx SEM openpyxl (so biblioteca padrao)
store.py           -> ler/gravar cadastro por empresa (contas, bancos, de-para)
seed.json          -> contas padrao de fabrica (tudo em branco)
templates/         -> uma tela por modulo + base_head (CSS) + base_nav (menu)
static/            -> logo
dados/empresas/    -> um JSON por empresa cadastrada
Iniciar.bat        -> localiza o Python e sobe o servidor abrindo o navegador
```

O app e dividido em **dois departamentos**, e o menu (`templates/base_nav.html`)
e um arquivo so, incluido em todas as telas — antes cada tela tinha sua copia
do menu e alguma sempre ficava sem o modulo novo.

**O menu lista so os PROCESSOS**; os cadastros ficam na **lateral direita do
modulo que os usa** (`.modulo` + `.lateral` no CSS), e cada um tem o caminho
de volta para o seu modulo:

| Departamento | No menu | Cadastros, na lateral do modulo |
|---|---|---|
| Contabil | Vendas de Cartao | Cadastro de Contas |
| Contabil | Extrato Bancario | Regra, De-Para |
| Contabil | Francesinha BB, Descontados BB, Sispag | — (a definir) |
| Rotinas | Receita Financeira, Aluguel e Royalties | — |
| Rotinas | Estoque Citel | Contas do estoque |

Separacao de responsabilidades: **leitura** (`parsers*.py`), **contabilizacao**
(`core_*.py`), **cadastro** (`store.py`) e **web** (`app.py`) sao independentes.
`core_extrato.py` **reaproveita** `core_cartao.py` para o layout do CSV e a
normalizacao de historico — nao ha um layout de CSV separado por modulo.

---

## Modulo AUDITORIA — Depreciacao

Tela `/aud_depreciacao`. Confronta o **Resumo da Depreciacao Fiscal**
(relatorio do Patrimonial) com o **Balancete** do mesmo periodo — os dois
soltos juntos, em qualquer ordem, reconhecidos pelo **conteudo**.

Duas linhas de conferencia, por desenho (nao e um confronto generico):

1. **Saldo acumulado de depreciacao** — total "Valor ja depreciado" do
   Resumo x saldo da conta de depreciacao acumulada no Balancete.
   **Normalmente NAO bate** — e esperado quando o saldo inicial da conta foi
   lancado na implantacao (migracao de outro sistema) sem reproduzir o
   acumulado exato do patrimonial. O modulo **aponta a diferenca**, nao tenta
   zera-la.
2. **Depreciacao do mes** — o lancamento do periodo (nao o acumulado).
   Este **costuma bater exatamente**: e o lancamento feito no mes, sem
   historico de saldo anterior para divergir.

Pontos que evitam erro de conferencia aqui:

- As contas sao achadas no Balancete por **palavra-chave** ("DEPRECIA" na
  descricao), nunca por codigo/classificacao — que mudam de empresa para
  empresa. "ACUMULADA" na descricao separa a conta de Ativo (contra-conta,
  saldo negativo no balancete) da conta de despesa.
- **Conta-grupo x conta-analitica com o MESMO saldo.** Um balancete lista
  tanto o grupo sintetico (`4.5.02.03 DEPRECIACOES E AMORTIZACOES`) quanto a
  conta analitica dentro dele (`4.5.02.03.0001 DEPRECIACAO E AMORTIZACAO`)
  com o **mesmo valor** quando so ha uma conta no grupo. Somar as duas
  dobraria o numero — `parsers_balancete.folhas()` remove qualquer conta que
  seja ancestral (prefixo de classificacao) de outra na mesma busca.
- **Saldo negativo entre parenteses**: `(958.323,08)` = -958.323,08 (contra-
  conta). Sem tratar isso a depreciacao acumulada entraria como positiva.
- **Cruzamento de partida dobrada**: o debito lancado na despesa do mes e o
  credito lancado na conta acumulada tem que ser iguais entre si (nao so
  contra o Resumo) — se nao forem, entra aviso em vez de escolher um dos dois
  em silencio.
- Conta nao encontrada (por nenhuma das duas linhas) sai como aviso
  explicito, nunca como zero disfarcado de "bateu".

---

## Validacao com relatorios reais

| Operadora | Dias | Bruto (R$) | Tarifa (R$) | Liquido (R$) | Conferencia |
|-----------|------|-----------:|------------:|-------------:|:-----------:|
| GETNET    | 26   | 65.164,90  | 763,48      | 64.401,42    | ✅ bate com a coluna "valor liquido" |
| REDE      | 25   | 49.376,74  | 859,87      | 48.516,87    | ✅ bate com a coluna "valor liquido" |

Soltando os dois juntos: **1 CSV**, ordenado por data, com 2 linhas por dia por
operadora (venda bruta + tarifa), coluna E vazia e historicos em maiusculo.
