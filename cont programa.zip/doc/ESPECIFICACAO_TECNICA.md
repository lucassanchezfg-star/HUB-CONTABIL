# Especificação Técnica — Leitor de Vendas de Cartão → CSV Contábil

**Handoff para desenvolvimento.** Este documento descreve tudo que precisa ser executado
para reimplementar o sistema (ex.: como site web). Cada operadora tem armadilhas reais
descobertas contra arquivos de produção — elas estão documentadas com a solução, para não
ser preciso redescobrir.

Escopo: **GetNet, Rede, Cielo e Stone**. Entrada: `.xlsx` da operadora.
Saída: **CSV de lançamentos contábeis** pronto para importação.

Referência de implementação funcionando: `parsers.py`, `core_cartao.py`, `store.py`, `app.py`.

---

## 1. Visão geral do fluxo

```
.xlsx da operadora
      │
      ├─ 1. DETECTAR operadora ......... pelo nome das abas internas
      ├─ 2. LOCALIZAR o cabeçalho ...... linha varia por operadora
      ├─ 3. MAPEAR colunas ............. pelo NOME do cabeçalho, nunca por posição fixa
      ├─ 4. FILTRAR .................... somente vendas aprovadas
      ├─ 5. EXTRAIR .................... por venda: { data, bruto, tarifa }
      ├─ 6. AGRUPAR por data ........... soma bruto e tarifa do dia
      ├─ 7. CONTABILIZAR ............... 2 lançamentos por dia (débito/crédito)
      └─ 8. GERAR CSV .................. layout por perfil da operadora
```

Regra de ouro do passo 5: o parser devolve sempre a **mesma estrutura**, independente da
operadora. Todo o resto do sistema (contabilização, CSV, tela) não sabe qual operadora é.

```json
[ { "data": "01/06/2026", "bruto": 1490.00, "tarifa": 31.14 }, ... ]
```

---

## 2. Glossário de negócio

| Termo | Significado |
|---|---|
| **Operadora / adquirente** | GetNet, Rede, Cielo, Stone |
| **Bruto** | Valor da venda antes das taxas |
| **Tarifa / taxa** | O que a operadora desconta (MDR, antecipação etc.) |
| **Líquido** | `bruto − tarifa`. A operadora informa esse valor no relatório |
| **Competência** | Mês/ano de referência (`mm/aaaa`) |
| **Conta reduzida** | Código curto da conta no plano (ex.: `5097`) — é o que vai no CSV |
| **Classificação** | Máscara da conta (ex.: `1.1.02.02.0001`) — guardada, mas não usada hoje |
| **Filial** | Empresas como a HAC têm um relatório por loja |

> **Conferência obrigatória:** `soma(bruto) − soma(tarifa)` **deve** ser igual à soma da
> coluna de líquido do relatório. É o teste que prova que o parser está correto.
> Implemente isso como teste automatizado.

---

## 3. Regra contábil (o motor)

Para **cada data** e **cada operadora**, gerar **2 lançamentos**:

| # | Lançamento | Débito | Crédito | Valor |
|---|---|---|---|---|
| 1 | Venda bruta | Conta do cartão da operadora | Conta de Clientes | `soma(bruto)` do dia |
| 2 | Tarifa | Conta de despesa c/ tarifa | Conta do cartão da operadora | `soma(tarifa)` do dia |

Regras:

- Arredondar as somas do dia para **2 casas** antes de gerar o lançamento.
- Emitir o lançamento **somente se o valor > 0** (dia com bruto 0 não gera linha).
- Ordenação final: **data cronológica** → operadora → tipo (venda antes da tarifa).
  Atenção: a data é `dd/mm/aaaa` (texto); para ordenar, converter para `aaaammdd`.
- As contas **nunca** são fixas no código: vêm do cadastro da empresa (seção 5).

---

## 4. Layout do CSV de saída

Separador `;`, **6 campos**, **coluna E sempre vazia** (proposital),
**BOM UTF-8** (`EF BB BF`), quebra de linha **CRLF**.

```
Data;Debito;Credito;Valor;;Historico
02/01/2026;1101;1103;3790,00;;RECEBIMENTO VENDA CARTAO GETNET 02/01/2026
```

| Col | Conteúdo |
|---|---|
| A | Data `dd/mm/aaaa` |
| B | Débito (código da conta) |
| C | Crédito (código da conta) |
| D | Valor com **vírgula** decimal, **sem** separador de milhar |
| E | **VAZIA** |
| F | Histórico, sempre **MAIÚSCULO** |

### 4.1 Perfis por operadora (importante)

Cada operadora pode ter um modelo de importação diferente. Isso **não é detalhe
cosmético**: o modelo do Stone foi validado contra um arquivo de produção do escritório.

| | GetNet · Rede · Cielo | **Stone** |
|---|---|---|
| Linha de cabeçalho | **sim** | **não** |
| Histórico da venda | `RECEBIMENTO VENDA CARTAO {OPERADORA} {dd/mm/aaaa}` | `TRANSFERÊNCIA P/ CARTÃO STONE {mm/aaaa}` |
| Histórico da tarifa | `TARIFA CARTAO {OPERADORA} {dd/mm/aaaa}` | `DESCONTOS (MDR/ANTECIPAÇÃO/UNIFICADO) CARTÃO STONE {mm/aaaa}` |
| Acentos no histórico | **removidos** | **preservados** |
| Data no histórico | data completa | **competência** `mm/aaaa` |
| Formato do valor | sempre 2 casas: `1234,50` | formato "geral", sem zeros à direita: `5582,9` · `2325` · `2` |

Implementar como tabela de configuração (dicionário/JSON), não como `if` espalhado:

```js
PERFIL_PADRAO = {
  histVenda:  "RECEBIMENTO VENDA CARTAO {operadora} {data}",
  histTarifa: "TARIFA CARTAO {operadora} {data}",
  acentos: false, cabecalho: true, valor: "2dec"
}
PERFIS = {
  STONE: {
    histVenda:  "TRANSFERÊNCIA P/ CARTÃO STONE {mesano}",
    histTarifa: "DESCONTOS (MDR/ANTECIPAÇÃO/UNIFICADO) CARTÃO STONE {mesano}",
    acentos: true, cabecalho: false, valor: "geral"
  }
}
```

Formato `geral` (replicar exatamente):

```js
s = valor.toFixed(2)            // "5582.90"
s = s.replace(/0+$/,"").replace(/\.$/,"")   // "5582.9" ; "2325.00"→"2325" ; "2.00"→"2"
s = s.replace(".", ",")
```

Se um CSV misturar operadoras (consolidado), usar o **perfil padrão** (com cabeçalho).

---

## 5. Modelo de dados — cadastro por empresa

O que torna o sistema reutilizável. Um registro por empresa:

```json
{
  "empresa": "HAC MATERIAIS PARA CONSTRUCAO LTDA",
  "modo_codigo": "reduzido",
  "contas": {
    "cartao_getnet": { "reduzido": "",     "classificacao": "", "nome": "" },
    "cartao_rede":   { "reduzido": "5097", "classificacao": "1.1.3.01.0018", "nome": "CARTAO DE CREDITO A RECEBER" },
    "cartao_cielo":  { "reduzido": "",     "classificacao": "", "nome": "" },
    "cartao_stone":  { "reduzido": "",     "classificacao": "", "nome": "" },
    "clientes":      { "reduzido": "27",   "classificacao": "1.1.3.01.0001", "nome": "CLIENTES DIVERSOS" },
    "tarifa":        { "reduzido": "307",  "classificacao": "4.2.2.04.0004", "nome": "TAXA ADMINISTRATIVA CARTAO DE CREDITO" }
  }
}
```

Requisitos:

- Mapa fixo **operadora → chave da conta**:
  `GETNET→cartao_getnet`, `REDE→cartao_rede`, `CIELO→cartao_cielo`, `STONE→cartao_stone`.
- **Empresa nova nasce com todas as contas em branco.** Não herdar códigos de exemplo —
  código errado silencioso é pior que campo vazio.
- Opção de **criar copiando** o de-para de outra empresa (útil em grupos empresariais).
- **Não permitir excluir a última empresa.**
- Guardar `reduzido` **e** `classificacao`; o CSV usa hoje só o `reduzido`.
- **Validação antes de gerar:** se a conta do cartão da operadora detectada, a de Clientes
  ou a de tarifa estiverem vazias, **avisar na tela**. Sem isso o CSV sai com o campo de
  conta em branco e a importação quebra sem ninguém perceber.

---

## 6. Como ler `.xlsx` — fundamentos (leia antes da seção 7)

Um `.xlsx` é um **ZIP**. As armadilhas das operadoras estão todas nesta camada, então a
recomendação é **ler o XML direto** em vez de confiar numa biblioteca de alto nível.
(Na implementação de referência, a biblioteca padrão de leitura de Excel devolvia a
planilha da GetNet **vazia**.)

Estrutura relevante do ZIP:

```
xl/workbook.xml            -> lista de abas: <sheet name="..." r:id="rIdN"/>
xl/_rels/workbook.xml.rels -> mapeia rIdN -> worksheets/sheetN.xml
xl/worksheets/sheetN.xml   -> as células
xl/sharedStrings.xml       -> textos compartilhados (quando existe)
```

### 6.1 Resolver aba pelo nome (não pela ordem)

Nunca assumir que a aba desejada é `sheet1.xml`. Ler `workbook.xml`, achar o `<sheet>`
pelo `name`, pegar o `r:id`, e resolver esse id em `workbook.xml.rels` para descobrir o
arquivo real. A Cielo precisa de busca por **conteúdo** ("contém `cielo`"), porque o nome
da aba tem sufixo variável.

### 6.2 Ler o valor de uma célula `<c>`

Tratar **três** casos:

| `t` da célula | Onde está o valor |
|---|---|
| `t="s"` | `<v>` contém um **índice** → buscar em `sharedStrings.xml` |
| `t="inlineStr"` | o texto está em `<is><t>` (pode haver vários `<t>`, concatenar) |
| ausente / `t="n"` / `t="str"` | `<v>` já é o valor literal |

### 6.3 As duas armadilhas estruturais

**(a) `<dimension>` pode mentir.** A GetNet declara `<dimension ref="A1"/>` numa planilha
com centenas de linhas. **Ignorar completamente o `dimension`** e varrer todos os `<row>`
do `<sheetData>`.

**(b) Os atributos `r` são opcionais.** No OOXML, `<row r="...">` e `<c r="A1">` podem não
existir — e no Stone **não existem**. Solução: quando faltar `r`, usar a **posição
sequencial** (índice da linha; índice da célula → letra de coluna: 0→A, 25→Z, 26→AA).
Sem isso, o arquivo do Stone é lido como vazio.

### 6.4 Localizar a linha do cabeçalho

Não hardcodar o número da linha quando houver preâmbulo (Cielo tem capa com filtros e
totalizador). Estratégia robusta: **varrer as linhas até achar a que contém todas as
colunas obrigatórias** daquela operadora. Guardar o número dessa linha; os dados começam
na linha seguinte.

---

## 7. Especificação por operadora

Detecção — **a ordem importa**:

| Ordem | Teste | Resultado |
|---|---|---|
| 1º | alguma aba **contém** `CIELO` | `CIELO` |
| 2º | existe aba `CARTOES` (normalizado de `CARTÕES`) | `GETNET` |
| 3º | existe aba exatamente `VENDAS` | `REDE` |
| 4º | existe aba `REPORT` **e** o cabeçalho tem as colunas do Stone | `STONE` |
| — | nada casou | erro claro ao usuário |

> **Por que a ordem importa:** a aba da Cielo chama `vendas_cielo_historico_detalhe1`, que
> *contém* `vendas` — se o teste da Rede vier primeiro e usar "contém", a Cielo é
> classificada errado. A Rede exige igualdade exata; a Cielo, "contém".
> O Stone fica por último e **confirma pelo cabeçalho** porque `Report` é nome genérico e
> pode colidir com relatórios de outros sistemas.

---

### 7.1 GETNET

| Item | Valor |
|---|---|
| Aba | `CARTÕES` (o arquivo tem também `PIX`, `RECARGA`, `VAN`, `VOUCHER` — ignorar) |
| Cabeçalho | linha **8** |
| Dados | linha **9** em diante |
| Nome do arquivo | `Vendas_Detalhado_<estab>_<aaaammdd>_<aaaammdd>_<guid>.xlsx` |

Colunas (mapear por nome):

| Campo | Nome no cabeçalho | Obs. |
|---|---|---|
| Data | `DATA/HORA DA VENDA` | texto `"dd/mm/aaaa hh:mm"` → **usar os 10 primeiros chars** |
| Status | `STATUS DA TRANSAÇÃO` | aceitar somente `Aprovada` |
| Bruto | `VALOR BRUTO` | |
| Tarifa | `VALOR TAXA` | **vem NEGATIVO** → usar valor absoluto |
| Líquido | `VALOR LÍQUIDO` | só para conferência |

**Armadilhas:**

1. `<dimension ref="A1"/>` **inválido** (ver 6.3a).
2. Strings **inline** (`t="inlineStr"`), e `sharedStrings.xml` existe mas com
   `count="0"` — quem só lê sharedStrings não acha texto nenhum.
3. Números aparecem como `"398.0"` (ponto decimal), diferente do padrão BR do resto.

---

### 7.2 REDE

| Item | Valor |
|---|---|
| Aba | `vendas` |
| Linha 1 | título (descartar) |
| Cabeçalho | linha **2** |
| Dados | linha **3** em diante |
| Nome do arquivo | `[filial ]Rede_Rel_Vendas_<dd_mm_aaaa>-<dd_mm_aaaa>-<guid>.xlsx` |

Colunas (nomes em **minúsculo** no arquivo):

| Campo | Nome no cabeçalho |
|---|---|
| Data | `data da venda` |
| Status | `status da venda` → somente `aprovada` |
| Bruto | `valor da venda original` |
| Tarifa | `valor total das taxas descontadas (MDR+recebimento automático)` |
| Líquido | `valor líquido` |

**Armadilhas:**

1. A data vem como **serial numérico do Excel**, e ao ler o XML direto chega como string
   (`"46203.0"`). Converter: `data = 1899-12-30 + serial dias`.
2. O relatório tem **várias** colunas de taxa (`taxa MDR`, `valor MDR`,
   `taxa de recebimento automático`, `valor taxa de recebimento automático`,
   `taxas descontadas...`). A correta é **`valor total das taxas descontadas
   (MDR+recebimento automático)`** — pegar a errada muda o resultado.
3. Este é o formato "bem comportado": `dimension` válido, sharedStrings normal.

---

### 7.3 CIELO

| Item | Valor |
|---|---|
| Aba | nome **contém** `cielo` (ex.: `vendas_cielo_historico_detalhe1`) |
| Preâmbulo | dados da loja, filtros e um bloco **Totalizador** |
| Cabeçalho | **não fixo** — no arquivo analisado é a linha 10, mas **deve ser localizado** |
| Dados | linha seguinte ao cabeçalho |

Colunas obrigatórias para identificar o cabeçalho:
`DATA DA VENDA`, `VALOR BRUTO`, `TAXA/TARIFA`, `STATUS DA VENDA`.

| Campo | Nome no cabeçalho | Obs. |
|---|---|---|
| Data | `DATA DA VENDA` | texto `dd/mm/aaaa` |
| Status | `STATUS DA VENDA` | somente `Aprovada` |
| Bruto | `VALOR BRUTO` | |
| Tarifa | `TAXA/TARIFA` | **vem NEGATIVA** → valor absoluto |
| Líquido | `VALOR LÍQUIDO` | conferência |

**Armadilhas:**

1. **Cabeçalho móvel** por causa do preâmbulo (ver 6.4).
2. **O relatório traz Pix junto com cartão** (coluna `FORMA DE PAGAMENTO` tem
   `Pix`, `Crédito à vista`, `Crédito parcelado loja`, `Débito à vista`, `Débito pré-pago`,
   `Crediário`, `Pagamento carnê`).
   **Decisão vigente do escritório: incluir tudo que estiver aprovado**, para o total
   fechar com o Totalizador do próprio arquivo. Deixar isso **configurável** — é uma
   decisão de negócio, não técnica.
3. O bloco Totalizador é um presente para teste: ele dá bruto/tarifa/líquido do arquivo
   inteiro. Use para validar.

---

### 7.4 STONE

| Item | Valor |
|---|---|
| Aba | `Report` |
| Cabeçalho | linha **1** |
| Dados | linha **2** em diante |
| Nome do arquivo | GUID puro, ex.: `58e0368e-e05f-4a3d-ac5f-9c6f9a438108.xlsx` |

Colunas na ordem do arquivo:

```
1 DOCUMENTO          2 STONECODE                 3 DATA DA VENDA
4 BANDEIRA           5 PRODUTO                   6 STONE ID
7 N DE PARCELAS      8 VALOR BRUTO               9 VALOR LIQUIDO
10 DESCONTO DE MDR   11 DESCONTO DE ANTECIPACAO  12 DESCONTO UNIFICADO
13 N DO CARTAO       14 MEIO DE CAPTURA          15 N DE SERIE
16 ULTIMO STATUS     17 DATA DO ULTIMO STATUS
```

| Campo | Nome no cabeçalho | Obs. |
|---|---|---|
| Data | `DATA DA VENDA` | `"30/04/2026 21:29"` → **usar os 10 primeiros chars** |
| Status | `ULTIMO STATUS` | somente `Aprovada` |
| Bruto | `VALOR BRUTO` | `"32,000000"` — vírgula decimal, 6 casas |
| **Tarifa** | **soma de 3 colunas** | `DESCONTO DE MDR` + `DESCONTO DE ANTECIPACAO` + `DESCONTO UNIFICADO`, todas negativas → **somar e tomar o valor absoluto da soma** |
| Líquido | `VALOR LIQUIDO` | conferência |

**Armadilhas:**

1. **Sem `<dimension>` e sem atributo `r` nas células** (ver 6.3b). É a pior das quatro:
   sem o fallback posicional o arquivo é lido como vazio.
2. **A data vem com hora.** Sem descartar a hora, cada horário vira um "dia" distinto:
   abril/2026 sairia com **2.232 lançamentos em vez de 54**.
3. A tarifa é a **soma de três colunas** — usar só o `DESCONTO UNIFICADO` dá resultado
   errado nos dias que têm Pix (o Pix carrega o valor em `DESCONTO DE MDR`).
4. **Tomar o valor absoluto DA SOMA, não a soma dos absolutos por coluna separada com
   sinais trocados.** Ver o erro real documentado na seção 11.
5. Existe o status `Falha na transação` no arquivo — **não é venda**, tem que ser filtrado.

---

## 8. Normalizações obrigatórias

Sem estas três funções nada funciona de forma estável.

### 8.1 Texto (para comparar cabeçalho e status)

Maiúsculas, **sem acento**, espaços colapsados.
Motivo: `STATUS DA TRANSAÇÃO` vs `STATUS DA TRANSACAO`, `CARTÕES` vs `CARTOES`,
`aprovada` vs `Aprovada`. Usar normalização Unicode NFKD e remover marcas de combinação.

### 8.2 Número

Precisa aceitar **três** formatos, porque as operadoras divergem:

| Entrada | Origem | Saída |
|---|---|---|
| `398.0` | GetNet (ponto decimal) | `398.0` |
| `1.234,56` | BR com milhar | `1234.56` |
| `1234,56` / `32,000000` | Rede/Stone (vírgula decimal) | `1234.56` / `32.0` |

Algoritmo: remover `R$` e espaços; se tiver **ponto e vírgula**, o ponto é milhar
(remover) e a vírgula é decimal; se tiver **só vírgula**, vírgula é decimal; se tiver
**só ponto**, já está pronto. Vazio ou `-` → `0`.

### 8.3 Data

Aceitar:

- `datetime`/`date` nativo;
- string `"dd/mm/aaaa"` ou `"dd/mm/aaaa hh:mm"` → **10 primeiros caracteres**;
- **serial do Excel** como número **ou como string numérica** (`"46203.0"`) →
  `1899-12-30 + N dias`.

Saída sempre `dd/mm/aaaa`.

---

## 9. Aplicação — rotas e comportamento

Rotas da implementação de referência (adaptar ao framework escolhido):

| Rota | Método | Função |
|---|---|---|
| `/` | GET | hub de processos |
| `/cartao` | GET | tela de upload + geração |
| `/cadastro` | GET | gestão de empresas e contas |
| `/processar_cartao` | POST | recebe `multipart/form-data` (`empresa`, N× `arquivos`) → JSON do resultado |
| `/baixar?token=` | GET | download de um CSV gerado |
| `/api/empresas` | GET / POST | listar / criar empresa |
| `/api/empresa_ativa` | POST | definir empresa padrão da sessão |
| `/api/empresas_excluir` | POST | excluir empresa |
| `/api/config?empresa=` | GET / POST | ler / gravar contas de uma empresa |

### 9.1 Regras de comportamento que **não** são opcionais

1. **Um CSV por arquivo enviado.** O usuário solta os 5 relatórios das 5 filiais da HAC e
   recebe **5 CSVs separados**, um por filial — não um consolidado. (Opcionalmente
   oferecer também um consolidado, mas o padrão é separado.)
2. **Rótulo/filial derivado do nome do arquivo.** Normalizar o nome (sem acento,
   maiúsculo) e cortar nos tokens `REDE_REL`, `VENDAS_DETALHADO`, `RELATORIO`; o que
   sobrar antes é a filial (`enseada Rede_Rel_Vendas_...` → `ENSEADA`).
   Se sobrar vazio, ou se o resultado for um **GUID** (caso do Stone), usar o nome da
   operadora.
3. **Aviso de conta em branco** antes de entregar o CSV (ver seção 5).
4. **Arquivo não reconhecido** → mensagem clara dizendo quais formatos são aceitos, sem
   abortar os outros arquivos do mesmo lote.
5. **Resumo por arquivo** na tela: dias, bruto, tarifa, líquido, período, nº de
   lançamentos, e prévia das primeiras linhas do CSV.

---

## 10. Testes de aceitação (fixtures reais)

Reproduzir estes números **exatamente**. São arquivos de produção já conferidos.

| Operadora | Arquivo | Aprovadas | Dias | Bruto | Tarifa | Líquido | Lanç. |
|---|---|---:|---:|---:|---:|---:|---:|
| GETNET | Pratice Bag · set/2025 | 534 | 26 | 65.164,90 | 763,48 | 64.401,42 | 52 |
| REDE | jun/2026 | 164 | 25 | 49.376,74 | 859,87 | 48.516,87 | 50 |
| CIELO | Coimbra · jun/2026 | 469 | 25 | 383.584,26 | 22.153,55 | 361.430,71 | 50 |
| STONE | Vovó Diana · abr/2026 | 2.232 | 27 | 104.364,73 | 2.424,95 | 101.939,78 | 54 |

HAC, 5 filiais Rede, jun/2026 (solte os 5 juntos → 5 CSVs):

| Filial | Bruto | Tarifa | Líquido | Lanç. |
|---|---:|---:|---:|---:|
| ENSEADA | 356.358,65 | 6.110,42 | 350.248,23 | 50 |
| LINK | 171.726,68 | 3.670,38 | 168.056,30 | 52 |
| SANTA ROSA | 428.522,43 | 6.557,56 | 421.964,87 | 50 |
| SANTO ANTONIO | 182.981,22 | 2.774,01 | 180.207,21 | 50 |
| SANTOS | 206.524,42 | 3.237,50 | 203.286,92 | 48 |
| **Total** | **1.346.113,40** | **22.349,87** | **1.323.763,53** | **250** |

Asserções que devem passar em todos os casos:

- [ ] `soma(bruto) − soma(tarifa) == soma(líquido do relatório)` (tolerância R$ 0,01)
- [ ] Cielo: bruto/tarifa/líquido iguais ao bloco **Totalizador** do próprio arquivo
- [ ] Toda linha do CSV tem **exatamente 6 campos**
- [ ] Campo **E vazio** em toda linha
- [ ] Histórico **maiúsculo** em toda linha, e contém o nome da operadora
- [ ] Arquivo começa com **BOM UTF-8**
- [ ] Nº de lançamentos = 2 × dias (quando bruto>0 e tarifa>0 em todos os dias)
- [ ] Ordenação cronológica ao misturar operadoras/competências
- [ ] Trocar o código no cadastro muda o CSV **sem tocar em código-fonte**
- [ ] GetNet é lido apesar do `dimension="A1"`
- [ ] Stone é lido apesar da ausência dos atributos `r`

---

## 11. Caso real de erro — replicar a regra CORRETA, não o arquivo

Ao comparar o CSV gerado com o `STONE_IMPORTAR.csv` que o escritório fazia à mão
(abril/2026, 54 linhas), **50 linhas saíram idênticas** e 4 divergiram. As 4 eram
**erros do processo manual**:

**Erro 1 — sinal do MDR do Pix invertido (3 dias, R$ 0,70).**
A planilha manual calculou `|soma(UNIFICADO)| − |soma(MDR)|`, ou seja **subtraiu** o MDR
das vendas Pix QR Code em vez de somar.

| Data | Correto | Manual | Δ |
|---|---:|---:|---:|
| 02/04 | 98,30 | 97,94 | −0,36 |
| 03/04 | 131,87 | 131,65 | −0,22 |
| 27/04 | 2,12 | 2,00 | −0,12 |

Prova: em 27/04, `218,10 − 2,00 = 216,10`, mas o líquido informado pela Stone é
**215,98**. Com `2,12` fecha exato.

**Erro 2 — transação com falha lançada como venda (R$ 8,00).**
Em 05/04 o manual usou 4.138,40; o correto é **4.130,40**. A diferença é uma transação
com `ULTIMO STATUS = "Falha na transação"`.

> **Instrução ao desenvolvedor:** implementar a regra correta
> (`|MDR + ANTECIPAÇÃO + UNIFICADO|`, somente `Aprovada`) e usar a asserção
> `bruto − tarifa == líquido` como juiz. Se um arquivo de referência do escritório não
> fechar nessa conta, o arquivo está errado — não o parser.

---

## 12. Armadilhas de implementação web

Encontradas na prática, provavelmente vão reaparecer:

1. **Nome de arquivo acentuado em `multipart/form-data`.** Navegadores enviam o
   `filename` do `Content-Disposition` em **UTF-8**. Decodificar os cabeçalhos como
   latin-1 corrompe `RELATÓRIO CARTÃO CIELO...` → `RELATA?RIO CARTA?O...`, sujando o
   rótulo da filial e o nome do CSV. **Decodificar como UTF-8.**
2. **Excel PT-BR exige BOM UTF-8** no CSV, senão acentos aparecem quebrados.
3. **Arquivos grandes**: o relatório do Stone tem 2.234 linhas × 17 colunas; a HAC soma
   ~7.300 linhas em 5 arquivos. Processar por streaming/iteração, não carregar tudo em
   memória de uma vez, se for escalar.
4. **Aba com nome genérico** (`Report`): sempre confirmar pelo cabeçalho antes de assumir
   a operadora.
5. **Não confiar no nome do arquivo** para detectar a operadora — muda toda exportação
   (GUIDs, prefixos manuais de filial).

---

## 13. Pendências de negócio (decisões do escritório, não do dev)

Precisam de resposta antes de entrar em produção:

1. **Cielo · Pix** — hoje entra junto com o cartão, na mesma conta. Separar em conta
   própria? (Se sim, precisa de um campo `pix` no cadastro.)
2. **Contas faltantes no cadastro:**
   - **Coimbra** — está com códigos de exemplo. Falta a conta do cartão **Cielo** (ainda
     não existe no plano de contas dela), Clientes e Tarifa. Obs.: no CSV de importação da
     Coimbra o código usado é o da coluna **"Conta Domínio"** (GetNet=975, Rede=974,
     PagSeguro=973) — não o código interno do balancete.
   - **Callix** e **Pratice Pack** — falta a conta de tarifa (os arquivos recebidos foram
     Balanço Patrimonial, que não traz contas de despesa).
   - **Pratice Bag** — usando "Despesas Bancárias Diversas" (genérica); confirmar se há
     conta específica de taxa de cartão.
3. **Uso do campo `classificacao`** — hoje o CSV usa só o código reduzido. Definir se
   algum cliente precisa da máscara completa.
4. **Outras operadoras** — a Coimbra tem conta de **PagSeguro** no plano; provável
   próxima operadora a suportar.

---

## 14. Ordem sugerida de implementação

1. **Camada de leitura de `.xlsx`** (seção 6) + as 3 normalizações (seção 8).
   Entregar com testes: abrir os 4 arquivos de exemplo e listar o cabeçalho de cada um.
   *Nada funciona antes disso estar sólido.*
2. **Parser da REDE** — é o formato mais limpo; valida a arquitetura ponta a ponta.
3. **Motor contábil + CSV** (seções 3 e 4) com o perfil padrão; rodar as asserções da
   seção 10 para a Rede.
4. **Cadastro por empresa** (seção 5), incluindo a validação de conta em branco.
5. **Parser da GETNET** — exercita o `dimension` inválido e `inlineStr`.
6. **Parser da CIELO** — exercita o cabeçalho móvel.
7. **Parser do STONE** — exercita o fallback posicional, a data com hora e a tarifa de
   3 colunas; implementar o **perfil de saída** (seção 4.1).
8. **Web/UI**: upload múltiplo, 1 CSV por arquivo, resumo, prévia, avisos.
9. **Suíte de regressão** com os números da seção 10, rodando a cada alteração.

---

## 15. Arquivos da implementação de referência

```
parsers.py        detecção + leitura de xlsx + 1 parser por operadora
                  -> saída padronizada [{data, bruto, tarifa}]
core_cartao.py    regra contábil, perfis de saída, geração do CSV
store.py          cadastro multiempresa (JSON por empresa)
app.py            servidor web e rotas
templates/        hub, tela de cartão, tela de cadastro
seed.json         contas de fábrica (todas em branco para cartões novos)
dados/empresas/   um JSON por empresa cadastrada
```

Separação de responsabilidades a preservar: **leitura** (parsers) ·
**contabilização** (core) · **cadastro** (store) · **web** (app). Trocar a camada web não
deve exigir tocar nas outras três.
