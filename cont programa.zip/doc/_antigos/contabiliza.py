# -*- coding: utf-8 -*-
"""
contabiliza.py - Processa a PASTA DO MES inteira por linha de comando.

E a mesma coisa que as telas fazem, sem navegador: serve para o mes ser
processado por um agente/atalho/tarefa agendada em vez de arrastar arquivo a
arquivo. Uso:

    python contabiliza.py "C:\\...\\CONTABIL OUTUBRO 2025"
    python contabiliza.py "<pasta>" --empresa hac_materiais_para_construcao_ltda
    python contabiliza.py "<pasta>" --simular          (nao grava nada)
    python contabiliza.py "<pasta>" --saida "C:\\...\\IMPORTAR"

O que ele faz:
  1. Varre a pasta (com subpastas) e RECONHECE cada arquivo PELO CONTEUDO -
     nao pelo nome nem pela pasta onde esta.
  2. Gera os CSVs chamando EXATAMENTE as mesmas funcoes das rotas web
     (app.processar_*): o que sai daqui e o que sairia da tela, byte a byte.
     Nao ha uma segunda copia da regra contabil neste arquivo.
  3. Grava cada CSV em "CSV IMPORTACAO", DENTRO da pasta do arquivo que o
     originou (o CSV do extrato fica junto dos extratos, o do cartao junto
     dos relatorios de cartao). Com --saida, tudo vai para uma pasta so.
  4. Imprime o relatorio do que fez, incluindo o que exige conferencia sua:
     saldo que nao fechou, pagamento sem de-para e rubrica fiscal zerada.

UM ARQUIVO PODE ALIMENTAR DOIS MODULOS. O extrato do Itau em PDF e lancamento
contabil (modulo Extrato) E fonte de rendimento de aplicacao (modulo fiscal
Receita Financeira). Por isso a classificacao NAO e exclusiva: o mesmo PDF
entra nas duas listas.
"""
import argparse
import os
import sys

import app
import parsers
import parsers_extrato
import parsers_fiscal
import store

SUBPASTA_SAIDA = "CSV IMPORTACAO"
EXTS = (".xlsx", ".xlsm", ".csv", ".pdf")
# Nao reprocessar o que este proprio comando gerou numa rodada anterior.
IGNORAR_PASTAS = {SUBPASTA_SAIDA.upper(), "__PYCACHE__"}


# --------------------------------------------------------------------------
# Descoberta e classificacao
# --------------------------------------------------------------------------
def listar_arquivos(raiz):
    achados = []
    for pasta, subs, arquivos in os.walk(raiz):
        subs[:] = [s for s in subs if s.upper() not in IGNORAR_PASTAS]
        for nome in sorted(arquivos):
            if nome.lower().endswith(EXTS) and not nome.startswith("~$"):
                achados.append(os.path.join(pasta, nome))
    return achados


def classificar(caminho):
    """
    Modulos que este arquivo alimenta: subconjunto de
    {"CARTAO", "EXTRATO", "FISCAL"}. Vazio = arquivo nao reconhecido.
    """
    ext = caminho.lower()
    modulos = set()
    if ext.endswith((".xlsx", ".xlsm")):
        try:
            if parsers.detectar_operadora(caminho):
                modulos.add("CARTAO")
        except Exception:  # noqa: BLE001 - arquivo corrompido
            pass
    if ext.endswith(".pdf"):
        try:
            if parsers_extrato.detectar_banco(caminho):
                modulos.add("EXTRATO")
        except Exception:  # noqa: BLE001
            pass
    if "CARTAO" not in modulos:
        try:
            if parsers_fiscal.detectar_tipo(caminho):
                modulos.add("FISCAL")
        except Exception:  # noqa: BLE001
            pass
    return modulos


# --------------------------------------------------------------------------
# Gravacao
# --------------------------------------------------------------------------
def destino(caminho_origem, raiz, saida_fixa):
    if saida_fixa:
        return saida_fixa
    return os.path.join(os.path.dirname(caminho_origem) or raiz, SUBPASTA_SAIDA)


def gravar(pasta, nome, conteudo, simular):
    """Grava o CSV. Devolve (caminho, 'novo'|'substituido'|'simulado')."""
    alvo = os.path.join(pasta, nome)
    situacao = "substituido" if os.path.exists(alvo) else "novo"
    if simular:
        return alvo, "simulado"
    os.makedirs(pasta, exist_ok=True)
    with open(alvo, "wb") as f:
        f.write(conteudo)
    return alvo, situacao


def item_upload(caminho):
    with open(caminho, "rb") as f:
        return {"filename": os.path.basename(caminho), "content": f.read()}


def csv_do_token(token):
    return app._CSV_CACHE.get(token)


# --------------------------------------------------------------------------
# Os tres modulos
# --------------------------------------------------------------------------
def rodar_cartao(caminhos, slug, raiz, saida_fixa, simular, rel):
    for caminho in caminhos:
        res = app.processar_arquivos([item_upload(caminho)], "", slug)
        if not res.get("ok"):
            rel["erros"].append(f"[cartao] {os.path.basename(caminho)}: {res['erro']}")
            continue
        rel["avisos"].extend(f"[cartao] {a}" for a in res.get("avisos", []))
        for arq in res["arquivos"]:
            csv, nome_csv = csv_do_token(arq["token"])
            alvo, sit = gravar(destino(caminho, raiz, saida_fixa), nome_csv,
                               csv, simular)
            rel["gerados"].append({
                "modulo": "Cartao", "origem": os.path.basename(caminho),
                "rotulo": f"{arq['operadora']} · {arq['label']}",
                "lancamentos": arq["lancamentos"],
                "detalhe": (f"bruto {arq['bruto']:.2f} · tarifa {arq['tarifa']:.2f} "
                            f"· liquido {arq['liquido']:.2f}"),
                "destino": alvo, "situacao": sit,
            })


def rodar_extrato(caminhos, slug, raiz, saida_fixa, simular, rel):
    for caminho in caminhos:
        res = app.processar_extratos([item_upload(caminho)], slug)
        if not res.get("ok"):
            rel["erros"].append(f"[extrato] {os.path.basename(caminho)}: {res['erro']}")
            continue
        rel["avisos"].extend(f"[extrato] {a}" for a in res.get("avisos", []))
        for arq in res["arquivos"]:
            csv, nome_csv = csv_do_token(arq["token"])
            alvo, sit = gravar(destino(caminho, raiz, saida_fixa), nome_csv,
                               csv, simular)
            if arq.get("saldo_confere") is True:
                conf = "saldo fecha"
            elif arq.get("saldo_confere") is False:
                conf = "SALDO NAO FECHA — conferir"
                rel["conferir"].append(
                    f"{os.path.basename(caminho)}: saldo do extrato nao fecha "
                    f"(calculado {arq.get('saldo_final_calculado')}, "
                    f"extrato {arq.get('saldo_final_extrato')}).")
            else:
                conf = "extrato sem saldo para conferir"
            if arq.get("pendencia_saidas"):
                rel["conferir"].append(
                    f"{os.path.basename(caminho)}: {arq['pendencia_saidas']} "
                    f"pagamento(s) sem De-Para foram para a conta de pendencia "
                    f"({arq['pendencia_valor']:.2f}).")
            rel["gerados"].append({
                "modulo": "Extrato", "origem": os.path.basename(caminho),
                "rotulo": arq["label"], "lancamentos": arq["lancamentos"],
                "detalhe": (f"entradas {arq['total_entradas']:.2f} · saidas "
                            f"{arq['total_saidas']:.2f} · {conf}"),
                "destino": alvo, "situacao": sit,
            })


def rodar_fiscal(caminhos, slug, raiz, saida_fixa, simular, rel, competencia):
    """A receita financeira e UMA apuracao do mes: todos os arquivos de uma vez."""
    if not caminhos:
        return
    res = app.processar_receita_financeira(
        [item_upload(c) for c in caminhos], slug, competencia)
    if not res.get("ok"):
        rel["erros"].append(f"[fiscal] {res['erro']}")
        return
    for a in res.get("avisos", []):
        (rel["conferir"] if "ZERADA" in a or "competencias" in a
         else rel["avisos"]).append(f"[fiscal] {a}")
    csv, nome_csv = csv_do_token(res["token"])
    alvo, sit = gravar(saida_fixa or os.path.join(raiz, SUBPASTA_SAIDA),
                       nome_csv, csv, simular)
    ap = res["apuracao"]
    rel["gerados"].append({
        "modulo": "Fiscal", "origem": f"{res['lidos']} arquivo(s)",
        "rotulo": f"Receita financeira {res['competencia'] or ''}".strip(),
        "lancamentos": "-",
        "detalhe": (f"descontos {ap['descontos']:.2f} · juros {ap['juros']:.2f} "
                    f"· Itau {ap['itau_rendimento']:.2f} (IRRF {ap['itau_irrf']:.2f}) "
                    f"· Bradesco {ap['bradesco']:.2f} · TOTAL {ap['total']:.2f}"),
        "destino": alvo, "situacao": sit,
    })
    rel["conferir"].extend(f"[fiscal] {m}" for m in res.get("manuais", []))


# --------------------------------------------------------------------------
# Relatorio
# --------------------------------------------------------------------------
def imprimir(rel, simular, empresa, raiz):
    barra = "=" * 78
    print(barra)
    print(f"  {'SIMULACAO (nada foi gravado)' if simular else 'PROCESSAMENTO'}"
          f" — empresa: {empresa}")
    print(f"  Pasta: {raiz}")
    print(barra)

    if rel["nao_reconhecidos"]:
        print(f"\nIgnorados ({len(rel['nao_reconhecidos'])} arquivo(s) que nao "
              f"sao de nenhum modulo):")
        for n in rel["nao_reconhecidos"][:15]:
            print(f"  - {n}")
        if len(rel["nao_reconhecidos"]) > 15:
            print(f"  ... e mais {len(rel['nao_reconhecidos']) - 15}")

    if not rel["gerados"]:
        print("\nNenhum CSV gerado.")
    else:
        print(f"\nCSVs gerados ({len(rel['gerados'])}):\n")
        for g in rel["gerados"]:
            print(f"  [{g['modulo']}] {g['rotulo']}")
            print(f"     origem   : {g['origem']}")
            print(f"     lancament: {g['lancamentos']}   {g['detalhe']}")
            print(f"     gravado  : {g['destino']}  ({g['situacao']})")
            print()

    if rel["conferir"]:
        print("-" * 78)
        print("CONFERIR (o sistema nao decide isto sozinho):")
        for c in rel["conferir"]:
            print(f"  ! {c}")
        print()
    if rel["avisos"]:
        print("-" * 78)
        print("Avisos:")
        for a in rel["avisos"]:
            print(f"  - {a}")
        print()
    if rel["erros"]:
        print("-" * 78)
        print("ERROS:")
        for e in rel["erros"]:
            print(f"  x {e}")
        print()
    print(barra)


# --------------------------------------------------------------------------
def main(argv=None):
    p = argparse.ArgumentParser(
        description="Processa a pasta do mes e grava os CSVs de importacao.")
    p.add_argument("pasta", help="pasta do mes (varre as subpastas)")
    p.add_argument("--empresa", default="",
                   help="slug da empresa (padrao: a empresa ativa do app)")
    p.add_argument("--saida", default="",
                   help=f"grava tudo nesta pasta (padrao: '{SUBPASTA_SAIDA}' "
                        f"dentro da pasta de cada arquivo)")
    p.add_argument("--competencia", default="",
                   help="mm/aaaa da receita financeira (padrao: detectada)")
    p.add_argument("--simular", action="store_true",
                   help="mostra o que faria, sem gravar nenhum arquivo")
    args = p.parse_args(argv)

    raiz = os.path.abspath(args.pasta)
    if not os.path.isdir(raiz):
        print(f"[ERRO] Pasta nao encontrada: {raiz}")
        return 2

    slug = args.empresa or store.empresa_ativa_slug()
    try:
        cfg = store.carregar_empresa(slug)
    except ValueError as e:
        print(f"[ERRO] {e}\nEmpresas cadastradas:")
        for emp in store.listar_empresas():
            print(f"  {emp['slug']:50} {emp['nome']}")
        return 2

    rel = {"gerados": [], "conferir": [], "avisos": [], "erros": [],
           "nao_reconhecidos": []}
    por_modulo = {"CARTAO": [], "EXTRATO": [], "FISCAL": []}

    arquivos = listar_arquivos(raiz)
    print(f"Lendo {len(arquivos)} arquivo(s) em {raiz} ...")
    for caminho in arquivos:
        modulos = classificar(caminho)
        if not modulos:
            rel["nao_reconhecidos"].append(os.path.relpath(caminho, raiz))
            continue
        for m in modulos:
            por_modulo[m].append(caminho)

    rodar_cartao(por_modulo["CARTAO"], slug, raiz, args.saida, args.simular, rel)
    rodar_extrato(por_modulo["EXTRATO"], slug, raiz, args.saida, args.simular, rel)
    rodar_fiscal(por_modulo["FISCAL"], slug, raiz, args.saida, args.simular, rel,
                 args.competencia)

    imprimir(rel, args.simular, cfg.get("empresa", slug), raiz)
    return 1 if rel["erros"] else 0


if __name__ == "__main__":
    sys.exit(main())
