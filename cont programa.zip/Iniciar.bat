@echo off
chcp 65001 >nul
title Contabilizador de Cartao (GetNet / Rede)
cd /d "%~dp0"

echo ============================================================
echo   Contabilizador de Cartao - iniciando...
echo ============================================================
echo.

rem --- localizar o Python (evitando o "stub" da Microsoft Store) ---
set "PYEXE="
where py >nul 2>&1 && set "PYEXE=py"
if not defined PYEXE (
  if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
)
if not defined PYEXE (
  for /f "delims=" %%P in ('where python 2^>nul') do (
    echo %%P | find /i "WindowsApps" >nul || if not defined PYEXE set "PYEXE=%%P"
  )
)
if not defined PYEXE (
  echo Python 3 nao encontrado nesta maquina.
  where winget >nul 2>&1
  if errorlevel 1 (
    echo [ERRO] "winget" tambem nao foi encontrado, nao consigo instalar automaticamente.
    echo Instale o Python 3 manualmente em https://www.python.org/downloads/ e marque
    echo "Add python.exe to PATH". Depois rode este arquivo novamente.
    echo.
    pause
    exit /b 1
  )
  echo Instalando o Python 3.12 automaticamente via winget - uma vez so, leva 1-2 min...
  echo.
  winget install --id Python.Python.3.12 --scope user --silent --accept-source-agreements --accept-package-agreements --disable-interactivity
  if errorlevel 1 (
    echo [ERRO] A instalacao via winget falhou. Instale manualmente em
    echo https://www.python.org/downloads/ - marque "Add python.exe to PATH"
    echo e rode este arquivo novamente.
    echo.
    pause
    exit /b 1
  )
  echo.
  echo Python instalado. Localizando...
  where py >nul 2>&1 && set "PYEXE=py"
  if not defined PYEXE (
    if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
  )
  if not defined PYEXE (
    echo [ERRO] Python foi instalado mas nao foi localizado. Feche esta janela,
    echo abra uma nova - para recarregar o PATH - e rode Iniciar.bat de novo.
    echo.
    pause
    exit /b 1
  )
)

echo Python encontrado: %PYEXE%
echo.

rem --- este app usa SOMENTE a biblioteca padrao do Python ---
rem --- nenhuma dependencia externa (Flask/openpyxl) e necessaria ---
rem --- Se voce quiser usar Flask e o proxy permitir pip, rode:    ---
rem ---    %PYEXE% -m pip install flask openpyxl                   ---

rem --- o servidor sobe SOLTO desta janela ---
rem O app roda no pythonw (sem console) e por 'start', num processo proprio:
rem assim fechar esta janela NAO derruba mais o sistema. Quem desliga e o
rem botao "Encerrar" no menu do site. Log em dados\servidor.log.
set "PYWEXE="
if /i "%PYEXE%"=="py" (
  where pyw >nul 2>&1 && set "PYWEXE=pyw"
) else (
  for %%D in ("%PYEXE%") do if exist "%%~dpDpythonw.exe" set "PYWEXE=%%~dpDpythonw.exe"
)
if not defined PYWEXE set "PYWEXE=%PYEXE%"

rem Ja esta rodando? Descobre o PID para saber se e uma versao velha.
set "SRVPID="
for /f "tokens=5" %%P in ('netstat -ano ^| findstr /r /c:"127.0.0.1:5000 .*LISTENING"') do set "SRVPID=%%P"

if defined SRVPID (
  rem O servidor fica no ar entre sessoes - inclusive DEPOIS de o sistema ser
  rem atualizado, quando continuaria servindo o codigo antigo em silencio
  rem (telas novas abrindo, botoes novos dando erro). Por isso comparamos a
  rem hora em que o processo subiu com a data do arquivo mais recente.
  powershell -NoProfile -Command ^
    "$ini=(Get-Process -Id %SRVPID% -ErrorAction Stop).StartTime;" ^
    "$novo=(Get-ChildItem '%~dp0sistema\*.py','%~dp0sistema\templates\*.html' -ErrorAction SilentlyContinue |" ^
    "  Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime;" ^
    "if ($novo -ne $null -and $novo -gt $ini) { exit 1 } else { exit 0 }" >nul 2>&1
  if errorlevel 1 (
    echo O sistema foi ATUALIZADO depois que o servidor subiu.
    echo Reiniciando para valer a versao nova...
    echo.
    taskkill /PID %SRVPID% /F >nul 2>&1
    timeout /t 2 >nul
  ) else (
    echo O Jota Contabil JA esta rodando. Abrindo o navegador...
    start "" "http://127.0.0.1:5000/"
    timeout /t 3 >nul
    exit /b 0
  )
)

echo Subindo o servidor e abrindo http://127.0.0.1:5000/ ...
echo.
echo Pode fechar esta janela: o sistema continua no ar.
echo Para desligar, use o botao "Encerrar" no menu do site.
rem SEM /b: com /b o servidor nasce DENTRO do console desta janela e morre
rem junto com ela - exatamente o que este arquivo tenta evitar. Sem /b ele
rem vira um processo proprio (e o pythonw nem abre janela).
rem O codigo fica todo em sistema\ - na raiz sobra so este .bat. O Python
rem poe a pasta do script no sys.path sozinho, entao os imports nao mudam.
start "Jota Contabil" "%PYWEXE%" "%~dp0sistema\app.py"
timeout /t 5 >nul
