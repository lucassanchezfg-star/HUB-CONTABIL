# -*- coding: utf-8 -*-
"""
parsers_estoque_precito.py - Le o "Demonstrativo Estoque" da PRECITO.

FORMA DA PLANILHA (uma so, do ano inteiro)
-----------------------------------------
    A1  Demonstrativo Estoque
    A3  Lojas    B3..M3  31/01  28/02  31/03 ...  (o ULTIMO DIA de cada mes)
    A4  Cuiaba          907.520,69   1.341.751,44  ...
    A5  Brasilia       1.533.925,91  ...
    ...  (uma linha por loja)
    A11 Total          7.077.909,72  ...

O LAYOUT NAO MUDA: o que muda e que, a cada mes, a coluna daquele mes deixa
de estar vazia. Por isso o modulo pede a COMPETENCIA e le a coluna dela -
nunca "a ultima coluna preenchida", que pegaria o mes errado se alguem
adiantar um numero.

O CABECALHO VEM COMO NUMERO DE SERIE do Excel (46265 = 31/08/2026), nao como
texto. Cada coluna e identificada pelo mes dessa data.

CONFERENCIA EMBUTIDA: a planilha traz a linha "Total". A soma das lojas que o
leitor achou e comparada com ela, mes a mes; divergencia significa que uma
linha de loja ficou de fora da leitura, e o modulo avisa em vez de lancar
estoque a menos.
"""
import datetime
import re
import unicodedata
import zipfile

import parsers

RE_ROTULO_LOJAS = re.compile(r"^\s*LOJAS?\s*$", re.I)
RE_TOTAL = re.compile(r"^\s*TOTAL", re.I)
# datas plausiveis como numero de serie do Excel (1980..2079)
SERIE_MIN, SERIE_MAX = 29000, 65000


def _chave(texto):
    t = unicodedata.normalize("NFKD", str(texto or ""))
    t = "".join(c for c in t if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", t).strip().upper()


def _mes_da_celula(v):
    """Valor do cabecalho -> 'mm/aaaa'. Aceita numero de serie ou texto."""
    s = str(v or "").strip()
    if not s:
        return ""
    try:
        n = float(s)
    except ValueError:
        m = re.search(r"(\d{2})/(\d{2})/(\d{4})", s)
        if m:
            return "%s/%s" % (m.group(2), m.group(3))
        m = re.search(r"(\d{2})/(\d{4})", s)
        return "%s/%s" % (m.group(1), m.group(2)) if m else ""
    if not (SERIE_MIN < n < SERIE_MAX):
        return ""
    d = datetime.date(1899, 12, 30) + datetime.timedelta(days=int(n))
    return "%02d/%04d" % (d.month, d.year)


def _num(v):
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return round(float(v), 2)
    s = str(v or "").strip()
    if not s:
        return None
    return round(parsers.parse_numero(s), 2)


def detectar(caminho):
    try:
        return bool(ler_estoque(caminho)["lojas"])
    except Exception:  # noqa: BLE001
        return False


def ler_estoque(caminho, nome_original=""):
    """
    Devolve {"arquivo","meses":[...],"lojas":[...],"total_declarado":{...},
             "total_lido":{...},"avisos":[...]}.

    lojas: [{"loja": "CUIABA", "valores": {"08/2026": 803103.23, ...}}]
    """
    nome = nome_original or caminho.replace("\\", "/").rsplit("/", 1)[-1]
    with zipfile.ZipFile(caminho) as z:
        shared = parsers._carregar_shared_strings(z)
        for aba in parsers._abas_do_xlsx(caminho):
            sp = parsers._sheet_path_por_nome(z, aba)
            if not sp:
                continue
            linhas = list(parsers._linhas_xml(z, sp, shared))

            # --- cabecalho: a linha cuja coluna A diz "Lojas" ---
            cab_rn, colunas = None, {}
            for rn, cells in linhas:
                if not RE_ROTULO_LOJAS.match(str(cells.get("A") or "")):
                    continue
                for col, val in cells.items():
                    if col == "A":
                        continue
                    mes = _mes_da_celula(val)
                    if mes:
                        colunas[col] = mes
                if colunas:
                    cab_rn = rn
                    break
            if cab_rn is None:
                continue

            lojas, total_declarado = [], {}
            for rn, cells in linhas:
                if rn <= cab_rn:
                    continue
                rotulo = _chave(cells.get("A"))
                if not rotulo:
                    continue
                valores = {}
                for col, mes in colunas.items():
                    v = _num(cells.get(col))
                    if v is not None:
                        valores[mes] = v
                if RE_TOTAL.match(rotulo):
                    total_declarado = valores
                    continue
                if not valores:
                    continue
                lojas.append({"loja": rotulo, "valores": valores})

            if not lojas:
                continue

            meses = sorted(set(colunas.values()),
                           key=lambda m: (m[3:], m[:2]))
            total_lido = {}
            for m in meses:
                soma = sum(l["valores"].get(m, 0.0) for l in lojas)
                total_lido[m] = round(soma, 2)

            avisos = []
            for m in meses:
                d = total_declarado.get(m)
                if d is None:
                    continue
                # mes ainda nao preenchido: total declarado 0 e nada nas lojas
                if abs(d) < 0.01 and abs(total_lido[m]) < 0.01:
                    continue
                if abs(d - total_lido[m]) > 0.01:
                    avisos.append(
                        "'%s': em %s a soma das lojas que li (%.2f) nao bate "
                        "com a linha Total da planilha (%.2f) - pode ter loja "
                        "faltando na leitura." % (nome, m, total_lido[m], d))

            return {"arquivo": nome, "meses": meses, "lojas": lojas,
                    "colunas": colunas, "total_declarado": total_declarado,
                    "total_lido": total_lido, "avisos": avisos}

    raise ValueError(
        "nao achei o quadro do estoque neste arquivo (esperava a linha "
        "'Lojas' com uma coluna por mes).")


def meses_preenchidos(dados):
    """Meses que ja tem valor - os que dao para lancar."""
    return [m for m in dados["meses"] if abs(dados["total_lido"].get(m, 0.0)) > 0.01]


def mes_anterior(competencia):
    """'08/2026' -> '07/2026'."""
    m = re.match(r"^(\d{2})/(\d{4})$", str(competencia or "").strip())
    if not m:
        return ""
    mes, ano = int(m.group(1)), int(m.group(2))
    mes -= 1
    if mes == 0:
        mes, ano = 12, ano - 1
    return "%02d/%04d" % (mes, ano)


def ultimo_dia(competencia):
    """'08/2026' -> '31/08/2026'."""
    m = re.match(r"^(\d{2})/(\d{4})$", str(competencia or "").strip())
    if not m:
        return ""
    mes, ano = int(m.group(1)), int(m.group(2))
    if mes == 12:
        prox = datetime.date(ano + 1, 1, 1)
    else:
        prox = datetime.date(ano, mes + 1, 1)
    return (prox - datetime.timedelta(days=1)).strftime("%d/%m/%Y")


def primeiro_dia(competencia):
    """'08/2026' -> '01/08/2026'."""
    m = re.match(r"^(\d{2})/(\d{4})$", str(competencia or "").strip())
    return "01/%s/%s" % (m.group(1), m.group(2)) if m else ""
