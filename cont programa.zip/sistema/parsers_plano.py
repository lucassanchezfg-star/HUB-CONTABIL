# -*- coding: utf-8 -*-
"""
parsers_plano.py - Leitura do relatorio "Plano de Contas" (PDF).

Formato de cada linha (uma conta por linha, gerado por sistemas tipo Dominio):
    <codigo> <T> <classificacao> <nome da conta> <grau>
Exemplos reais:
    "1 S 1 ATIVO 1"
    "670 A 1.1.01.01.0002 RECLASSIFICAR 5"
    "707 A 2.1.01.01.0083 GETNET ADQUIRENCIA E SERVIÇOS PARA MEIOS DE PAGAMENTO S.A. 5"

T = 'S' (sintetica, grupo) ou 'A' (analitica, conta que recebe lancamento).
Nomes longos podem quebrar em 2 linhas de PDF; ver _juntar_quebras().
"""
import re

import pdftexto
from parsers import norm_txt

# A coluna T e' OPCIONAL: em parte dos planos exportados so a linha
# SINTETICA traz o "S", e a ANALITICA vem com a coluna em branco -
#     "6 S 1.1.01.02 DEPOSITOS BANCARIOS A VISTA 4"   (sintetica, com T)
#     "700 1.1.01.01.0002 LANCAMENTOS A CLASSIFICAR 5" (analitica, sem T)
# Exigindo o T, o plano da ML devolvia 179 contas de 800 e TODAS as
# analiticas (justo as que recebem lancamento) ficavam de fora, em silencio.
RE_LINHA = re.compile(
    r"^\s*(\d+)\s+(?:([SA])\s+)?([\d.]+)\s+(.+?)\s+([1-5])\s*$")


def parse_plano_contas(caminho):
    """
    Le o PDF do plano de contas e devolve a lista de contas:
        [{"codigo","tipo","classificacao","nome","grau"}, ...]
    So devolve contas ANALITICAS ('A') por padrao de uso (sao as que recebem
    lancamento); as sinteticas ('S') sao os grupos/totalizadores.
    """
    linhas = pdftexto.linhas_do_pdf(caminho)
    linhas = _juntar_quebras(linhas)

    contas = []
    for l in linhas:
        m = RE_LINHA.match(l)
        if not m:
            continue
        codigo, tipo, classif, nome, grau = m.groups()
        tipo = tipo or "A"      # coluna em branco = conta analitica
        contas.append({
            "codigo": codigo,
            "tipo": tipo,
            "classificacao": classif,
            "nome": re.sub(r"\s+", " ", nome).strip(),
            "grau": grau,
        })
    return contas


def _juntar_quebras(linhas):
    """
    Quando o nome da conta e longo, o PDF as vezes quebra em 2 linhas: a
    primeira NAO termina em ' <grau 1-5>' (fica sem o numero final), e a
    linha seguinte e so a continuacao do nome (sem codigo/tipo no inicio).

    ARMADILHA: o PDF tem "lixo" decorativo entre as linhas de conta (logo,
    cabecalho) que vem sem ToUnicode reconhecivel — texto ilegivel tipo
    'Q X MEMEVMEVZ...'. Esse lixo NAO comeca com "numero letra classificacao",
    exatamente como uma continuacao de nome legitima; colar ele na ultima
    conta ja **completa** corrompe essa conta (ela some do resultado, porque
    o texto colado quebra o casamento do regex). A guarda certa: SO colar
    quando a ultima linha guardada ainda estiver INCOMPLETA (sem o grau no
    fim) — senao, e lixo e e descartado.
    """
    saida = []
    for l in linhas:
        if RE_LINHA.match(l):
            saida.append(l)
            continue
        comeca_com_conta = re.match(r"^\s*\d+\s+(?:[SA]\s+)?[\d.]+\s", l)
        if comeca_com_conta:
            # linha de conta SEM o grau final -> guarda incompleta, a
            # continuacao do nome deve vir na(s) linha(s) seguinte(s)
            saida.append(l)
            continue
        # so cola em cima de uma entrada AINDA INCOMPLETA; senao e lixo
        if saida and not RE_LINHA.match(saida[-1]) and re.search(r"[A-Za-zÀ-ÿ]", l):
            saida[-1] = saida[-1].rstrip() + " " + l.strip()
    return saida


def indexar_por_codigo(contas):
    """{codigo: item} para lookup O(1) ao preencher nome automaticamente."""
    return {c["codigo"]: c for c in contas}


def buscar(contas, termo, limite=30):
    """Busca simples por codigo OU nome (contem, maiusculo sem acento)."""
    t = norm_txt(termo)
    if not t:
        return contas[:limite]
    out = [c for c in contas
           if t in c["codigo"] or t in norm_txt(c["nome"])]
    return out[:limite]
