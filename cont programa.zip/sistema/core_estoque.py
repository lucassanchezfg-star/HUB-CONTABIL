# -*- coding: utf-8 -*-
"""
core_estoque.py - Monta a CONTABILIZACAO DE ESTOQUE a partir dos inventarios.

Saida: um .xlsx igual ao modelo que o escritorio ja usa -

    aba CONSOLIDACAO
        A1  CONSOLIDACAO DE ESTOQUE POR FILIAL - <competencia>
        A3  CONTA | FILIAL | TOTAL ESTOQUE (R$)
        A4+ uma linha por filial, com a conta contabil do cadastro e a
            formula =SUM('<ABA DA FILIAL>'!H25:H1048576)
        ..  TOTAL CONSOLIDADO = SUM(C4:Cn)
    uma aba por filial, com o inventario inteiro (numeros ja convertidos)

POR QUE FORMULA E NAO O NUMERO PRONTO. O total tambem e calculado aqui (a tela
mostra e confere), mas na planilha o que vai e a FORMULA, igual ao modelo: quem
recebe consegue clicar na celula e ver de onde saiu, e conferir linha a linha na
aba da filial. Um numero cravado obrigaria a confiar no sistema sem poder
verificar.

A FAIXA DA FORMULA NAO E FIXA. Comeca na primeira linha de dados DAQUELE
relatorio (o cabecalho anda conforme os filtros escolhidos na emissao) e vai
ate o fim da planilha, para servir a qualquer mes sem ajuste.
"""
import parsers
import xlsxescreve
from xlsxescreve import Aba, Formula

ABA_CONSOLIDACAO = "CONSOLIDAÇÃO"
TITULO = "CONSOLIDAÇÃO DE ESTOQUE POR FILIAL"
CABECALHO = ["CONTA", "FILIAL", "TOTAL ESTOQUE (R$)"]
ROTULO_TOTAL = "TOTAL CONSOLIDADO"
ULTIMA_LINHA = 1048576   # limite de linhas do Excel


def casar_conta(inventario, filiais_cadastradas):
    """
    Acha o cadastro da filial deste inventario.

    Casa primeiro pelo CODIGO DA EMPRESA (005, 003, ...) e so depois pelo nome:
    o codigo e o que o sistema usa e nao muda, enquanto o nome da filial e
    digitado e vive divergindo ("SANTA ROSA" x "MATRIZ").
    """
    codigo = (inventario.get("codigo_empresa") or "").lstrip("0")
    if codigo:
        for f in filiais_cadastradas:
            cad = str(f.get("codigo_empresa") or "").strip().lstrip("0")
            if cad and cad == codigo:
                return f
    alvo = parsers.norm_txt(inventario.get("filial"))
    for f in filiais_cadastradas:
        if alvo and parsers.norm_txt(f.get("filial")) == alvo:
            return f
    return None


def ordenar(inventarios, filiais_cadastradas):
    """
    Ordem das abas = ordem do cadastro (o usuario manda na sequencia da
    planilha). Filial nao cadastrada vai para o fim, em ordem alfabetica.
    """
    ordem = {}
    for i, f in enumerate(filiais_cadastradas):
        ordem[parsers.norm_txt(f.get("filial"))] = i
        cod = str(f.get("codigo_empresa") or "").strip().lstrip("0")
        if cod:
            ordem["#" + cod] = i

    def chave(inv):
        cod = (inv.get("codigo_empresa") or "").lstrip("0")
        pos = ordem.get("#" + cod)
        if pos is None:
            pos = ordem.get(parsers.norm_txt(inv.get("filial")))
        if pos is None:
            return (1, parsers.norm_txt(inv.get("filial")))
        return (0, pos)

    return sorted(inventarios, key=chave)


def montar(inventarios, filiais_cadastradas, competencia=""):
    """
    Devolve (abas_para_o_xlsx, resumo).

    resumo = {"competencia", "total", "filiais": [...], "sem_conta": [...]}
    """
    inventarios = ordenar(inventarios, filiais_cadastradas or [])
    comp = (competencia or "").strip() or _competencia(inventarios)

    nomes = xlsxescreve.nomes_unicos(
        [ABA_CONSOLIDACAO] + [inv["filial"] for inv in inventarios])
    nome_consolidacao, nomes_filiais = nomes[0], nomes[1:]

    filiais = []
    linhas_consolidacao = []
    for inv, nome_aba in zip(inventarios, nomes_filiais):
        cad = casar_conta(inv, filiais_cadastradas or [])
        conta = (cad or {}).get("conta", "")
        faixa = (f"SUM({xlsxescreve.ref_aba(nome_aba)}!"
                 f"{inv['col_total']}{inv['linha_dados']}:"
                 f"{inv['col_total']}{ULTIMA_LINHA})")
        linhas_consolidacao.append([conta, inv["filial"], Formula(faixa)])
        filiais.append({
            "filial": inv["filial"],
            "aba": nome_aba,
            "conta": conta,
            "cadastrada": cad is not None,
            "codigo_empresa": inv.get("codigo_empresa", ""),
            "arquivo": inv.get("arquivo", ""),
            "competencia": inv.get("competencia", ""),
            "itens": inv.get("itens", 0),
            "itens_com_saldo": inv.get("itens_com_saldo", 0),
            "total": inv.get("total", 0.0),
            "total_bruto": inv.get("total_bruto", inv.get("total", 0.0)),
            "faixa": f"{inv['col_total']}{inv['linha_dados']}:"
                     f"{inv['col_total']}{ULTIMA_LINHA}",
        })

    primeira = 4
    ultima = primeira + len(linhas_consolidacao) - 1
    linhas = [[TITULO + (f" — {comp}" if comp else "")], [], CABECALHO]
    linhas.extend(linhas_consolidacao)
    if linhas_consolidacao:
        linhas.append(["", ROTULO_TOTAL, Formula(f"SUM(C{primeira}:C{ultima})")])

    abas = [Aba(nome_consolidacao, linhas,
                larguras={"A": 10, "B": 26, "C": 20})]
    for inv, nome_aba in zip(inventarios, nomes_filiais):
        abas.append(Aba(nome_aba, inv["linhas"],
                        larguras={"A": 10, "B": 52, "C": 12, "D": 8,
                                  "E": 14, "F": 12, "G": 12, "H": 14}))

    resumo = {
        "competencia": comp,
        "total": round(sum(f["total_bruto"] for f in filiais), 2),
        "filiais": filiais,
        "sem_conta": [f["filial"] for f in filiais if not f["conta"]],
    }
    return abas, resumo


def _competencia(inventarios):
    """Competencia mais frequente entre os inventarios lidos."""
    contagem = {}
    for inv in inventarios:
        c = (inv.get("competencia") or "").strip()
        if c:
            contagem[c] = contagem.get(c, 0) + 1
    if not contagem:
        return ""
    return max(contagem.items(), key=lambda kv: kv[1])[0]


def divergencia_de_competencia(inventarios):
    """Competencias diferentes na mesma pilha (inventario de outro mes junto)."""
    achadas = sorted({(i.get("competencia") or "").strip()
                      for i in inventarios if (i.get("competencia") or "").strip()})
    return achadas if len(achadas) > 1 else []


def escrever(caminho_ou_buffer, abas):
    xlsxescreve.escrever(caminho_ou_buffer, abas)


def nome_arquivo(competencia=""):
    comp = (competencia or "").strip().replace("/", "-")
    if comp:
        return f"CONTABILIZACAO ESTOQUE {comp}.xlsx"
    return "CONTABILIZACAO ESTOQUE.xlsx"
