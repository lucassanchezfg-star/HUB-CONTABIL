# -*- coding: utf-8 -*-
"""
core_auditoria_extrato.py - Confronta os EXTRATOS BANCARIOS (contas
correntes) e as APLICACOES (investimentos automaticos) com o BALANCETE.

DOIS GRUPOS, cada um com o seu total de conferencia:
  CORRENTE   - grupo "DEPOSITOS BANCARIOS A VISTA" do balancete
  APLICACAO  - grupo "APLICACOES DE LIQUIDEZ IMEDIATA" do balancete
(achados por PALAVRA-CHAVE na descricao - nunca por classificacao fixa, que
muda de empresa para empresa; ver parsers_balancete.buscar/folhas).

CASAMENTO EXTRATO <-> CONTA DO BALANCETE: por NOME DO BANCO e, quando o
mesmo banco tem mais de uma conta (visto no Banco do Brasil: a conta normal
e a conta com varredura automatica "Rende Facil" ficam em contas SEPARADAS
no balancete), pelos DIGITOS do numero da conta - o mesmo metodo que
core_extrato.achar_banco ja usa para casar extrato com a Regra cadastrada.

TOLERANCIA: 0,10 - cobre so arredondamento/instante de consulta (contas com
varredura automatica tipo Bradesco Invest Facil fecham a poucos centavos do
balancete pelo MOTIVO explicado em parsers_extrato_saldo._bradesco, nao por
erro de lancamento). Diferenca REAL de valores e sempre maior que isso.
"""
import re

import parsers_balancete as bal
import xlsxescreve
from xlsxescreve import Aba, Cabecalho, Dinheiro, Negrito, Titulo

TOLERANCIA = 0.10

PALAVRAS_BANCO = {
    "ITAU": ("ITAU",),
    "SANTANDER": ("SANTANDER",),
    "BRADESCO": ("BRADESCO",),
    "SICREDI": ("SICREDI",),
    "CAIXA ECONOMICA FEDERAL": ("CAIXA ECON",),
    "BANCO DO BRASIL": ("BANCO DO BRASIL", "BCO DO BRASIL", "BCO BRASIL"),
}

# O grupo e achado por PALAVRA-CHAVE porque o nome muda de plano de contas
# para plano de contas: a Coimbra chama "DEPOSITOS BANCARIOS A VISTA" e a
# HAC chama "BANCOS - CONTAS CORRENTES". Cada entrada de "alternativas" e um
# par (palavras_obrigatorias_1, palavras_obrigatorias_2) - basta UM par casar.
GRUPOS = {
    "corrente": {"rotulo": "Extrato Bancario (contas correntes)",
                "alternativas": [(["DEPOSITOS BANCARIOS"], ["VISTA"]),
                                 (["BANCOS"], ["CONTAS CORRENTES", "CONTA CORRENTE"])]},
    "aplicacao": {"rotulo": "Aplicacao (liquidez imediata)",
                 "alternativas": [(["APLICACOES"], ["LIQUIDEZ"]),
                                  (["APLICACOES"], ["FINANCEIRAS"])]},
}


def _grupo_balancete(contas, alternativas):
    """
    (conta_do_grupo_ou_None, [contas_folha_dentro_do_grupo]).
    Tenta cada par (contem, contem2) de "alternativas" na ordem e para na
    primeira que achar - assim um plano de contas com outro nome para o
    mesmo grupo nao derruba a conferencia inteira.
    """
    candidatos = []
    for contem, contem2 in alternativas:
        achados = bal.buscar(contas, contem=contem)
        achados = [c for c in achados
                   if any(bal.norm_txt(p) in bal.norm_txt(c["descricao"]) for p in contem2)]
        if achados:
            candidatos = achados
            break
    if not candidatos:
        return None, []
    grupo = min(candidatos, key=lambda c: len(c["classificacao"]))
    prefixo = grupo["classificacao"] + "."
    filhas = [c for c in contas if c["classificacao"].startswith(prefixo)]
    return grupo, bal.folhas(filhas)


def _digitos(s):
    return "".join(ch for ch in str(s or "") if ch.isdigit()).lstrip("0")


# Palavras que aparecem em quase toda descricao de conta bancaria e por isso
# nao ajudam a distinguir uma filial da outra.
RUIDO_DESCRICAO = {"BANCO", "S", "A", "SA", "LTDA", "CONTA", "CORRENTE",
                   "APLICACAO", "APLICACOES", "FILIAL", "DE", "DA", "DO"}


def _tokens_filial(descricao, palavras_banco):
    """O que sobra da descricao depois de tirar o nome do banco e o ruido -
    normalmente o nome da filial ("ENSEADA", "STO ANTONIO", "MATRIZ")."""
    texto = bal.norm_txt(descricao)
    for p in palavras_banco:
        texto = texto.replace(bal.norm_txt(p), " ")
    brutos = re.split(r"[^A-Z0-9]+", texto)
    return {t for t in brutos if len(t) >= 3 and t not in RUIDO_DESCRICAO
            and not t.isdigit()}


def _do_cadastro(extrato, contas_disponiveis, cadastro):
    """
    Conta apontada A MAO no cadastro de bancos (tela Regra): numero da conta
    bancaria -> conta contabil. E o criterio de MAIOR prioridade, porque e o
    unico em que o escritorio disse explicitamente qual conta e qual - todo o
    resto e deducao a partir do texto da descricao.

    A REGRA DA APLICACAO/RESGATE mora aqui: a mesma conta bancaria tem DUAS
    contas contabeis (a corrente e a da aplicacao automatica, para onde o
    banco varre o saldo). O cadastro guarda as duas, e o extrato ja vem
    marcado com o tipo, entao a escolha e direta em vez de adivinhada pelo
    nome da filial.

    Devolve (conta, aviso). 'aviso' so aparece quando o cadastro aponta para
    uma conta que nao existe no balancete (numero digitado errado, conta que
    mudou) - situacao que precisa ser dita, nao engolida.
    """
    if not cadastro:
        return None, None
    alvo = _digitos(extrato["conta"])
    if not alvo:
        return None, None
    campo = "conta_aplicacao" if extrato["tipo"] == "aplicacao" else "conta_contabil"
    for b in cadastro:
        if _digitos(b.get("conta")) != alvo:
            continue
        cod = str(b.get(campo) or "").strip()
        if not cod:
            continue
        achadas = [c for c in contas_disponiveis
                   if cod in (c["codigo"], c["classificacao"])
                   or _digitos(c["codigo"]) == _digitos(cod)]
        if len(achadas) == 1:
            return achadas[0], None
        rotulo = "aplicacao" if campo == "conta_aplicacao" else "conta corrente"
        return None, ("O cadastro de bancos manda usar a conta %s como %s do "
                      "%s %s, mas nao achei essa conta livre neste bloco do "
                      "balancete — confira o numero em Regra." %
                      (cod, rotulo, b.get("banco") or "banco",
                       b.get("conta") or alvo))
    return None, None


def _casar(extrato, contas_disponiveis, pistas=None, cadastro=None, avisos=None):
    """
    Acha a conta do balancete deste extrato.

    Ordem: CADASTRO de bancos -> nome do banco -> digitos do numero da conta
    -> nome da filial.

    O ULTIMO CRITERIO EXISTE POR CAUSA DAS APLICACOES: no plano da HAC a
    conta CORRENTE traz o numero ("BANCO ITAU S/A - ENSEADA (21410-0)"),
    mas a de APLICACAO so traz a filial ("BANCO ITAU S/A - FILIAL ENSEADA").
    Com quatro contas do mesmo banco, o numero nao desempata e sem isso as
    quatro aplicacoes ficariam sem conta. A pista vem da conta corrente JA
    casada pelo numero - mesma conta bancaria, mesma filial.
    """
    escolhida, aviso = _do_cadastro(extrato, contas_disponiveis, cadastro)
    if escolhida is not None:
        return escolhida
    if aviso and avisos is not None:
        avisos.append(aviso)

    palavras = PALAVRAS_BANCO.get(extrato["banco"], (extrato["banco"],))
    candidatas = [c for c in contas_disponiveis
                 if any(bal.norm_txt(p) in bal.norm_txt(c["descricao"]) for p in palavras)]
    if len(candidatas) <= 1:
        return candidatas[0] if candidatas else None

    alvo = _digitos(extrato["conta"])
    if alvo:
        por_digito = [c for c in candidatas if alvo in _digitos(c["descricao"])]
        if len(por_digito) == 1:
            return por_digito[0]

    pista = (pistas or {}).get((extrato["banco"], alvo))
    if pista:
        por_nome = [c for c in candidatas
                    if _tokens_filial(c["descricao"], palavras) & pista]
        if len(por_nome) == 1:
            return por_nome[0]
    return None   # ambiguo - melhor nao adivinhar (ver avisos)


def conciliar(extratos, balancete, cadastro=None):
    """
    extratos: lista de registros de parsers_extrato_saldo.ler_extrato
             (varios arquivos ja concatenados numa lista so).
    balancete: devolvido por parsers_balancete.ler_balancete.
    cadastro: cfg["bancos"] - o de-para conta bancaria -> conta contabil
             (corrente e aplicacao). Opcional: sem ele o motor continua
             deduzindo pelo texto, como antes.

    Devolve {"grupos": {"corrente": {...}, "aplicacao": {...}}, "avisos": [...]}
    Cada grupo: {"rotulo", "balancete_total", "extrato_total", "diferenca",
                 "status", "linhas": [...]}
    Cada linha: {"banco", "conta_extrato", "arquivo", "balancete_classificacao",
                 "balancete_descricao", "balancete_saldo", "extrato_saldo",
                 "diferenca", "status", "modo"}
    """
    avisos = []
    saida = {}
    # (banco, digitos_da_conta) -> tokens do nome da filial, aprendidos da
    # conta CORRENTE (que traz o numero) e usados para casar a APLICACAO
    # da mesma conta (que so traz o nome). Ver _casar.
    pistas = {}

    for tipo, info in GRUPOS.items():
        grupo_conta, folhas = _grupo_balancete(
            balancete["contas"], info["alternativas"])
        itens = [e for e in extratos if e["tipo"] == tipo]

        if grupo_conta is None:
            procurado = " ou ".join(" + ".join(a + b) for a, b in info["alternativas"])
            avisos.append(f"Nao achei no balancete o grupo '{info['rotulo']}' "
                          f"(procurei por {procurado} na descricao) — sem como "
                          f"conferir este bloco.")
            saida[tipo] = {"rotulo": info["rotulo"], "balancete_total": None,
                          "extrato_total": round(sum(e["saldo_final"] for e in itens), 2),
                          "diferenca": None, "status": "sem_grupo", "linhas": []}
            continue

        usadas = set()
        linhas = []
        for e in itens:
            disponiveis = [c for c in folhas if id(c) not in usadas]
            conta_bal = _casar(e, disponiveis, pistas, cadastro, avisos)
            if conta_bal is None:
                avisos.append(f"[{info['rotulo']}] '{e['arquivo']}' ({e['banco']} "
                              f"conta {e['conta'] or '?'}): nao achei (ou achei mais "
                              f"de uma) conta correspondente no balancete. Cadastre "
                              f"esse banco em Regra (coluna 'Conta contabil' para a "
                              f"corrente, 'Conta aplicacao' para a aplicacao) e o "
                              f"casamento passa a ser direto, sem depender do texto "
                              f"da descricao.")
                linhas.append({"banco": e["banco"], "conta_extrato": e["conta"],
                              "arquivo": e["arquivo"], "balancete_classificacao": None,
                              "balancete_descricao": None, "balancete_saldo": None,
                              "extrato_saldo": e["saldo_final"], "diferenca": None,
                              "status": "sem_conta_balancete", "modo": e.get("modo", "")})
                continue
            usadas.add(id(conta_bal))
            if tipo == "corrente":
                chave = (e["banco"], _digitos(e["conta"]))
                pistas[chave] = _tokens_filial(
                    conta_bal["descricao"],
                    PALAVRAS_BANCO.get(e["banco"], (e["banco"],)))
            dif = round(e["saldo_final"] - conta_bal["saldo_atual"], 2)
            status = "bate" if abs(dif) <= TOLERANCIA else "nao_bate"
            linhas.append({"banco": e["banco"], "conta_extrato": e["conta"],
                          "arquivo": e["arquivo"],
                          "balancete_classificacao": conta_bal["classificacao"],
                          "balancete_descricao": conta_bal["descricao"],
                          "balancete_saldo": conta_bal["saldo_atual"],
                          "extrato_saldo": e["saldo_final"], "diferenca": dif,
                          "status": status, "modo": e.get("modo", "")})

        pendentes = [c for c in folhas if id(c) not in usadas]
        for c in pendentes:
            if abs(c["saldo_atual"]) <= TOLERANCIA:
                continue   # conta zerada sem extrato enviado nao e pendencia
            avisos.append(f"[{info['rotulo']}] O balancete tem "
                          f"'{c['descricao']}' (conta {c['classificacao']}) com "
                          f"saldo de {c['saldo_atual']:.2f} mas nenhum extrato "
                          f"correspondente foi enviado.")
            linhas.append({"banco": c["descricao"], "conta_extrato": None,
                          "arquivo": None, "balancete_classificacao": c["classificacao"],
                          "balancete_descricao": c["descricao"],
                          "balancete_saldo": c["saldo_atual"], "extrato_saldo": None,
                          "diferenca": None, "status": "sem_extrato", "modo": ""})

        extrato_total = round(sum(e["saldo_final"] for e in itens), 2)
        dif_total = round(extrato_total - grupo_conta["saldo_atual"], 2)
        saida[tipo] = {
            "rotulo": info["rotulo"],
            "balancete_total": grupo_conta["saldo_atual"],
            "balancete_classificacao": grupo_conta["classificacao"],
            "extrato_total": extrato_total,
            "diferenca": dif_total,
            "status": "bate" if abs(dif_total) <= TOLERANCIA * len(folhas or [1])
                      else "nao_bate",
            "linhas": linhas,
        }

    return {"grupos": saida, "avisos": avisos}


ROTULO_STATUS = {"bate": "BATE", "nao_bate": "NAO BATE",
                 "sem_conta_balancete": "SEM CONTA NO BALANCETE",
                 "sem_extrato": "SEM EXTRATO ENVIADO"}


def montar_planilha(resultado, balancete):
    """Planilha com o consolidado (1 linha por grupo) e o detalhe por banco."""
    empresa = balancete.get("empresa") or ""
    linhas = [[Titulo(f"AUDITORIA DE EXTRATO BANCARIO — {empresa}")]]
    if balancete.get("periodo"):
        linhas.append([Negrito(f"Periodo: {balancete['periodo']}")])
    linhas.append([])

    linhas.append([Cabecalho("Consolidado")])
    linhas.append([Cabecalho("Grupo"), Cabecalho("Extratos"), Cabecalho("Balancete"),
                   Cabecalho("Diferenca"), Cabecalho("Situacao")])
    for g in resultado["grupos"].values():
        linhas.append([
            g["rotulo"],
            Dinheiro(g["extrato_total"]),
            Dinheiro(g["balancete_total"]) if g["balancete_total"] is not None else "-",
            Dinheiro(g["diferenca"]) if g["diferenca"] is not None else "-",
            ROTULO_STATUS.get(g["status"], g["status"]),
        ])
    linhas.append([])

    for g in resultado["grupos"].values():
        linhas.append([Cabecalho(g["rotulo"])])
        linhas.append([Cabecalho("Banco"), Cabecalho("Conta"), Cabecalho("Arquivo"),
                       Cabecalho("Extrato"), Cabecalho("Balancete"),
                       Cabecalho("Diferenca"), Cabecalho("Situacao"),
                       Cabecalho("Conta no balancete")])
        for l in g["linhas"]:
            linhas.append([
                l["banco"] or "-",
                l["conta_extrato"] or "-",
                l["arquivo"] or "-",
                Dinheiro(l["extrato_saldo"]) if l["extrato_saldo"] is not None else "-",
                Dinheiro(l["balancete_saldo"]) if l["balancete_saldo"] is not None else "-",
                Dinheiro(l["diferenca"]) if l["diferenca"] is not None else "-",
                ROTULO_STATUS.get(l["status"], l["status"]),
                (f"{l['balancete_classificacao']} {l['balancete_descricao']}"
                 if l["balancete_classificacao"] else "-"),
            ])
        linhas.append([])

    if resultado["avisos"]:
        linhas.append([Negrito("Avisos")])
        for a in resultado["avisos"]:
            linhas.append([a])

    aba = Aba("AUDITORIA EXTRATO", linhas,
             larguras={"A": 26, "B": 16, "C": 30, "D": 16, "E": 16, "F": 14,
                       "G": 22, "H": 40})
    return [aba]


def planilha_bytes(resultado, balancete):
    import io
    buf = io.BytesIO()
    xlsxescreve.escrever(buf, montar_planilha(resultado, balancete))
    return buf.getvalue()


def nome_arquivo(empresa, periodo):
    partes = ["AUDITORIA EXTRATO"]
    if empresa:
        partes.append(empresa)
    if periodo:
        partes.append(str(periodo).replace("/", "-"))
    return " ".join(partes) + ".xlsx"
