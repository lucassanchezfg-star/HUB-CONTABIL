# -*- coding: utf-8 -*-
"""
parsers_acumulador.py - Le o relatorio "Resumo por Acumulador" (fiscal, um
.xls antigo por filial/empresa, exportado direto do sistema fiscal) usando
xls_lite (stdlib puro, sem xlrd).

FILIAL: identificada pelo NOME do arquivo (ex.: "Empresa 509 - COIMBRA.xls"
-> "509") - e o proprio sistema fiscal que nomeia assim o arquivo exportado,
nao e uma convencao nossa. Por isso, ao contrario do resto do app, aqui o
nome do arquivo E relevante (nao so o conteudo).

Layout das linhas (depois de tirar as celulas vazias '' que sobram de
merge de celulas do Excel): codigo, descricao, e 8 colunas numericas fixas
(nesta ordem): valor_contabil, base_icms, valor_icms, isentas_icms,
outras_icms, valor_ipi, bc_icms_st, valor_icms_st.
"""
import re

import xls_lite

NOME_ARQUIVO_RE = re.compile(r"Empresa\s+(\d+)", re.IGNORECASE)

COLUNAS = ("valor_contabil", "base_icms", "valor_icms", "isentas_icms",
          "outras_icms", "valor_ipi", "bc_icms_st", "valor_icms_st")


def identificar_filial(nome_arquivo):
    """'Empresa 509 - COIMBRA.xls' -> '509'. None se nao achar o padrao."""
    m = NOME_ARQUIVO_RE.search(nome_arquivo or "")
    return m.group(1) if m else None


def detectar(caminho):
    """Confirma que e um .xls (OLE2) do 'Resumo por Acumulador', pelo
    CONTEUDO (titulo do relatorio), sem depender do nome do arquivo."""
    try:
        linhas = xls_lite.read_sheet(caminho)
    except Exception:  # noqa: BLE001
        return False
    texto = " ".join(str(v) for l in linhas[:10] for v in l if v != "").upper()
    return "RESUMO POR ACUMULADOR" in texto


def ler_itens(caminho):
    """
    So o CONTEUDO do relatorio (sem exigir/usar o nome do arquivo) - usado
    quando a filial ja e' conhecida por outro caminho (ex.: o arquivo esta
    salvo em disco como "<filial>/1.xls", a pasta ja diz qual e' a filial).
    Devolve {"itens": [{"codigo","descricao","secao", **8 colunas}],
    "total_entradas": valor_contabil somado, "total_saidas": idem}.
    Lanca ValueError se o arquivo nao parecer um Resumo por Acumulador.

    Os totais sao SOMADOS a partir dos itens lidos, nunca copiados da(s)
    linha(s) "Total:" do proprio relatorio: alem do bloco principal de
    ENTRADAS/SAIDAS (colunas de ICMS/IPI), o relatorio pode trazer um
    sub-bloco extra "SERVICOS" (colunas de ISS) dentro da MESMA secao,
    com o seu PROPRIO "Total:" - se esse "Total:" sobrescrever o do bloco
    principal, o total sai errado (visto no Resumo da matriz da Coimbra,
    07/2026: "Total:" de SAIDAS = 1.130.731,03, mas o "Total:" seguinte,
    ja do sub-bloco SERVICOS, sobrescrevia para 2.263,58). Somar os itens
    e' imune a quantos sub-blocos/paginas existirem.
    """
    linhas = xls_lite.read_sheet(caminho)
    secao_atual = None
    itens = []
    achou_titulo = False
    for linha in linhas:
        valores = [v for v in linha if v != ""]
        if not valores:
            continue
        primeiro = valores[0]
        if isinstance(primeiro, str) and "RESUMO POR ACUMULADOR" in primeiro.upper():
            achou_titulo = True
            continue
        if primeiro == "ENTRADAS":
            secao_atual = "entradas"
            continue
        if primeiro in ("SAÍDAS", "SAIDAS"):
            secao_atual = "saidas"
            continue
        if not secao_atual or primeiro in ("Código", "Cód", "Total:"):
            continue
        if isinstance(primeiro, (int, float)) and len(valores) >= 10:
            itens.append({
                "codigo": str(int(primeiro)),
                "descricao": str(valores[1]).strip(),
                "secao": secao_atual,
                **dict(zip(COLUNAS, valores[2:10])),
            })

    if not achou_titulo and not itens:
        raise ValueError("Nao parece ser um Resumo por Acumulador (.xls).")

    total_entradas = round(sum(i["valor_contabil"] for i in itens if i["secao"] == "entradas"), 2)
    total_saidas = round(sum(i["valor_contabil"] for i in itens if i["secao"] == "saidas"), 2)
    return {"itens": itens, "total_entradas": total_entradas, "total_saidas": total_saidas}


def ler_resumo_acumulador(caminho, nome_original=""):
    """
    Ponto de entrada usado no UPLOAD (a filial ainda precisa ser
    identificada pelo NOME do arquivo original). Devolve {"arquivo",
    "filial", **ler_itens(caminho)}. Lanca ValueError se a filial nao puder
    ser identificada pelo nome, ou se o conteudo nao for reconhecido (ver
    ler_itens).
    """
    nome = nome_original or caminho
    filial = identificar_filial(nome)
    if not filial:
        raise ValueError(
            f"Nao consegui identificar a filial pelo nome do arquivo "
            f"'{nome}' (precisa ter \"Empresa <codigo>\" no nome).")
    dados = ler_itens(caminho)
    return {"arquivo": nome, "filial": filial, **dados}
