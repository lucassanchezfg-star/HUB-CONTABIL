# -*- coding: utf-8 -*-
"""
core_extrato.py - Regras contabeis do extrato bancario + geracao do CSV.

REGRA CONTABIL (o banco e conta do ATIVO)
-----------------------------------------
  ENTRADA (dinheiro entrou / valor > 0):
      Debito  = conta do BANCO
      Credito = contrapartida do de-para; se nao identificar -> conta de CLIENTES
      Historico: "RECEBIMENTO <NOME> <dd/mm/aaaa>"

  SAIDA (dinheiro saiu / valor < 0):
      Debito  = contrapartida do de-para (fornecedor/despesa);
                se nao identificar -> conta de PENDENCIA (RECLASSIFICAR)
      Credito = conta do BANCO
      Historico: "PAGAMENTO <NOME> <dd/mm/aaaa>"

Historico sempre em MAIUSCULO (sem acento, igual ao modulo de cartao).
O CSV usa exatamente o mesmo layout do cartao (perfil padrao):
    Data;Debito;Credito;Valor;;Historico   (coluna E vazia, BOM UTF-8)

A conta do banco vem do modulo REGRA (cadastro de bancos, casado por
agencia+conta). As contrapartidas vem do modulo DE-PARA.
"""
import re

from store import codigo_conta
from parsers import norm_txt
import core_cartao

# Prefixos genericos do extrato que nao identificam a contraparte.
# Usados so quando NAO houve casamento no de-para, para limpar o nome.
PREFIXOS_GENERICOS = (
    "PAGAMENTO DE BOLETO OUTROS BANCOS",
    "PAGAMENTO DE BOLETO",
    "PAGAMENTO CARTAO DE DEBITO",
    "PAGAMENTO DARF EM CANAIS",
    "PGTO TRIBUTO ESTADUAL EM CANAIS",
    "PAGAMENTO TRIBUTO ESTADUAL EM CANAIS",
    "DEBITO PAGAMENTO DE SALARIO",
    "PIX RECEBIDO",
    "PIX ENVIADO",
    "TED RECEBIDA",
    "TED ENVIADA",
    "DOC RECEBIDO",
    "DEP DINHEIRO CAIXA AG",
    "CR COB BLOQ COMP CONF RECEBIMENTO",
    "DEBITO AUT.",
    "DEBITO AUT",
)


# --------------------------------------------------------------------------
# DE-PARA
# --------------------------------------------------------------------------
def casar_depara(historico, depara):
    """
    Procura no historico do extrato um dos padroes cadastrados no de-para.
    Comparacao em MAIUSCULO SEM ACENTO, por 'contem'.
    Os padroes mais LONGOS sao testados primeiro, para que um padrao curto
    ('DECO') nao roube o casamento de um mais especifico ('DECOPLAST').
    Retorna o item do de-para ou None.
    """
    alvo = norm_txt(historico)
    candidatos = [d for d in depara if (d.get("padrao") or "").strip()]
    candidatos.sort(key=lambda d: len(norm_txt(d["padrao"])), reverse=True)
    for d in candidatos:
        if norm_txt(d["padrao"]) in alvo:
            return d
    return None


def raiz_cnpj(cnpj):
    """Os 8 primeiros digitos - o que identifica a EMPRESA, nao a filial."""
    d = re.sub(r"\D", "", str(cnpj or ""))
    return d[:8] if len(d) >= 8 else ""


def e_mesma_titularidade(historico, raiz):
    """
    O lancamento e' entre contas da PROPRIA empresa?

    O criterio e' o CNPJ RAIZ no historico, nao o nome. O extrato corta o nome
    da empresa ("...RECEBIMENTOS ML I"), mas o CNPJ vem inteiro e traz a filial
    junto (43.408.981/0002-02) - a raiz 43408981 cobre matriz e filiais de uma
    vez, que e' exatamente o que "mesma titularidade" quer dizer.
    """
    if not raiz:
        return False
    return raiz in re.sub(r"\D", "", str(historico or ""))


MIN_PREFIXO_PLANO = 10   # letras minimas do nome da conta para valer o teste
MIN_SEGUNDA_PALAVRA = 4  # letras que o casamento tem de avancar na 2a palavra
MIN_ATE_A_BORDA = 16     # tamanho para aceitar casamento que para numa palavra


def _casamento_convence(chave, corte):
    """
    O pedaco casado do nome da conta e evidencia SUFICIENTE, ou coincidencia?

    Dez letras batendo nao provam nada: no extrato da PRECITO, 566
    lancamentos de um mes so estavam caindo em conta ERRADA por coincidencia
    do comeco do nome -

        "RENY GONCALVES DA SIL"   caia em GONCALVES COMERCIO E SERVICOS...
        "LUIZ HENRIQUE DE CASS"   caia em HENRIQUE DE ALMEIDA ALVES
        "BDL MARKET COMERCIO DE"  caia em COMERCIO DE ACOS JACINOX
        "ANA PAULA MAGALHAES"     caia em ANA PAULA DA SILVA RODRIGUES

    Sao tres exigencias, e todas tem de passar:

    1. PASSAR DA PRIMEIRA PALAVRA. Nome de empresa que comeca por descritor
       ("DISTRIBUIDORA...", "SEGUROS...", "SUPERMERCADO...") se identifica
       pelo que vem DEPOIS; casar so o descritor e casar o ramo, nao a
       empresa.
    2. NAO PARAR NUMA PALAVRA INTEIRA - a nao ser que o pedaco ja seja
       grande (MIN_ATE_A_BORDA) ou o nome INTEIRO da conta. Quando o extrato
       corta o nome, ele corta no meio de uma palavra ("JB QUALITY G",
       "LAVORO LOCADORA E T", "W C DA SILVA CRUZ S") - esse corte no meio e
       justamente o sinal de que a leitura veio do mesmo nome. Ja duas
       pessoas diferentes divergem no COMECO de uma palavra nova
       ("ANA PAULA |DA SILVA" x "ANA PAULA |MAGALHAES").
    3. O nome inteiro sempre vale: aparecendo por completo na descricao
       ("AGUA E ESGOTO"), nao ha o que duvidar.
    """
    n = len(chave)
    if corte >= n:
        return True                       # o nome inteiro apareceu

    pedaco = chave[:corte]
    if " " not in pedaco.strip():
        return False                      # casou uma palavra so
    resto = pedaco.strip().split(" ", 1)[1]
    if len(resto.replace(" ", "")) < MIN_SEGUNDA_PALAVRA:
        return False                      # mal encostou na segunda palavra

    parou_no_meio_da_palavra = (chave[corte - 1] != " " and chave[corte] != " ")
    return parou_no_meio_da_palavra or corte >= MIN_ATE_A_BORDA


def _casar_plano(descricao, candidatas):
    """
    Acha no PLANO DE CONTAS a conta cujo nome aparece na descricao do extrato.

    O extrato CORTA o nome do favorecido ("PAGAMENTO DE BOLETO OUTROS BANCOS
    JB QUALITY G 24.538.403/0001-57"), entao nao adianta procurar o nome da
    conta inteiro no texto. O teste e ao contrario: o COMECO do nome da conta
    ("JB QUALITY G...") aparece na descricao? Ganha o nome mais longo que
    casar, e so vale se for UNICO nesse tamanho - dois candidatos empatados
    seria chute.

    Sem isso, um pagamento para a JB Quality caia em "fornecedores diversos"
    ou na conta de reclassificar mesmo existindo a conta 731 dela no plano.

    A DESCRICAO E NORMALIZADA DO MESMO JEITO QUE O NOME DA CONTA (sem
    pontuacao, so letra/numero/espaco) - "chave" ja vem assim de
    core_sispag._chave_nome (contas_do_plano usa ela). Contas com hifen ou
    barra no nome ("LAVORO - LOCADORA E TRANSPORTADORA EIREL") tem esse
    caractere virando espaco na chave; comparar contra o texto CRU do
    extrato ("...DES: LAVORO - LOCADORA E T 27/08", hifen preservado) nunca
    fechava - "LAVORO LOCADORA" (chave, um espaco) nao e' "LAVORO -
    LOCADORA" (extrato, espaco-hifen-espaco) - e o pagamento caia sempre em
    reclassificar mesmo com a conta certa cadastrada no plano.
    """
    import core_sispag
    alvo = core_sispag._norm(descricao)
    if len(alvo) < MIN_PREFIXO_PLANO:
        return None
    achados = []
    for c in candidatas:
        chave = c["chave"]
        n = len(chave)
        if n < MIN_PREFIXO_PLANO:
            continue
        # do nome inteiro ate o prefixo minimo: o maior pedaco que couber
        for corte in range(n, MIN_PREFIXO_PLANO - 1, -1):
            if chave[:corte] in alvo and _casamento_convence(chave, corte):
                achados.append((corte, c))
                break
    if not achados:
        return None
    melhor = max(a[0] for a in achados)
    finalistas = [c for tam, c in achados if tam == melhor]
    return finalistas[0] if len(finalistas) == 1 else None


def contas_do_plano(cfg, fora=()):
    """Contas ANALITICAS que podem ser contrapartida, ja com a chave de busca."""
    import core_sispag
    return core_sispag.contas_candidatas(cfg.get("plano_contas"), fora=fora)


def _nome_contraparte(historico, item, contas_balde=()):
    """
    Nome que entra no historico do lancamento.
      - com casamento no de-para -> o NOME cadastrado (nome da conta contabil)
      - sem casamento -> a descricao do extrato, sem os prefixos genericos

    EXCECAO - CONTAS "BALDE" (reclassificar / pendencia / a classificar): o
    nome da conta nao diz NADA sobre quem foi. Um lancamento saindo
    "PAGAMENTO LANCAMENTOS A CLASSIFICAR" obriga a voltar no extrato para
    descobrir de quem era. Nessas contas o historico fica com a descricao do
    EXTRATO, que traz o nome da pessoa - a conta ja diz que e para
    reclassificar, o historico nao precisa repetir.
    """
    if item and (item.get("nome") or "").strip():
        conta = str(item.get("conta") or "").strip()
        if conta not in contas_balde:
            return item["nome"].strip()

    t = norm_txt(historico)
    for pref in sorted(PREFIXOS_GENERICOS, key=len, reverse=True):
        if t.startswith(pref):
            t = t[len(pref):].strip(" .:-")
            break
    t = re.sub(r"\s+", " ", t).strip(" .:-")
    if len(t) < 3:
        return norm_txt(historico)
    return t


# --------------------------------------------------------------------------
# Banco (modulo REGRA)
# --------------------------------------------------------------------------
def _so_digitos(s):
    return re.sub(r"\D", "", str(s or ""))


def achar_banco(cfg, banco, agencia, conta):
    """
    Casa o extrato com um banco cadastrado na REGRA.
    Compara so os digitos da conta (ignora ponto/hifen e zeros a esquerda).
    Retorna o item de banco ou None.
    """
    alvo_conta = _so_digitos(conta).lstrip("0")
    alvo_ag = _so_digitos(agencia).lstrip("0")
    for b in cfg.get("bancos") or []:
        if _so_digitos(b.get("conta")).lstrip("0") != alvo_conta:
            continue
        ag_cad = _so_digitos(b.get("agencia")).lstrip("0")
        if ag_cad and alvo_ag and ag_cad != alvo_ag:
            continue
        return b

    # POR SUFIXO: o OFX manda a conta de jeitos diferentes conforme o banco -
    # o Bradesco so o numero sem digito ("1428"), o Itau e o Safra a AGENCIA
    # E A CONTA COLADAS ("0288466550", "01455825899"). Sem esta passada, uma
    # conta cadastrada certa nao seria achada e o CSV sairia sem a conta do
    # banco.
    mesmo_banco = [b for b in (cfg.get("bancos") or [])
                   if not banco or norm_txt(b.get("banco")) == norm_txt(banco)]
    for tirar_digito in (False, True):
        achados = []
        for b in mesmo_banco:
            c = _so_digitos(b.get("conta")).lstrip("0")
            if tirar_digito:
                c = c[:-1]
            if len(c) >= 4 and (alvo_conta.endswith(c) or c.endswith(alvo_conta)):
                achados.append(b)
        # dois candidatos empatados seria chute: melhor nao casar e avisar
        if len(achados) == 1:
            return achados[0]

    # fallback: mesmo banco cadastrado, conta unica
    return mesmo_banco[0] if len(mesmo_banco) == 1 else None


# --------------------------------------------------------------------------
# Motor
# --------------------------------------------------------------------------
def gerar_lancamentos(extrato, cfg, banco_cad):
    """
    extrato: saida de parsers_extrato.parse_extrato
    cfg: cadastro da empresa
    banco_cad: item de banco da REGRA (define a conta contabil do banco)

    Retorna (lancamentos, nao_identificados).
    Um lancamento por linha do extrato (nao agrupa por dia: cada linha tem
    a sua propria contraparte).
    """
    modo = cfg.get("modo_codigo", "reduzido")
    contas = cfg["contas"]
    depara = cfg.get("depara") or []

    cod_banco = (banco_cad or {}).get("conta_contabil", "")
    cod_clientes = codigo_conta(contas.get("clientes") or {}, modo)
    cod_pendencia = codigo_conta(contas.get("pendencia") or {}, modo)
    # contrapartida padrao da SAIDA: campo proprio, caindo na pendencia
    cod_pagamento = codigo_conta(contas.get("extrato_pagamento") or {}, modo)         or cod_pendencia
    cod_transf = codigo_conta(contas.get("transferencia") or {}, modo)
    raiz = raiz_cnpj(cfg.get("cnpj"))
    modelo_hist = cfg.get("historico_extrato", "padrao")
    # contas em que o historico tem de manter o nome de quem foi (ver
    # _nome_contraparte)
    contas_balde = {c for c in (cod_pendencia,) if c}
    candidatas_plano = contas_do_plano(
        cfg, fora=(cod_banco, cod_clientes, cod_pendencia, cod_pagamento, cod_transf))

    lancamentos = []
    nao_identificados = []

    for lan in extrato["lancamentos"]:
        valor = lan["valor"]
        if abs(valor) < 0.005:
            continue
        item = casar_depara(lan["historico"], depara)
        nome = _nome_contraparte(lan["historico"], item, contas_balde)
        conta_contra = (item or {}).get("conta", "")

        # ORDEM: de-para cadastrado (alguem DISSE qual e a conta) ->
        # mesma titularidade -> padrao do sentido.
        # PLANO DE CONTAS: so quando o de-para nao resolveu
        if not conta_contra and candidatas_plano:
            achada = _casar_plano(lan["historico"], candidatas_plano)
            if achada:
                conta_contra = achada["codigo"]
                if not (item and (item.get("nome") or "").strip()):
                    nome = achada["nome"]

        transferencia = False
        if not conta_contra and cod_transf and e_mesma_titularidade(lan["historico"], raiz):
            conta_contra = cod_transf
            transferencia = True
            # mesmo tratamento das regras do de-para: o historico leva o NOME
            # DA CONTA, nao o texto cru do extrato (que vem cortado, tipo
            # "...RECEBIMENTOS ML I")
            nome_transf = (contas.get("transferencia") or {}).get("nome", "").strip()
            if nome_transf:
                nome = nome_transf

        if valor > 0:   # ENTRADA
            # conta propria do RECEBIMENTO, quando a regra tem uma
            conta_ent = (item or {}).get("conta_recebimento", "").strip()
            if conta_ent:
                conta_contra = conta_ent
            if not conta_contra:
                conta_contra = cod_clientes
            debito, credito = cod_banco, conta_contra
            hist = f"RECEBIMENTO {nome}"
        else:           # SAIDA
            if not conta_contra:
                conta_contra = cod_pagamento
            debito, credito = conta_contra, cod_banco
            hist = f"PAGAMENTO {nome}"

        # HISTORICO FIXO da regra tem prioridade sobre o padrao
        # "PAGAMENTO/RECEBIMENTO <nome>": em tarifa, IOF e rendimento o texto
        # do extrato nao diz nada ("TAR/CUSTAS COBRANCA"), e o que o contador
        # quer ler no razao e "VALOR REF. A TARIFA BANCARIA".
        # MODELO "valor_referente": o historico e o TEXTO DO BANCO, prefixado,
        # como o razao desses escritorios ja registra ("VALOR REFERENTE A
        # PAGAMENTO DE BOLETO OUTROS BANCOS JB QUALITY G"). O nome da conta
        # nao entra: quem confere o razao quer ver a descricao original.
        # MODELO "bruto": a descricao do banco e SO ela. E o que o razao da
        # PRECITO ja registra, e o que os arquivos de importacao do mes
        # anterior levaram. Nada e acrescentado - nem prefixo, nem data (a
        # data do PIX ja vem dentro do texto do banco).
        bruto = re.sub(r"\s+", " ", str(lan["historico"] or "")).strip()
        if modelo_hist == "valor_referente":
            hist = "VALOR REFERENTE A " + (bruto or "LANCAMENTO")
        elif modelo_hist == "bruto":
            hist = bruto or "LANCAMENTO"

        hist_fixo = (item or {}).get("historico", "").strip()
        if hist_fixo:
            hist = hist_fixo

        # DATA DO MOVIMENTO no fim do historico: a coluna A do CSV ja traz a
        # data, mas no razao do sistema contabil o que se le e o historico -
        # e com varios lancamentos parecidos no mesmo mes ("RECEBIMENTO
        # CLIENTES DIVERSOS") a data e o que permite achar a linha no extrato.
        # No modelo "bruto" nao: o escritorio que usa esse modelo quer a
        # descricao do banco identica a que ja esta no razao.
        if modelo_hist != "bruto":
            hist = "%s %s" % (hist, lan["data"])

        if item is None and not transferencia:
            nao_identificados.append({
                "data": lan["data"],
                "valor": abs(valor),
                "tipo": "ENTRADA" if valor > 0 else "SAIDA",
                "historico": lan["historico"],
                "conta_usada": conta_contra,
            })

        lancamentos.append({
            "data": lan["data"],
            "debito": debito,
            "credito": credito,
            "valor": round(abs(valor), 2),
            # mesmo tratamento de historico do modulo de cartao (maiusculo,
            # sem acento) -> perfil padrao
            "historico": core_cartao._maiusculo(hist, acentos=False),
            "_operadora": "EXTRATO",   # nao ha perfil proprio -> perfil padrao
            "_ord": 0 if valor > 0 else 1,
        })

    lancamentos.sort(key=lambda l: (core_cartao._data_ordenavel(l["data"]), l["_ord"]))
    return lancamentos, nao_identificados


def montar_csv(lancamentos):
    """CSV no mesmo layout do cartao (com cabecalho, valor 2 casas)."""
    return core_cartao.montar_csv(lancamentos)


def csv_bytes(lancamentos):
    return core_cartao.csv_bytes(lancamentos)


def resumo(extrato, lancamentos, nao_identificados):
    """Resumo para a tela."""
    ent = [l for l in lancamentos if l["_ord"] == 0]
    sai = [l for l in lancamentos if l["_ord"] == 1]
    total_ent = round(sum(l["valor"] for l in ent), 2)
    total_sai = round(sum(l["valor"] for l in sai), 2)
    movimento = round(total_ent - total_sai, 2)

    # SALDOS: so para conferencia na TELA. Nunca entram no CSV.
    s_ant = extrato.get("saldo_anterior")
    s_fim = extrato.get("saldo_final")
    s_calc = round(s_ant + movimento, 2) if s_ant is not None else None
    confere = None
    if s_calc is not None and s_fim is not None:
        confere = abs(s_calc - s_fim) < 0.01

    return {
        "saldo_anterior": s_ant,
        "saldo_final_extrato": s_fim,
        "saldo_final_calculado": s_calc,
        "saldo_confere": confere,
        "banco": extrato["banco"],
        "agencia": extrato["agencia"],
        "conta": extrato["conta"],
        "periodo": list(extrato["periodo"]),
        "lancamentos": len(lancamentos),
        "entradas": len(ent),
        "saidas": len(sai),
        "total_entradas": total_ent,
        "total_saidas": total_sai,
        "movimento": movimento,
        # Entrada sem de-para cai em CLIENTES (e o padrao da regra, normal).
        # SAIDA sem de-para cai na conta de PENDENCIA -> e o que precisa de
        # atencao do contador, por isso e contada separadamente.
        "nao_identificados": len(nao_identificados),
        "pendencia_saidas": sum(1 for n in nao_identificados if n["tipo"] == "SAIDA"),
        "pendencia_valor": round(sum(n["valor"] for n in nao_identificados
                                     if n["tipo"] == "SAIDA"), 2),
        "entradas_sem_depara": sum(1 for n in nao_identificados if n["tipo"] == "ENTRADA"),
    }
