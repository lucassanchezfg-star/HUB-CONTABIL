# -*- coding: utf-8 -*-
"""
core_cartao.py - Regras contabeis do cartao + geracao do CSV.

Recebe as contas do cadastro (store.py) e as vendas ja parseadas (parsers.py).
Nao conhece o formato dos relatorios nem a operadora especifica: so aplica as
regras. As contas nunca sao hardcoded aqui.

Regras (agrupar por DATA DA VENDA, somente vendas APROVADAS - filtro feito no parser):
  Para cada dia, somar bruto e tarifa e gerar 2 lancamentos:
    - VENDA BRUTA: Debito = conta do cartao (operadora)   Credito = Clientes
        historico: "TRANSFERENCIA VENDA CARTAO <OPERADORA> <data>"
    - TARIFA:      Debito = Despesa c/ tarifa bancaria     Credito = conta do cartao
        historico: "TARIFA CARTAO <OPERADORA> <data>"

Layout do CSV (separador ';'):
  A = Data (dd/mm/aaaa)
  B = Debito (codigo da conta)
  C = Credito (codigo da conta)
  D = Valor (virgula decimal, sem separador de milhar)
  E = (VAZIA de proposito)
  F = Historico (MAIUSCULO)
Cabecalho: Data;Debito;Credito;Valor;;Historico
Gravado com BOM UTF-8.
"""
import io
import unicodedata
from collections import defaultdict

from store import codigo_conta

CABECALHO = "Data;Debito;Credito;Valor;;Historico"

CONTA_CARTAO_POR_OPERADORA = {
    "GETNET": "cartao_getnet",
    "REDE": "cartao_rede",
    "CIELO": "cartao_cielo",
    "STONE": "cartao_stone",
}

# --------------------------------------------------------------------------
# Perfis de saida por operadora
# --------------------------------------------------------------------------
# Cada operadora pode ter um "modelo de importacao" proprio: o texto do
# historico, se o CSV leva cabecalho, se mantem acentos e como formata o valor.
# Placeholders do historico: {operadora}, {data} (dd/mm/aaaa), {mesano} (mm/aaaa).
PERFIL_PADRAO = {
    "hist_venda": "TRANSFERENCIA VENDA CARTAO {operadora} {data}",
    "hist_tarifa": "TARIFA CARTAO {operadora} {data}",
    "acentos": False,      # remove acentos do historico
    "cabecalho": True,     # grava a linha "Data;Debito;..."
    "valor": "2dec",       # 1234,50
}

PERFIS = {
    # Modelo usado no STONE_IMPORTAR.csv da VOVO DIANA: sem cabecalho, historico
    # COM acentos e por competencia (mm/aaaa), valor no formato "geral" do Excel
    # (sem zeros a direita: 5582,9 / 2325 / 2).
    "STONE": {
        "hist_venda": "TRANSFERÊNCIA P/ CARTÃO STONE {mesano}",
        "hist_tarifa": "DESCONTOS (MDR/ANTECIPAÇÃO/UNIFICADO) CARTÃO STONE {mesano}",
        "acentos": True,
        "cabecalho": False,
        "valor": "geral",
    },
}


def perfil_de(operadora):
    """Retorna o perfil de saida da operadora (cai no padrao se nao houver)."""
    p = dict(PERFIL_PADRAO)
    p.update(PERFIS.get(operadora, {}))
    return p


def perfil_dos_lancamentos(lancamentos):
    """
    Perfil a usar num CSV: se todos os lancamentos sao da mesma operadora, usa o
    perfil dela; se o CSV mistura operadoras, usa o padrao (com cabecalho).
    """
    ops = {l.get("_operadora") for l in lancamentos}
    if len(ops) == 1:
        return perfil_de(ops.pop())
    return dict(PERFIL_PADRAO)


def _maiusculo(s, acentos=False):
    """
    Historico SEMPRE em maiusculo. Por padrao remove acentos (compatibilidade
    contabil); com acentos=True preserva (ex.: TRANSFERÊNCIA P/ CARTÃO STONE).
    """
    s = str(s)
    if not acentos:
        s = unicodedata.normalize("NFKD", s)
        s = "".join(c for c in s if not unicodedata.combining(c))
    return s.upper()


def fmt_valor(v, estilo="2dec"):
    """
    float -> string com virgula decimal, SEM separador de milhar.
      '2dec'  -> sempre 2 casas: 1234,50
      'geral' -> formato "geral" do Excel, sem zeros a direita: 1234,5 / 2325 / 2
    """
    s = f"{v:.2f}"
    if estilo == "geral":
        s = s.rstrip("0").rstrip(".")
        if s in ("", "-"):
            s = "0"
    return s.replace(".", ",")


def _mesano(data_str):
    """'dd/mm/aaaa' -> 'mm/aaaa' (competencia usada no historico do Stone)."""
    partes = str(data_str).split("/")
    return f"{partes[1]}/{partes[2]}" if len(partes) == 3 else str(data_str)


def _data_ordenavel(data_str):
    """'dd/mm/aaaa' -> 'aaaammdd' para ordenacao cronologica."""
    try:
        d, m, a = data_str.split("/")
        return a + m + d
    except ValueError:
        return data_str


def agrupar_por_dia(vendas):
    """
    Recebe [{data, bruto, tarifa}, ...] e retorna dict:
        { data: {"bruto": soma, "tarifa": soma, "n": qtd} }
    """
    acc = defaultdict(lambda: {"bruto": 0.0, "tarifa": 0.0, "n": 0})
    for v in vendas:
        d = acc[v["data"]]
        d["bruto"] += v["bruto"]
        d["tarifa"] += v["tarifa"]
        d["n"] += 1
    return acc


def gerar_lancamentos(dados_por_operadora, config):
    """
    dados_por_operadora: { "GETNET": [vendas...], "REDE": [vendas...] }
    config: cadastro (store.carregar_config()).

    Retorna lista de lancamentos (dicts) ordenados por data e depois por operadora:
        {data, debito, credito, valor, historico}
    Gera 2 lancamentos por dia por operadora (venda bruta + tarifa).
    """
    modo = config.get("modo_codigo", "reduzido")
    contas = config["contas"]
    cod_clientes = codigo_conta(contas["clientes"], modo)
    cod_tarifa = codigo_conta(contas["tarifa"], modo)

    lancamentos = []
    for operadora, vendas in dados_por_operadora.items():
        conta_cartao_key = CONTA_CARTAO_POR_OPERADORA.get(operadora)
        if not conta_cartao_key:
            continue
        cod_cartao = codigo_conta(contas[conta_cartao_key], modo)
        perfil = perfil_de(operadora)
        por_dia = agrupar_por_dia(vendas)
        for data in por_dia:
            bruto = round(por_dia[data]["bruto"], 2)
            tarifa = round(por_dia[data]["tarifa"], 2)
            campos = {"operadora": operadora, "data": data,
                      "mesano": _mesano(data)}

            # 1) VENDA BRUTA: D = cartao, C = clientes
            if bruto > 0:
                lancamentos.append({
                    "data": data,
                    "debito": cod_cartao,
                    "credito": cod_clientes,
                    "valor": bruto,
                    "historico": _maiusculo(
                        perfil["hist_venda"].format(**campos), perfil["acentos"]),
                    "_operadora": operadora,
                    "_ord": 0,
                })
            # 2) TARIFA: D = despesa tarifa, C = cartao
            if tarifa > 0:
                lancamentos.append({
                    "data": data,
                    "debito": cod_tarifa,
                    "credito": cod_cartao,
                    "valor": tarifa,
                    "historico": _maiusculo(
                        perfil["hist_tarifa"].format(**campos), perfil["acentos"]),
                    "_operadora": operadora,
                    "_ord": 1,
                })

    # ordenar por data (cronologico), depois operadora, depois tipo (bruta antes da tarifa)
    lancamentos.sort(key=lambda l: (_data_ordenavel(l["data"]),
                                    l["_operadora"], l["_ord"]))
    return lancamentos


def montar_csv(lancamentos):
    """
    Gera o conteudo do CSV (string), uma linha por lancamento.
    Coluna E sempre vazia. Historico em maiusculo (ja vem tratado).
    O cabecalho e o formato do valor seguem o perfil da operadora (o Stone, por
    exemplo, nao leva cabecalho e usa valor no formato "geral").
    """
    perfil = perfil_dos_lancamentos(lancamentos)
    linhas = [CABECALHO] if perfil["cabecalho"] else []
    for l in lancamentos:
        # A;B;C;D;E(vazia);F
        linha = ";".join([
            l["data"],
            l["debito"],
            l["credito"],
            fmt_valor(l["valor"], perfil["valor"]),
            "",                    # coluna E - VAZIA de proposito
            l["historico"],
        ])
        linhas.append(linha)
    return "\r\n".join(linhas) + "\r\n"


def csv_bytes(lancamentos):
    """Retorna o CSV codificado em UTF-8 COM BOM (abre certo no Excel PT-BR)."""
    conteudo = montar_csv(lancamentos)
    return conteudo.encode("utf-8-sig")


def resumo_por_operadora(dados_por_operadora):
    """
    Resumo por operadora para exibir na tela:
      { operadora: {dias, bruto, tarifa, liquido, periodo:(ini,fim), lancamentos} }
    """
    out = {}
    for operadora, vendas in dados_por_operadora.items():
        por_dia = agrupar_por_dia(vendas)
        datas = sorted(por_dia.keys(), key=_data_ordenavel)
        bruto = round(sum(d["bruto"] for d in por_dia.values()), 2)
        tarifa = round(sum(d["tarifa"] for d in por_dia.values()), 2)
        # nº de lancamentos gerados: 2 por dia (quando bruto>0 e tarifa>0)
        n_lanc = 0
        for d in por_dia.values():
            if round(d["bruto"], 2) > 0:
                n_lanc += 1
            if round(d["tarifa"], 2) > 0:
                n_lanc += 1
        out[operadora] = {
            "dias": len(por_dia),
            "bruto": bruto,
            "tarifa": tarifa,
            "liquido": round(bruto - tarifa, 2),
            "periodo": (datas[0], datas[-1]) if datas else ("-", "-"),
            "lancamentos": n_lanc,
        }
    return out
