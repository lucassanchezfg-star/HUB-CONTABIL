# -*- coding: utf-8 -*-
"""
core_francesinha.py - Transforma a francesinha do BB (relacao de boletos
liquidados) nos lancamentos contabeis de recebimento.

A REGRA (a mesma da rotina que era feita a mao no Excel):

  Boleto SEM juros -> 1 linha, lancamento fechado:
      D 1054 (banco)   C 47 (recebimentos)   pelo Valor

  Boleto COM juros -> 3 linhas, lancamento aberto (padrao INVERTIDO: um
  debito no topo e dois creditos embaixo), amarradas pelo marcador LOTE=1
  na PRIMEIRA linha:
      D 1054  ...........  pelo Valor Liquidacao (o total que entrou)
         C 47  ..........  pelo Valor (o principal)
         C 385  .........  pelos Juros
  O "1" na coluna LOTE aparece SO na primeira linha do lancamento com
  juros - e' ele que diz ao importador que aquelas 3 linhas sao um
  lancamento so. Lancamento fechado NAO leva marcador.

JUROS = Valor Liquidacao - Valor (o que entrou a mais que o titulo).

HISTORICO: "RECEBIMENTO NUMERARIO <numero> <pagador>", com o numero do
boleto sem os zeros a esquerda e sem a letra final (000002568D -> 2568).
Na linha de juros vai "JUROS S/" na frente do mesmo historico.

AS CONTAS NAO SAO FIXAS: vem do cadastro da empresa (store.py). Os padroes
abaixo so valem para empresa que ainda nao cadastrou as suas.
"""
import io

import xlsxescreve
from xlsxescreve import Aba, Cabecalho, Dinheiro, Negrito

CONTA_DEBITO_PADRAO = "1054"      # banco (entrada do numerario)
CONTA_CREDITO_PADRAO = "47"       # recebimentos (baixa do titulo)
CONTA_JUROS_PADRAO = "385"        # juros ativos

CABECALHO = ["DATA", "DEBITO", "CREDITO", "VALOR", "HISTORICO", "COMPLEMENTO", "LOTE"]


def contas_da_empresa(cfg):
    """Le as contas no cadastro da empresa, caindo no padrao quando vazias."""
    contas = cfg.get("contas") or {}
    modo = cfg.get("modo_codigo", "reduzido")

    def _cod(chave, padrao):
        c = contas.get(chave) or {}
        valor = (c.get("classificacao") if modo == "classificacao" else c.get("reduzido")) \
            or c.get("reduzido") or c.get("classificacao") or ""
        return valor.strip() or padrao

    return {"debito": _cod("francesinha_banco", CONTA_DEBITO_PADRAO),
            "credito": _cod("francesinha_recebimentos", CONTA_CREDITO_PADRAO),
            "juros": _cod("francesinha_juros", CONTA_JUROS_PADRAO)}


def historico(item):
    """'RECEBIMENTO NUMERARIO 2568 FULANO DE TAL' (sem espaco duplo quando
    o BB exporta o boleto sem numero ou sem nome do pagador)."""
    partes = ["RECEBIMENTO NUMERÁRIO", item["numero"], item["pagador"]]
    return " ".join(p for p in partes if str(p).strip())


def gerar_lancamentos(dados, cfg):
    """
    dados: parsers_francesinha.ler_francesinha()
    Devolve {"lancamentos": [...], "resumo": {...}, "avisos": [...]}.
    Cada lancamento: {data, debito, credito, valor, historico, lote, tipo}
    """
    contas = contas_da_empresa(cfg)
    lancamentos = []
    avisos = []
    com_juros = sem_juros = 0
    total_juros = 0.0

    for item in dados["itens"]:
        hist = historico(item)
        juros = item["juros"]

        if juros < 0:
            # Liquidou por MENOS que o titulo (desconto/abatimento). Nao ha
            # regra combinada para isso - lanca so o valor que entrou e
            # avisa, em vez de inventar uma conta de desconto.
            avisos.append(
                f"Linha {item['linha']} ({hist}): liquidou {item['valor_liquidacao']:.2f} "
                f"para um titulo de {item['valor']:.2f} — R$ {abs(juros):.2f} A MENOS. "
                f"Lancei so o valor recebido; confira se foi desconto/abatimento.")
            lancamentos.append({"data": item["data_situacao"], "debito": contas["debito"],
                               "credito": contas["credito"], "valor": item["valor_liquidacao"],
                               "historico": hist, "lote": "", "tipo": "desconto"})
            sem_juros += 1
            continue

        if juros == 0:
            lancamentos.append({"data": item["data_situacao"], "debito": contas["debito"],
                               "credito": contas["credito"], "valor": item["valor"],
                               "historico": hist, "lote": "", "tipo": "fechado"})
            sem_juros += 1
            continue

        com_juros += 1
        total_juros += juros
        lancamentos.append({"data": item["data_situacao"], "debito": contas["debito"],
                           "credito": "", "valor": item["valor_liquidacao"],
                           "historico": hist, "lote": "1", "tipo": "juros_debito"})
        lancamentos.append({"data": item["data_situacao"], "debito": "",
                           "credito": contas["credito"], "valor": item["valor"],
                           "historico": hist, "lote": "", "tipo": "juros_principal"})
        lancamentos.append({"data": item["data_situacao"], "debito": "",
                           "credito": contas["juros"], "valor": juros,
                           "historico": "JUROS S/" + hist, "lote": "", "tipo": "juros_juros"})

    resumo = {
        "boletos": len(dados["itens"]),
        "sem_juros": sem_juros,
        "com_juros": com_juros,
        "lancamentos": len(lancamentos),
        "total_valor": dados["total_valor"],
        "total_liquidacao": dados["total_liquidacao"],
        "total_juros": round(total_juros, 2),
        "contas": contas,
    }

    # Conferencia: a soma dos debitos tem que fechar com o total recebido.
    debitos = round(sum(l["valor"] for l in lancamentos if l["debito"]), 2)
    resumo["total_debitos"] = debitos
    resumo["confere"] = abs(debitos - dados["total_liquidacao"]) <= 0.01
    if not resumo["confere"]:
        avisos.append(f"A soma dos debitos ({debitos:.2f}) nao fechou com o total "
                      f"liquidado da francesinha ({dados['total_liquidacao']:.2f}).")

    return {"lancamentos": lancamentos, "resumo": resumo, "avisos": avisos}


def _valor(v):
    """1234.5 -> '1234,50' (virgula decimal, sem separador de milhar) - o
    mesmo formato que os outros modulos ja usam no CSV."""
    return f"{v:.2f}".replace(".", ",")


def montar_csv(lancamentos):
    linhas = [";".join(CABECALHO)]
    for l in lancamentos:
        linhas.append(";".join([
            l["data"], l["debito"], l["credito"], _valor(l["valor"]),
            "",                      # HISTORICO - vazia; o texto vai no COMPLEMENTO
            l["historico"], l["lote"],
        ]))
    return "\r\n".join(linhas) + "\r\n"


def csv_bytes(lancamentos):
    """UTF-8 COM BOM (abre certo no Excel PT-BR)."""
    return montar_csv(lancamentos).encode("utf-8-sig")


def planilha_bytes(dados, resultado):
    """
    Planilha de conferencia com DUAS abas:
      FRANCESINHA - a origem ja tratada (coluna JUROS e o historico montado)
      LANCAMENTOS - exatamente o que vai no CSV
    """
    origem = [[Cabecalho("Pagador"), Cabecalho("Seu Numero"), Cabecalho("Numero"),
               Cabecalho("Banco"), Cabecalho("Data Situacao"), Cabecalho("Valor"),
               Cabecalho("JUROS"), Cabecalho("Valor Liquidacao"), Cabecalho("Historico")]]
    for i in dados["itens"]:
        origem.append([i["pagador"], i["seu_numero"], i["numero"], "BB RECEBIMENTO",
                       i["data_situacao"], Dinheiro(i["valor"]), Dinheiro(i["juros"]),
                       Dinheiro(i["valor_liquidacao"]), historico(i)])
    r = resultado["resumo"]
    origem.append([Negrito("TOTAL"), "", "", "", "",
                   Dinheiro(r["total_valor"]), Dinheiro(r["total_juros"]),
                   Dinheiro(r["total_liquidacao"]), ""])

    lanc = [[Cabecalho(c) for c in CABECALHO]]
    for l in resultado["lancamentos"]:
        lanc.append([l["data"], l["debito"], l["credito"], Dinheiro(l["valor"]),
                     "", l["historico"], l["lote"]])

    abas = [
        Aba("FRANCESINHA", origem,
            larguras={"A": 40, "B": 14, "C": 10, "D": 16, "E": 14, "F": 14,
                      "G": 12, "H": 16, "I": 60}),
        Aba("LANCAMENTOS", lanc,
            larguras={"A": 12, "B": 10, "C": 10, "D": 14, "E": 10, "F": 62, "G": 7}),
    ]
    buf = io.BytesIO()
    xlsxescreve.escrever(buf, abas)
    return buf.getvalue()


def nome_arquivo(empresa_slug, extensao, competencia=""):
    partes = ["francesinha_bb", empresa_slug]
    if competencia:
        partes.append(competencia.replace("/", "-"))
    return "_".join(p for p in partes if p) + extensao
