# -*- coding: utf-8 -*-
"""
parsers_alugueis.py - Le a planilha de conciliacao de ALUGUEIS A PAGAR.

Uma linha por locatario, com o valor do aluguel, o IRRF retido e o LIQUIDO
a pagar; o rodape traz os somatorios. O que a contabilidade provisiona no
passivo e o LIQUIDO (e o que efetivamente sai do caixa), por isso e' esse o
total confrontado com a conta "Alugueis a pagar" do balancete.

O CABECALHO NAO ESTA NUMA LINHA FIXA: a primeira linha costuma trazer a
data de referencia da planilha, entao a linha do cabecalho e' PROCURADA
pelas colunas conhecidas, e as colunas sao mapeadas PELO NOME.

O TOTAL E SOMADO DAS LINHAS, nunca lido do rodape: o rodape do arquivo real
tem a formula na coluna errada (=SUM(E3:E10) gravada em D11), entao ler "a
celula do total" pegaria o numero certo por acidente num arquivo e o errado
no proximo. Somar as linhas nao depende de onde a formula foi parar.
"""
import os
import re

import parsers

norm_txt = parsers.norm_txt

COLUNAS = {
    "tipo": ("TIPO",),
    "locatario": ("LOCATARIO", "LOCADOR", "BENEFICIARIO", "NOME", "FORNECEDOR"),
    "valor": ("VALOR",),
    "irrf": ("IRRF", "IR", "IRRFRETIDO"),
    "liquido": ("LIQUIDO", "VALORLIQUIDO"),
    "dt_pagamento": ("DTPAG", "DATAPAGAMENTO", "DTPAGAMENTO"),
    "valor_pago": ("VALORPAG", "VALORPAGO"),
    "diferenca": ("DIFERENCA",),
}
OBRIGATORIAS = ("locatario", "valor", "liquido")


def _chave(t):
    return re.sub(r"[^A-Z0-9]", "", norm_txt(t))


def _num(v):
    if v in (None, ""):
        return 0.0
    if isinstance(v, (int, float)):
        return round(float(v), 2)
    return round(parsers.parse_numero(v), 2)


def _linhas(caminho):
    """[(numero, {coluna: valor}), ...] de qualquer aba do arquivo."""
    ext = os.path.splitext(caminho)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        import zipfile
        with zipfile.ZipFile(caminho) as z:
            shared = parsers._carregar_shared_strings(z)
            for aba in parsers._abas_do_xlsx(caminho):
                sp = parsers._sheet_path_por_nome(z, aba)
                if sp:
                    yield aba, list(parsers._linhas_xml(z, sp, shared))
        return
    tabela = parsers.ler_tabela(caminho)
    yield "planilha", [(i + 1, {chr(65 + j): v for j, v in enumerate(l)})
                       for i, l in enumerate(tabela)]


def detectar(caminho):
    try:
        return bool(ler_alugueis(caminho))
    except Exception:  # noqa: BLE001
        return False


def ler_alugueis(caminho, nome_original=""):
    """
    Devolve {"arquivo","aba","itens":[...],"total_valor","total_irrf",
             "total_liquido"}.
    Cada item: {locatario, tipo, valor, irrf, liquido, dt_pagamento,
                valor_pago, diferenca, _linha}
    """
    nome = nome_original or os.path.basename(caminho)
    for aba, linhas in _linhas(caminho):
        cab = mapa = None
        for rn, cells in linhas[:15]:
            m = {}
            for col, val in cells.items():
                k = _chave(val)
                if not k:
                    continue
                for campo, nomes in COLUNAS.items():
                    if campo not in m and k in nomes:
                        m[campo] = col
                        break
            if all(c in m for c in OBRIGATORIAS):
                cab, mapa = rn, m
                break
        if mapa is None:
            continue

        itens = []
        for rn, cells in linhas:
            if rn <= cab:
                continue
            locatario = str(cells.get(mapa["locatario"]) or "").strip()
            valor = _num(cells.get(mapa["valor"]))
            liquido = _num(cells.get(mapa.get("liquido")))
            # rodape/linha vazia: sem locatario nao e' aluguel de ninguem
            if not locatario:
                continue
            if not valor and not liquido:
                continue
            if re.match(r"^(TOTAL|TOTAIS|SOMA)\b", norm_txt(locatario)):
                continue
            itens.append({
                "_linha": rn,
                "tipo": str(cells.get(mapa.get("tipo")) or "").strip(),
                "locatario": locatario,
                "valor": valor,
                "irrf": _num(cells.get(mapa.get("irrf"))),
                "liquido": liquido,
                "dt_pagamento": _data(cells.get(mapa.get("dt_pagamento"))),
                "valor_pago": _num(cells.get(mapa.get("valor_pago"))),
                "diferenca": _num(cells.get(mapa.get("diferenca"))),
            })

        if itens:
            return {
                "arquivo": nome, "aba": aba, "itens": itens,
                "total_valor": round(sum(i["valor"] for i in itens), 2),
                "total_irrf": round(sum(i["irrf"] for i in itens), 2),
                "total_liquido": round(sum(i["liquido"] for i in itens), 2),
            }

    raise ValueError("nao parece a planilha de alugueis a pagar (esperava as "
                     "colunas LOCATARIO, VALOR e LIQUIDO).")


def _data(v):
    import datetime
    if v in (None, ""):
        return ""
    if isinstance(v, (int, float)) or (isinstance(v, str) and re.fullmatch(r"\d{5}(\.0+)?", str(v).strip())):
        try:
            return (datetime.date(1899, 12, 30)
                    + datetime.timedelta(days=int(float(v)))).strftime("%d/%m/%Y")
        except (ValueError, OverflowError):
            return ""
    m = re.match(r"^(\d{2})[/-](\d{2})[/-](\d{4})", str(v).strip())
    return f"{m.group(1)}/{m.group(2)}/{m.group(3)}" if m else ""
