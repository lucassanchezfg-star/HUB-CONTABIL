# -*- coding: utf-8 -*-
"""
parsers_couto.py - Le os quatro relatorios do sistema da HAC / Grupo Couto,
ja TRATADOS pela rotina de integracao do Cowork.

OS QUATRO, E O QUE CADA UM E
----------------------------
    TITULOS PAGOS       um titulo pago por linha, com fornecedor, CNPJ, o
                        plano de contas do ERP e a forma de pagamento
    TITULOS RECEBIDOS   um titulo recebido por linha, com cliente, juros e
                        desconto, e o plano de contas da baixa
    BANCO SISTEMA       a conta corrente do ERP: debito, credito e saldo
    RESUMO DE CAIXA     o movimento do caixa da loja, por forma de pagamento

O CABECALHO NAO FICA NA LINHA 1: antes dele vem o titulo do relatorio e a
lista de filtros da consulta, que muda de tamanho de um relatorio para o
outro (linha 21 no Banco Sistema, 24 no Resumo de Caixa, 35 nos Titulos
Pagos, 48 nos Recebidos). Por isso a linha do cabecalho e achada PELOS
NOMES DAS COLUNAS, nunca por posicao.

CONFERENCIA EMBUTIDA: cada leitura e conferida contra um numero que o
proprio relatorio declara -
    BANCO SISTEMA      o rodape PORTADOR | SALDO ANTERIOR | VALOR DEBITO |
                       VALOR CREDITO | SALDO FINAL
    TITULOS PAGOS      o bloco MODALIDADES (DINHEIRO, CARTAO, CHEQUE
                       EMITIDO, CHEQUE REPASSADO, ORDEM DE PAGAMENTO)
    RESUMO DE CAIXA    o bloco RESUMO POR FORMA, uma linha por forma
    TITULOS RECEBIDOS  nao tem rodape proprio - a conferencia dele e por
                       confronto com o Banco Sistema (ver core_couto)

CUIDADO QUE JA PEGOU ERRO: o Banco Sistema sai filtrado por
"Opcao : CONCILIADOS". Quando ha movimento nao conciliado, a listagem vem
incompleta e o rodape NAO bate - foi assim que apareceram os R$ 238.116,79
de credito que faltavam no SISTEMA DINHEIRO de 08/2026. A divergencia vira
aviso; nunca e engolida.
"""
import os
import re
import unicodedata
import zipfile

import parsers

RE_DATA = re.compile(r"^\d{2}/\d{2}/\d{4}$")

# titulos das secoes que vem DEPOIS da tabela principal do Resumo de Caixa
RE_SECAO_RC = re.compile(r"^\s*RESUMO DE CAIXA\s*-", re.I)


def _chave(texto):
    """Nome de coluna comparavel: maiusculo, sem acento, so letra/numero."""
    t = unicodedata.normalize("NFKD", str(texto or ""))
    t = "".join(c for c in t if not unicodedata.combining(c))
    return re.sub(r"[^A-Z0-9]", "", t.upper())


def _num(v):
    """'1.234,56' -> 1234.56 ; vazio -> None (que e diferente de zero)."""
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return round(float(v), 2)
    s = str(v or "").strip()
    if not s:
        return None
    try:
        return round(float(s.replace(".", "").replace(",", ".")), 2)
    except ValueError:
        return None


def _linhas(caminho):
    z = zipfile.ZipFile(caminho)
    sh = parsers._carregar_shared_strings(z)
    abas = parsers._abas_do_xlsx(caminho)
    if not abas:
        return []
    sp = parsers._sheet_path_por_nome(z, abas[0])
    return list(parsers._linhas_xml(z, sp, sh)) if sp else []


def _achar_cabecalho(linhas, obrigatorias):
    """
    (numero da linha, mapa da PRIMEIRA ocorrencia, mapa da ULTIMA).

    Os dois mapas existem porque em TITULOS PAGOS o nome "CONTA" aparece
    duas vezes: na coluna B, que so repete o rotulo da quebra, e na coluna
    G, que e o valor da propria linha. E a ultima que vale.
    """
    alvo = {_chave(o) for o in obrigatorias}
    for rn, cells in linhas:
        pri, ult = {}, {}
        for col, val in sorted(cells.items()):
            k = _chave(val)
            if k:
                pri.setdefault(k, col)
                ult[k] = col
        if alvo <= set(pri):
            return rn, pri, ult
    return None, {}, {}


def _texto(cells, mapa, nome):
    col = mapa.get(_chave(nome))
    return re.sub(r"\s+", " ", str(cells.get(col) or "")).strip() if col else ""


def _valor(cells, mapa, nome):
    col = mapa.get(_chave(nome))
    return _num(cells.get(col)) if col else None


def _codigo_plano(*textos):
    """'04.02.014 TAXA DE CARTAO' -> '04.02.014' ; o primeiro que houver."""
    for t in textos:
        m = re.match(r"\s*(\d{2}\.\d{2}\.\d{3})", str(t or ""))
        if m:
            return m.group(1)
    return ""


# Como cada loja aparece escrita. A ordem importa: "SANTO ANTONIO" tem de
# ser testado antes de "SANTOS", senao "SANTOS" casaria dentro dele.
# "SANTA ROSA" e o nome da matriz na razao social; nos nomes de arquivo ela
# vem ora como SANTA ROSA, ora como MATRIZ.
FILIAIS = (
    ("SANTO ANTONIO", ("SANTOANTONIO", "STOANTONIO", "STANTONIO")),
    ("ENSEADA", ("ENSEADA",)),
    ("SANTOS", ("SANTOS",)),
    ("MATRIZ", ("MATRIZ", "SANTAROSA")),
    ("GALPAO", ("GALPAO",)),
)


def filial_no_texto(texto):
    """
    Qual loja este texto menciona, seja ele um nome de arquivo ou o nome
    de uma conta do plano ("BANCO ITAU - STO ANTONIO (21033-0)").
    """
    n = _chave(texto)
    for rotulo, formas in FILIAIS:
        if any(f in n for f in formas):
            return rotulo
    return ""


def _filial_do_nome(nome):
    """A filial sai do NOME do arquivo - e o tratamento que a poe ali."""
    return filial_no_texto(nome)


def _banco_do_nome(nome):
    n = _chave(nome)
    for chave in ("ITAU", "BRADESCO", "SICREDI"):
        if chave in n:
            return chave
    return ""


def _linha_de_titulo(cells):
    """O texto de uma linha que so tem um rotulo (titulo de secao)."""
    vals = [str(v).strip() for _k, v in sorted(cells.items()) if str(v).strip()]
    return vals[0] if len(vals) == 1 else ""


# ==========================================================================
# 1) TITULOS PAGOS
# ==========================================================================
def ler_titulos_pagos(caminho, nome_original=""):
    nome = nome_original or os.path.basename(caminho)
    linhas = _linhas(caminho)
    cab, mapa, ult = _achar_cabecalho(linhas, ("DTA.PAG", "FORNECEDOR", "VAL.PAG"))
    if cab is None:
        raise ValueError(
            "nao achei a tabela de TITULOS PAGOS neste arquivo (esperava as "
            "colunas DTA.PAG, FORNECEDOR e VAL.PAG).")

    itens = []
    for rn, cells in linhas:
        if rn <= cab:
            continue
        data = _texto(cells, mapa, "DTA.PAG")
        if not RE_DATA.match(data):
            continue
        valor = _valor(cells, mapa, "VAL.PAG")
        if valor is None:
            continue
        itens.append({
            "linha": rn, "data": data, "valor": valor,
            # a conta do ERP e a coluna CONTA da propria linha (a ultima)
            "conta_erp": _codigo_plano(_texto(cells, ult, "CONTA")),
            "centro_custo": _texto(cells, ult, "CEN. CUSTO"),
            "fornecedor": _texto(cells, mapa, "FORNECEDOR"),
            "cnpj": _texto(cells, mapa, "C.P.F./C.N.P.J."),
            "duplicata": _texto(cells, mapa, "DUPLICATA"),
            "portador": _texto(cells, mapa, "POR.BAI"),
            "forma": _texto(cells, mapa, "FORMA(S) DE PAGAMENTO"),
            "historico": _texto(cells, mapa, "HISTORICO"),
            "emp": _texto(cells, mapa, "EMP"),
            "vencimento": _texto(cells, mapa, "DTA.VEN"),
            "valor_original": _valor(cells, mapa, "VAL.ORI"),
            "diferenca": _valor(cells, mapa, "VAL.DIF") or 0.0,
        })

    rod = _rodape_pagos(linhas)
    soma = round(sum(i["valor"] for i in itens), 2)
    avisos = []
    if rod and rod.get("modalidades"):
        decl = round(sum(rod["modalidades"].values()), 2)
        if round(soma - decl, 2):
            avisos.append(
                "'%s': li R$ %.2f mas o rodape do proprio relatorio declara "
                "R$ %.2f nas modalidades de pagamento - diferenca de R$ %.2f."
                % (nome, soma, decl, round(soma - decl, 2)))
    else:
        avisos.append("'%s': este relatorio veio sem o bloco de MODALIDADES, "
                      "entao a leitura nao pode ser conferida por ele." % nome)
    return {"arquivo": nome, "tipo": "TITULOS PAGOS",
            "banco": _banco_do_nome(nome), "filial": _filial_do_nome(nome),
            "itens": itens, "total": soma, "rodape": rod, "avisos": avisos}


def _rodape_pagos(linhas):
    """
    Os dois blocos do fim dos TITULOS PAGOS:
        TITULOS PAGOS - (JUROS E DESCONTOS)   TOTAL DOS DESCONTOS / DOS JUROS
        TITULOS PAGOS - (MODALIDADES ...)     DINHEIRO, CARTAO, CHEQUE
                                              EMITIDO, CHEQUE REPASSADO,
                                              ORDEM DE PAGAMENTO
    Os rotulos sao lidos como vierem: se o ERP passar a emitir uma forma
    nova, ela entra sozinha na conferencia.
    """
    out = {"modalidades": {}, "juros": None, "descontos": None}
    bloco = ""
    for _rn, cells in linhas:
        titulo = _chave(_linha_de_titulo(cells))
        if titulo.startswith("TITULOSPAGOS"):
            bloco = ("MOD" if "MODALIDADE" in titulo else
                     "JUR" if "JUROS" in titulo else "")
            continue
        if not bloco:
            continue
        ordem = sorted(cells.items())
        if len(ordem) < 2:
            continue
        rot = str(ordem[0][1] or "").strip().rstrip(":")
        val = _num(ordem[1][1])
        if not rot or val is None:
            continue
        if bloco == "MOD":
            out["modalidades"][rot.upper()] = val
        elif "DESCONTO" in _chave(rot):
            out["descontos"] = val
        elif "JURO" in _chave(rot):
            out["juros"] = val
    return out if (out["modalidades"] or out["juros"] is not None) else None


# ==========================================================================
# 2) TITULOS RECEBIDOS
# ==========================================================================
def ler_titulos_recebidos(caminho, nome_original=""):
    """
    Um titulo recebido por linha.

    JUROS E DESCONTO SAO LANCAMENTO A PARTE: VR.REC ja vem liquido, e o
    que foi cobrado de juros (VR.JUROS) ou concedido de desconto (VR.DESC)
    nao pertence a conta do cliente. Por isso os tres saem separados, e
    quem monta o lancamento decide - somar aqui seria esconder receita.

    Este relatorio NAO TEM RODAPE. A conferencia dele e por confronto com o
    Banco Sistema do mesmo portador (core_couto faz isso).
    """
    nome = nome_original or os.path.basename(caminho)
    linhas = _linhas(caminho)
    cab, mapa, ult = _achar_cabecalho(linhas, ("DTA.REC", "CLIENTE", "VR.REC"))
    if cab is None:
        raise ValueError(
            "nao achei a tabela de TITULOS RECEBIDOS neste arquivo (esperava "
            "as colunas DTA.REC, CLIENTE e VR.REC).")
    # a coluna a esquerda do cabecalho repete "PLANO DE CONTAS DA BAIXA: x"
    primeira = min(mapa.values()) if mapa else ""
    col_plano = (chr(ord(primeira) - 1)
                 if len(primeira) == 1 and primeira > "A" else "")

    itens = []
    for rn, cells in linhas:
        if rn <= cab:
            continue
        data = _texto(cells, mapa, "DTA.REC")
        if not RE_DATA.match(data):
            continue
        valor = _valor(cells, mapa, "VR.REC")
        if valor is None:
            continue
        plano = ""
        if col_plano:
            plano = _codigo_plano(str(cells.get(col_plano) or "").split(":")[-1])
        itens.append({
            "linha": rn, "data": data, "valor": valor,
            "conta_erp": plano,
            "cliente": _texto(cells, mapa, "CLIENTE"),
            "duplicata": _texto(cells, mapa, "DUPLICATA"),
            "portador": _texto(cells, mapa, "POR.BAI"),
            "juros": _valor(cells, mapa, "VR.JUROS") or 0.0,
            "desconto": _valor(cells, mapa, "VR.DESC") or 0.0,
            "valor_original": _valor(cells, mapa, "VR.ORIGI"),
            "tipo_rec": _texto(cells, mapa, "TIPO. REC"),
            "historico": _texto(cells, mapa, "HISTORICO"),
            "historico_baixa": _texto(cells, mapa, "HISTORICO DA BAIXA"),
            "vencimento": _texto(cells, mapa, "DTA.VEN"),
            "emp": _texto(cells, mapa, "EMP"),
        })
    return {"arquivo": nome, "tipo": "TITULOS RECEBIDOS",
            "banco": _banco_do_nome(nome), "filial": _filial_do_nome(nome),
            "itens": itens, "total": round(sum(i["valor"] for i in itens), 2),
            "total_juros": round(sum(i["juros"] for i in itens), 2),
            "total_desconto": round(sum(i["desconto"] for i in itens), 2),
            "rodape": None,
            "avisos": ["'%s': o relatorio de TITULOS RECEBIDOS nao traz total "
                       "proprio; a conferencia dele e o confronto com o Banco "
                       "Sistema do mesmo portador." % nome]}


# ==========================================================================
# 3) BANCO SISTEMA (conta corrente do ERP)
# ==========================================================================
def ler_banco_sistema(caminho, nome_original=""):
    nome = nome_original or os.path.basename(caminho)
    linhas = _linhas(caminho)
    cab, mapa, ult = _achar_cabecalho(
        linhas, ("DTA.LAN", "DEBITO", "CREDITO", "HISTORICO"))
    if cab is None:
        raise ValueError(
            "nao achei a tabela de BANCO SISTEMA neste arquivo (esperava as "
            "colunas DTA.LAN, DEBITO, CREDITO e HISTORICO).")

    itens = []
    for rn, cells in linhas:
        if rn <= cab:
            continue
        data = _texto(cells, mapa, "DTA.LAN")
        if not RE_DATA.match(data):
            continue
        deb = _valor(cells, mapa, "DEBITO") or 0.0
        cre = _valor(cells, mapa, "CREDITO") or 0.0
        if not deb and not cre:
            continue
        itens.append({
            "linha": rn, "data": data,
            # sinal na convencao de extrato: >0 entrou, <0 saiu
            "valor": round(cre - deb, 2), "debito": deb, "credito": cre,
            "saldo": _valor(cells, mapa, "SALDO"),
            # o SISTEMA DINHEIRO nao traz a coluna PLANO DE CONTAS; nele o
            # codigo vem so na coluna CONTA
            "conta_erp": _codigo_plano(_texto(cells, ult, "CONTA"),
                                       _texto(cells, mapa, "PLANO DE CONTAS")),
            "plano_nome": _texto(cells, mapa, "PLANO DE CONTAS"),
            "historico": _texto(cells, mapa, "HISTORICO"),
            "documento": _texto(cells, mapa, "NUM.DOC"),
            "sequencia": _texto(cells, mapa, "SEQ.LAN"),
            "status": _texto(cells, mapa, "STATUS"),
            "emp": _texto(cells, mapa, "EMP"),
        })

    td = round(sum(i["debito"] for i in itens), 2)
    tc = round(sum(i["credito"] for i in itens), 2)
    rod = _rodape_portador(linhas)
    avisos = []
    if rod:
        dd = round(td - (rod["debito"] or 0.0), 2)
        dc = round(tc - (rod["credito"] or 0.0), 2)
        if dd or dc:
            avisos.append(
                "'%s': a listagem NAO fecha com o rodape do proprio relatorio "
                "- debito li %.2f contra %.2f (%+.2f), credito li %.2f contra "
                "%.2f (%+.2f). O relatorio sai filtrado por 'Opcao: "
                "CONCILIADOS': o que ainda nao foi conciliado entra no total "
                "do rodape mas nao aparece na listagem. Peca o relatorio sem "
                "esse filtro antes de importar."
                % (nome, td, rod["debito"] or 0.0, dd,
                   tc, rod["credito"] or 0.0, dc))
    else:
        avisos.append("'%s': nao achei o rodape PORTADOR/SALDO deste "
                      "relatorio, entao a leitura nao pode ser conferida."
                      % nome)
    return {"arquivo": nome, "tipo": "BANCO SISTEMA",
            "banco": _banco_do_nome(nome), "filial": _filial_do_nome(nome),
            "itens": itens, "total_debito": td, "total_credito": tc,
            "rodape": rod, "avisos": avisos}


def _rodape_portador(linhas):
    """PORTADOR | SALDO ANTERIOR | VALOR DEBITO | VALOR CREDITO | SALDO FINAL."""
    for i, (_rn, cells) in enumerate(linhas):
        vals = [_chave(v) for v in cells.values()]
        if "PORTADOR" in vals and "SALDOANTERIOR" in vals and "SALDOFINAL" in vals:
            pos = {_chave(v): k for k, v in sorted(cells.items())}
            for _rn2, c2 in linhas[i + 1:]:
                nome = str(c2.get(pos.get("PORTADOR")) or "").strip()
                if not nome:
                    continue
                return {
                    "portador": nome,
                    "saldo_anterior": _num(c2.get(pos.get("SALDOANTERIOR"))),
                    "debito": _num(c2.get(pos.get("VALORDEBITO"))),
                    "credito": _num(c2.get(pos.get("VALORCREDITO"))),
                    "saldo_final": _num(c2.get(pos.get("SALDOFINAL"))),
                }
    return None


# ==========================================================================
# 4) RESUMO DE CAIXA
# ==========================================================================
# O VALOR DO LANCAMENTO E A COLUNA DA FORMA, NAO A COLUNA "VALOR".
#
# A coluna VALOR e o total do documento, e nele entra tambem o credito que
# o cliente usou. Na linha 101 do Resumo da Matriz, VALOR e -0,40 e
# VLR.CRED. e -247,65: quem lancasse -0,40 perderia 247,25 de movimento.
# As colunas de forma (DINHEIRO, CARTAO, CHQ.VISTA, CHQ.PRE, ORD.PAG.) sao
# o que de fato passou pelo caixa, e uma linha pode ter mais de uma - uma
# venda paga metade em dinheiro e metade no cartao gera DOIS lancamentos,
# um por forma, nunca um so pelo total.
#
# Conferido nos quatro Resumos de 08/2026, forma a forma, contra o bloco
# RESUMO POR FORMA do proprio relatorio: 20 de 20 casam na casa do centavo.
#
# VLR.CRED. fica DE FORA: no rodape ela vem na linha "UTILIZ. DE CRED.
# (INFORMATIVO)", fora dos TOTAIS - e uso de credito do cliente, ja contado
# na duplicata. Somar seria contar duas vezes.
FORMAS_CAIXA = ("DINHEIRO", "CARTAO", "CHQ.VISTA", "CHQ.PRE", "ORD.PAG.")

# o rotulo de cada forma no bloco RESUMO POR FORMA do rodape
FORMA_NO_RODAPE = {
    "DINHEIRO": "DINHEIRO", "CARTAO": "CARTAO DE CREDITO",
    "CHQ.VISTA": "CHEQUE A VISTA", "CHQ.PRE": "CHEQUE PRE",
    "ORD.PAG.": "ORDEM DE PAGAMENTO",
}


def ler_resumo_caixa(caminho, nome_original=""):
    nome = nome_original or os.path.basename(caminho)
    linhas = _linhas(caminho)
    cab, mapa, ult = _achar_cabecalho(
        linhas, ("DTA.CAD", "HISTORICO", "DINHEIRO", "VALOR"))
    if cab is None:
        raise ValueError(
            "nao achei a tabela do RESUMO DE CAIXA neste arquivo (esperava as "
            "colunas DTA.CAD, HISTORICO, DINHEIRO e VALOR).")

    itens = []
    for rn, cells in linhas:
        if rn <= cab:
            continue
        # a tabela principal acaba no primeiro titulo "RESUMO DE CAIXA - ...";
        # dali para baixo vem OPERACOES, DADOS INFORMATIVOS, RELACAO DE
        # CREDITOS, DUPLICATAS EMITIDAS... que tambem tem coluna de data e
        # entrariam como lancamento se a leitura nao parasse aqui
        if RE_SECAO_RC.match(_linha_de_titulo(cells)):
            break
        data = _texto(cells, mapa, "DTA.CAD")
        if not RE_DATA.match(data):
            continue
        valor = _valor(cells, mapa, "VALOR")
        if valor is None:
            continue
        formas = {f: _valor(cells, mapa, f) for f in FORMAS_CAIXA}
        formas = {f: v for f, v in formas.items() if v}
        doc = _texto(cells, mapa, "DOCUMENTO")
        especie = doc.rsplit("-", 1)[-1].strip().upper() if "-" in doc else ""
        itens.append({
            "linha": rn, "data": data,
            # o total do documento, so para conferencia - NAO e o lancamento
            "valor_documento": valor,
            "formas": formas,
            "forma": (list(formas)[0] if len(formas) == 1 else ""),
            "valor": round(sum(formas.values()), 2),
            "credito_usado": _valor(cells, mapa, "VLR.CRED.") or 0.0,
            "historico": _texto(cells, mapa, "HISTORICO"),
            "documento": doc, "especie": especie,
            # TF e transferencia do caixa para o portador: e a perna que tira
            # do caixa o que o banco recebe. Entra no extrato do banco, nao
            # aqui - lancar dos dois lados contaria o dinheiro duas vezes
            "transferencia": especie == "TF",
            "saldo": _valor(cells, mapa, "SALDO"),
            "operador": _texto(cells, mapa, "OPE"),
            "sequencia": _texto(cells, mapa, "SEQ.BAI"),
        })

    rod = _rodape_formas_caixa(linhas)
    avisos = _conferir_caixa(nome, itens, rod)
    return {"arquivo": nome, "tipo": "RESUMO DE CAIXA", "banco": "",
            "filial": _filial_do_nome(nome), "itens": itens,
            "total": round(sum(i["valor"] for i in itens
                               if not i["transferencia"]), 2),
            "total_transferencias": round(sum(i["valor"] for i in itens
                                              if i["transferencia"]), 2),
            "rodape": rod, "avisos": avisos}


def _rodape_formas_caixa(linhas):
    """
    O bloco RESUMO POR FORMA:
        FORMA | SALDO INICIAL | VENDAS A VISTA | REC. DE TITULO | OUTROS REC.
              | PAGAMENTOS | TRANSF. | OUTROS PAG. | SALDO FINAL
    E o melhor rodape dos quatro relatorios: declara, forma por forma, o
    mesmo movimento que a tabela detalha.
    """
    for i, (_rn, cells) in enumerate(linhas):
        vals = [_chave(v) for v in cells.values()]
        if "FORMA" in vals and "SALDOINICIAL" in vals and "SALDOFINAL" in vals:
            pos = {_chave(v): k for k, v in sorted(cells.items())}
            out = {}
            for _rn2, c2 in linhas[i + 1:]:
                rot = str(c2.get(pos.get("FORMA")) or "").strip()
                if not rot:
                    break
                linha = {"saldo_inicial": _num(c2.get(pos.get("SALDOINICIAL"))),
                         "saldo_final": _num(c2.get(pos.get("SALDOFINAL")))}
                mov = 0.0
                for nome_col, k in (("VENDASAVISTA", "vendas"),
                                    ("RECDETITULO", "titulos"),
                                    ("OUTROSREC", "outros_rec"),
                                    ("PAGAMENTOS", "pagamentos"),
                                    ("TRANSF", "transferencias"),
                                    ("OUTROSPAG", "outros_pag")):
                    v = _num(c2.get(pos.get(nome_col))) or 0.0
                    linha[k] = v
                    mov += v
                linha["movimento"] = round(mov, 2)
                out[_chave(rot)] = linha
            return out or None
    return None


def _conferir_caixa(nome, itens, rod):
    """Forma por forma: o que foi lido contra o que o rodape declara."""
    if not rod:
        return ["'%s': nao achei o bloco RESUMO POR FORMA, entao a leitura "
                "nao pode ser conferida." % nome]
    avisos = []
    for forma in FORMAS_CAIXA:
        linha = rod.get(_chave(FORMA_NO_RODAPE[forma]))
        if not linha:
            continue
        lido = round(sum(i["formas"].get(forma, 0.0) for i in itens), 2)
        dif = round(lido - linha["movimento"], 2)
        if dif:
            avisos.append(
                "'%s': em %s li R$ %.2f mas o rodape do proprio relatorio "
                "declara R$ %.2f de movimento - diferenca de R$ %.2f."
                % (nome, forma, lido, linha["movimento"], dif))
    return avisos


# ==========================================================================
# Deteccao pelo CONTEUDO, nunca pelo nome do arquivo
# ==========================================================================
OBRIGATORIAS = (
    ("TITULOS PAGOS", ("DTA.PAG", "FORNECEDOR", "VAL.PAG")),
    ("TITULOS RECEBIDOS", ("DTA.REC", "CLIENTE", "VR.REC")),
    ("BANCO SISTEMA", ("DTA.LAN", "DEBITO", "CREDITO", "HISTORICO")),
    ("RESUMO DE CAIXA", ("DTA.CAD", "HISTORICO", "DINHEIRO", "VALOR")),
)

LEITORES = {
    "TITULOS PAGOS": ler_titulos_pagos,
    "TITULOS RECEBIDOS": ler_titulos_recebidos,
    "BANCO SISTEMA": ler_banco_sistema,
    "RESUMO DE CAIXA": ler_resumo_caixa,
}


def detectar(caminho):
    """Qual dos quatro relatorios e este arquivo, ou '' se nao for nenhum."""
    try:
        linhas = _linhas(caminho)
    except Exception:  # noqa: BLE001 - nao e um xlsx
        return ""
    for tipo, obrig in OBRIGATORIAS:
        cab, _p, _u = _achar_cabecalho(linhas, obrig)
        if cab is not None:
            return tipo
    return ""


def ler(caminho, nome_original=""):
    tipo = detectar(caminho)
    if not tipo:
        raise ValueError(
            "este arquivo nao e nenhum dos quatro relatorios tratados "
            "(TITULOS PAGOS, TITULOS RECEBIDOS, BANCO SISTEMA ou "
            "RESUMO DE CAIXA).")
    return LEITORES[tipo](caminho, nome_original)
