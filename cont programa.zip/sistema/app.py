# -*- coding: utf-8 -*-
"""
app.py - Servidor web LOCAL do Contabilizador de Cartao.

Roda 100% em 127.0.0.1 (nada vai para a internet). Interface em pt-BR.

NOTA SOBRE A STACK
------------------
A especificacao pedia Flask. No ambiente-alvo o proxy corporativo autenticado
bloqueia o 'pip install' (erro 407), impedindo instalar Flask/openpyxl. Para o
app rodar SEM depender de instalacao, usamos apenas a BIBLIOTECA PADRAO do
Python 3 (http.server + zipfile/ElementTree). A arquitetura, as rotas e o
comportamento sao os mesmos previstos para Flask:
    /                     -> hub (dois grupos: CONTABIL e ROTINAS)
  CONTABIL
    /cartao               -> vendas de cartao: upload + gerar CSV
    /extrato              -> extrato bancario: upload (PDF) + gerar CSV
    /cadastro             -> gerenciar empresas + editar contas de cada uma
    /regra                -> bancos (conta fixa) + contas padrao do extrato
    /depara               -> de-para: texto do extrato -> conta contabil
    /francesinha_bb       -> boletos recebidos do BB (.xls) -> CSV de lancamentos
    /aplicacao_diaria     -> extrato de aplicacao (PDF/xlsx) -> CSV de lancamentos
    /aplicacao_depara     -> contas da aplicacao, por banco
    /processar_francesinha -> (POST) le a francesinha e gera o CSV + planilha
    /sispag               -> SISPAG do Itau -> CSV de lancamentos
  ROTINAS
    /receita_financeira   -> descontos obtidos, juros ativos e rendimento de
                             aplicacao (Itau/Bradesco) -> CSV da apuracao
    /aluguel_royalties    -> (modulo criado, regras a definir)
    /estoque_citel        -> inventarios do Citel -> planilha de contabilizacao
    /estoque_precito      -> (modulo criado, regras a definir)
    /fornecedores         -> posicao contabil de contas a pagar (uma por
                             filial) -> planilha consolidada (so leitura e
                             consolidacao; conciliacao a definir)
    /magnojet             -> Grupo Magnojet: pagos + recebidos + extrato ->
                             planilhas tratadas e conciliadas
    /estoque_contas       -> cadastro filial -> conta contabil do estoque
  AUDITORIA
    /aud_depreciacao      -> Resumo da Depreciacao Fiscal x Balancete -> quadro
    /aud_extrato           -> Extratos + Aplicacoes x Balancete -> quadro
    /aud_cartao            -> Relatorios de vendas de cartao x Balancete -> quadro
    /aud_fiscal            -> Resumo por Acumulador (por filial) x Balancete
    /confrontacao_final    -> TUDO acima num checklist so (1 balancete para todos)
    /aud_folha             -> (regras a definir)
    /processar_cartao     -> (POST) processa relatorios de cartao -> JSON
    /processar_extrato    -> (POST) processa extratos bancarios -> JSON
    /processar_receita    -> (POST) apura a receita financeira -> JSON
    /processar_estoque    -> (POST) consolida o estoque -> JSON
    /processar_fornecedores -> (POST) consolida as contas a pagar -> JSON
    /api/estoque_filiais  -> (GET/POST, ?empresa=slug) filiais do estoque
    /baixar               -> download do arquivo gerado (CSV ou XLSX)
    /api/empresas         -> (GET) lista empresas | (POST) cria nova empresa
    /api/empresas_editar  -> (POST) edita nome/CNPJ/codigo/apelido de uma empresa
    /api/empresa_ativa    -> (POST) define a empresa ativa (padrao nas telas)
    /api/empresas_excluir -> (POST) exclui uma empresa
    /api/config           -> (GET/POST, ?empresa=slug) ler/gravar contas de 1 empresa
    /api/bancos           -> (GET/POST, ?empresa=slug) modulo REGRA
    /api/depara           -> (GET/POST, ?empresa=slug) modulo DE-PARA
Se um dia o pip funcionar, os mesmos parsers/core/store servem a uma versao
Flask sem alteracao.
"""
import json
import os
import re
import socket
import sys
import time
import webbrowser
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

import store
import parsers
import core_cartao
import parsers_extrato
import core_extrato
import parsers_plano
import parsers_fiscal
import core_fiscal
import parsers_estoque
import core_estoque
import core_estoque_apuracao
import parsers_balancete
import parsers_depreciacao
import core_auditoria_depreciacao
import parsers_extrato_saldo
import core_auditoria_extrato
import core_auditoria_cartao
import parsers_acumulador
import core_auditoria_fiscal
import core_confrontacao_final
import parsers_alugueis
import core_relatorio_auditoria
import parsers_francesinha
import parsers_sispag
import core_sispag
import core_francesinha
import parsers_aplicacao
import core_aplicacao
import parsers_financeiro
import parsers_extrato_mov
import core_magnojet_saida
import xlsx_magnojet
import parsers_fornecedores
import core_fornecedores
import parsers_ofx
import parsers_extrato_decl
import core_importacao_txt
import parsers_estoque_precito
import core_estoque_precito
import parsers_couto
import core_couto

BASE_DIR = os.path.dirname(os.path.abspath(__file__))   # pasta do CODIGO
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")
STATIC_DIR = os.path.join(BASE_DIR, "static")
# Os dados ficam na RAIZ do projeto, nao junto do codigo - quem manda no
# caminho e o store (ver store.pasta_dados), para os dois nunca divergirem.
DADOS_DIR = store.DADOS_DIR
FISCAL_DIR = os.path.join(DADOS_DIR, "fiscal")
HOST = "127.0.0.1"
PORT = 5000
# Nome do escritorio: fica no topo, fixo. Quem muda de tela para tela e a
# EMPRESA (o cliente), que agora tem barra propria logo abaixo do cabecalho.
ESCRITORIO = "JBQUALITY CONTABILIDADE LTDA"

# CSVs gerados guardados em memoria (app local, uso pessoal) -> token: (bytes, nome)
# O token e ALEATORIO (nao sequencial) para que duas geracoes simultaneas -
# por exemplo duas abas do navegador - nao disputem o mesmo numero.
_CSV_CACHE = {}

# O servidor fica aqui para a rota /encerrar conseguir desliga-lo. Ele sobe
# SOLTO da janela do Iniciar.bat (pythonw), entao fechar a janela nao derruba
# mais o sistema - quem desliga e o botao "Encerrar" do menu.
_SERVIDOR = None

# ---- desligamento automatico -------------------------------------------
# A tela manda uma "batida" a cada 5s (ver base_nav.html). Sem batida por
# SEGUNDOS_SEM_TELA o servidor se desliga sozinho: e o que faz o sistema
# encerrar quando se fecha a janela, sem botao de desligar.
#
# O tempo e folgado de proposito: trocar de tela abre um vao de menos de um
# segundo, mas uma maquina lenta abrindo um PDF grande pode demorar mais.
# Encerrar cedo demais derrubaria o trabalho de quem esta usando.
SEGUNDOS_SEM_TELA = 60
_ULTIMA_BATIDA = time.time()


def _novo_token():
    import uuid
    return uuid.uuid4().hex[:12]


def _guardar(dados, nome, ctype="text/csv; charset=utf-8"):
    """Guarda um arquivo gerado para download e devolve o token."""
    token = _novo_token()
    _CSV_CACHE[token] = (dados, nome, ctype)
    return token


TIPO_XLSX = ("application/vnd.openxmlformats-officedocument"
             ".spreadsheetml.sheet")

# Grupo AUDITORIA: rota -> titulo. Sao telas iguais em estrutura, entao ficam
# numa tabela em vez de cinco 'elif' repetidos - modulo novo aqui e uma linha.
# "/aud_depreciacao" e "/aud_extrato" sairam daqui: tem tela e processamento
# propios (ver processar_aud_depreciacao/processar_aud_extrato) - os demais
# continuam so a pagina descritiva.
AUDITORIA = {
    "/aud_folha": "Auditoria - Folha",
}


# --------------------------------------------------------------------------
# Templates (sem framework: substituicao simples de placeholders)
# --------------------------------------------------------------------------
def _ler_template(nome):
    with open(os.path.join(TEMPLATES_DIR, nome), "r", encoding="utf-8") as f:
        return f.read()


def render(nome_template, titulo):
    cfg = store.carregar_empresa()  # empresa ativa
    head = _ler_template("base_head.html").replace("__TITULO__", titulo)
    html = _ler_template(nome_template)
    html = html.replace("__HEAD__", head)
    # O menu fica num arquivo so (base_nav.html): sao 7 telas, e manter uma
    # copia do menu em cada uma ja tinha feito paginas ficarem com a lista
    # desatualizada quando um modulo novo entrava.
    html = html.replace("__NAV__", _ler_template("base_nav.html"))
    html = html.replace("__ESCRITORIO__", _escape(ESCRITORIO))
    html = html.replace("__EMPRESA__", _escape(cfg.get("empresa", "")))
    return html


def _escape(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def _render_couto(modulo):
    """
    As quatro telas Beta saem do mesmo template.

    Sao quatro modulos para o usuario poder mexer na regra de um sem tocar
    na dos outros; a tela, essa, e a mesma - o que muda e o texto da regra,
    que vem de COUTO_TELAS.
    """
    tela = COUTO_TELAS[modulo]
    html = render("couto.html", tela["rotulo"])
    for marca, valor in (("__MODULO__", modulo),
                         ("__ROTULO__", tela["rotulo"]),
                         ("__DESCRICAO__", tela["descricao"]),
                         ("__RELATORIO__", tela["relatorio"]),
                         ("__REGRA__", tela["regra"]),
                         ("__AJUDA__", tela["ajuda"])):
        html = html.replace(marca, valor)
    return html


# --------------------------------------------------------------------------
# Parser de multipart/form-data (biblioteca padrao apenas)
# --------------------------------------------------------------------------
def parse_multipart(body, content_type):
    """
    Retorna dict campo -> lista de itens.
      item de arquivo: {"filename": str, "content": bytes}
      item de texto:   {"value": str}
    """
    m = re.search(r"boundary=(.+)$", content_type)
    if not m:
        return {}
    boundary = m.group(1).strip().strip('"')
    delim = b"--" + boundary.encode("latin-1")
    campos = {}
    # separar partes; ignorar preambulo e epilogo
    partes = body.split(delim)
    for parte in partes:
        if parte in (b"", b"--", b"--\r\n", b"\r\n"):
            continue
        if parte.startswith(b"--"):
            continue
        parte = parte.lstrip(b"\r\n")
        if b"\r\n\r\n" not in parte:
            continue
        cab_raw, conteudo = parte.split(b"\r\n\r\n", 1)
        # remover CRLF final antes do proximo boundary
        if conteudo.endswith(b"\r\n"):
            conteudo = conteudo[:-2]
        # Navegadores enviam o filename em UTF-8 no Content-Disposition.
        # Decodificar como latin-1 aqui estragaria nomes acentuados
        # (ex.: "RELATÓRIO CARTÃO CIELO...").
        cabecalhos = cab_raw.decode("utf-8", "replace")
        disp = ""
        for linha in cabecalhos.split("\r\n"):
            if linha.lower().startswith("content-disposition"):
                disp = linha
                break
        nome_m = re.search(r'name="([^"]*)"', disp)
        if not nome_m:
            continue
        nome = nome_m.group(1)
        fn_m = re.search(r'filename="([^"]*)"', disp)
        campos.setdefault(nome, [])
        if fn_m is not None:
            campos[nome].append({"filename": fn_m.group(1), "content": conteudo})
        else:
            campos[nome].append({"value": conteudo.decode("utf-8", "replace")})
    return campos


# --------------------------------------------------------------------------
# Logica de processamento dos relatorios
# --------------------------------------------------------------------------
def _rotulo_arquivo(nome, operadora):
    """
    Deriva um rotulo (filial) a partir do nome do arquivo, removendo os tokens
    padrao dos relatorios. Ex.: 'enseada Rede_Rel_Vendas_...' -> 'ENSEADA'.
    O nome e normalizado (maiusculo, sem acento) antes de cortar, para que
    'RELATORIO' e 'RELATÓRIO' sejam tratados igual.
    Se nao sobrar nada, usa o nome da operadora.
    """
    base = parsers.norm_txt(nome.rsplit(".", 1)[0])
    prefixo = re.split(r"REDE_REL|VENDAS_DETALHADO|RELATORIO", base)[0]
    prefixo = prefixo.strip(" -_").strip()
    prefixo = re.sub(r"\s+", " ", prefixo)
    if not prefixo:
        return operadora
    # Nomes tipo GUID (o Stone baixa como "58e0368e-e05f-4a3d-...") nao
    # identificam filial nenhuma: nesses casos usa o nome da operadora.
    if re.fullmatch(r"[0-9A-F][0-9A-F-]{7,}", prefixo) or len(prefixo) > 40:
        return operadora
    return prefixo


def _slug(s):
    return re.sub(r"[^A-Za-z0-9]+", "_", s or "").strip("_")


def _checar_contas(cfg, operadora, nome_arquivo):
    """
    Avisa quando alguma conta necessaria esta em branco no cadastro da empresa.
    Sem isso o CSV sairia com o codigo da conta VAZIO, quebrando a importacao
    silenciosamente.
    """
    modo = cfg.get("modo_codigo", "reduzido")
    faltando = []
    chave_cartao = core_cartao.CONTA_CARTAO_POR_OPERADORA.get(operadora)
    obrigatorias = [
        (chave_cartao, f"conta do cartao {operadora}"),
        ("clientes", "conta de Clientes"),
        ("tarifa", "conta de Despesa c/ tarifa"),
    ]
    for chave, rotulo in obrigatorias:
        if not chave:
            continue
        conta = cfg["contas"].get(chave) or {}
        if not store.codigo_conta(conta, modo):
            faltando.append(rotulo)
    if not faltando:
        return []
    return [f"'{nome_arquivo}': cadastre em /cadastro a " + ", a ".join(faltando)
            + f" da empresa '{cfg.get('empresa', '')}' — sem isso o CSV sai com "
              "o codigo da conta em branco."]


def processar_arquivos(itens_arquivo, modo, empresa_slug_sel):
    """
    itens_arquivo: lista de {"filename", "content"}.
    modo: 'reduzido' | 'classificacao' (sobrepoe o modo do cadastro para esta geracao).
    empresa_slug_sel: slug da empresa escolhida na tela (define o de-para de contas).

    Gera UM CSV POR ARQUIVO (uma filial por arquivo). Tambem monta um CSV
    consolidado (conveniencia). Retorna dict JSON-serializavel e registra cada
    CSV no cache com seu proprio token.
    """
    cfg = store.carregar_empresa(empresa_slug_sel or None)
    if modo in ("reduzido", "classificacao"):
        cfg["modo_codigo"] = modo

    empresa_slug = _slug(cfg.get("empresa", "empresa")) or "empresa"
    avisos = []
    arquivos_out = []
    dados_consolidado = {}
    tot = {"arquivos": 0, "bruto": 0.0, "tarifa": 0.0, "liquido": 0.0, "lancamentos": 0}

    tmp_dir = os.path.join(DADOS_DIR, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    for it in itens_arquivo:
        nome = it.get("filename") or "arquivo.xlsx"
        conteudo = it.get("content") or b""
        if not conteudo:
            continue
        caminho = os.path.join(tmp_dir, "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome))
        with open(caminho, "wb") as f:
            f.write(conteudo)
        try:
            operadora, vendas = parsers.parse_arquivo(caminho)
        except ValueError as e:
            avisos.append(f"'{nome}': {e}")
            continue
        except Exception as e:  # noqa: BLE001
            avisos.append(f"'{nome}': falha ao ler ({e}).")
            continue
        finally:
            try:
                os.remove(caminho)
            except OSError:
                pass

        rotulo = _rotulo_arquivo(nome, operadora)
        avisos.extend(_checar_contas(cfg, operadora, nome))
        dados_arq = {operadora: vendas}
        resumo = core_cartao.resumo_por_operadora(dados_arq)[operadora]
        lancamentos = core_cartao.gerar_lancamentos(dados_arq, cfg)
        csv = core_cartao.csv_bytes(lancamentos)
        texto = core_cartao.montar_csv(lancamentos)
        preview = texto.split("\r\n")[:7]

        nome_csv = f"vendas_cartao_{empresa_slug}_{_slug(rotulo) or operadora}.csv"
        token = _guardar(csv, nome_csv)

        arquivos_out.append({
            "label": rotulo,
            "arquivo": nome,
            "operadora": operadora,
            "token": token,
            "csv_nome": nome_csv,
            "dias": resumo["dias"],
            "bruto": resumo["bruto"],
            "tarifa": resumo["tarifa"],
            "liquido": resumo["liquido"],
            "periodo": list(resumo["periodo"]),
            "lancamentos": resumo["lancamentos"],
            "preview": preview,
        })
        # acumular para o consolidado (por operadora)
        dados_consolidado.setdefault(operadora, []).extend(vendas)
        tot["arquivos"] += 1
        tot["bruto"] += resumo["bruto"]
        tot["tarifa"] += resumo["tarifa"]
        tot["liquido"] += resumo["liquido"]
        tot["lancamentos"] += resumo["lancamentos"]

    if not arquivos_out:
        erro = "Nenhum relatorio valido foi lido."
        if avisos:
            erro += " " + " ".join(avisos)
        return {"ok": False, "erro": erro}

    for k in ("bruto", "tarifa", "liquido"):
        tot[k] = round(tot[k], 2)

    # CSV consolidado (conveniencia): tudo junto, ordenado por data
    consolidado = None
    if len(arquivos_out) > 1:
        lanc_c = core_cartao.gerar_lancamentos(dados_consolidado, cfg)
        nome_c = f"vendas_cartao_{empresa_slug}_CONSOLIDADO.csv"
        tk = _guardar(core_cartao.csv_bytes(lanc_c), nome_c)
        consolidado = {"token": tk, "csv_nome": nome_c, "lancamentos": len(lanc_c)}

    return {
        "ok": True,
        "arquivos": arquivos_out,
        "total": tot,
        "consolidado": consolidado,
        "avisos": avisos,
        "modo": cfg["modo_codigo"],
    }


# --------------------------------------------------------------------------
# Extrato bancario
# --------------------------------------------------------------------------
# Palavras que aparecem em quase toda descricao de extrato e em quase todo
# nome de conta - casar por elas devolve lixo. Com "CONTA" na lista, buscar
# "CONTA DE TELEFONE INTERNET CLARO" para de sugerir "SAFRA CONTA VINCULADA"
# e "SUBSTITUICAO DE CONTAS".
PALAVRAS_VAGAS = {
    "CONTA", "CONTAS", "BANCO", "BANCARIA", "BANCARIO", "PAGTO", "PAGAMENTO",
    "PAGAMENTOS", "RECEBIMENTO", "RECEBIDO", "RECEBIDA", "ENVIADO", "ENVIADA",
    "TRANSF", "TRANSFERENCIA", "TRANSFERENCIAS", "VALOR", "TARIFA", "TARIFAS",
    "ELETRON", "ELETRONICO", "COBRANCA", "DINHEIRO", "DEPOSITO", "CREDITO",
    "DEBITO", "SALDO", "LTDA", "EIRELI", "COMERCIO", "COMERCIAL", "INDUSTRIA",
    "DISTRIBUIDORA", "SERVICOS", "SERVICO", "GERAL", "DIVERSOS", "DIVERSAS",
    "OUTROS", "OUTRAS", "REFERENTE", "INTERNET", "TITULARIDADE", "MESMA",
}


def _sugerir_contas(texto, cfg, limite=15):
    """
    Contas do plano que podem servir para esta descricao.

    Ranqueia pela PALAVRA MAIS LONGA que casou: "CLARO" casando vale mais que
    "CONTA" casando, e palavra vaga nao vale nada (ver PALAVRAS_VAGAS). Sem
    isso a lista vinha cheia de conta que nada tem a ver, e uma sugestao ruim
    e pior que nenhuma - convida a cadastrar errado.
    """
    alvo = parsers.norm_txt(texto)
    palavras = sorted({p for p in re.split(r"[^A-Za-z0-9]+", alvo)
                       if len(p) >= 4 and p not in PALAVRAS_VAGAS
                       and not p.isdigit()}, key=len, reverse=True)
    if not palavras:
        return []
    achados = []
    for c in (cfg.get("plano_contas") or []):
        if (c.get("tipo") or "A").upper() != "A":
            continue
        nome = parsers.norm_txt(c.get("nome"))
        melhor = 0
        for p in palavras:
            if p in nome:
                melhor = max(melhor, len(p))
        if melhor:
            achados.append((melhor, c))
    achados.sort(key=lambda x: (-x[0], x[1]["nome"]))
    return [{"codigo": c["codigo"], "nome": c["nome"],
             "classificacao": c.get("classificacao", ""), "casou": n}
            for n, c in achados[:limite]]


# As duas notas que o escritorio quis no botao do topo.
NOTAS = {"muito_bom": "Muito bom", "excelente": "Excelente"}


def guardar_avaliacao(nota, tela=""):
    """
    Guarda a nota dada no botao de avaliacao (dados/avaliacoes.json).

    Sem gravar, o botao seria so enfeite: ninguem saberia o que foi votado
    nem de que tela. O arquivo e uma lista simples, para dar para abrir e
    contar sem ferramenta nenhuma.
    """
    chave = str(nota or "").strip().lower()
    if chave not in NOTAS:
        return {"ok": False, "erro": "nota desconhecida: %r" % nota}

    caminho = os.path.join(DADOS_DIR, "avaliacoes.json")
    try:
        with open(caminho, "r", encoding="utf-8") as f:
            lista = json.load(f)
        if not isinstance(lista, list):
            lista = []
    except (OSError, ValueError):
        lista = []

    lista.append({
        "quando": time.strftime("%d/%m/%Y %H:%M:%S"),
        "nota": chave,
        "rotulo": NOTAS[chave],
        "tela": str(tela or "")[:80],
    })
    os.makedirs(DADOS_DIR, exist_ok=True)
    with open(caminho, "w", encoding="utf-8") as f:
        json.dump(lista, f, ensure_ascii=False, indent=1)

    contagem = {}
    for a in lista:
        contagem[a.get("nota")] = contagem.get(a.get("nota"), 0) + 1
    return {"ok": True, "rotulo": NOTAS[chave], "total": len(lista),
            "contagem": contagem}


def testar_depara(descricao, cfg):
    """
    Responde "esta descricao do extrato cai em que conta, e por que?".

    O de-para cadastrado e so a PRIMEIRA das quatro portas do motor (ver
    core_extrato.gerar_lancamentos): a maioria dos lancamentos e resolvida
    pelo PLANO DE CONTAS, pelo nome do favorecido. Por isso procurar so na
    tabela de de-para nao acha nada de "CLARO" - a conta dela vem do plano.
    Esta funcao percorre as quatro portas, nos dois sentidos, e diz qual
    respondeu.
    """
    texto = str(descricao or "").strip()
    modo = cfg.get("modo_codigo", "reduzido")
    contas = cfg.get("contas") or {}
    nome_de = {c["codigo"]: c["nome"] for c in (cfg.get("plano_contas") or [])}

    cod_clientes = store.codigo_conta(contas.get("clientes") or {}, modo)
    cod_pendencia = store.codigo_conta(contas.get("pendencia") or {}, modo)
    cod_pagamento = (store.codigo_conta(contas.get("extrato_pagamento") or {}, modo)
                     or cod_pendencia)
    cod_transf = store.codigo_conta(contas.get("transferencia") or {}, modo)
    raiz = core_extrato.raiz_cnpj(cfg.get("cnpj"))

    if not texto:
        return {"ok": False, "erro": "digite uma descricao do extrato."}

    item = core_extrato.casar_depara(texto, cfg.get("depara") or [])
    achada = None
    if not item:
        candidatas = core_extrato.contas_do_plano(
            cfg, fora=(cod_clientes, cod_pendencia, cod_pagamento, cod_transf))
        achada = core_extrato._casar_plano(texto, candidatas)
    mesma_tit = bool(cod_transf and not item and not achada
                     and core_extrato.e_mesma_titularidade(texto, raiz))

    def resolver(entrada):
        if item:
            conta = ((item.get("conta_recebimento") or item.get("conta"))
                     if entrada else item.get("conta"))
            return conta, "regra de De-Para: o padrao %r foi achado na descricao" \
                % item.get("padrao")
        if achada:
            return achada["codigo"], ("plano de contas: o nome da conta %r "
                                      "aparece na descricao" % achada["nome"])
        if mesma_tit:
            return cod_transf, ("mesma titularidade: o CNPJ da propria empresa "
                                "(%s) esta na descricao" % raiz)
        if entrada:
            return cod_clientes, "nenhuma regra casou - conta padrao de RECEBIMENTO"
        return cod_pagamento, "nenhuma regra casou - conta padrao de PAGAMENTO"

    saida = []
    for entrada, rotulo in ((True, "Recebimento (entrou dinheiro)"),
                            (False, "Pagamento (saiu dinheiro)")):
        conta, porque = resolver(entrada)
        saida.append({"sentido": rotulo, "conta": conta,
                      "nome": nome_de.get(conta, ""), "porque": porque,
                      "casou": bool(item or achada or mesma_tit)})

    sugestoes = _sugerir_contas(texto, cfg)
    return {"ok": True, "descricao": texto, "resultados": saida,
            "regra": item, "plano": achada, "mesma_titularidade": mesma_tit,
            "sugestoes": sugestoes}


def _classificar_uploads(itens_arquivo, tmp_dir):
    """
    Grava os arquivos enviados e separa OFX de PDF.

    Devolve (ofx, pdf, avisos), cada um como [(nome, caminho)]. Quem apaga os
    arquivos e o chamador (precisa deles ate o fim do processamento, porque o
    PDF e lido duas vezes: lancamentos e numeros declarados).
    """
    ofx, pdf, avisos = [], [], []
    for it in itens_arquivo or []:
        nome = it.get("filename") or "extrato"
        conteudo = it.get("content") or b""
        if not conteudo:
            continue
        caminho = os.path.join(tmp_dir, "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome))
        with open(caminho, "wb") as f:
            f.write(conteudo)
        # PELO CONTEUDO, nunca pela extensao: o mesmo banco manda ".OFX",
        # ".ofx" e ".pdf" com maiuscula trocada, e ha .xls que e OFX dentro.
        if parsers_ofx.detectar(caminho):
            ofx.append((nome, caminho))
        else:
            pdf.append((nome, caminho))
    return ofx, pdf, avisos


def _conferir_extrato(ext, declarados, avisos, nome):
    """
    Confere a leitura contra o que o banco DECLARA, e devolve o resultado
    para a tela.

    Duas fontes, e as duas valem:
      - o proprio OFX, quando traz o saldo de cada dia (o Safra traz);
      - o PDF da mesma conta, quando foi enviado junto (saldo anterior,
        saldo por dia, linha de totais).
    Nao havendo nenhuma das duas, isso e DITO - "conferido: 0" - em vez de
    deixar a tela sugerindo que fechou.
    """
    itens = []
    fecha = None

    cf = ext.get("conferencia") or {}
    if cf.get("tem_saldos"):
        fecha = bool(cf.get("fecha"))
        itens.append({"rotulo": cf.get("rotulo") or
                      ("Cadeia de saldos do proprio arquivo (%d dias)"
                       % cf.get("dias", 0)),
                      "fecha": fecha, "diferenca": 0.0})
        for d in (cf.get("divergencias") or [])[:20]:
            itens.append({"rotulo": "Saldo de " + d["data"], "fecha": False,
                          "calculado": d["saldo_calculado"],
                          "declarado": d["saldo_declarado"],
                          "diferenca": d["diferenca"]})

    chave = _conta_do_extrato(ext)
    meus = [d for d in declarados
            if _mesma_conta(chave, (re.sub(r"\D", "", "".join(
                re.findall(r"\d", str(d.get("arquivo") or "")))) or "",
                (d.get("banco") or "").upper()))]
    # o nome do arquivo nao e chave confiavel: casa pelos SALDOS/TOTAIS de
    # quem declara o mesmo banco, e so quando houver um unico candidato
    if not meus:
        mesmo_banco = [d for d in declarados
                       if (d.get("banco") or "").upper() == (ext.get("banco") or "").upper()]
        if len(mesmo_banco) == 1:
            meus = mesmo_banco
    if meus:
        sal = {}
        for d in meus:
            for s in d.get("saldos_dia") or []:
                sal[s["data"]] = s      # o mesmo dia em dois PDFs conta 1x
        junto = {"saldo_anterior": next((d.get("saldo_anterior") for d in meus
                                         if d.get("saldo_anterior") is not None), None),
                 "saldos_dia": list(sal.values()),
                 "totais": next((d.get("totais") for d in meus if d.get("totais")), None)}
        r = parsers_extrato_decl.conferir(ext, junto)
        if r["conferido"]:
            fecha = r["fecha"] if fecha is None else (fecha and r["fecha"])
            itens.append({"rotulo": "Numeros declarados no PDF (%d comparacoes)"
                                    % r["conferido"],
                          "fecha": r["fecha"], "diferenca": 0.0})
            itens.extend(r["divergencias"][:20])

    if not itens:
        avisos.append(
            "'%s': nao havia saldo nem total declarado para conferir a "
            "leitura (o OFX deste banco nao traz saldo diario). Mande o PDF "
            "do mesmo extrato junto para o sistema poder conferir."
            % nome)
    elif fecha is False:
        avisos.append(
            "'%s': a leitura NAO fecha com o que o banco declara — veja a "
            "conferencia antes de importar." % nome)

    return {"fecha": fecha, "itens": itens, "conferido": len(itens)}


def _conta_do_extrato(ext):
    """Chave para casar o mesmo extrato lido do OFX e do PDF."""
    return (re.sub(r"\D", "", str(ext.get("conta") or "")).lstrip("0"),
           (ext.get("banco") or "").upper())


def _mesma_conta(a, b):
    """A conta de um extrato e a mesma do outro? (uma pode vir sem digito)"""
    ca, ba = a
    cb, bb = b
    if ba and bb and ba != bb:
        return False
    if not ca or not cb:
        return False
    return ca.endswith(cb) or cb.endswith(ca) or ca[:-1] == cb or cb[:-1] == ca


def processar_extratos(itens_arquivo, empresa_slug_sel, so_periodo=True):
    """
    Le extratos bancarios, aplica o de-para e devolve UM CSV POR CONTA.
    Mesmo layout de CSV do modulo de cartao.

    ACEITA OFX E PDF, e o melhor resultado sai com OS DOIS:
      - o OFX da os LANCAMENTOS (cada um e um registro fechado, com valor e
        sinal proprios - nao ha o que reconstruir a partir do texto);
      - o PDF da os NUMEROS DECLARADOS pelo banco (saldo anterior, saldo de
        cada dia, linha de totais), e e contra eles que a leitura e conferida.
    Mandando so o PDF, ele faz os dois papeis, como antes. Mandando so o OFX,
    a conferencia usa os saldos diarios quando o proprio arquivo os traz (o
    Safra traz; o Bradesco e o Itau nao).

    so_periodo: descarta o que estiver fora do mes do proprio extrato (a
        "sobra" que o extrato mensal costuma trazer no fim - o Bradesco chega
        a imprimir um segundo extrato, com SALDO ANTERIOR proprio, embaixo do
        primeiro). Desligar so quando se QUER importar a sobra.
    """
    cfg = store.carregar_empresa(empresa_slug_sel or None)
    empresa_slug = _slug(cfg.get("empresa", "empresa")) or "empresa"
    avisos = []
    arquivos_out = []
    tot = {"arquivos": 0, "entradas": 0.0, "saidas": 0.0, "lancamentos": 0,
           "pendencia_saidas": 0, "pendencia_valor": 0.0}

    tmp_dir = os.path.join(DADOS_DIR, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    arq_ofx, arq_pdf, avs = _classificar_uploads(itens_arquivo, tmp_dir)
    avisos.extend(avs)
    caminhos = [c for _n, c in arq_ofx + arq_pdf]

    try:
        # ---- OFX: lancamentos ----
        brutos = []
        for nome, caminho in arq_ofx:
            try:
                lidos = parsers_ofx.ler_ofx(caminho, nome)
            except ValueError as e:
                avisos.append(f"'{nome}': {e}")
                continue
            except Exception as e:  # noqa: BLE001
                avisos.append(f"'{nome}': falha ao ler o OFX ({e}).")
                continue
            for e in lidos:
                if so_periodo:
                    parsers_ofx.restringir_ao_mes(e)
                brutos.append(e)
        # a mesma conta pode vir em dois arquivos (o Safra parte o mes em
        # "(01 a 15)" e "(16 a 31)", repetindo o dia da virada inteiro)
        extratos = parsers_ofx.juntar(brutos) if brutos else []
        for e in extratos:
            avisos.extend(e.get("avisos") or [])

        # ---- PDF: lancamentos quando nao houver OFX da mesma conta;
        #      numeros declarados sempre ----
        declarados = []
        for nome, caminho in arq_pdf:
            try:
                d = parsers_extrato_decl.ler_declarado(caminho, nome)
                declarados.append(d)
            except Exception as e:  # noqa: BLE001
                avisos.append(f"'{nome}': nao deu para ler o PDF ({e}).")
                continue
            # PDF QUE SERVE SO DE CONFERENTE nao precisa ser lido como
            # extrato: quando o OFX do mesmo banco ja veio, os lancamentos
            # saem dele. Sem esta checagem, o Bradesco e o Safra (que o
            # leitor de PDF nao sabe ler linha por linha) enchiam a tela de
            # "PDF nao reconhecido" mesmo tendo sido usados com sucesso na
            # conferencia.
            so_conferencia = bool(d.get("saldos_dia") or d.get("totais")) and any(
                (x.get("banco") or "").upper() == (d.get("banco") or "").upper()
                for x in extratos)
            try:
                ext = parsers_extrato.parse_extrato(caminho)
            except ValueError as e:
                if not so_conferencia:
                    avisos.append(f"'{nome}': {e}")
                continue
            except Exception as e:  # noqa: BLE001
                if not so_conferencia:
                    avisos.append(f"'{nome}': falha ao ler o PDF ({e}).")
                continue
            if any(_mesma_conta(_conta_do_extrato(ext), _conta_do_extrato(x))
                   for x in extratos):
                continue          # o OFX desta conta manda nos lancamentos
            if so_periodo:
                ext, fora = parsers_extrato.restringir_ao_periodo(ext)
                if fora:
                    avisos.append(
                        "'%s': %d lancamento(s) fora do %s foram deixados de "
                        "fora (sobra do mes seguinte que o extrato traz no "
                        "fim; eles voltam no extrato do proximo mes). Total "
                        "deixado de fora: R$ %s."
                        % (nome, len(fora), ext.get("criterio_periodo", "periodo"),
                           _brl_simples(sum(abs(l["valor"]) for l in fora))[3:]))
            ext.setdefault("arquivo", nome)
            ext.setdefault("saldos_dia", [])
            ext.setdefault("conferencia", {"tem_saldos": False})
            extratos.append(ext)

        arquivos_out, avs2, tot = _lancar_extratos(
            extratos, declarados, cfg, empresa_slug)
        avisos.extend(avs2)
    finally:
        for c in caminhos:
            try:
                os.remove(c)
            except OSError:
                pass

    if not arquivos_out:
        erro = "Nenhum extrato valido foi lido."
        if avisos:
            erro += " " + " ".join(avisos)
        return {"ok": False, "erro": erro}
    return {"ok": True, "arquivos": arquivos_out, "total": tot,
            "avisos": avisos}


def _lancar_extratos(extratos, declarados, cfg, empresa_slug):
    """Gera os lancamentos e o CSV de cada conta, com a conferencia."""
    avisos = []
    arquivos_out = []
    tot = {"arquivos": 0, "entradas": 0.0, "saidas": 0.0, "lancamentos": 0,
           "pendencia_saidas": 0, "pendencia_valor": 0.0}

    for ext in extratos:
        nome = ext.get("arquivo") or "extrato"
        banco_cad = core_extrato.achar_banco(cfg, ext["banco"], ext["agencia"],
                                             ext["conta"])
        if not banco_cad:
            avisos.append(
                f"'{nome}': o banco {ext['banco']} agencia {ext['agencia']} conta "
                f"{ext['conta']} nao esta cadastrado em Regra — cadastre a conta "
                f"contabil dele, senao o CSV sai sem a conta do banco.")
        elif not banco_cad.get("conta_contabil"):
            avisos.append(
                f"'{nome}': o banco {ext['banco']} esta cadastrado em Regra mas "
                f"SEM conta contabil.")
        if not store.codigo_conta(cfg["contas"].get("pendencia") or {},
                                  cfg.get("modo_codigo", "reduzido")):
            avisos.append(
                "Cadastre em Regra a conta de PENDENCIA/RECLASSIFICAR — os "
                "pagamentos nao identificados ficariam sem conta.")

        lanc, nid = core_extrato.gerar_lancamentos(ext, cfg, banco_cad)
        if not lanc:
            avisos.append(f"'{nome}': nenhum lancamento encontrado no extrato.")
            continue
        resumo = core_extrato.resumo(ext, lanc, nid)
        csv = core_extrato.csv_bytes(lanc)
        preview = core_extrato.montar_csv(lanc).split("\r\n")[:7]

        conf = _conferir_extrato(ext, declarados, avisos, nome)

        rotulo = f"{ext['banco']} {ext['conta']}".strip()
        nome_csv = f"extrato_{empresa_slug}_{_slug(rotulo)}.csv"
        token = _guardar(csv, nome_csv)

        # SEGUNDO FORMATO: o arquivo de colunas entre barras que o escritorio
        # ja usa para importar (ver core_importacao_txt). Os dois saem sempre
        # do MESMO lancamento - quem escolhe o formato e quem baixa.
        nome_txt = nome_csv[:-4] + "_PAGAR.txt"
        token_txt = _guardar(
            core_importacao_txt.bytes_txt(
                lanc, cfg.get("cnpj"),
                core_importacao_txt.filiais_dos_bancos(cfg)),
            nome_txt, "text/plain; charset=windows-1252")

        arquivos_out.append({
            "label": rotulo,
            "arquivo": nome,
            "banco": ext["banco"],
            "token": token,
            "csv_nome": nome_csv,
            "token_txt": token_txt,
            "txt_nome": nome_txt,
            "preview": preview,
            # os 40 primeiros nao identificados de SAIDA (para virar de-para)
            "pendentes": [n for n in nid if n["tipo"] == "SAIDA"][:40],
            # COMPOSICAO: todos os lancamentos que formam o CSV, para a tela
            # mostrar exatamente o que esta sendo baixado.
            "composicao": [
                {"data": l["data"], "debito": l["debito"], "credito": l["credito"],
                 "valor": l["valor"], "historico": l["historico"],
                 "tipo": "ENTRADA" if l["_ord"] == 0 else "SAIDA"}
                for l in lanc
            ],
            # CONFERENCIA contra o que o banco declara (ver
            # _conferir_extrato). E o que responde "os saldos batem?".
            "conferencia": conf,
            **resumo,
        })
        tot["arquivos"] += 1
        tot["entradas"] += resumo["total_entradas"]
        tot["saidas"] += resumo["total_saidas"]
        tot["lancamentos"] += resumo["lancamentos"]
        tot["pendencia_saidas"] += resumo["pendencia_saidas"]
        tot["pendencia_valor"] += resumo["pendencia_valor"]

    for k in ("entradas", "saidas", "pendencia_valor"):
        tot[k] = round(tot[k], 2)
    tot["movimento"] = round(tot["entradas"] - tot["saidas"], 2)
    return arquivos_out, avisos, tot


# --------------------------------------------------------------------------
# FISCAL - Receita Financeira
# --------------------------------------------------------------------------
# Rubricas que o relatorio do fiscal tem mas que NAO saem de nenhum destes
# arquivos - o usuario preenche a mao. Avisar e obrigatorio: sem o aviso, um
# total menor passa por completo.
MANUAIS_RECEITA = [
    "DISTRIBUICAO DE SOBRAS (Sicredi) — nao sai dos arquivos lidos aqui.",
    "Rendimentos de aplicacao de outros bancos (fora Itau e Bradesco).",
]


def processar_receita_financeira(itens_arquivo, empresa_slug_sel, competencia):
    """
    Le os titulos pagos/recebidos e os extratos de aplicacao do mes, soma as
    rubricas de receita financeira e devolve UM CSV com a apuracao.
    """
    cfg = store.carregar_empresa(empresa_slug_sel or None)
    empresa_slug = _slug(cfg.get("empresa", "empresa")) or "empresa"
    avisos = []
    lidos = []

    tmp_dir = os.path.join(DADOS_DIR, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    for it in itens_arquivo:
        nome = it.get("filename") or "arquivo"
        conteudo = it.get("content") or b""
        if not conteudo:
            continue
        caminho = os.path.join(tmp_dir, "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome))
        with open(caminho, "wb") as f:
            f.write(conteudo)
        try:
            lidos.append(parsers_fiscal.ler_arquivo(caminho, nome))
        except ValueError as e:
            avisos.append(f"'{nome}': {e}")
        except Exception as e:  # noqa: BLE001
            avisos.append(f"'{nome}': falha ao ler ({e}).")
        finally:
            try:
                os.remove(caminho)
            except OSError:
                pass

    if not lidos:
        erro = "Nenhum arquivo valido foi lido."
        if avisos:
            erro += " " + " ".join(avisos)
        return {"ok": False, "erro": erro}

    divergentes = core_fiscal.divergencia_de_competencia(lidos)
    if divergentes:
        avisos.append(
            "Os arquivos sao de competencias diferentes (" +
            ", ".join(divergentes) + ") — confira se nao entrou arquivo de "
            "outro mes na pilha.")

    apuracao = core_fiscal.apurar(lidos)
    # Rubrica sem NENHUM arquivo sai zerada e o CSV nao denuncia isso - o
    # relatorio do fiscal ficaria a menos por um arquivo esquecido na pilha.
    for chave, rotulo in core_fiscal.RUBRICAS:
        if not apuracao["por_rubrica"][chave]:
            avisos.append(f"Nenhum arquivo alimentou '{rotulo}' — a rubrica "
                          f"ficou ZERADA no CSV. Faltou soltar o arquivo?")
    comp = (competencia or "").strip() or apuracao["competencia"]
    csv = core_fiscal.csv_bytes(apuracao, comp)

    nome_csv = f"{empresa_slug}_{core_fiscal.nome_arquivo(comp)}"
    token = _guardar(csv, nome_csv)

    # Planilha no MODELO DO FISCAL - e o que o escritorio envia. O CSV
    # continua saindo, para quem prefere importar.
    planilha, detalhe = core_fiscal.planilha_bytes(apuracao, cfg, comp)
    nome_xlsx = core_fiscal.nome_arquivo_xlsx(comp)
    token_xlsx = _guardar(planilha, nome_xlsx, TIPO_XLSX)
    if not cfg.get("cnpj"):
        avisos.append("A empresa esta sem CNPJ no cadastro — a planilha do "
                      "fiscal sai com o campo CNPJ em branco.")
    if not (cfg.get("instituicoes") or []):
        avisos.append("Nenhuma instituicao financeira cadastrada — a planilha "
                      "sai sem as linhas de rendimento e sem os CNPJs.")
    if detalhe["sem_cnpj"]:
        avisos.append("Sem CNPJ cadastrado: " + ", ".join(detalhe["sem_cnpj"]) +
                      ". O fiscal exige o CNPJ da instituicao em cada linha "
                      "de rendimento.")

    # As mesmas linhas do CSV baixado, para a tela mostrar exatamente o que vai
    # no arquivo (rubrica, valor) sem o usuario precisar abrir o CSV.
    csv_linhas = [l.split(";") for l in core_fiscal.montar_csv(apuracao, comp)
                  .split("\r\n") if l.count(";") == 1]
    csv_linhas = [l for l in csv_linhas if l[0] != core_fiscal.CABECALHO.split(";")[0]]

    return {"ok": True, "apuracao": apuracao, "competencia": comp,
            "token": token, "csv_nome": nome_csv, "csv_linhas": csv_linhas,
            "token_xlsx": token_xlsx, "xlsx_nome": nome_xlsx,
            "planilha": detalhe,
            "lidos": len(lidos), "manuais": MANUAIS_RECEITA, "avisos": avisos}


# --------------------------------------------------------------------------
# ROTINAS - Estoque Citel
# --------------------------------------------------------------------------
def _ler_inventarios(itens_arquivo, tmp_dir, rotulo):
    """Le uma pilha de inventarios do Citel. Devolve (inventarios, avisos)."""
    inventarios, avisos = [], []
    for it in itens_arquivo or []:
        nome = it.get("filename") or "inventario"
        conteudo = it.get("content") or b""
        if not conteudo:
            continue
        caminho = os.path.join(tmp_dir, "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome))
        with open(caminho, "wb") as f:
            f.write(conteudo)
        try:
            inventarios.append(parsers_estoque.ler_inventario(caminho, nome))
        except ValueError as e:
            avisos.append(f"[{rotulo}] '{nome}': {e}")
        except Exception as e:  # noqa: BLE001
            avisos.append(f"[{rotulo}] '{nome}': falha ao ler ({e}).")
        finally:
            try:
                os.remove(caminho)
            except OSError:
                pass
    return inventarios, avisos


def processar_estoque(itens_arquivo, empresa_slug_sel, competencia,
                      itens_inicial=None, manuais=None):
    """
    Apuracao do estoque do mes: le os inventarios do Citel do estoque FINAL
    (um por filial) e, opcionalmente, os do estoque INICIAL (o inventario do
    mes anterior), e devolve a planilha de conferencia + o CSV de lancamentos.

    Os valores tambem podem ser DIGITADOS (manuais), por filial - util quando
    nao se tem o relatorio do Citel daquele lado. Valor digitado tem
    prioridade sobre o relatorio (ver core_estoque_apuracao).
    """
    import io as _io

    cfg = store.carregar_empresa(empresa_slug_sel or None)
    empresa_slug = _slug(cfg.get("empresa", "empresa")) or "empresa"
    filiais_cad = cfg.get("estoque_filiais") or []
    avisos = []

    tmp_dir = os.path.join(DADOS_DIR, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    inventarios, avs = _ler_inventarios(itens_arquivo, tmp_dir, "estoque final")
    avisos.extend(avs)
    inventarios_ini, avs = _ler_inventarios(itens_inicial, tmp_dir, "estoque inicial")
    avisos.extend(avs)

    tem_manual = any((v or {}).get("inicial") is not None or (v or {}).get("final") is not None
                     for v in (manuais or {}).values())
    if not inventarios and not inventarios_ini and not tem_manual:
        erro = ("Nenhum inventario valido foi lido e nenhum valor foi digitado.")
        if avisos:
            erro += " " + " ".join(avisos)
        return {"ok": False, "erro": erro}

    divergentes = core_estoque.divergencia_de_competencia(inventarios)
    if divergentes:
        avisos.append("Os inventarios sao de competencias diferentes (" +
                      ", ".join(divergentes) + ") — confira se nao entrou "
                      "arquivo de outro mes na pilha.")

    # Duas filiais iguais na mesma pilha = o mesmo estoque contado 2x no total.
    vistas = {}
    for inv in inventarios:
        chave = (inv.get("codigo_empresa") or inv.get("filial") or "").upper()
        vistas.setdefault(chave, []).append(inv.get("arquivo", ""))
    for chave, arquivos in vistas.items():
        if len(arquivos) > 1:
            avisos.append(f"A filial '{chave}' veio em {len(arquivos)} arquivos "
                          f"({', '.join(arquivos)}) — o total esta contando "
                          f"esse estoque mais de uma vez.")

    abas, resumo = core_estoque.montar(inventarios, filiais_cad, competencia)
    if resumo["sem_conta"]:
        avisos.append("Sem conta contabil no cadastro: " +
                      ", ".join(resumo["sem_conta"]) +
                      ". A planilha sai com a coluna CONTA em branco nessas "
                      "filiais — cadastre em 'Contas do estoque'.")

    # --- apuracao (estoque inicial x final) + lancamentos ---
    comp = resumo["competencia"] or (competencia or "").strip()
    contas_ap = core_estoque_apuracao.contas_da_apuracao(cfg)
    saldos, avs = core_estoque_apuracao.montar_saldos(
        inventarios, inventarios_ini, filiais_cad, manuais)
    avisos.extend(avs)
    lancamentos, avs = core_estoque_apuracao.gerar_lancamentos(saldos, comp, contas_ap)
    avisos.extend(avs)
    apuracao = core_estoque_apuracao.resumo_apuracao(saldos, lancamentos)
    apuracao["contas"] = contas_ap

    # A aba de conferencia vai na FRENTE das demais: e ela que responde a
    # pergunta do usuario ("o que foi lancado e de onde saiu cada numero").
    abas = [core_estoque_apuracao.aba_apuracao(saldos, lancamentos, comp, contas_ap)] + abas

    buf = _io.BytesIO()
    core_estoque.escrever(buf, abas)
    nome_xlsx = f"{empresa_slug}_{core_estoque.nome_arquivo(comp)}"
    token = _guardar(buf.getvalue(), nome_xlsx, TIPO_XLSX)

    token_csv = nome_csv = None
    if lancamentos:
        nome_csv = f"{empresa_slug}_{core_estoque_apuracao.nome_csv(comp)}"
        token_csv = _guardar(core_estoque_apuracao.csv_bytes(lancamentos), nome_csv)

    return {"ok": True, "resumo": resumo, "token": token,
            "arquivo_nome": nome_xlsx, "lidos": len(inventarios),
            "lidos_inicial": len(inventarios_ini),
            "saldos": saldos, "lancamentos": lancamentos, "apuracao": apuracao,
            "token_csv": token_csv, "csv_nome": nome_csv,
            "avisos": avisos}


# --------------------------------------------------------------------------
# ESTOQUE PRECITO - "Demonstrativo Estoque" (matriz loja x mes)
# --------------------------------------------------------------------------
def processar_estoque_precito(itens_arquivo, empresa_slug_sel, competencia):
    """
    Le o Demonstrativo Estoque (uma linha por loja, uma coluna por mes) e
    lanca A COMPETENCIA PEDIDA.

    A competencia e OBRIGATORIA e vem digitada: o layout nao muda de mes para
    mes, so ganha mais uma coluna preenchida, e adivinhar "a ultima coluna com
    valor" lancaria o mes errado se alguem adiantar um numero.
    """
    cfg = store.carregar_empresa(empresa_slug_sel or None)
    empresa_slug = _slug(cfg.get("empresa", "empresa")) or "empresa"
    avisos = []

    tmp_dir = os.path.join(DADOS_DIR, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    dados = None
    for it in itens_arquivo or []:
        nome = it.get("filename") or "estoque.xlsx"
        conteudo = it.get("content") or b""
        if not conteudo:
            continue
        caminho = os.path.join(tmp_dir, "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome))
        with open(caminho, "wb") as f:
            f.write(conteudo)
        try:
            dados = parsers_estoque_precito.ler_estoque(caminho, nome)
        except ValueError as e:
            avisos.append(f"'{nome}': {e}")
        except Exception as e:  # noqa: BLE001
            avisos.append(f"'{nome}': falha ao ler ({e}).")
        finally:
            try:
                os.remove(caminho)
            except OSError:
                pass
        if dados:
            break

    if not dados:
        erro = "Nenhum demonstrativo de estoque valido foi lido."
        if avisos:
            erro += " " + " ".join(avisos)
        return {"ok": False, "erro": erro}

    comp = (competencia or "").strip()
    if not re.match(r"^\d{2}/\d{4}$", comp):
        return {"ok": False,
                "erro": "Informe a competencia a lancar no formato mm/aaaa "
                        "(a planilha tem varios meses; meses com valor: %s)."
                        % ", ".join(parsers_estoque_precito.meses_preenchidos(dados))}

    try:
        r = core_estoque_precito.apurar(dados, comp, cfg)
    except ValueError as e:
        return {"ok": False, "erro": str(e)}
    avisos.extend(r["avisos"])

    token = nome_csv = token_txt = nome_txt = None
    if r["lancamentos"]:
        nome_csv = core_estoque_precito.nome_csv(empresa_slug, comp)
        token = _guardar(core_estoque_precito.csv_bytes(r["lancamentos"]),
                         nome_csv)
        nome_txt = nome_csv[:-4] + "_PAGAR.txt"
        # cada lancamento ja carrega a filial da loja (ver core_importacao_txt)
        token_txt = _guardar(
            core_importacao_txt.bytes_txt(r["lancamentos"], cfg.get("cnpj")),
            nome_txt, "text/plain; charset=windows-1252")

    return {"ok": True, "arquivo": dados["arquivo"],
            "meses": dados["meses"],
            "meses_preenchidos": parsers_estoque_precito.meses_preenchidos(dados),
            "resumo": r["resumo"], "linhas": r["linhas"],
            "lancamentos": r["lancamentos"], "conferencia": r["conferencia"],
            "token": token, "csv_nome": nome_csv,
            "token_txt": token_txt, "txt_nome": nome_txt,
            "avisos": avisos}


# --------------------------------------------------------------------------
# HAC - os quatro relatorios tratados pela rotina de integracao
# --------------------------------------------------------------------------
# Sao quatro modulos separados de proposito: cada relatorio tem a sua regra
# de leitura, e so olhando um de cada vez da para dizer se a regra esta
# certa. O que cada tela diz de si mesma fica aqui, junto - o texto e a
# regra sao a mesma coisa vista de dois lados.
COUTO_TELAS = {
    "pagamentos": {
        "rotulo": "Beta - Pagamentos",
        "relatorio": "TITULOS PAGOS",
        "descricao": "Titulos pagos, ja tratados pela rotina de integracao: "
                     "um lancamento por titulo, na conta do fornecedor.",
        "regra": "D a conta do fornecedor / C o banco do portador. "
                 "<b>Nao lanca</b> as contas do ERP marcadas como "
                 "&ldquo;so banco&rdquo; (a taxa de cartao) &mdash; essas "
                 "entram pelo Banco Sistema.",
        "ajuda": """
      <p>Le o relatorio <b>TITULOS PAGOS</b> (por portador da baixa ou por
        filial, tanto faz &mdash; o modulo acha o cabecalho pelos nomes das
        colunas, nao pela posicao).</p>
      <h4>O lancamento</h4>
      <p><b>D</b> a conta do fornecedor &nbsp;/&nbsp; <b>C</b> a conta
        corrente do banco daquele arquivo.</p>
      <p>A conta do fornecedor sai, <b>nesta ordem</b>: do de-para do
        fornecedor (pelo CNPJ), do de-para da conta do ERP, e por ultimo da
        conta de pendencia. A ordem importa &mdash; dois fornecedores da
        mesma conta do ERP podem ter contas contabeis diferentes, entao o
        de-para do fornecedor tem de ganhar do da conta do ERP.</p>
      <h4>O que ele NAO lanca</h4>
      <p>As contas do ERP marcadas como <b>so banco</b>. A taxa de cartao e
        o caso classico: ela aparece aqui e tambem no Banco Sistema, e
        lancar as duas dobraria a despesa. Em 08/2026 eram 68 titulos na
        Matriz &mdash; exatamente os 68 que o Banco Sistema lanca.</p>
      <h4>Conferencia</h4>
      <p>O relatorio fecha com o bloco <b>MODALIDADES</b> (dinheiro, cartao,
        cheque emitido, cheque repassado, ordem de pagamento). A soma do que
        foi lido tem de bater com ele, e o que foi lancado mais o que ficou
        para o Banco Sistema tem de dar o total. As duas provas aparecem na
        tela; se alguma nao passar, o modulo <b>avisa</b> em vez de entregar
        lancamento errado.</p>""",
    },
    "recebimentos": {
        "rotulo": "Beta - Recebimentos",
        "relatorio": "TITULOS RECEBIDOS",
        "descricao": "Titulos recebidos, ja tratados: baixa do cliente com "
                     "os juros separados em conta propria.",
        "regra": "D o banco (ou a conta de cobranca, quando o historico diz "
                 "<b>REF. AGRUPAMENTO</b>) / C clientes pelo liquido, e os "
                 "<b>juros em conta propria</b>.",
        "ajuda": """
      <p>Le o relatorio <b>TITULOS RECEBIDOS</b>, que o tratamento ja deixa
        so com boleto.</p>
      <h4>O lancamento &mdash; duas ou tres pernas</h4>
      <ul>
        <li><b>D</b> o banco, ou a conta de cobranca &mdash; o valor recebido;</li>
        <li><b>C</b> clientes &mdash; o valor recebido <b>menos os juros</b>;</li>
        <li><b>C</b> juros recebidos &mdash; os juros, quando houver.</li>
      </ul>
      <p>Os juros sao perna propria porque o <b>VR.REC ja vem com eles
        dentro</b>. Jogar o valor inteiro contra clientes baixaria do cliente
        mais do que ele devia, e a receita de juros nunca apareceria.</p>
      <h4>Banco ou cobranca</h4>
      <p>Quem decide e o <b>historico</b>: &ldquo;REF. AGRUPAMENTO&rdquo; vai
        para a conta de cobranca (o boleto ainda nao caiu no banco);
        &ldquo;REFERENTE A FATURAMENTO&rdquo; vai direto para o banco. Os 574
        titulos da Matriz em 08/2026 se dividem em 459 e 115 &mdash; nao ha
        um terceiro caso.</p>
      <h4>Conferencia</h4>
      <p>Este relatorio <b>nao tem rodape proprio</b>, e o modulo diz isso em
        vez de fingir que conferiu. As provas que ele faz sao internas: a
        soma dos lancamentos contra a soma do VR.REC lido, e os juros
        separados contra a soma da coluna VR.JUROS. A conferencia de verdade
        e o confronto com o Banco Sistema do mesmo portador.</p>""",
    },
    "banco_sistema": {
        "rotulo": "Beta - Banco Sistema",
        "relatorio": "BANCO SISTEMA",
        "descricao": "A conta corrente do ERP &mdash; so o que ainda nao "
                     "veio pelos titulos pagos e recebidos.",
        "regra": "Debito entra so quando o historico <b>nao</b> comeca com "
                 "&ldquo;Pag.&rdquo;; credito entra menos o "
                 "&ldquo;ESTORNO BX. CT. PAGAR&rdquo;.",
        "ajuda": """
      <p>Le a <b>conta corrente do ERP</b>. Ela tem tudo: o mesmo pagamento
        que esta nos Titulos Pagos tambem esta aqui. Lancar os dois contaria
        a despesa duas vezes, entao este modulo lanca <b>so o que sobra</b>.</p>
      <h4>A divisao</h4>
      <ul>
        <li><b>Debito</b> (saiu dinheiro): entra so o que <b>nao</b> comeca
          com &ldquo;Pag.&nbsp;&rdquo; &mdash; o que comeca ja foi lancado
          pelos Titulos Pagos. Excecao: as contas do ERP marcadas como
          <b>so banco</b> entram mesmo assim, porque elas nao saem nos
          titulos.</li>
        <li><b>Credito</b> (entrou dinheiro): entra tudo, menos
          &ldquo;ESTORNO BX. CT. PAGAR&rdquo;.</li>
      </ul>
      <p>Essa regra foi conferida linha a linha contra o que a integracao ja
        gerou em 08/2026: <b>5.042 de 5.051 linhas</b>, 99,8%. Os 9 casos em
        que as duas discordaram sao todos estorno de centavos.</p>
      <h4>Conferencia</h4>
      <p>O rodape do relatorio declara <b>portador, saldo anterior, valor
        debito, valor credito e saldo final</b>. O modulo compara a soma que
        leu com esses numeros e refaz a cadeia do saldo.</p>
      <div class="pcalerta" style="margin-top:10px"><span>&#9888;</span><span>
        Este relatorio costuma sair filtrado por <b>&ldquo;Opcao:
        CONCILIADOS&rdquo;</b>. Quando ha movimento nao conciliado, a
        listagem vem incompleta e o rodape nao bate &mdash; foi assim que
        apareceram R$&nbsp;238.116,79 de credito faltando no SISTEMA DINHEIRO
        de 08/2026. O modulo <b>avisa</b>; nao engole.</span></div>""",
    },
    "resumo_caixa": {
        "rotulo": "Beta - Resumo de Caixa",
        "relatorio": "RESUMO DE CAIXA",
        "descricao": "O caixa da loja &mdash; so o que passou em dinheiro.",
        "regra": "<b>So a forma DINHEIRO.</b> Positivo: D caixa da loja / C "
                 "a contrapartida. Negativo e transferencia: o contrario. "
                 "Cartao e ordem de pagamento entram pelos relatorios deles.",
        "ajuda": """
      <p>Le o <b>RESUMO DE CAIXA</b> da loja. O arquivo tem varias tabelas
        emendadas (operacoes, dados informativos, relacao de creditos,
        duplicatas emitidas...); o modulo le so a primeira e <b>para</b> no
        primeiro titulo de secao &mdash; as outras tambem tem coluna de data
        e virariam lancamento se ele nao parasse.</p>
      <h4>So o dinheiro</h4>
      <p>O relatorio mostra tudo que passou pelo balcao, mas so o
        <b>dinheiro</b> pertence a conta de caixa da loja: o cartao vira
        credito a receber na administradora e a ordem de pagamento cai direto
        no banco. Lancar as tres formas aqui triplicaria a receita.</p>
      <p>Conferido nas quatro lojas em 08/2026 contra o que a integracao
        gerou: <b>880</b> entradas na Matriz, <b>262</b> na Enseada,
        <b>598</b> em Santo Antonio e <b>333</b> em Santos &mdash; os mesmos
        numeros, nas quatro.</p>
      <h4>O valor NAO e a coluna VALOR</h4>
      <p>A coluna <b>VALOR</b> e o total do documento, e nele entra tambem o
        credito que o cliente usou. Numa linha da Matriz o VALOR e
        <b>-0,40</b> e o VLR.CRED. e <b>-247,65</b>: quem lancasse o VALOR
        perderia R$&nbsp;247,25 de movimento. O que vale e a
        <b>coluna da forma</b>.</p>
      <h4>Conferencia</h4>
      <p>O relatorio fecha com o bloco <b>RESUMO POR FORMA</b>, que declara
        forma a forma o mesmo movimento que a tabela detalha. E o melhor
        rodape dos quatro: nos quatro Resumos de 08/2026 as <b>20 celulas</b>
        bateram na casa do centavo. O modulo ainda prova que o que entrou no
        caixa e igual ao que saiu.</p>""",
    },
}


def _regras_couto(cfg):
    """As regras deste cliente, com o que ja esta no cadastro geral dentro."""
    r = core_couto.regras_de(cfg)
    contas = cfg.get("contas") or {}
    modo = cfg.get("modo_codigo", "reduzido")
    for chave_regra, chave_cadastro in (("clientes", "clientes"),
                                        ("pendencia", "pendencia"),
                                        ("transferencia", "transferencia")):
        if not r["contas"].get(chave_regra):
            r["contas"][chave_regra] = store.codigo_conta(
                contas.get(chave_cadastro) or {}, modo)
    return r


def _couto_faltando(modulo, regras):
    """O que precisa estar cadastrado para este modulo lancar direito."""
    precisa = {
        "pagamentos": ("pendencia",),
        "recebimentos": ("clientes", "juros_recebidos", "cobranca"),
        "banco_sistema": ("pendencia",),
        "resumo_caixa": ("clientes", "pendencia"),
    }.get(modulo, ())
    faltando = [k for k in precisa if not regras["contas"].get(k)]
    if modulo == "resumo_caixa" and not (regras.get("caixas") or {}):
        faltando.append("conta de caixa das lojas")
    return faltando


def _aprender_couto(modulo, leituras, txt, cfg, regras, empresa_slug_sel):
    """
    Cadastra os de-paras a partir do TXT que o Ottimizza ja gerou.

    As contas proprias (o banco de cada arquivo, o caixa de cada loja) sao
    passadas para o aprendizado saber qual dos dois lados do lancamento e a
    conta que interessa - a outra e sempre a mesma e nao ensina nada.
    """
    proprias = set()
    for leitura in leituras:
        banco = core_couto._conta_banco(cfg, leitura)
        if banco:
            proprias.add(str(banco.get("conta_contabil") or ""))
        caixa = (regras.get("caixas") or {}).get(leitura.get("filial") or "")
        if caixa:
            proprias.add(str(caixa))

    novos, ambiguos = {}, []
    casados = sem_par = sem_hist = 0
    grupo = ""
    for leitura in leituras:
        a = core_couto.aprender(
            modulo, leitura, txt, regras, proprias,
            nao_ensinam=(regras["contas"].get("pendencia"),))
        grupo = a["grupo"] or grupo
        casados += a["casados"]
        sem_par += a["sem_par"]
        sem_hist += a["sem_historico"]
        for chave, conta in a["novos"].items():
            if chave in novos and novos[chave] != conta:
                ambiguos.append({"chave": chave,
                                 "contas": {novos[chave]: 1, conta: 1}})
                novos.pop(chave, None)
            elif chave not in {x["chave"] for x in ambiguos}:
                novos[chave] = conta
        ambiguos.extend(a["ambiguos"])

    avisos = []
    if not grupo:
        avisos.append("O modulo de %s nao tem de-para para aprender: as "
                      "contas dele sao fixas, cadastradas em Regras e contas."
                      % core_couto.ROTULO_DO_MODULO.get(modulo, modulo))
        return None, avisos

    if novos:
        cfg_atual = store.carregar_empresa(empresa_slug_sel or None)
        couto = dict(cfg_atual.get("couto") or {})
        couto[grupo] = dict(couto.get(grupo) or {}, **novos)
        cfg_atual["couto"] = couto
        store.salvar_empresa(empresa_slug_sel or None, cfg_atual)
    if ambiguos:
        avisos.append(
            "%d chave(s) apareceram no TXT com MAIS DE UMA conta e NAO foram "
            "cadastradas: %s. Cadastrar a mais frequente esconderia a duvida "
            "justamente onde ela importa - resolva em Regras e contas."
            % (len(ambiguos),
               "; ".join("%s -> %s" % (a["chave"], "/".join(a["contas"]))
                         for a in ambiguos[:6])))
    if sem_hist:
        avisos.append(
            "%d linha(s) tinham data e valor iguais a um lancamento do TXT "
            "mas o historico dele nao citava o nome da linha - nao viraram "
            "regra. Casar so por data e valor ja pos lancamento na conta "
            "errada antes." % sem_hist)
    return {"grupo": grupo, "cadastradas": len(novos), "casados": casados,
            "ambiguas": len(ambiguos), "sem_par": sem_par,
            "sem_historico": sem_hist,
            "amostra": [{"chave": k, "conta": v}
                        for k, v in list(novos.items())[:12]]}, avisos


def processar_couto(itens_arquivo, empresa_slug_sel, competencia, modulo):
    """
    Le os relatorios enviados e apura pelo modulo pedido.

    Um arquivo que nao for do tipo deste modulo e RECUSADO com o nome dele.
    Aceitar em silencio seria pior que recusar: o Titulos Pagos e o Banco
    Sistema trazem o mesmo pagamento, e o modulo errado lancaria em dobro.
    """
    cfg = store.carregar_empresa(empresa_slug_sel or None)
    empresa_slug = _slug(cfg.get("empresa", "empresa")) or "empresa"
    tipo_esperado = core_couto.TIPO_DO_MODULO.get(modulo)
    if not tipo_esperado:
        return {"ok": False, "erro": "modulo desconhecido: %s" % modulo}
    regras = _regras_couto(cfg)
    avisos = []

    tmp_dir = os.path.join(DADOS_DIR, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    # Os TXT do Ottimizza vem junto com os relatorios: eles nao sao lidos
    # como movimento, e sim como GABARITO - as contas que ja foram usadas
    # neles viram de-para antes da apuracao rodar.
    txt_ottimizza = []
    planilhas = []
    for it in itens_arquivo or []:
        nome = (it.get("filename") or "").lower()
        if nome.endswith(".txt"):
            txt_ottimizza.extend(
                core_couto.ler_txt_ottimizza(it.get("content") or b""))
        else:
            planilhas.append(it)

    # 1a passada: LER. A apuracao so vem depois porque o TXT do Ottimizza
    # pode cadastrar de-paras, e eles precisam valer ja nesta rodada.
    leituras = []
    for it in planilhas:
        nome = it.get("filename") or "relatorio.xlsx"
        conteudo = it.get("content") or b""
        if not conteudo:
            continue
        caminho = os.path.join(tmp_dir,
                               "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome))
        with open(caminho, "wb") as f:
            f.write(conteudo)
        try:
            tipo = parsers_couto.detectar(caminho)
            if not tipo:
                avisos.append("'%s': nao e nenhum dos quatro relatorios "
                              "tratados - ficou de fora." % nome)
                continue
            if tipo != tipo_esperado:
                avisos.append(
                    "'%s' e um relatorio de %s, e esta tela e a de %s - ficou "
                    "de fora. Leve-o para o modulo dele; os dois trazem o "
                    "mesmo movimento e lancar aqui dobraria o valor."
                    % (nome, tipo, tipo_esperado))
                continue
            leituras.append(parsers_couto.ler(caminho, nome))
        except ValueError as e:
            avisos.append("'%s': %s" % (nome, e))
        except Exception as e:  # noqa: BLE001
            avisos.append("'%s': falha ao ler (%s)." % (nome, e))
        finally:
            try:
                os.remove(caminho)
            except OSError:
                pass

    if not leituras:
        erro = "Nenhum relatorio de %s valido foi lido." % tipo_esperado
        if avisos:
            erro += " " + " ".join(avisos)
        return {"ok": False, "erro": erro}

    aprendizado = None
    if txt_ottimizza:
        aprendizado, aviso_apr = _aprender_couto(
            modulo, leituras, txt_ottimizza, cfg, regras, empresa_slug_sel)
        avisos.extend(aviso_apr)
        regras = _regras_couto(store.carregar_empresa(empresa_slug_sel or None))

    # 2a passada: APURAR, ja com o que o TXT ensinou
    lancamentos, linhas, conferencia, resumos = [], [], [], []
    for leitura in leituras:
        r = core_couto.apurar(leitura, cfg, regras)
        lancamentos.extend(r["lancamentos"])
        linhas.extend(r["linhas"])
        conferencia.extend(r["conferencia"])
        avisos.extend(r["avisos"])
        resumos.append(r["resumo"])

    token = nome_csv = token_txt = nome_txt = None
    if lancamentos:
        nome_csv = core_couto.nome_csv(empresa_slug, modulo, competencia)
        token = _guardar(core_couto.csv_bytes(lancamentos), nome_csv)
        nome_txt = nome_csv[:-4] + ".txt"
        token_txt = _guardar(
            core_importacao_txt.bytes_txt(lancamentos, cfg.get("cnpj")),
            nome_txt, "text/plain; charset=windows-1252")

    resumo = {
        "modulo": core_couto.ROTULO_DO_MODULO.get(modulo, modulo),
        "linhas_lidas": sum(r["linhas_lidas"] for r in resumos),
        "linhas_lancadas": sum(r["linhas_lancadas"] for r in resumos),
        "lancamentos": len(lancamentos),
        "total": round(sum(l["valor"] for l in lancamentos), 2),
        "arquivos": len(resumos),
        "fecha": bool(lancamentos) and all(c["fecha"] for c in conferencia),
    }
    return {"ok": True, "resumo": resumo, "arquivos": resumos,
            "aprendizado": aprendizado,
            "conferencia": conferencia, "linhas": linhas,
            "lancamentos": lancamentos, "token": token, "csv_nome": nome_csv,
            "token_txt": token_txt, "txt_nome": nome_txt, "avisos": avisos}


# --------------------------------------------------------------------------
# FORNECEDORES - Posicao contabil de contas a pagar (uma por filial)
# --------------------------------------------------------------------------
def processar_fornecedores(itens_arquivo, empresa_slug_sel, competencia):
    """
    Le as POSICOES CONTABEIS DE CONTAS A PAGAR (uma por filial) e devolve a
    planilha de consolidacao.

    POR ENQUANTO SO LE E CONSOLIDA - nao gera lancamento nem faz conciliacao;
    as regras serao combinadas depois. Por isso nao ha CSV aqui.
    """
    cfg = store.carregar_empresa(empresa_slug_sel or None)
    empresa = cfg.get("empresa") or "empresa"
    avisos = []

    tmp_dir = os.path.join(DADOS_DIR, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    relatorios = []
    for it in itens_arquivo or []:
        nome = it.get("filename") or "relatorio"
        conteudo = it.get("content") or b""
        if not conteudo:
            continue
        caminho = os.path.join(tmp_dir, "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome))
        with open(caminho, "wb") as f:
            f.write(conteudo)
        try:
            relatorios.append(parsers_fornecedores.ler_posicao(caminho, nome))
        except ValueError as e:
            avisos.append(f"'{nome}': {e}")
        except Exception as e:  # noqa: BLE001
            avisos.append(f"'{nome}': falha ao ler ({e}).")
        finally:
            try:
                os.remove(caminho)
            except OSError:
                pass

    if not relatorios:
        erro = "Nenhuma posicao contabil de contas a pagar foi lida."
        if avisos:
            erro += " " + " ".join(avisos)
        return {"ok": False, "erro": erro}

    res = core_fornecedores.consolidar(relatorios)
    avisos.extend(res["avisos"])

    comp = (competencia or "").strip()
    nome_xlsx = core_fornecedores.nome_arquivo(empresa, comp)
    token = _guardar(core_fornecedores.planilha_bytes(res, empresa, comp),
                     nome_xlsx, TIPO_XLSX)

    return {"ok": True, "token": token, "arquivo_nome": nome_xlsx,
            "lidos": len(relatorios), "resumo": res["resumo"],
            "filiais": [{k: v for k, v in f.items() if k != "itens"}
                        for f in res["filiais"]],
            "aging": res["aging"],
            "fornecedores": res["fornecedores"][:50],
            "avisos": avisos}


# --------------------------------------------------------------------------
# AUDITORIA - Depreciacao (Resumo da Depreciacao Fiscal x Balancete)
# --------------------------------------------------------------------------
def _ler_um(item, tmp_dir, rotulo_esperado, detectar, ler, detectar_outro,
           rotulo_outro):
    """
    Le UM upload de um campo dedicado (nao mais uma pilha misturada), mas
    ainda confere o CONTEUDO: um campo dedicado evita que os dois arquivos
    se misturem, mas nao impede o usuario de soltar o arquivo errado no
    campo certo - se acontecer, o aviso diz exatamente qual foi o engano em
    vez de um erro generico.
    Devolve (dados_lidos_ou_None, aviso_ou_None).
    """
    nome = item.get("filename") or "arquivo.pdf"
    conteudo = item.get("content") or b""
    if not conteudo:
        return None, None
    caminho = os.path.join(tmp_dir, "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome))
    with open(caminho, "wb") as f:
        f.write(conteudo)
    try:
        if detectar(caminho):
            return ler(caminho, nome), None
        if detectar_outro(caminho):
            return None, (f"'{nome}' parece ser {rotulo_outro}, nao "
                          f"{rotulo_esperado} — solte no campo certo.")
        return None, f"'{nome}': nao parece {rotulo_esperado}."
    except ValueError as e:
        return None, f"'{nome}': {e}"
    except Exception as e:  # noqa: BLE001
        return None, f"'{nome}': falha ao ler ({e})."
    finally:
        try:
            os.remove(caminho)
        except OSError:
            pass


def processar_aud_depreciacao(item_resumo, item_balancete, empresa_slug_sel):
    """
    Recebe o 'Resumo da Depreciacao Fiscal' e o 'Balancete' (PDF, CADA UM NO
    SEU PROPRIO CAMPO de upload) e devolve o quadro de conciliacao: o que
    bate e o que nao bate.
    """
    empresa_slug = _slug(store.carregar_empresa(empresa_slug_sel or None)
                         .get("empresa", "empresa")) or "empresa"
    avisos = []

    tmp_dir = os.path.join(DADOS_DIR, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    resumo = balancete = None
    if item_resumo:
        resumo, aviso = _ler_um(
            item_resumo, tmp_dir, "o Resumo da Depreciacao Fiscal",
            parsers_depreciacao.detectar, parsers_depreciacao.ler_resumo,
            parsers_balancete.detectar, "um Balancete")
        if aviso:
            avisos.append(aviso)
    if item_balancete:
        balancete, aviso = _ler_um(
            item_balancete, tmp_dir, "um Balancete",
            parsers_balancete.detectar, parsers_balancete.ler_balancete,
            parsers_depreciacao.detectar, "o Resumo da Depreciacao Fiscal")
        if aviso:
            avisos.append(aviso)

    if not resumo or not balancete:
        faltou = []
        if not resumo:
            faltou.append("o Resumo da Depreciacao Fiscal")
        if not balancete:
            faltou.append("o Balancete")
        erro = "Faltou " + " e ".join(faltou) + "."
        if avisos:
            erro += " " + " ".join(avisos)
        return {"ok": False, "erro": erro}

    resultado = core_auditoria_depreciacao.conciliar(resumo, balancete)
    avisos.extend(resultado["avisos"])

    planilha = core_auditoria_depreciacao.planilha_bytes(resultado, resumo, balancete)
    nome_xlsx = f"{empresa_slug}_" + core_auditoria_depreciacao.nome_arquivo(
        resumo.get("empresa", ""), resumo.get("competencia", ""))
    token = _guardar(planilha, nome_xlsx, TIPO_XLSX)

    return {"ok": True, "quadro": resultado["quadro"], "avisos": avisos,
            "token": token, "arquivo_nome": nome_xlsx,
            "resumo_info": {"empresa": resumo.get("empresa", ""),
                            "cnpj": resumo.get("cnpj", ""),
                            "competencia": resumo.get("competencia", ""),
                            "arquivo": resumo["arquivo"]},
            "balancete_info": {"empresa": balancete.get("empresa", ""),
                               "cnpj": balancete.get("cnpj", ""),
                               "periodo": balancete.get("periodo", ""),
                               "arquivo": balancete["arquivo"],
                               "total_contas": len(balancete["contas"])}}


# --------------------------------------------------------------------------
# AUDITORIA - Extrato Bancario (Extratos + Aplicacoes x Balancete)
# --------------------------------------------------------------------------
def _ler_varios_extratos(itens_por_tipo, tmp_dir):
    """
    Le os arquivos de extrato/aplicacao respeitando O CAMPO em que cada um
    foi solto.

    itens_por_tipo: [("corrente", [itens...]), ("aplicacao", [itens...])].

    DUAS REGRAS, as duas por causa de erro real:

    1. CADA ARQUIVO E LIDO UMA VEZ SO. O mesmo PDF solto nos dois campos
       (natural, porque o extrato do Itau traz a conta corrente E a aplicacao)
       era lido duas vezes e gerava registros em dobro: no balancete a segunda
       copia nao achava conta livre e aparecia como "verificar", e o total do
       grupo saia dobrado (R$ 640.591,47 no lugar de R$ 320.710,69). A chave e
       o CONTEUDO, nao o nome - o mesmo arquivo com nome diferente tambem cai
       fora.

    2. O CAMPO MANDA. Um arquivo solto em "Extratos bancarios" entra so como
       conta corrente; solto em "Aplicacoes", so como aplicacao. Antes o campo
       era enfeite (o tipo saia do conteudo), e quem enviava so a aplicacao
       via aparecer tambem a linha da conta corrente, que nao tinha pedido.
       Nada some calado: se o arquivo traz a outra metade, sai um aviso
       dizendo qual e o valor e em que campo solta-lo.

    Devolve (lista_de_registros, [avisos]).
    """
    import hashlib

    registros, avisos = [], []
    lidos = {}          # hash do conteudo -> registros lidos daquele arquivo
    tipos_pedidos = {}  # hash -> {"corrente", "aplicacao"}
    nomes = {}          # hash -> nome do primeiro envio
    ordem = []

    ROTULO_CAMPO = {"corrente": "Extratos bancarios", "aplicacao": "Aplicacoes"}

    for tipo, itens in itens_por_tipo:
        for item in itens:
            nome = item.get("filename") or "arquivo.pdf"
            conteudo = item.get("content") or b""
            if not conteudo:
                continue
            chave = hashlib.sha1(conteudo).hexdigest()
            tipos_pedidos.setdefault(chave, set()).add(tipo)
            if chave in lidos:
                continue                     # ja foi lido: nao le de novo
            nomes[chave] = nome
            ordem.append(chave)

            caminho = os.path.join(tmp_dir, "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome))
            with open(caminho, "wb") as f:
                f.write(conteudo)
            try:
                lidos[chave] = list(parsers_extrato_saldo.ler_extrato(caminho, nome))
            except ValueError as e:
                lidos[chave] = []
                if parsers_balancete.detectar(caminho):
                    avisos.append(f"'{nome}' parece ser um Balancete, nao um "
                                  f"extrato/aplicacao — solte no campo do Balancete.")
                else:
                    avisos.append(f"'{nome}': {e}")
            except Exception as e:  # noqa: BLE001
                lidos[chave] = []
                avisos.append(f"'{nome}': falha ao ler ({e}).")
            finally:
                try:
                    os.remove(caminho)
                except OSError:
                    pass

    for chave in ordem:
        pedidos = tipos_pedidos.get(chave) or set()
        for reg in lidos.get(chave, []):
            if reg["tipo"] in pedidos:
                registros.append(reg)
            elif abs(reg.get("saldo_final") or 0.0) > 0.005:
                # a outra metade do arquivo tem saldo e ficou de fora: avisa,
                # com o valor e o campo onde solta-lo, em vez de sumir calado
                avisos.append(
                    "'%s' tambem traz %s de %s. Nao entrou na conferencia porque "
                    "o arquivo foi solto so no campo '%s' — se quiser conferir "
                    "esse saldo, solte o mesmo arquivo tambem em '%s'."
                    % (nomes.get(chave, "arquivo"),
                       "saldo de aplicacao" if reg["tipo"] == "aplicacao"
                       else "saldo de conta corrente",
                       _brl_simples(reg.get("saldo_final")),
                       ", ".join(sorted(ROTULO_CAMPO[t] for t in pedidos)) or "?",
                       ROTULO_CAMPO.get(reg["tipo"], reg["tipo"])))
    return registros, avisos


def _brl_simples(v):
    if v is None:
        return "-"
    return "R$ " + ("{:,.2f}".format(v).replace(",", "\x00")
                    .replace(".", ",").replace("\x00", "."))


def processar_aud_extrato(itens_extrato, itens_aplicacao, item_balancete,
                          empresa_slug_sel):
    """
    Recebe os extratos bancarios (contas correntes), as aplicacoes
    (investimentos automaticos) e o Balancete, cada categoria no seu campo de
    upload, e devolve a conciliacao: consolidado por grupo (Extrato Bancario
    x Aplicacao) e o detalhe banco a banco.
    """
    cfg = store.carregar_empresa(empresa_slug_sel or None)
    empresa_slug = _slug(cfg.get("empresa", "empresa")) or "empresa"
    avisos = []

    tmp_dir = os.path.join(DADOS_DIR, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    registros, avs = _ler_varios_extratos(
        [("corrente", itens_extrato or []), ("aplicacao", itens_aplicacao or [])],
        tmp_dir)
    avisos.extend(avs)

    balancete = None
    if item_balancete:
        balancete, aviso = _ler_um(
            item_balancete, tmp_dir, "um Balancete",
            parsers_balancete.detectar, parsers_balancete.ler_balancete,
            parsers_extrato_saldo.detectar, "um extrato/aplicacao")
        if aviso:
            avisos.append(aviso)

    if not registros or not balancete:
        faltou = []
        if not registros:
            faltou.append("ao menos um extrato ou aplicacao")
        if not balancete:
            faltou.append("o Balancete")
        erro = "Faltou " + " e ".join(faltou) + "."
        if avisos:
            erro += " " + " ".join(avisos)
        return {"ok": False, "erro": erro}

    resultado = core_auditoria_extrato.conciliar(
        registros, balancete, (cfg or {}).get("bancos"))
    avisos.extend(resultado["avisos"])

    planilha = core_auditoria_extrato.planilha_bytes(resultado, balancete)
    nome_xlsx = f"{empresa_slug}_" + core_auditoria_extrato.nome_arquivo(
        balancete.get("empresa", ""), balancete.get("periodo", ""))
    token = _guardar(planilha, nome_xlsx, TIPO_XLSX)

    return {"ok": True, "grupos": resultado["grupos"], "avisos": avisos,
            "token": token, "arquivo_nome": nome_xlsx,
            "lidos": {"extrato_aplicacao": len(registros)},
            "balancete_info": {"empresa": balancete.get("empresa", ""),
                               "cnpj": balancete.get("cnpj", ""),
                               "periodo": balancete.get("periodo", ""),
                               "arquivo": balancete["arquivo"],
                               "total_contas": len(balancete["contas"])}}


# --------------------------------------------------------------------------
# AUDITORIA - Taxa Cartao (relatorios de vendas de cartao x Balancete)
# --------------------------------------------------------------------------
def processar_aud_cartao(itens_relatorios, item_balancete, empresa_slug_sel):
    """
    Recebe os relatorios de vendas de cartao (GetNet/Rede/Cielo/Stone - o
    mesmo parsers.py do modulo CONTABIL, xlsx ou PDF) e o Balancete, e
    devolve a conciliacao: por operadora (vendas) e o total de tarifa,
    contra as contas JA CADASTRADAS em /cadastro para esta empresa.
    """
    cfg = store.carregar_empresa(empresa_slug_sel or None)
    empresa_slug = _slug(cfg.get("empresa", "empresa")) or "empresa"
    avisos = []

    tmp_dir = os.path.join(DADOS_DIR, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    dados_por_operadora = {}
    for it in itens_relatorios:
        nome = it.get("filename") or "arquivo"
        conteudo = it.get("content") or b""
        if not conteudo:
            continue
        caminho = os.path.join(tmp_dir, "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome))
        with open(caminho, "wb") as f:
            f.write(conteudo)
        try:
            operadora, vendas = parsers.parse_arquivo(caminho)
            dados_por_operadora.setdefault(operadora, []).extend(vendas)
        except ValueError as e:
            avisos.append(f"'{nome}': {e}")
        except Exception as e:  # noqa: BLE001
            avisos.append(f"'{nome}': falha ao ler ({e}).")
        finally:
            try:
                os.remove(caminho)
            except OSError:
                pass

    balancete = None
    if item_balancete:
        balancete, aviso = _ler_um(
            item_balancete, tmp_dir, "um Balancete",
            parsers_balancete.detectar, parsers_balancete.ler_balancete,
            lambda c: parsers.detectar_operadora(c) is not None,
            "um relatorio de vendas de cartao")
        if aviso:
            avisos.append(aviso)

    if not dados_por_operadora or not balancete:
        faltou = []
        if not dados_por_operadora:
            faltou.append("ao menos um relatorio de vendas de cartao")
        if not balancete:
            faltou.append("o Balancete")
        erro = "Faltou " + " e ".join(faltou) + "."
        if avisos:
            erro += " " + " ".join(avisos)
        return {"ok": False, "erro": erro}

    resumo = core_cartao.resumo_por_operadora(dados_por_operadora)
    resultado = core_auditoria_cartao.conciliar(resumo, cfg, balancete)
    avisos.extend(resultado["avisos"])

    planilha = core_auditoria_cartao.montar_planilha(
        resultado, cfg.get("empresa", ""), balancete.get("periodo", ""))
    nome_xlsx = f"{empresa_slug}_" + core_auditoria_cartao.nome_arquivo(
        cfg.get("empresa", ""), balancete.get("periodo", ""))
    token = _guardar(planilha, nome_xlsx, TIPO_XLSX)

    return {"ok": True, "quadro": resultado["quadro"], "avisos": avisos,
            "token": token, "arquivo_nome": nome_xlsx,
            "resumo_relatorios": resumo,
            "balancete_info": {"empresa": balancete.get("empresa", ""),
                               "cnpj": balancete.get("cnpj", ""),
                               "periodo": balancete.get("periodo", ""),
                               "arquivo": balancete["arquivo"],
                               "total_contas": len(balancete["contas"])}}


# --------------------------------------------------------------------------
# AUDITORIA - Fiscal (Resumo por Acumulador, por filial, x Balancete)
#
# Diferente das outras auditorias (upload -> resultado, tudo descartado
# depois), esta e' COM ESTADO: os arquivos enviados ficam salvos por
# competencia (para o "reaproveitamento automatico" quando o usuario deixa
# um campo vazio num reenvio) e o resultado de cada competencia fica salvo
# para reabrir depois ("Paineis ja gerados"), sem precisar subir tudo de
# novo so para OLHAR um periodo ja processado.
# --------------------------------------------------------------------------
def _pasta_fiscal_uploads(slug, periodo):
    return os.path.join(FISCAL_DIR, slug, "uploads", periodo)


def _pasta_fiscal_resultados(slug):
    return os.path.join(FISCAL_DIR, slug, "resultados")


def _fiscal_periodos_disponiveis(slug):
    base = _pasta_fiscal_resultados(slug)
    if not os.path.isdir(base):
        return []
    return sorted((p[:-5] for p in os.listdir(base) if p.endswith(".json")), reverse=True)


def _fiscal_arquivos_ja_enviados(slug, periodo):
    """{'509': [caminhos .xls], ..., 'balancete': [caminho .pdf]} ja salvos
    numa rodada anterior para esta competencia."""
    up_dir = _pasta_fiscal_uploads(slug, periodo)
    out = {}
    if not os.path.isdir(up_dir):
        return out
    for nome in os.listdir(up_dir):
        sub = os.path.join(up_dir, nome)
        if not os.path.isdir(sub):
            continue
        arquivos = sorted(os.path.join(sub, f) for f in os.listdir(sub)
                          if f.lower().endswith((".xls", ".pdf")))
        if arquivos:
            out[nome] = arquivos
    return out


def _fiscal_ler_resultado(slug, periodo):
    caminho = os.path.join(_pasta_fiscal_resultados(slug), periodo + ".json")
    if not os.path.exists(caminho):
        return None
    with open(caminho, "r", encoding="utf-8") as f:
        return json.load(f)


def _fiscal_gerar_e_salvar(slug, cfg, periodo, competencia, arquivos_por_filial, caminho_balancete):
    """Le os .xls por filial + o balancete, roda a conciliacao, persiste o
    cadastro (se ganhou acumulador novo) e grava o resultado da competencia."""
    itens_por_filial = {}
    avisos = []
    for filial, caminhos in arquivos_por_filial.items():
        itens_filial = []
        for caminho in caminhos:
            r = parsers_acumulador.ler_itens(caminho)
            itens_filial.extend(r["itens"])
        itens_por_filial[filial] = itens_filial

    balancete = parsers_balancete.ler_balancete(caminho_balancete)
    cadastro = cfg.setdefault("fiscal_acumuladores", {})
    resultado = core_auditoria_fiscal.processar(itens_por_filial, cadastro, balancete)
    if resultado["cadastro_mudou"]:
        store.salvar_empresa(slug, cfg)

    # O trabalho de REVISAO (linha conferida + observacao) sobrevive ao
    # reprocessamento: reenviar um arquivo ou mexer no cadastro de
    # acumuladores nao pode apagar o que o contador ja revisou a mao.
    anterior = _fiscal_ler_resultado(slug, periodo) or {}
    validacoes = anterior.get("validacoes") or {}
    core_auditoria_fiscal.aplicar_validacoes(resultado["confrontacoes"], validacoes)
    resultado["resumo"]["validadas"] = sum(
        1 for c in resultado["confrontacoes"] if c.get("validado"))

    planilha = core_auditoria_fiscal.montar_planilha(resultado, cfg.get("empresa", ""), competencia)
    nome_xlsx = f"{_slug(cfg.get('empresa', 'empresa'))}_" + core_auditoria_fiscal.nome_arquivo(
        cfg.get("empresa", ""), competencia)
    token = _guardar(planilha, nome_xlsx, TIPO_XLSX)

    saida = {"empresa": cfg.get("empresa", ""), "periodo": periodo, "competencia": competencia,
             "filiais": sorted(arquivos_por_filial.keys(), key=lambda x: int(x) if x.isdigit() else 0),
             "pendencias": resultado["pendencias"], "confrontacoes": resultado["confrontacoes"],
             "resumo": resultado["resumo"], "validacoes": validacoes,
             "avisos": avisos + resultado["avisos"],
             "balancete_info": {"empresa": balancete.get("empresa", ""),
                                "periodo": balancete.get("periodo", ""),
                                "total_contas": len(balancete["contas"])},
             "token": token, "arquivo_nome": nome_xlsx}

    saida_dir = _pasta_fiscal_resultados(slug)
    os.makedirs(saida_dir, exist_ok=True)
    with open(os.path.join(saida_dir, periodo + ".json"), "w", encoding="utf-8") as f:
        json.dump(saida, f, ensure_ascii=False, indent=2)
    return saida


def _fiscal_regenerar_existentes(slug, cfg):
    """Depois de editar o cadastro de acumuladores, re-roda TODA competencia
    que ja tem arquivos salvos - sem isso o painel antigo ficaria mostrando
    numeros de antes da edicao."""
    up_base = os.path.join(FISCAL_DIR, slug, "uploads")
    if not os.path.isdir(up_base):
        return []
    atualizados = []
    for periodo in os.listdir(up_base):
        arquivos = _fiscal_arquivos_ja_enviados(slug, periodo)
        caminho_balancete = (arquivos.get("balancete") or [None])[0]
        arquivos_por_filial = {k: v for k, v in arquivos.items() if k != "balancete"}
        if not arquivos_por_filial or not caminho_balancete:
            continue
        competencia = f"{periodo[:2]}/{periodo[2:]}"
        _fiscal_gerar_e_salvar(slug, cfg, periodo, competencia, arquivos_por_filial, caminho_balancete)
        atualizados.append(competencia)
    return atualizados


def processar_aud_fiscal(itens_acumuladores, item_balancete, mes, ano, empresa_slug_sel):
    slug = empresa_slug_sel or store.empresa_ativa_slug()
    cfg = store.carregar_empresa(slug)
    mes = (mes or "").strip().zfill(2)
    ano = (ano or "").strip()
    if not re.match(r"^(0[1-9]|1[0-2])$", mes) or not re.match(r"^\d{4}$", ano):
        return {"ok": False, "erro": "Mes/ano invalidos."}
    periodo = mes + ano
    competencia = f"{mes}/{ano}"

    up_dir = _pasta_fiscal_uploads(slug, periodo)
    os.makedirs(up_dir, exist_ok=True)
    ja_enviados_antes = _fiscal_arquivos_ja_enviados(slug, periodo)
    avisos = []

    novos_por_filial = {}
    for item in itens_acumuladores:
        nome = item.get("filename") or ""
        conteudo = item.get("content") or b""
        if not conteudo:
            continue
        filial = parsers_acumulador.identificar_filial(nome)
        if not filial:
            avisos.append(f"Nao consegui identificar a filial pelo nome do arquivo "
                          f"'{nome}' (precisa ter \"Empresa <codigo>\" no nome) — ignorado.")
            continue
        novos_por_filial.setdefault(filial, []).append((nome, conteudo))

    arquivos_por_filial = {}
    for filial, infos in novos_por_filial.items():
        sub = os.path.join(up_dir, filial)
        os.makedirs(sub, exist_ok=True)
        for antigo in os.listdir(sub):
            os.remove(os.path.join(sub, antigo))
        caminhos = []
        for i, (nome, conteudo) in enumerate(infos, start=1):
            caminho = os.path.join(sub, f"{i}.xls")
            with open(caminho, "wb") as f:
                f.write(conteudo)
            caminhos.append(caminho)
        arquivos_por_filial[filial] = caminhos

    for filial, caminhos in ja_enviados_antes.items():
        if filial == "balancete" or filial in arquivos_por_filial:
            continue
        arquivos_por_filial[filial] = caminhos

    if not arquivos_por_filial:
        erro = "Envie ao menos um Resumo por Acumulador (.xls)."
        if avisos:
            erro += " " + " ".join(avisos)
        return {"ok": False, "erro": erro}

    conteudo_bal = (item_balancete or {}).get("content") or b""
    if conteudo_bal:
        sub = os.path.join(up_dir, "balancete")
        os.makedirs(sub, exist_ok=True)
        for antigo in os.listdir(sub):
            os.remove(os.path.join(sub, antigo))
        caminho_balancete = os.path.join(sub, "1.pdf")
        with open(caminho_balancete, "wb") as f:
            f.write(conteudo_bal)
    elif "balancete" in ja_enviados_antes:
        caminho_balancete = ja_enviados_antes["balancete"][0]
    else:
        erro = "Envie o Balancete do periodo (nunca foi enviado nesta competencia)."
        if avisos:
            erro += " " + " ".join(avisos)
        return {"ok": False, "erro": erro}

    try:
        saida = _fiscal_gerar_e_salvar(slug, cfg, periodo, competencia,
                                       arquivos_por_filial, caminho_balancete)
    except ValueError as e:
        return {"ok": False, "erro": str(e)}
    saida["avisos"] = avisos + saida["avisos"]
    return {"ok": True, **saida}


def processar_aud_fiscal_acumuladores(empresa_slug_sel, filial, acumuladores):
    """Salva as contas (debito/credito) e o 'desconsiderar' de UMA filial e
    re-roda toda competencia ja processada (o cadastro mudou, o painel
    antigo nao pode continuar mostrando o numero de antes)."""
    slug = empresa_slug_sel or store.empresa_ativa_slug()
    cfg = store.carregar_empresa(slug)
    mapa = cfg.setdefault("fiscal_acumuladores", {}).setdefault(filial, {})
    for cod, info in (acumuladores or {}).items():
        atual = mapa.setdefault(cod, {"descricao": "", "conta_d": None,
                                      "conta_c": None, "desconsiderar": False})
        atual["conta_d"] = (info.get("conta_d") or "").strip() or None
        atual["conta_c"] = (info.get("conta_c") or "").strip() or None
        atual["desconsiderar"] = bool(info.get("desconsiderar"))
    salvo = store.salvar_empresa(slug, cfg)
    atualizados = _fiscal_regenerar_existentes(slug, salvo)
    return {"ok": True, "atualizados": atualizados}


def processar_aud_fiscal_validacoes(empresa_slug_sel, periodo, validacoes):
    """
    Grava a revisao do contador (linha conferida + observacao) de UMA
    competencia e devolve o painel ja atualizado. Nao re-le arquivo nenhum:
    a revisao e' opiniao sobre numeros que ja estao calculados, entao
    reprocessar aqui so gastaria tempo e poderia mudar o numero embaixo do
    que a pessoa acabou de revisar.
    """
    slug = empresa_slug_sel or store.empresa_ativa_slug()
    resultado = _fiscal_ler_resultado(slug, periodo)
    if resultado is None:
        return {"ok": False, "erro": f"Nao ha painel gerado para {periodo}."}

    guardadas = resultado.setdefault("validacoes", {})
    for cod, info in (validacoes or {}).items():
        guardadas[str(cod)] = {"validado": bool((info or {}).get("validado")),
                               "observacao": str((info or {}).get("observacao") or "").strip()}
    core_auditoria_fiscal.aplicar_validacoes(resultado["confrontacoes"], guardadas)
    resultado.setdefault("resumo", {})["validadas"] = sum(
        1 for c in resultado["confrontacoes"] if c.get("validado"))

    cfg = store.carregar_empresa(slug)
    planilha = core_auditoria_fiscal.montar_planilha(
        resultado, cfg.get("empresa", ""), resultado.get("competencia", ""))
    resultado["token"] = _guardar(planilha, resultado["arquivo_nome"], TIPO_XLSX)

    caminho = os.path.join(_pasta_fiscal_resultados(slug), periodo + ".json")
    with open(caminho, "w", encoding="utf-8") as f:
        json.dump(resultado, f, ensure_ascii=False, indent=2)
    return {"ok": True, **resultado}


# --------------------------------------------------------------------------
# GRUPO MAGNOJET - tratamento e conciliacao de pagos/recebidos x extrato
# --------------------------------------------------------------------------
def processar_magnojet(item_pagos, item_recebidos, item_extrato, competencia,
                       empresa_slug_sel):
    """
    Le os tres relatorios da rotina (contas pagas, contas recebidas e o
    extrato bancario), concilia cada lado contra o extrato e devolve as duas
    planilhas finais + o log de auditoria.
    """
    cfg = store.carregar_empresa(empresa_slug_sel or None)
    empresa = cfg.get("empresa", "") or "EMPRESA"
    avisos = []

    tmp_dir = os.path.join(DADOS_DIR, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    def _salvar(item, sufixo):
        nome = item.get("filename") or ("arquivo" + sufixo)
        caminho = os.path.join(tmp_dir, "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome))
        with open(caminho, "wb") as f:
            f.write(item.get("content") or b"")
        return nome, caminho

    faltou = [r for r, it in (("as contas pagas", item_pagos),
                              ("as contas recebidas", item_recebidos),
                              ("o extrato bancario", item_extrato))
              if not (it or {}).get("content")]
    if faltou:
        return {"ok": False, "erro": "Faltou " + " e ".join(faltou) + "."}

    caminhos = []
    try:
        nome_p, cam_p = _salvar(item_pagos, ".xlsx")
        nome_r, cam_r = _salvar(item_recebidos, ".xlsx")
        nome_e, cam_e = _salvar(item_extrato, ".pdf")
        caminhos = [cam_p, cam_r, cam_e]

        try:
            extrato = parsers_extrato_mov.ler_extrato(cam_e, nome_e)
        except ValueError as e:
            return {"ok": False, "erro": f"'{nome_e}': {e}"}
        avisos.extend(extrato["avisos"])
        # Extracao que nao fecha com o total do proprio extrato invalida tudo
        # o que viesse depois - melhor parar aqui do que conciliar contra uma
        # base bancaria incompleta.
        if extrato["avisos"]:
            return {"ok": False, "erro": " ".join(extrato["avisos"]) +
                    " Nao atualizei os controles: confira o extrato."}

        try:
            pagos = parsers_financeiro.ler_baixas(cam_p, nome_p)
            recebidos = parsers_financeiro.ler_baixas(cam_r, nome_r)
        except ValueError as e:
            return {"ok": False, "erro": str(e)}
    finally:
        for c in caminhos:
            try:
                os.remove(c)
            except OSError:
                pass

    comp = (competencia or "").strip() or extrato["competencia"]
    debitos = [m for m in extrato["movimentos"] if m["natureza"] == "D"]
    creditos = [m for m in extrato["movimentos"] if m["natureza"] == "C"]

    # O codigo do banco sai da coluna "Bco" do controle; quando ela vem
    # vazia (acontece nos pagamentos de alguns relatorios), a reserva e' o
    # layout do proprio extrato - nunca a agencia ou a conta.
    reserva = extrato.get("banco_sugerido", "")
    banco = (core_magnojet_saida.codigo_banco_do_controle(recebidos["registros"])
             or core_magnojet_saida.codigo_banco_do_controle(pagos["registros"])
             or reserva)

    saida = {}
    for fluxo, dados, movs in (("pagamentos", pagos, debitos),
                               ("recebimentos", recebidos, creditos)):
        r = core_magnojet_saida.processar_fluxo(dados, movs, fluxo,
                                                codigo_banco=banco)
        nome_xlsx = xlsx_magnojet.nome_arquivo(empresa, fluxo, comp)
        aba = "Pagamentos" if fluxo == "pagamentos" else "Recebimentos"
        token = _guardar(xlsx_magnojet.bytes_da_planilha(r["linhas"], aba),
                         nome_xlsx, TIPO_XLSX)
        saida[fluxo] = {"resumo": r["resumo"], "pendencias": r["pendencias"],
                        "previa": r["linhas"][:25], "token": token,
                        "arquivo_nome": nome_xlsx, "log": r["log"]}

    # log tecnico de auditoria (item 14 da rotina): fica disponivel para
    # download, mas nao polui a planilha final
    auditoria = {
        "empresa": empresa, "competencia": comp,
        "banco": saida["pagamentos"]["resumo"]["banco"],
        "agencia": extrato["agencia"], "conta": extrato["conta"],
        "periodo_extrato": list(extrato["periodo"]),
        "arquivos": {"pagos": nome_p, "recebidos": nome_r, "extrato": nome_e},
        "extrato": {"movimentos": len(extrato["movimentos"]),
                    "creditos": extrato["total_creditos"] / 100.0,
                    "debitos": extrato["total_debitos"] / 100.0},
        "pagamentos": saida["pagamentos"]["log"],
        "recebimentos": saida["recebimentos"]["log"],
    }
    token_log = _guardar(
        json.dumps(auditoria, ensure_ascii=False, indent=2).encode("utf-8"),
        f"auditoria_{_slug(empresa)}_{comp.replace('/', '-')}.json",
        "application/json; charset=utf-8")

    for f in ("pagamentos", "recebimentos"):
        saida[f].pop("log", None)

    return {"ok": True, "competencia": comp, "avisos": avisos,
            "identificacao": {
                "empresa": empresa, "banco": saida["pagamentos"]["resumo"]["banco"],
                "banco_nome": saida["pagamentos"]["resumo"]["banco_nome"],
                "agencia": extrato["agencia"], "conta": extrato["conta"],
                "periodo": " a ".join(x for x in extrato["periodo"] if x),
                "movimentos": len(extrato["movimentos"]),
                "creditos": round(extrato["total_creditos"] / 100.0, 2),
                "debitos": round(abs(extrato["total_debitos"]) / 100.0, 2)},
            "pagamentos": saida["pagamentos"],
            "recebimentos": saida["recebimentos"],
            "token_log": token_log}


# --------------------------------------------------------------------------
# APLICACAO DIARIA (extrato de aplicacao automatica -> lancamentos)
# --------------------------------------------------------------------------
def processar_aplicacao(itens_arquivo, empresa_slug_sel, banco, competencia):
    """
    Le o extrato da aplicacao automatica (PDF ou xlsx - o mesmo relatorio) e
    devolve os lancamentos + o CSV de importacao. Varios arquivos sao
    SOMADOS num CSV so (o mesmo mes pode vir partido por produto/conta).
    """
    cfg = store.carregar_empresa(empresa_slug_sel or None)
    empresa_slug = _slug(cfg.get("empresa", "empresa")) or "empresa"
    banco = (banco or "ITAU").strip().upper()
    contas = (cfg.get("aplicacao_depara") or {}).get(banco) or {}
    avisos = []

    tmp_dir = os.path.join(DADOS_DIR, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    lidos = []
    for it in itens_arquivo:
        nome = it.get("filename") or "extrato"
        conteudo = it.get("content") or b""
        if not conteudo:
            continue
        caminho = os.path.join(tmp_dir, "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome))
        with open(caminho, "wb") as f:
            f.write(conteudo)
        try:
            lidos.append(parsers_aplicacao.ler_aplicacao(caminho, nome))
        except ValueError as e:
            avisos.append(f"'{nome}': {e}")
        except Exception as e:  # noqa: BLE001
            avisos.append(f"'{nome}': falha ao ler ({e}).")
        finally:
            try:
                os.remove(caminho)
            except OSError:
                pass

    if not lidos:
        erro = "Nenhum extrato de aplicacao valido foi lido."
        if avisos:
            erro += " " + " ".join(avisos)
        return {"ok": False, "erro": erro}

    # Junta os arquivos num so conjunto de itens (mantendo a ordem lida).
    itens = [i for d in lidos for i in d["itens"]]
    comp = (competencia or "").strip() or next(
        (d["competencia"] for d in lidos if d.get("competencia")), "")
    produto = next((d["produto"] for d in lidos if d.get("produto")), "")
    if not comp:
        return {"ok": False, "erro": (
            "Nao consegui descobrir a competencia no arquivo (o Excel convertido "
            "perde esse cabecalho). Informe a competencia (mm/aaaa) na tela.")}

    base = dict(lidos[0])
    base.update({
        "itens": itens, "competencia": comp, "produto": produto,
        "arquivo": ", ".join(d["arquivo"] for d in lidos),
        "totais": {c: round(sum(i[c] for i in itens), 2)
                   for c in parsers_aplicacao.CAMPOS[:6]},
        "avisos": [a for d in lidos for a in d.get("avisos") or []],
    })

    resultado = core_aplicacao.gerar_lancamentos(
        base, contas, produto_padrao=contas.get("produto", ""))
    avisos.extend(resultado["avisos"])
    if not resultado["lancamentos"]:
        erro = " ".join(avisos) or "Nenhum lancamento gerado."
        return {"ok": False, "erro": erro}

    nome_csv = core_aplicacao.nome_arquivo(empresa_slug, banco, comp, ".csv")
    token_csv = _guardar(core_aplicacao.csv_bytes(resultado["lancamentos"]), nome_csv)
    nome_xlsx = core_aplicacao.nome_arquivo(empresa_slug, banco, comp, ".xlsx")
    token_xlsx = _guardar(core_aplicacao.planilha_bytes(base, resultado),
                          nome_xlsx, TIPO_XLSX)

    return {"ok": True, "resumo": resultado["resumo"], "avisos": avisos,
            "previa": resultado["lancamentos"][:30],
            "extrato": {"arquivo": base["arquivo"], "origem": lidos[0]["origem"],
                        "banco": banco, "agencia": base.get("agencia", ""),
                        "conta": base.get("conta", ""), "competencia": comp},
            "token_csv": token_csv, "csv_nome": nome_csv,
            "token_xlsx": token_xlsx, "xlsx_nome": nome_xlsx}


# --------------------------------------------------------------------------
# FRANCESINHA BB (boletos recebidos -> lancamentos de recebimento)
# --------------------------------------------------------------------------
def processar_francesinha(itens_arquivo, empresa_slug_sel):
    """
    Le a(s) francesinha(s) do BB (.xls) e devolve os lancamentos + o CSV
    para importar. Varios arquivos sao SOMADOS num CSV so (o BB exporta por
    faixa de data, entao um mes pode vir partido em dois arquivos).
    """
    cfg = store.carregar_empresa(empresa_slug_sel or None)
    empresa_slug = _slug(cfg.get("empresa", "empresa")) or "empresa"
    avisos = []

    tmp_dir = os.path.join(DADOS_DIR, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    itens = []
    arquivos_lidos = []
    for it in itens_arquivo:
        nome = it.get("filename") or "francesinha.xls"
        conteudo = it.get("content") or b""
        if not conteudo:
            continue
        caminho = os.path.join(tmp_dir, "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome))
        with open(caminho, "wb") as f:
            f.write(conteudo)
        try:
            r = parsers_francesinha.ler_francesinha(caminho, nome)
            itens.extend(r["itens"])
            arquivos_lidos.append({"arquivo": nome, "boletos": len(r["itens"]),
                                   "total_liquidacao": r["total_liquidacao"]})
            # O proprio arquivo traz a linha de total: se a soma dos boletos
            # lidos nao bater com ela, alguma linha se perdeu na leitura.
            ta = r.get("total_arquivo")
            if ta and abs(ta["valor_liquidacao"] - r["total_liquidacao"]) > 0.01:
                avisos.append(
                    f"'{nome}': a soma dos boletos lidos ({r['total_liquidacao']:.2f}) "
                    f"nao bate com o total do proprio arquivo "
                    f"({ta['valor_liquidacao']:.2f}) — confira antes de importar.")
        except ValueError as e:
            avisos.append(f"'{nome}': {e}")
        except Exception as e:  # noqa: BLE001
            avisos.append(f"'{nome}': falha ao ler ({e}).")
        finally:
            try:
                os.remove(caminho)
            except OSError:
                pass

    if not itens:
        erro = "Nenhuma francesinha valida foi lida."
        if avisos:
            erro += " " + " ".join(avisos)
        return {"ok": False, "erro": erro}

    dados = {"arquivo": ", ".join(a["arquivo"] for a in arquivos_lidos), "itens": itens,
             "total_valor": round(sum(i["valor"] for i in itens), 2),
             "total_liquidacao": round(sum(i["valor_liquidacao"] for i in itens), 2),
             "total_arquivo": None}
    resultado = core_francesinha.gerar_lancamentos(dados, cfg)
    avisos.extend(resultado["avisos"])

    nome_csv = core_francesinha.nome_arquivo(empresa_slug, ".csv")
    token_csv = _guardar(core_francesinha.csv_bytes(resultado["lancamentos"]), nome_csv)
    nome_xlsx = core_francesinha.nome_arquivo(empresa_slug, ".xlsx")
    token_xlsx = _guardar(core_francesinha.planilha_bytes(dados, resultado),
                          nome_xlsx, TIPO_XLSX)

    return {"ok": True, "resumo": resultado["resumo"], "avisos": avisos,
            "arquivos": arquivos_lidos,
            "previa": resultado["lancamentos"][:30],
            "token_csv": token_csv, "csv_nome": nome_csv,
            "token_xlsx": token_xlsx, "xlsx_nome": nome_xlsx}


# --------------------------------------------------------------------------
# NOVIDADES - o que mudou nos modulos, mostrado no sino da barra de cima.
#
# Lista escrita a mao, do mais recente para o mais antigo. O 'id' e o que o
# navegador guarda como "ja li": mudou o id do topo, o sino ganha o ponto
# vermelho de novo. Ao acrescentar uma linha, use uma data/id novos.
# --------------------------------------------------------------------------
NOVIDADES = [
    {"id": "2026-09-04-1", "data": "04/09/2026", "modulo": "Estoque Citel",
     "texto": "Tela refeita no desenho novo, com as duas etapas (estoque final "
              "e inicial) em areas separadas e o bloco de digitar a mao "
              "recolhivel."},
    {"id": "2026-09-04-2", "data": "04/09/2026", "modulo": "Inicio",
     "texto": "Modulos em cartoes, com filtro por grupo em abas. A casinha da "
              "barra virou este sino; para voltar, use o botao no topo de cada "
              "tela."},
    {"id": "2026-09-03-1", "data": "03/09/2026", "modulo": "Extrato Bancario",
     "texto": "Opcao 'somente o periodo do extrato': descarta a sobra do mes "
              "seguinte que o extrato mensal traz no fim, que virava lancamento "
              "em dobro."},
    {"id": "2026-09-03-2", "data": "03/09/2026", "modulo": "Extrato Bancario",
     "texto": "O favorecido passa a ser procurado tambem no PLANO DE CONTAS "
              "quando o De-Para nao resolve, e a data do movimento entra no "
              "fim do historico."},
    {"id": "2026-09-02-1", "data": "02/09/2026", "modulo": "Sispag",
     "texto": "Modulo liberado: le o relatorio do Sispag Itau e gera o CSV, com "
              "cadastro de conta por favorecido direto na tela de resultado."},
    {"id": "2026-09-02-2", "data": "02/09/2026", "modulo": "Vendas de Cartao",
     "texto": "Historico da venda passou de 'RECEBIMENTO' para 'TRANSFERENCIA "
              "VENDA CARTAO'."},
]


# --------------------------------------------------------------------------
# SISPAG (Itau) - pagamentos -> lancamentos contabeis
# --------------------------------------------------------------------------
def processar_sispag(itens_arquivo, empresa_slug_sel, tudo_reclassificar=False):
    """
    Le um ou varios relatorios do SISPAG e devolve o CSV de importacao mais a
    planilha de conferencia. Varios meses podem ser enviados de uma vez: o
    Itau exporta por faixa de data e o escritorio costuma ter um arquivo por
    mes.
    """
    cfg = store.carregar_empresa(empresa_slug_sel or None)
    empresa = cfg.get("empresa", "empresa")
    avisos = []

    tmp_dir = os.path.join(DADOS_DIR, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    itens, arquivos_lidos, periodos = [], [], []
    for it in itens_arquivo:
        nome = it.get("filename") or "sispag.xlsx"
        conteudo = it.get("content") or b""
        if not conteudo:
            continue
        caminho = os.path.join(tmp_dir, "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome))
        with open(caminho, "wb") as f:
            f.write(conteudo)
        try:
            r = parsers_sispag.ler_sispag(caminho, nome)
            itens.extend(r["itens"])
            if r["periodo"]:
                periodos.append(r["periodo"])
            arquivos_lidos.append({
                "arquivo": nome, "pagamentos": len(r["itens"]),
                "descartados": r["descartados"], "periodo": r["periodo"],
                "total": round(sum(i["valor"] for i in r["itens"]), 2)})
            if r["descartados"]:
                avisos.append(
                    "'%s': %d pagamento(s) fora do lancamento por nao estarem "
                    "com status 'Efetuado' (agendado, cancelado ou recusado)."
                    % (nome, r["descartados"]))
        except ValueError as e:
            avisos.append(f"'{nome}': {e}")
        except Exception as e:  # noqa: BLE001
            avisos.append(f"'{nome}': falha ao ler ({e}).")
        finally:
            try:
                os.remove(caminho)
            except OSError:
                pass

    if not itens:
        erro = "Nenhum pagamento efetuado foi lido dos arquivos enviados."
        if avisos:
            erro += " " + " ".join(avisos)
        return {"ok": False, "erro": erro}

    resultado = core_sispag.conciliar(itens, cfg, tudo_reclassificar)
    avisos.extend(resultado["avisos"])
    if not resultado["resumo"]["credito"]:
        return {"ok": False, "erro": " ".join(avisos)}

    periodo = "-".join(sorted(set(periodos))) if periodos else ""
    nome_csv = core_sispag.nome_arquivo(empresa, periodo, "csv")
    token_csv = _guardar(core_sispag.csv_bytes(resultado), nome_csv)
    nome_xlsx = core_sispag.nome_arquivo(empresa, periodo, "xlsx")
    token_xlsx = _guardar(
        core_sispag.planilha_bytes(resultado, empresa, periodo), nome_xlsx, TIPO_XLSX)

    return {"ok": True, "resumo": resultado["resumo"], "avisos": avisos,
            "arquivos": arquivos_lidos, "periodo": periodo,
            "previa": resultado["linhas"][:40],
            "fornecedores": resultado["fornecedores"],
            "tudo_reclassificar": bool(tudo_reclassificar),
            "token_csv": token_csv, "csv_nome": nome_csv,
            "token_xlsx": token_xlsx, "xlsx_nome": nome_xlsx}


# --------------------------------------------------------------------------
# CONFRONTACAO FINAL - todas as auditorias numa conferencia so
#
# O Balancete e' enviado UMA VEZ e serve a todos os modulos. Cada campo de
# relatorio e' OPCIONAL: quem nao enviar simplesmente sai como "nao
# enviado" no checklist (nunca como "bate"). Ver core_confrontacao_final.
# --------------------------------------------------------------------------
def processar_confrontacao_final(campos, empresa_slug_sel):
    slug = empresa_slug_sel or store.empresa_ativa_slug()
    cfg = store.carregar_empresa(slug)
    empresa_slug = _slug(cfg.get("empresa", "empresa")) or "empresa"
    avisos = []
    # todo arquivo que entrou, na ORDEM da conferencia - vai para a secao
    # "Documentos utilizados" do relatorio de auditoria
    documentos = []

    tmp_dir = os.path.join(DADOS_DIR, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    item_balancete = (campos.get("balancete") or [None])[0]
    balancete = None
    if item_balancete:
        balancete, aviso = _ler_um(
            item_balancete, tmp_dir, "um Balancete",
            parsers_balancete.detectar, parsers_balancete.ler_balancete,
            lambda c: False, "")
        if aviso:
            avisos.append(aviso)
    if not balancete:
        erro = "Faltou o Balancete (ele e a base de toda a conferencia)."
        if avisos:
            erro += " " + " ".join(avisos)
        return {"ok": False, "erro": erro}
    documentos.append({"nome": balancete.get("arquivo", ""), "tipo": "balancete"})

    dados = {}

    # Depreciacao (1 arquivo)
    item_dep = (campos.get("depreciacao") or [None])[0]
    if item_dep and item_dep.get("content"):
        resumo, aviso = _ler_um(
            item_dep, tmp_dir, "o Resumo da Depreciacao Fiscal",
            parsers_depreciacao.detectar, parsers_depreciacao.ler_resumo,
            parsers_balancete.detectar, "um Balancete")
        if aviso:
            avisos.append(aviso)
        documentos.append({"nome": item_dep.get("filename", ""), "tipo": "depreciacao"})
        dados["depreciacao"] = resumo

    # Extratos + aplicacoes (varios; o tipo sai do CONTEUDO de cada arquivo)
    for chave in ("extratos", "aplicacoes"):
        for it in campos.get(chave, []):
            if it.get("content"):
                documentos.append({"nome": it.get("filename", ""),
                                   "tipo": "extrato" if chave == "extratos" else "aplicacao"})
    registros, avs = _ler_varios_extratos(
        [("corrente", campos.get("extratos") or []),
         ("aplicacao", campos.get("aplicacoes") or [])], tmp_dir)
    avisos.extend(avs)
    dados["extratos"] = registros

    # Relatorios de cartao (varios, qualquer operadora)
    dados_cartao = {}
    for it in campos.get("cartao", []):
        nome = it.get("filename") or "arquivo"
        conteudo = it.get("content") or b""
        if not conteudo:
            continue
        caminho = os.path.join(tmp_dir, "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome))
        with open(caminho, "wb") as f:
            f.write(conteudo)
        try:
            operadora, vendas = parsers.parse_arquivo(caminho)
            dados_cartao.setdefault(operadora, []).extend(vendas)
            documentos.append({"nome": nome, "tipo": "cartao"})
        except ValueError as e:
            avisos.append(f"'{nome}': {e}")
        except Exception as e:  # noqa: BLE001
            avisos.append(f"'{nome}': falha ao ler ({e}).")
        finally:
            try:
                os.remove(caminho)
            except OSError:
                pass
    if dados_cartao:
        dados["cartao"] = core_cartao.resumo_por_operadora(dados_cartao)

    # Planilha de alugueis a pagar (provisao do passivo)
    item_alug = (campos.get("alugueis") or [None])[0]
    if item_alug and item_alug.get("content"):
        nome = item_alug.get("filename") or "alugueis.xlsx"
        caminho = os.path.join(tmp_dir, "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome))
        with open(caminho, "wb") as f:
            f.write(item_alug["content"])
        try:
            dados["alugueis"] = parsers_alugueis.ler_alugueis(caminho, nome)
            documentos.append({"nome": nome, "tipo": "alugueis"})
        except ValueError as e:
            avisos.append(f"'{nome}': {e}")
        except Exception as e:  # noqa: BLE001
            avisos.append(f"'{nome}': falha ao ler ({e}).")
        finally:
            try:
                os.remove(caminho)
            except OSError:
                pass



    # Inventarios de estoque (um por filial) - conferidos contra as contas
    # de estoque do balancete, pela conta cadastrada de cada filial.
    inventarios = []
    for it in campos.get("estoque", []):
        nome = it.get("filename") or "inventario"
        conteudo = it.get("content") or b""
        if not conteudo:
            continue
        caminho = os.path.join(tmp_dir, "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome))
        with open(caminho, "wb") as f:
            f.write(conteudo)
        try:
            inventarios.append(parsers_estoque.ler_inventario(caminho, nome))
            documentos.append({"nome": nome, "tipo": "estoque"})
        except ValueError as e:
            avisos.append(f"'{nome}': {e}")
        except Exception as e:  # noqa: BLE001
            avisos.append(f"'{nome}': falha ao ler ({e}).")
        finally:
            try:
                os.remove(caminho)
            except OSError:
                pass
    dados["estoque"] = inventarios

    resultado = core_confrontacao_final.confrontar(balancete, cfg, dados)
    if resultado["cadastro_mudou"]:
        store.salvar_empresa(slug, cfg)
    avisos.extend(resultado["avisos"])

    periodo = balancete.get("periodo", "")
    planilha = core_confrontacao_final.montar_planilha(
        resultado, cfg.get("empresa", ""), periodo)
    nome_xlsx = f"{empresa_slug}_" + core_confrontacao_final.nome_arquivo(
        cfg.get("empresa", ""), periodo)
    token = _guardar(planilha, nome_xlsx, TIPO_XLSX)

    # Relatorio de auditoria, no modelo do escritorio (HTML -> Ctrl+P vira PDF)
    resultado_rel = dict(resultado)
    resultado_rel["avisos"] = avisos
    html_rel = core_relatorio_auditoria.montar_html(
        resultado_rel, balancete.get("empresa", "") or cfg.get("empresa", ""),
        balancete.get("cnpj", ""), periodo,
        core_relatorio_auditoria.competencia_do_periodo(periodo),
        documentos, escritorio="JB QUALITY")
    nome_rel = core_relatorio_auditoria.nome_arquivo(
        balancete.get("empresa", "") or cfg.get("empresa", ""), periodo)
    token_rel = _guardar(html_rel.encode("utf-8"), nome_rel,
                         "text/html; charset=utf-8")

    return {"ok": True, "linhas": resultado["linhas"], "modulos": resultado["modulos"],
            "resumo": resultado["resumo"], "avisos": avisos,
            "token": token, "arquivo_nome": nome_xlsx,
            "token_relatorio": token_rel, "relatorio_nome": nome_rel,
            "balancete_info": {"empresa": balancete.get("empresa", ""),
                               "cnpj": balancete.get("cnpj", ""),
                               "periodo": periodo,
                               "arquivo": balancete["arquivo"],
                               "total_contas": len(balancete["contas"])}}


# --------------------------------------------------------------------------
# Plano de Contas (upload que atualiza o De-Para de uma vez)
# --------------------------------------------------------------------------
def processar_plano_contas(itens_arquivo, empresa_slug_sel):
    """
    Le o PDF do plano de contas, guarda a lista completa na empresa (para
    autocompletar 'nome' ao cadastrar de-para) e, DE UMA VEZ, corrige o nome
    de todo item do De-Para ja cadastrado cujo codigo exista no plano.
    """
    it = next((i for i in itens_arquivo if i.get("content")), None)
    if not it:
        return {"ok": False, "erro": "Nenhum arquivo de plano de contas enviado."}

    nome_arq = it.get("filename") or "plano.pdf"
    tmp_dir = os.path.join(DADOS_DIR, "_tmp")
    os.makedirs(tmp_dir, exist_ok=True)
    caminho = os.path.join(tmp_dir, "up_" + re.sub(r"[^A-Za-z0-9_.-]", "_", nome_arq))
    with open(caminho, "wb") as f:
        f.write(it["content"])
    try:
        contas = parsers_plano.parse_plano_contas(caminho)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "erro": f"'{nome_arq}': falha ao ler o PDF ({e})."}
    finally:
        try:
            os.remove(caminho)
        except OSError:
            pass

    if not contas:
        return {"ok": False, "erro": f"'{nome_arq}': nenhuma conta reconhecida no PDF."}

    slug = empresa_slug_sel or None
    cfg = store.carregar_empresa(slug)
    cfg["plano_contas"] = contas
    idx = parsers_plano.indexar_por_codigo(contas)

    atualizados, nao_encontrados = [], []
    for item in cfg.get("depara") or []:
        conta_cod = (item.get("conta") or "").strip()
        if not conta_cod:
            continue
        achado = idx.get(conta_cod)
        if achado is None:
            nao_encontrados.append({"padrao": item.get("padrao", ""),
                                    "conta": conta_cod})
            continue
        if parsers.norm_txt(achado["nome"]) != parsers.norm_txt(item.get("nome", "")):
            atualizados.append({"padrao": item.get("padrao", ""), "conta": conta_cod,
                                "nome_antigo": item.get("nome", ""),
                                "nome_novo": achado["nome"]})
            item["nome"] = achado["nome"]

    salvo = store.salvar_empresa(slug or store.empresa_ativa_slug(), cfg)
    return {
        "ok": True,
        "arquivo": nome_arq,
        "empresa": salvo["empresa"],
        "total_contas": len(contas),
        "depara_total": len(salvo["depara"]),
        "depara_atualizados": atualizados,
        "depara_nao_encontrados": nao_encontrados,
    }


# --------------------------------------------------------------------------
# HTTP Handler
# --------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "ContabCartao/1.0"

    def log_message(self, fmt, *args):  # silenciar log padrao ruidoso
        pass

    # ---- helpers de resposta ----
    def _send(self, code, body, ctype="text/html; charset=utf-8", extra=None):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        if extra:
            for k, v in extra.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False),
                   "application/json; charset=utf-8")

    # ---- GET ----
    def do_GET(self):
        parsed = urlparse(self.path)
        rota = parsed.path
        qs = parse_qs(parsed.query)
        try:
            if rota == "/":
                self._send(200, render("hub.html", "Inicio"))
            elif rota == "/cartao":
                self._send(200, render("cartao.html", "Vendas de Cartao"))
            elif rota == "/cadastro":
                self._send(200, render("cadastro.html", "Cadastro"))
            elif rota == "/extrato":
                self._send(200, render("extrato.html", "Extrato Bancario"))
            elif rota == "/regra":
                self._send(200, render("regra.html", "Regra"))
            elif rota == "/depara":
                self._send(200, render("depara.html", "De-Para"))
            elif rota == "/magnojet":
                self._send(200, render("magnojet.html", "Grupo Magnojet"))
            elif rota == "/aplicacao_diaria":
                self._send(200, render("aplicacao_diaria.html", "Aplicacao Diaria"))
            elif rota == "/aplicacao_depara":
                self._send(200, render("aplicacao_depara.html", "De-Para da aplicacao"))
            elif rota == "/api/aplicacao_depara":
                slug = (qs.get("empresa") or [None])[0]
                self._json({
                    "aplicacao_depara": store.carregar_empresa(slug)["aplicacao_depara"],
                    "bancos": list(core_aplicacao.BANCOS),
                    "contas": [list(c) for c in core_aplicacao.CONTAS],
                    "lidos": list(core_aplicacao.BANCOS_LIDOS)})
            elif rota == "/francesinha_bb":
                self._send(200, render("francesinha_bb.html", "Francesinha BB"))
            elif rota == "/sispag":
                self._send(200, render("sispag.html", "Sispag"))
            elif rota == "/receita_financeira":
                self._send(200, render("receita_financeira.html",
                                       "Receita Financeira"))
            elif rota == "/aluguel_royalties":
                self._send(200, render("aluguel_royalties.html",
                                       "Aluguel e Royalties"))
            elif rota.lstrip("/") in COUTO_TELAS:
                self._send(200, _render_couto(rota.lstrip("/")))
            elif rota == "/api/couto_regras":
                slug = (qs.get("empresa") or [None])[0]
                mod = (qs.get("m") or ["pagamentos"])[0]
                cfg = store.carregar_empresa(slug)
                regras = _regras_couto(cfg)
                self._json({
                    "modulo": mod, "contas": regras["contas"],
                    "caixas": regras.get("caixas") or {},
                    "erp_so_banco": regras.get("erp_so_banco") or [],
                    "depara_total": (len(regras.get("fornecedores") or {})
                                     if mod == "pagamentos"
                                     else len(regras.get("erp") or {})
                                     if mod == "banco_sistema"
                                     else len(regras.get("caixa_historicos") or {})
                                     if mod == "resumo_caixa" else None),
                    "faltando": _couto_faltando(mod, regras)})
            elif rota == "/couto_regras":
                self._send(200, render("couto_regras.html",
                                       "Regras dos modulos HAC"))
            elif rota == "/estoque_precito":
                self._send(200, render("estoque_precito.html", "Estoque Precito"))
            elif rota == "/estoque_citel":
                self._send(200, render("estoque_citel.html", "Estoque Citel"))
            elif rota == "/fornecedores":
                self._send(200, render("fornecedores.html",
                                       "Beta - Fornecedores"))
            elif rota == "/receita_contas":
                self._send(200, render("receita_contas.html",
                                       "Empresa e instituicoes"))
            elif rota == "/api/instituicoes":
                slug = (qs.get("empresa") or [None])[0]
                cfg = store.carregar_empresa(slug)
                self._json({"instituicoes": cfg["instituicoes"],
                            "cnpj": cfg["cnpj"],
                            "razao_social": cfg["razao_social"],
                            "empresa": cfg.get("empresa", "")})
            elif rota in AUDITORIA:
                self._send(200, render(f"{rota.lstrip('/')}.html",
                                       AUDITORIA[rota]))
            elif rota == "/aud_depreciacao":
                self._send(200, render("aud_depreciacao.html",
                                       "Auditoria - Depreciacao"))
            elif rota == "/aud_extrato":
                self._send(200, render("aud_extrato.html",
                                       "Auditoria - Extrato Bancario"))
            elif rota == "/aud_cartao":
                self._send(200, render("aud_cartao.html",
                                       "Auditoria - Taxa Cartao"))
            elif rota == "/confrontacao_final":
                self._send(200, render("confrontacao_final.html", "Confrontacao Final"))
            elif rota == "/aud_fiscal":
                self._send(200, render("aud_fiscal.html", "Auditoria - Fiscal"))
            elif rota == "/aud_fiscal_acumuladores":
                self._send(200, render("aud_fiscal_acumuladores.html",
                                       "Cadastro de Acumuladores"))
            elif rota == "/api/aud_fiscal_status":
                slug = (qs.get("empresa") or [None])[0] or store.empresa_ativa_slug()
                mes = (qs.get("mes") or [""])[0]
                ano = (qs.get("ano") or [""])[0]
                periodo = mes + ano if mes and ano else None
                enviados = _fiscal_arquivos_ja_enviados(slug, periodo) if periodo else {}
                periodos = _fiscal_periodos_disponiveis(slug)
                self._json({
                    "filiais_enviadas": sorted((k for k in enviados if k != "balancete"),
                                               key=lambda x: int(x) if x.isdigit() else 0),
                    "balancete_enviado": "balancete" in enviados,
                    "paineis": [{"periodo": p, "competencia": f"{p[:2]}/{p[2:]}"} for p in periodos],
                })
            elif rota == "/api/aud_fiscal_painel":
                slug = (qs.get("empresa") or [None])[0] or store.empresa_ativa_slug()
                periodo = (qs.get("periodo") or [""])[0]
                resultado = _fiscal_ler_resultado(slug, periodo) if periodo else None
                if resultado is None:
                    self._json({"ok": False, "erro": f"Nao ha painel gerado para {periodo}."}, 404)
                else:
                    self._json({"ok": True, **resultado})
            elif rota == "/api/aud_fiscal_acumuladores":
                slug = (qs.get("empresa") or [None])[0]
                cfg = store.carregar_empresa(slug)
                self._json({"fiscal_acumuladores": cfg["fiscal_acumuladores"]})
            elif rota == "/estoque_depara":
                self._send(200, render("estoque_depara.html",
                                       "De-Para da apuracao de estoque"))
            elif rota == "/estoque_contas":
                self._send(200, render("estoque_contas.html",
                                       "Contas do estoque"))
            elif rota == "/api/estoque_filiais":
                slug = (qs.get("empresa") or [None])[0]
                self._json({"estoque_filiais":
                            store.carregar_empresa(slug)["estoque_filiais"]})
            elif rota == "/api/empresas":
                self._json({"empresas": store.listar_empresas(),
                           "ativa": store.empresa_ativa_slug()})
            elif rota == "/api/config":
                slug = (qs.get("empresa") or [None])[0]
                self._json(store.carregar_empresa(slug))
            elif rota == "/api/bancos":
                slug = (qs.get("empresa") or [None])[0]
                cfg = store.carregar_empresa(slug)
                self._json({"bancos": cfg["bancos"],
                            "cnpj": cfg.get("cnpj", ""),
                            "clientes": cfg["contas"]["clientes"],
                            "pendencia": cfg["contas"]["pendencia"],
                            "extrato_pagamento": cfg["contas"]["extrato_pagamento"],
                            "transferencia": cfg["contas"]["transferencia"],
                            "sispag_credito": cfg["contas"]["sispag_credito"],
                            "sispag_reclassificar": cfg["contas"]["sispag_reclassificar"]})
            elif rota == "/api/depara":
                slug = (qs.get("empresa") or [None])[0]
                self._json({"depara": store.carregar_empresa(slug)["depara"]})
            elif rota == "/api/novidades":
                self._json({"novidades": NOVIDADES})
            elif rota == "/api/plano":
                slug = (qs.get("empresa") or [None])[0]
                self._json({"plano_contas": store.carregar_empresa(slug)["plano_contas"]})
            elif rota == "/baixar":
                self._baixar(qs)
            elif rota.startswith("/static/"):
                self._static(rota)
            else:
                self._send(404, "Nao encontrado")
        except ValueError as e:
            self._json({"ok": False, "erro": str(e)}, 404)
        except Exception as e:  # noqa: BLE001
            self._send(500, f"Erro interno: {_escape(e)}")

    # ---- POST ----
    def do_POST(self):
        parsed = urlparse(self.path)
        rota = parsed.path
        qs = parse_qs(parsed.query)
        try:
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length) if length else b""
            ctype = self.headers.get("Content-Type", "")

            if rota == "/processar_cartao":
                campos = parse_multipart(body, ctype)
                modo = ""
                if campos.get("modo"):
                    modo = campos["modo"][0].get("value", "")
                empresa_sel = ""
                if campos.get("empresa"):
                    empresa_sel = campos["empresa"][0].get("value", "")
                itens = campos.get("arquivos", [])
                try:
                    resultado = processar_arquivos(itens, modo, empresa_sel)
                    self._json(resultado)
                except ValueError as e:
                    self._json({"ok": False, "erro": str(e)}, 404)
            elif rota == "/processar_extrato":
                campos = parse_multipart(body, ctype)
                empresa_sel = ""
                if campos.get("empresa"):
                    empresa_sel = campos["empresa"][0].get("value", "")
                try:
                    so_per = "1"
                    if campos.get("so_periodo"):
                        so_per = campos["so_periodo"][0].get("value", "1")
                    self._json(processar_extratos(campos.get("arquivos", []),
                                                  empresa_sel, so_per != "0"))
                except ValueError as e:
                    self._json({"ok": False, "erro": str(e)}, 404)
            elif rota == "/processar_receita":
                campos = parse_multipart(body, ctype)
                empresa_sel = ""
                if campos.get("empresa"):
                    empresa_sel = campos["empresa"][0].get("value", "")
                comp = ""
                if campos.get("competencia"):
                    comp = campos["competencia"][0].get("value", "")
                try:
                    self._json(processar_receita_financeira(
                        campos.get("arquivos", []), empresa_sel, comp))
                except ValueError as e:
                    self._json({"ok": False, "erro": str(e)}, 404)
            elif rota == "/processar_estoque":
                campos = parse_multipart(body, ctype)
                empresa_sel = ""
                if campos.get("empresa"):
                    empresa_sel = campos["empresa"][0].get("value", "")
                comp = ""
                if campos.get("competencia"):
                    comp = campos["competencia"][0].get("value", "")
                manuais = {}
                if campos.get("manuais"):
                    try:
                        manuais = json.loads(campos["manuais"][0].get("value") or "{}")
                    except (ValueError, TypeError):
                        manuais = {}
                try:
                    self._json(processar_estoque(
                        campos.get("arquivos", []), empresa_sel, comp,
                        itens_inicial=campos.get("arquivos_inicial", []),
                        manuais=manuais))
                except ValueError as e:
                    self._json({"ok": False, "erro": str(e)}, 404)
            elif rota == "/processar_fornecedores":
                campos = parse_multipart(body, ctype)
                empresa_sel = ""
                if campos.get("empresa"):
                    empresa_sel = campos["empresa"][0].get("value", "")
                comp = ""
                if campos.get("competencia"):
                    comp = campos["competencia"][0].get("value", "")
                try:
                    self._json(processar_fornecedores(
                        campos.get("arquivos", []), empresa_sel, comp))
                except ValueError as e:
                    self._json({"ok": False, "erro": str(e)}, 404)
            elif rota == "/processar_couto":
                campos = parse_multipart(body, ctype)

                def _campo(nome, padrao=""):
                    return (campos[nome][0].get("value", "")
                            if campos.get(nome) else padrao)
                try:
                    self._json(processar_couto(
                        campos.get("arquivos", []), _campo("empresa"),
                        _campo("competencia"), _campo("modulo", "pagamentos")))
                except ValueError as e:
                    self._json({"ok": False, "erro": str(e)}, 404)
            elif rota == "/api/couto_regras":
                slug = (qs.get("empresa") or [None])[0]
                try:
                    dados = json.loads(body.decode("utf-8"))
                    cfg = store.carregar_empresa(slug)
                    atual = dict(cfg.get("couto") or {})
                    # a tela de cada modulo mostra so os campos dele; a
                    # juncao e por dentro para que salvar numa aba nao apague
                    # a conta que so aparece em outra
                    for k, v in (dados.get("couto") or {}).items():
                        if isinstance(v, dict) and isinstance(atual.get(k), dict):
                            atual[k] = dict(atual[k], **v)
                        else:
                            atual[k] = v
                    cfg["couto"] = atual
                    store.salvar_empresa(slug, cfg)
                    self._json({"ok": True, "couto": atual})
                except (ValueError, TypeError, KeyError) as e:
                    self._json({"ok": False, "erro": str(e)}, 400)
            elif rota == "/processar_estoque_precito":
                campos = parse_multipart(body, ctype)
                empresa_sel = ""
                if campos.get("empresa"):
                    empresa_sel = campos["empresa"][0].get("value", "")
                comp = ""
                if campos.get("competencia"):
                    comp = campos["competencia"][0].get("value", "")
                try:
                    self._json(processar_estoque_precito(
                        campos.get("arquivos", []), empresa_sel, comp))
                except ValueError as e:
                    self._json({"ok": False, "erro": str(e)}, 404)
            elif rota == "/api/avaliar":
                try:
                    dados = json.loads(body.decode("utf-8"))
                    self._json(guardar_avaliacao(dados.get("nota"),
                                                 dados.get("tela")))
                except (ValueError, TypeError, KeyError) as e:
                    self._json({"ok": False, "erro": str(e)}, 400)
            elif rota == "/api/testar_depara":
                slug = (qs.get("empresa") or [None])[0]
                try:
                    dados = json.loads(body.decode("utf-8"))
                    self._json(testar_depara(
                        dados.get("descricao") or "",
                        store.carregar_empresa(slug)))
                except (ValueError, TypeError, KeyError) as e:
                    self._json({"ok": False, "erro": str(e)}, 400)
            elif rota == "/api/instituicoes":
                slug = (qs.get("empresa") or [None])[0]
                try:
                    dados = json.loads(body.decode("utf-8"))
                    cfg = store.carregar_empresa(slug)
                    cfg["instituicoes"] = dados.get("instituicoes") or []
                    for campo in ("cnpj", "razao_social"):
                        if dados.get(campo) is not None:
                            cfg[campo] = dados[campo]
                    salvo = store.salvar_empresa(slug, cfg)
                    self._json({"ok": True,
                                "instituicoes": salvo["instituicoes"],
                                "cnpj": salvo["cnpj"],
                                "razao_social": salvo["razao_social"]})
                except (ValueError, TypeError, KeyError) as e:
                    self._json({"ok": False, "erro": str(e)}, 400)
            elif rota == "/api/estoque_filiais":
                slug = (qs.get("empresa") or [None])[0]
                try:
                    dados = json.loads(body.decode("utf-8"))
                    cfg = store.carregar_empresa(slug)
                    cfg["estoque_filiais"] = dados.get("estoque_filiais") or []
                    salvo = store.salvar_empresa(slug, cfg)
                    self._json({"ok": True,
                                "estoque_filiais": salvo["estoque_filiais"]})
                except (ValueError, TypeError, KeyError) as e:
                    self._json({"ok": False, "erro": str(e)}, 400)
            elif rota == "/processar_aud_depreciacao":
                campos = parse_multipart(body, ctype)
                empresa_sel = ""
                if campos.get("empresa"):
                    empresa_sel = campos["empresa"][0].get("value", "")
                item_resumo = (campos.get("resumo") or [None])[0]
                item_balancete = (campos.get("balancete") or [None])[0]
                try:
                    self._json(processar_aud_depreciacao(
                        item_resumo, item_balancete, empresa_sel))
                except ValueError as e:
                    self._json({"ok": False, "erro": str(e)}, 404)
            elif rota == "/processar_aud_extrato":
                campos = parse_multipart(body, ctype)
                empresa_sel = ""
                if campos.get("empresa"):
                    empresa_sel = campos["empresa"][0].get("value", "")
                itens_extrato = campos.get("extratos", [])
                itens_aplicacao = campos.get("aplicacoes", [])
                item_balancete = (campos.get("balancete") or [None])[0]
                try:
                    self._json(processar_aud_extrato(
                        itens_extrato, itens_aplicacao, item_balancete, empresa_sel))
                except ValueError as e:
                    self._json({"ok": False, "erro": str(e)}, 404)
            elif rota == "/processar_aud_cartao":
                campos = parse_multipart(body, ctype)
                empresa_sel = ""
                if campos.get("empresa"):
                    empresa_sel = campos["empresa"][0].get("value", "")
                itens_relatorios = campos.get("relatorios", [])
                item_balancete = (campos.get("balancete") or [None])[0]
                try:
                    self._json(processar_aud_cartao(
                        itens_relatorios, item_balancete, empresa_sel))
                except ValueError as e:
                    self._json({"ok": False, "erro": str(e)}, 404)
            elif rota == "/processar_magnojet":
                campos = parse_multipart(body, ctype)
                empresa_sel = ""
                if campos.get("empresa"):
                    empresa_sel = campos["empresa"][0].get("value", "")
                comp = campos["competencia"][0].get("value", "") if campos.get("competencia") else ""
                try:
                    self._json(processar_magnojet(
                        (campos.get("pagos") or [None])[0],
                        (campos.get("recebidos") or [None])[0],
                        (campos.get("extrato") or [None])[0], comp, empresa_sel))
                except ValueError as e:
                    self._json({"ok": False, "erro": str(e)}, 404)
            elif rota == "/processar_aplicacao":
                campos = parse_multipart(body, ctype)
                def _campo(n):
                    return campos[n][0].get("value", "") if campos.get(n) else ""
                try:
                    self._json(processar_aplicacao(
                        campos.get("arquivos", []), _campo("empresa"),
                        _campo("banco"), _campo("competencia")))
                except ValueError as e:
                    self._json({"ok": False, "erro": str(e)}, 404)
            elif rota == "/api/aplicacao_depara":
                slug = (qs.get("empresa") or [None])[0]
                try:
                    dados = json.loads(body.decode("utf-8"))
                    cfg = store.carregar_empresa(slug)
                    cfg["aplicacao_depara"] = dados.get("aplicacao_depara") or {}
                    salvo = store.salvar_empresa(slug, cfg)
                    self._json({"ok": True,
                                "aplicacao_depara": salvo["aplicacao_depara"]})
                except (ValueError, TypeError, KeyError) as e:
                    self._json({"ok": False, "erro": str(e)}, 400)
            elif rota == "/processar_francesinha":
                campos = parse_multipart(body, ctype)
                empresa_sel = ""
                if campos.get("empresa"):
                    empresa_sel = campos["empresa"][0].get("value", "")
                try:
                    self._json(processar_francesinha(campos.get("arquivos", []),
                                                     empresa_sel))
                except ValueError as e:
                    self._json({"ok": False, "erro": str(e)}, 404)
            elif rota == "/processar_sispag":
                campos = parse_multipart(body, ctype)
                empresa_sel = ""
                if campos.get("empresa"):
                    empresa_sel = campos["empresa"][0].get("value", "")
                try:
                    tudo = ""
                    if campos.get("tudo_reclassificar"):
                        tudo = campos["tudo_reclassificar"][0].get("value", "")
                    self._json(processar_sispag(campos.get("arquivos", []),
                                                empresa_sel, tudo == "1"))
                except ValueError as e:
                    self._json({"ok": False, "erro": str(e)}, 404)
            elif rota == "/processar_confrontacao_final":
                campos = parse_multipart(body, ctype)
                empresa_sel = ""
                if campos.get("empresa"):
                    empresa_sel = campos["empresa"][0].get("value", "")
                try:
                    self._json(processar_confrontacao_final(campos, empresa_sel))
                except ValueError as e:
                    self._json({"ok": False, "erro": str(e)}, 404)
            elif rota == "/processar_aud_fiscal":
                campos = parse_multipart(body, ctype)
                empresa_sel = ""
                if campos.get("empresa"):
                    empresa_sel = campos["empresa"][0].get("value", "")
                mes = campos["mes"][0].get("value", "") if campos.get("mes") else ""
                ano = campos["ano"][0].get("value", "") if campos.get("ano") else ""
                itens_acumuladores = campos.get("acumuladores", [])
                item_balancete = (campos.get("balancete") or [None])[0]
                try:
                    self._json(processar_aud_fiscal(
                        itens_acumuladores, item_balancete, mes, ano, empresa_sel))
                except ValueError as e:
                    self._json({"ok": False, "erro": str(e)}, 404)
            elif rota == "/api/aud_fiscal_acumuladores":
                try:
                    dados = json.loads(body.decode("utf-8"))
                    self._json(processar_aud_fiscal_acumuladores(
                        dados.get("empresa"), dados.get("filial"), dados.get("acumuladores")))
                except (ValueError, TypeError, KeyError) as e:
                    self._json({"ok": False, "erro": str(e)}, 400)
            elif rota == "/api/aud_fiscal_validacoes":
                try:
                    dados = json.loads(body.decode("utf-8"))
                    self._json(processar_aud_fiscal_validacoes(
                        dados.get("empresa"), dados.get("periodo"), dados.get("validacoes")))
                except (ValueError, TypeError, KeyError) as e:
                    self._json({"ok": False, "erro": str(e)}, 400)
            elif rota == "/processar_plano":
                campos = parse_multipart(body, ctype)
                empresa_sel = ""
                if campos.get("empresa"):
                    empresa_sel = campos["empresa"][0].get("value", "")
                try:
                    self._json(processar_plano_contas(campos.get("arquivos", []),
                                                       empresa_sel))
                except ValueError as e:
                    self._json({"ok": False, "erro": str(e)}, 404)
            elif rota == "/api/bancos":
                slug = (qs.get("empresa") or [None])[0]
                try:
                    dados = json.loads(body.decode("utf-8"))
                    cfg = store.carregar_empresa(slug)
                    cfg["bancos"] = dados.get("bancos") or []
                    if dados.get("clientes") is not None:
                        cfg["contas"]["clientes"] = dados["clientes"]
                    if dados.get("pendencia") is not None:
                        cfg["contas"]["pendencia"] = dados["pendencia"]
                    for chave in ("extrato_pagamento", "transferencia",
                                  "sispag_credito", "sispag_reclassificar"):
                        if dados.get(chave) is not None:
                            cfg["contas"][chave] = dados[chave]
                    if dados.get("cnpj") is not None:
                        cfg["cnpj"] = dados["cnpj"]
                    salvo = store.salvar_empresa(slug, cfg)
                    self._json({"ok": True, "bancos": salvo["bancos"]})
                except (ValueError, TypeError, KeyError) as e:
                    self._json({"ok": False, "erro": str(e)}, 400)
            elif rota == "/api/depara":
                slug = (qs.get("empresa") or [None])[0]
                try:
                    dados = json.loads(body.decode("utf-8"))
                    cfg = store.carregar_empresa(slug)
                    cfg["depara"] = dados.get("depara") or []
                    salvo = store.salvar_empresa(slug, cfg)
                    self._json({"ok": True, "depara": salvo["depara"]})
                except (ValueError, TypeError, KeyError) as e:
                    self._json({"ok": False, "erro": str(e)}, 400)
            elif rota == "/api/config":
                slug = (qs.get("empresa") or [None])[0]
                try:
                    if not slug:
                        raise ValueError("Empresa nao informada (?empresa=slug).")
                    novo = json.loads(body.decode("utf-8"))
                    # MESCLAR, nao substituir: a tela de Cadastro envia apenas as
                    # contas de cartao. Substituir apagaria bancos, de-para e a
                    # conta de pendencia (perda silenciosa de cadastro).
                    atual = store.carregar_empresa(slug)
                    if novo.get("empresa"):
                        atual["empresa"] = novo["empresa"]
                    if novo.get("modo_codigo"):
                        atual["modo_codigo"] = novo["modo_codigo"]
                    for chave, valor in (novo.get("contas") or {}).items():
                        atual["contas"][chave] = valor
                    for chave, valor in (novo.get("aud_cartao_obs") or {}).items():
                        atual.setdefault("aud_cartao_obs", {})[chave] = valor
                    for campo in ("cnpj", "razao_social", "historico_extrato"):
                        if novo.get(campo) is not None:
                            atual[campo] = novo[campo]
                    for lista in ("bancos", "depara", "plano_contas",
                                  "estoque_filiais", "instituicoes"):
                        if novo.get(lista) is not None:
                            atual[lista] = novo[lista]
                    salvo = store.salvar_empresa(slug, atual)
                    self._json({"ok": True, "config": salvo})
                except (ValueError, TypeError) as e:
                    self._json({"ok": False, "erro": str(e)}, 400)
            elif rota == "/api/empresas":
                try:
                    dados = json.loads(body.decode("utf-8"))
                    criado = store.criar_empresa(
                        dados.get("nome", ""),
                        dados.get("copiar_de") or None,
                        cnpj=dados.get("cnpj", ""),
                        codigo=dados.get("codigo", ""),
                        apelido=dados.get("apelido", ""))
                    store.definir_empresa_ativa(criado["slug"])
                    self._json({"ok": True, **criado})
                except (ValueError, TypeError) as e:
                    self._json({"ok": False, "erro": str(e)}, 400)
            elif rota == "/api/empresas_editar":
                try:
                    dados = json.loads(body.decode("utf-8"))
                    slug = dados.get("slug", "")
                    if not slug:
                        raise ValueError("Empresa nao informada.")
                    salvo = store.atualizar_identificacao(
                        slug, dados.get("nome", ""),
                        cnpj=dados.get("cnpj", ""),
                        codigo=dados.get("codigo", ""),
                        apelido=dados.get("apelido", ""))
                    self._json({"ok": True, "slug": slug,
                                "nome": salvo["empresa"]})
                except (ValueError, TypeError) as e:
                    self._json({"ok": False, "erro": str(e)}, 400)
            elif rota == "/api/empresa_ativa":
                try:
                    dados = json.loads(body.decode("utf-8"))
                    store.definir_empresa_ativa(dados.get("empresa", ""))
                    self._json({"ok": True})
                except (ValueError, TypeError) as e:
                    self._json({"ok": False, "erro": str(e)}, 400)
            elif rota == "/api/ping":
                global _ULTIMA_BATIDA
                _ULTIMA_BATIDA = time.time()
                self._json({"ok": True})
            elif rota == "/encerrar":
                # Responde ANTES de desligar (senao o navegador ve conexao
                # cortada e mostra erro em vez da confirmacao). O shutdown
                # nao pode rodar nesta thread: ele espera o serve_forever
                # terminar, e serve_forever so termina depois desta resposta.
                self._json({"ok": True})
                if _SERVIDOR is not None:
                    threading.Timer(0.4, _SERVIDOR.shutdown).start()
            elif rota == "/api/empresas_excluir":
                try:
                    dados = json.loads(body.decode("utf-8"))
                    store.excluir_empresa(dados.get("empresa", ""))
                    self._json({"ok": True, "ativa": store.empresa_ativa_slug()})
                except (ValueError, TypeError) as e:
                    self._json({"ok": False, "erro": str(e)}, 400)
            else:
                self._send(404, "Nao encontrado")
        except Exception as e:  # noqa: BLE001
            self._json({"ok": False, "erro": f"Erro interno: {e}"}, 500)

    # ---- acoes ----
    def _baixar(self, qs):
        token = (qs.get("token") or [""])[0]
        item = _CSV_CACHE.get(token)
        if not item:
            self._send(404, "CSV nao encontrado (gere novamente).")
            return
        dados, nome, ctype = item
        self._send(200, dados, ctype,
                   {"Content-Disposition": f'attachment; filename="{nome}"'})

    def _static(self, rota):
        rel = rota[len("/static/"):]
        caminho = os.path.normpath(os.path.join(STATIC_DIR, rel))
        if not caminho.startswith(STATIC_DIR) or not os.path.isfile(caminho):
            self._send(404, "Arquivo nao encontrado")
            return
        with open(caminho, "rb") as f:
            dados = f.read()
        ctype = "application/octet-stream"
        if caminho.endswith(".png"):
            ctype = "image/png"
        elif caminho.endswith((".jpg", ".jpeg")):
            ctype = "image/jpeg"
        elif caminho.endswith(".svg"):
            ctype = "image/svg+xml"
        elif caminho.endswith(".webp"):
            ctype = "image/webp"
        elif caminho.endswith(".html"):
            ctype = "text/html; charset=utf-8"
        elif caminho.endswith(".json"):
            ctype = "application/json; charset=utf-8"
        self._send(200, dados, ctype)


def abrir_navegador():
    webbrowser.open(f"http://{HOST}:{PORT}/")


def _log_em_arquivo():
    """
    Sob pythonw.exe (sem janela) nao existe stdout: sem isto, qualquer erro
    do servidor sumiria em silencio e o app so ficaria "fora do ar" sem
    explicacao. Manda tudo para dados/servidor.log.
    """
    if sys.stdout is not None:
        return
    caminho = os.path.join(DADOS_DIR, "servidor.log")
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    f = open(caminho, "a", encoding="utf-8", buffering=1)
    sys.stdout = f
    sys.stderr = f


class Servidor(ThreadingHTTPServer):
    """
    allow_reuse_address DESLIGADO de proposito.

    O padrao do http.server e' 1, e no Windows isso deixa DUAS instancias
    ficarem escutando a MESMA porta ao mesmo tempo, sem erro nenhum. O
    resultado foi um problema que custou caro para achar: o Iniciar.bat era
    rodado de novo depois de uma atualizacao, subia um segundo servidor, e as
    requisicoes do navegador continuavam caindo no PRIMEIRO - que estava com o
    codigo ANTIGO carregado na memoria. Na pratica: leitor de extrato novo
    instalado no disco e a tela dizendo "nao reconheci este extrato".

    Com o reuso desligado, a segunda instancia toma OSError e cai no tratamento
    abaixo, que derruba a antiga e assume o lugar - assim quem atende e' sempre
    o codigo mais novo.
    """
    allow_reuse_address = False


def _derrubar_instancia_antiga():
    """Pede /encerrar para o servidor que ja esta na porta. True se ele saiu."""
    import urllib.error
    import urllib.request
    try:
        req = urllib.request.Request(f"http://{HOST}:{PORT}/encerrar",
                                     data=b"", method="POST")
        urllib.request.urlopen(req, timeout=3).read()
    except (urllib.error.URLError, OSError):
        return False
    for _ in range(20):                       # ate 5s esperando a porta soltar
        time.sleep(0.25)
        s = socket.socket()
        try:
            s.bind((HOST, PORT))
            return True
        except OSError:
            continue
        finally:
            s.close()
    return False


def _vigia_tela():
    """Desliga o servidor quando nenhuma tela bate ha SEGUNDOS_SEM_TELA."""
    while True:
        time.sleep(5)
        if time.time() - _ULTIMA_BATIDA <= SEGUNDOS_SEM_TELA:
            continue
        print("Nenhuma tela aberta ha %ds - encerrando." % SEGUNDOS_SEM_TELA)
        if _SERVIDOR is not None:
            # shutdown() nao pode rodar na thread do serve_forever
            threading.Thread(target=_SERVIDOR.shutdown, daemon=True).start()
        return


def main():
    global _SERVIDOR
    _log_em_arquivo()
    store.listar_empresas()  # garante migracao + ao menos 1 empresa cadastrada
    try:
        _SERVIDOR = Servidor((HOST, PORT), Handler)
    except OSError:
        # Ja tem um servidor de pe. Ele pode estar com codigo velho (foi aberto
        # antes da atualizacao), entao a regra e': derruba o antigo e assume.
        print(f"Porta {PORT} ocupada por uma instancia anterior — encerrando "
              f"ela para subir esta, que esta com o codigo atual.")
        if not _derrubar_instancia_antiga():
            print("Nao consegui encerrar a instancia anterior. Abrindo o "
                  "navegador nela; se o sistema parecer desatualizado, feche "
                  "a janela do Jota Contabil e rode o Iniciar.bat de novo.")
            abrir_navegador()
            return
        try:
            _SERVIDOR = Servidor((HOST, PORT), Handler)
        except OSError as e:
            print(f"Porta {PORT} continua ocupada ({e}).")
            abrir_navegador()
            return
    print("=" * 60)
    print("  Jota Contabil")
    print(f"  Rodando em: http://{HOST}:{PORT}/")
    print("  Para encerrar: botao 'Encerrar' no menu do site.")
    print("=" * 60)
    threading.Timer(1.0, abrir_navegador).start()
    threading.Thread(target=_vigia_tela, daemon=True).start()
    try:
        _SERVIDOR.serve_forever()
    except KeyboardInterrupt:
        pass
    print("Encerrado a pedido do usuario.")


if __name__ == "__main__":
    main()
