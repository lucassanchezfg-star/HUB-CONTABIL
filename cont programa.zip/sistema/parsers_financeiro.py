# -*- coding: utf-8 -*-
"""
parsers_financeiro.py - Le as planilhas de CONTAS PAGAS e CONTAS RECEBIDAS
do sistema financeiro (.xlsx, .xls ou .csv).

O CABECALHO NAO ESTA NUMA LINHA FIXA: nos arquivos reais o de pagamentos
comeca na linha 1 e o de recebimentos na linha 2 (a 1 traz o titulo
"Baixas"). Por isso a linha do cabecalho e' PROCURADA - e a primeira que
reconhecer varias das colunas conhecidas - e as colunas sao mapeadas PELO
NOME, com sinonimos, nunca pela posicao.

"NUMERO" E TEXTO, SEMPRE. '000000875' nao pode virar 875 nem 8,75E+05 em
lugar nenhum do caminho: o zero a esquerda faz parte do identificador. Por
isso o campo e lido como veio (o .xlsx guarda como texto) e, quando o Excel
tiver convertido para numero em algum arquivo, e' reconstruido com os zeros
que o formato original tinha.

NAO INVENTA DADO: coluna que nao existir no arquivo fica vazia no registro,
nunca preenchida por deducao.
"""
import os
import re

import parsers
import xls_lite

norm_txt = parsers.norm_txt

# campo interno -> nomes aceitos no cabecalho (comparados sem acento/espaco)
COLUNAS = {
    "prefixo": ("PRF", "PREFIXO"),
    "numero": ("NUMERO", "NRO", "NUM", "DOCUMENTO", "NOTITULO", "NTITULO",
               "NUMTITULO", "NUMEROTITULO"),
    "parcela": ("PRC", "PARCELA"),
    "tp": ("TP", "TIPO"),
    "cli_for": ("CLIFOR", "CLIENTEFORNECEDOR", "CODCLIFOR"),
    # "DADOSCLIFORN" vem no formato "001694/0001-SOLOFORTE" (codigo + nome
    # grudados) - separado depois em _separar_codigo_do_nome.
    "nome": ("NOMECLIFOR", "NOMECLIENTEFORNECEDOR", "NOMEDOFORNECEDOR",
             "NOMEDOCLIENTE", "DADOSCLIFORN", "DADOSCLIENTEFORNECEDOR",
             "FORNECEDOR", "CLIENTE", "NOME"),
    "natureza": ("NATUREZA", "NATUREZADABAIXA"),
    "vencimento": ("VENCTO", "VENCIMENTO", "DTVENCTO", "VENCTOREAL"),
    # HISTORICO e DESCRICAO sao colunas DIFERENTES em alguns relatorios: a
    # descricao traz a natureza do titulo ("CLIENTES") e o historico traz o
    # evento da baixa ("Compensacao de Adiantamentos") - que e' exatamente o
    # texto das exclusoes. Juntar as duas num campo so faria a primeira
    # coluna encontrada vencer e as compensacoes passarem despercebidas.
    "historico": ("HISTORICO", "HIST"),
    "descricao": ("DESCRICAO", "DESCR"),
    "dt_baixa": ("DTBAIXA", "DATABAIXA", "DATADABAIXA"),
    "valor_original": ("VALORORIGINAL", "VLRORIGINAL", "VALORDOTITULO",
                       "VLRTITULO", "VALORTITULO"),
    "juros": ("JURMULTA", "JUROSMULTAS", "JUROSMULTA", "JUROS"),
    "correcao": ("CORRECAO", "VALORDECORRECAO"),
    "descontos": ("DESCONTOS", "DESCONTO"),
    "abatimentos": ("ABATIM", "ABATIMENTOS", "ABATIMENTO",
                    "TOTALDEABATIMENTO"),
    "impostos": ("IMPOSTOS", "IMPOSTO", "TOTALIMPOSTOSRETIDOS"),
    "valor_acessorio": ("VALORACESSORIO", "VALORESACESSORIOS"),
    "total_baixado": ("TOTALBAIXADO", "TOTALDABAIXA", "VALORBAIXADO",
                      "VALORBAIXA"),
    "banco": ("BCO", "BANCO"),
    "dt_digitacao": ("DTDIG", "DATADIGITACAO", "DATADIGIT"),
    "motivo": ("MOT", "MOTIVO", "MOTIVODABAIXA", "MOTBAIXA"),
    "origem": ("ORIG", "ORIGEM"),
    "agencia": ("AGENCIA",),
    "conta_banco": ("CONTABANCO",),
}
# Sem estas o arquivo nao e' um relatorio de baixas.
OBRIGATORIAS = ("nome", "dt_baixa", "total_baixado")

CAMPOS_TEXTO = ("prefixo", "numero", "parcela", "tp", "cli_for", "nome",
                "natureza", "historico", "descricao", "banco", "motivo",
                "origem", "agencia", "conta_banco")

# "001694/0001-SOLOFORTE" -> codigo "001694/0001" + nome "SOLOFORTE".
# Exige que o prefixo seja codigo/subcodigo para nao partir nome de empresa
# que legitimamente tenha hifen ("COMERCIAL SAO JOSE - FILIAL").
RE_CODIGO_NO_NOME = re.compile(r"^([A-Z0-9]{3,8}/\d{3,4})-(.+)$", re.I)


def _separar_codigo_do_nome(reg):
    """Alguns relatorios trazem codigo e nome do cliente numa coluna so."""
    m = RE_CODIGO_NO_NOME.match(reg.get("nome") or "")
    if m:
        if not reg.get("cli_for"):
            reg["cli_for"] = m.group(1)
        reg["nome"] = m.group(2).strip()
    return reg
CAMPOS_VALOR = ("valor_original", "juros", "correcao", "descontos",
                "abatimentos", "impostos", "valor_acessorio", "total_baixado")
CAMPOS_DATA = ("vencimento", "dt_baixa", "dt_digitacao")


def _chave(t):
    return re.sub(r"[^A-Z0-9]", "", norm_txt(t))


def _mapear_cabecalho(valores):
    """{campo: indice/coluna} a partir de uma linha candidata a cabecalho."""
    mapa = {}
    for pos, bruto in valores:
        k = _chave(bruto)
        if not k:
            continue
        for campo, nomes in COLUNAS.items():
            if campo in mapa:
                continue
            if k in nomes or any(k == n for n in nomes):
                mapa[campo] = pos
                break
    return mapa


def _texto(v):
    if v is None:
        return ""
    if isinstance(v, float) and v == int(v):
        return str(int(v))
    return str(v).strip()


def _valor(v):
    if v in (None, ""):
        return 0.0
    if isinstance(v, (int, float)):
        return round(float(v), 2)
    return round(parsers.parse_numero(v), 2)


def _data(v):
    """Serial do Excel ou texto -> 'dd/mm/aaaa'. Vazio quando nao der."""
    import datetime
    if v in (None, ""):
        return ""
    if isinstance(v, (int, float)) or (isinstance(v, str) and re.fullmatch(r"\d{5}(\.0+)?", v.strip())):
        try:
            base = datetime.date(1899, 12, 30)
            return (base + datetime.timedelta(days=int(float(v)))).strftime("%d/%m/%Y")
        except (ValueError, OverflowError):
            return ""
    s = str(v).strip()
    m = re.match(r"^(\d{2})[/-](\d{2})[/-](\d{2,4})", s)
    if m:
        ano = m.group(3)
        ano = ("20" + ano) if len(ano) == 2 else ano
        return f"{m.group(1)}/{m.group(2)}/{ano}"
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})", s)
    if m:
        return f"{m.group(3)}/{m.group(2)}/{m.group(1)}"
    return ""


def _linhas_do_arquivo(caminho):
    """[(numero_da_linha, [(coluna, valor), ...]), ...] para xlsx/xls/csv."""
    ext = os.path.splitext(caminho)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        import zipfile
        with zipfile.ZipFile(caminho) as z:
            shared = parsers._carregar_shared_strings(z)
            for aba in parsers._abas_do_xlsx(caminho):
                sp = parsers._sheet_path_por_nome(z, aba)
                if not sp:
                    continue
                out = [(rn, sorted(cells.items())) for rn, cells in
                       parsers._linhas_xml(z, sp, shared)]
                if out:
                    yield aba, out
        return
    if ext == ".xls":
        linhas = xls_lite.read_sheet(caminho)
        yield "planilha", [(i + 1, list(enumerate(l))) for i, l in enumerate(linhas)]
        return
    linhas = parsers.ler_tabela(caminho)
    yield "planilha", [(i + 1, list(enumerate(l))) for i, l in enumerate(linhas)]


def detectar(caminho):
    try:
        return bool(ler_baixas(caminho))
    except Exception:  # noqa: BLE001
        return False


def ler_baixas(caminho, nome_original=""):
    """
    Devolve {"arquivo","aba","linha_cabecalho","colunas",
             "registros":[{campo: valor}...]}.
    Cada registro traz TODOS os campos internos (vazios quando a coluna nao
    existe no arquivo), mais "_linha" (a linha de origem, para o log).
    """
    nome = nome_original or os.path.basename(caminho)
    for aba, linhas in _linhas_do_arquivo(caminho):
        cab_rn = mapa = None
        for rn, valores in linhas[:30]:
            m = _mapear_cabecalho(valores)
            if len(m) >= 6 and all(c in m for c in OBRIGATORIAS):
                cab_rn, mapa = rn, m
                break
        if mapa is None:
            continue

        registros = []
        for rn, valores in linhas:
            if rn <= cab_rn:
                continue
            cells = dict(valores)
            reg = {"_linha": rn}
            for campo in COLUNAS:
                bruto = cells.get(mapa[campo]) if campo in mapa else None
                if campo in CAMPOS_VALOR:
                    reg[campo] = _valor(bruto)
                elif campo in CAMPOS_DATA:
                    reg[campo] = _data(bruto)
                else:
                    reg[campo] = _texto(bruto)
            _separar_codigo_do_nome(reg)
            # linha sem contraparte e sem valor nao e' baixa (vazia, subtotal
            # ou rodape) - o relatorio nao marca essas linhas de outro jeito
            if not reg["nome"] and not reg["total_baixado"]:
                continue
            # linha de TOTAL/SUBTOTAL: texto de totalizacao no lugar do nome
            if re.match(r"^(TOTAL|SUBTOTAL|TOTAIS)\b", norm_txt(reg["nome"])):
                continue
            registros.append(reg)

        if registros:
            return {"arquivo": nome, "aba": aba, "linha_cabecalho": cab_rn,
                    "colunas": sorted(mapa), "registros": registros}

    raise ValueError(
        "nao achei o cabecalho de um relatorio de baixas (esperava colunas "
        "como Nome Cli/For, Dt Baixa e Total Baixado).")
