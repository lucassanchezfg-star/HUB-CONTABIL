# -*- coding: utf-8 -*-
"""
xlsx_magnojet.py - Grava a planilha final de 9 colunas do modulo Grupo
Magnojet, com a formatacao pedida (fonte Inter, cabecalho azul-escuro com
texto branco, linhas alternadas, filtro, primeira linha congelada).

POR QUE UM GRAVADOR PROPRIO e nao o xlsxescreve compartilhado: o formato
daqui e' fixo e exige recursos que o outro nao tem (filtro automatico,
painel congelado, faixa alternada, data real, coluna forcada a texto).
Enfiar tudo isso no gravador compartilhado mexeria nos estilos usados por
outros seis modulos ja testados - o risco nao compensa para um layout que
nunca muda.

"NUMERO" E "BANCO" SAO GRAVADOS COMO TEXTO. Se fossem numero, '000000875'
viraria 875 e '237' perderia a natureza de codigo. A coluna inteira leva o
formato "@" (texto) alem do valor ser gravado como string.
"""
import datetime
import io
import re
import zipfile

NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NS_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

CABECALHO = ["Data da baixa", "Nome do fornecedor", "TP", "Número",
             "Valor original", "Juros/Multas", "Descontos", "Total da baixa",
             "Banco"]
LARGURAS = [14, 38, 8, 14, 16, 14, 13, 16, 10]

# indices em cellXfs (ver _styles)
E_TEXTO, E_CAB, E_DATA, E_DINHEIRO, E_TXT_COL = 0, 1, 2, 3, 4
E_DATA_Z, E_DINHEIRO_Z, E_TEXTO_Z, E_TXT_COL_Z = 5, 6, 7, 8   # linha zebrada

_BASE = datetime.date(1899, 12, 30)


def _serial(data_br):
    """'05/01/2026' -> serial do Excel. None quando nao for data."""
    m = re.match(r"^(\d{2})/(\d{2})/(\d{4})$", str(data_br or "").strip())
    if not m:
        return None
    d = datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
    return (d - _BASE).days


def _esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;"))


def _num(v):
    return ("%.10f" % float(v)).rstrip("0").rstrip(".") or "0"


def _styles():
    azul_escuro, azul_claro = "FF1F3864", "FFDCE6F1"
    fontes = (
        '<font><sz val="11"/><name val="Inter"/></font>',
        f'<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Inter"/></font>',
    )
    fills = (
        '<fill><patternFill patternType="none"/></fill>',
        '<fill><patternFill patternType="gray125"/></fill>',
        f'<fill><patternFill patternType="solid"><fgColor rgb="{azul_escuro}"/>'
        f'<bgColor indexed="64"/></patternFill></fill>',
        f'<fill><patternFill patternType="solid"><fgColor rgb="{azul_claro}"/>'
        f'<bgColor indexed="64"/></patternFill></fill>',
    )

    def xf(numfmt, font=0, fill=0, extra=""):
        return (f'<xf numFmtId="{numfmt}" fontId="{font}" fillId="{fill}" borderId="0"'
                f' xfId="0" applyFont="1" applyNumberFormat="1" applyFill="1"{extra}/>')

    xfs = [
        xf(0),                                   # 0 texto
        xf(0, 1, 2, ' applyAlignment="1"'),      # 1 cabecalho
        xf(164),                                 # 2 data
        xf(165),                                 # 3 dinheiro
        xf(49),                                  # 4 texto forcado (@)
        xf(164, 0, 3), xf(165, 0, 3), xf(0, 0, 3), xf(49, 0, 3),   # 5-8 zebrado
    ]
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<styleSheet xmlns="{NS}">'
        '<numFmts count="2">'
        '<numFmt numFmtId="164" formatCode="dd/mm/yyyy"/>'
        '<numFmt numFmtId="165" formatCode="#,##0.00"/>'
        '</numFmts>'
        f'<fonts count="{len(fontes)}">{"".join(fontes)}</fonts>'
        f'<fills count="{len(fills)}">{"".join(fills)}</fills>'
        '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        f'<cellXfs count="{len(xfs)}">{"".join(xfs)}</cellXfs>'
        '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
        '</styleSheet>')


def _col(i):
    letra = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        letra = chr(65 + r) + letra
    return letra


def _celula(ref, valor, estilo, texto=False):
    if valor is None or valor == "":
        return f'<c r="{ref}" s="{estilo}"/>'
    if not texto and isinstance(valor, (int, float)) and not isinstance(valor, bool):
        return f'<c r="{ref}" s="{estilo}"><v>{_num(valor)}</v></c>'
    return (f'<c r="{ref}" s="{estilo}" t="inlineStr"><is>'
            f'<t xml:space="preserve">{_esc(valor)}</t></is></c>')


def _sheet(linhas, nome_aba):
    n = len(linhas) + 1
    cols = "".join(f'<col min="{i+1}" max="{i+1}" width="{w}" customWidth="1"'
                   f'{" style=\"4\"" if i in (3, 8) else ""}/>'
                   for i, w in enumerate(LARGURAS))

    corpo = ['<row r="1">' + "".join(
        _celula(f"{_col(i)}1", h, E_CAB, texto=True)
        for i, h in enumerate(CABECALHO)) + "</row>"]

    for n_linha, l in enumerate(linhas, start=2):
        zebra = (n_linha % 2) == 1          # 3a, 5a... linha de dados
        e_data = E_DATA_Z if zebra else E_DATA
        e_din = E_DINHEIRO_Z if zebra else E_DINHEIRO
        e_txt = E_TEXTO_Z if zebra else E_TEXTO
        e_col = E_TXT_COL_Z if zebra else E_TXT_COL

        serial = _serial(l.get("data"))
        cs = [
            _celula(f"A{n_linha}", serial if serial is not None else l.get("data"),
                    e_data, texto=serial is None),
            _celula(f"B{n_linha}", l.get("nome"), e_txt, texto=True),
            _celula(f"C{n_linha}", l.get("tp"), e_txt, texto=True),
            _celula(f"D{n_linha}", l.get("numero"), e_col, texto=True),
            _celula(f"E{n_linha}", l.get("valor_original"), e_din),
            _celula(f"F{n_linha}", l.get("juros"), e_din),
            _celula(f"G{n_linha}", l.get("descontos"), e_din),
            _celula(f"H{n_linha}", l.get("total_baixa"), e_din),
            _celula(f"I{n_linha}", l.get("banco"), e_col, texto=True),
        ]
        corpo.append(f'<row r="{n_linha}">' + "".join(cs) + "</row>")

    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<worksheet xmlns="{NS}" xmlns:r="{NS_R}">'
        f'<dimension ref="A1:I{max(n,1)}"/>'
        '<sheetViews><sheetView workbookViewId="0" tabSelected="1">'
        '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>'
        '</sheetView></sheetViews>'
        '<sheetFormatPr defaultRowHeight="15"/>'
        f'<cols>{cols}</cols>'
        f'<sheetData>{"".join(corpo)}</sheetData>'
        f'<autoFilter ref="A1:I{max(n,1)}"/>'
        '</worksheet>')


def escrever(destino, linhas, nome_aba="Planilha"):
    """destino: caminho ou buffer. linhas: dicts com as chaves do layout."""
    aba = re.sub(r"[\\/*?:\[\]]", "-", nome_aba)[:31] or "Planilha"
    z = zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED)
    z.writestr("[Content_Types].xml",
               '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
               '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
               '<Default Extension="xml" ContentType="application/xml"/>'
               '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
               '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
               '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
               '</Types>')
    z.writestr("_rels/.rels",
               '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
               '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
               '</Relationships>')
    z.writestr("xl/workbook.xml",
               '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               f'<workbook xmlns="{NS}" xmlns:r="{NS_R}"><sheets>'
               f'<sheet name="{_esc(aba)}" sheetId="1" r:id="rId1"/></sheets></workbook>')
    z.writestr("xl/_rels/workbook.xml.rels",
               '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
               '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
               '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
               '</Relationships>')
    z.writestr("xl/styles.xml", _styles())
    z.writestr("xl/worksheets/sheet1.xml", _sheet(linhas, aba))
    z.close()


def bytes_da_planilha(linhas, nome_aba):
    buf = io.BytesIO()
    escrever(buf, linhas, nome_aba)
    return buf.getvalue()


def nome_arquivo(empresa, fluxo, competencia):
    emp = re.sub(r"[^A-Za-z0-9]+", "_", str(empresa or "EMPRESA")).strip("_").upper()
    rot = "Pagamentos" if fluxo == "pagamentos" else "Recebimentos"
    comp = str(competencia or "").replace("/", "-")
    return f"{emp}_{rot}_Tratados_Atualizado_{comp}.xlsx".replace("__", "_")
