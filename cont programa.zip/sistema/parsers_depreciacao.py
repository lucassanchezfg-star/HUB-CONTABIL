# -*- coding: utf-8 -*-
"""
parsers_depreciacao.py - Leitura do RESUMO DA DEPRECIACAO FISCAL POR CONTA
PATRIMONIAL (PDF, relatorio do modulo Patrimonial) - usado pela Auditoria de
Depreciacao para confrontar com o Balancete.

Formato (uma linha por conta patrimonial, SEM espaco entre o codigo e o
nome da conta):

    Codigo Conta patrimonial | Valor aquisicao | Valor original | Depreciacao
    do mes | Baixa original | Baixa depreciacao | Valor ja depreciado |
    Saldo a depreciar

    '2INSTALAÇÕES - 10 ANOS 268.313,34 268.313,34 2.121,18 0,00 0,00 221.690,20 46.623,14'
    'Total: 1.849.016,89 1.849.016,89 21.965,39 0,00 0,00 982.203,37 866.813,52'
    'TOTAL GERAL: 1.849.016,89 1.849.016,89 21.965,39 0,00 0,00 982.203,37 866.813,52'

ARMADILHA: o codigo da conta patrimonial vem COLADO no nome
("2INSTALAÇÕES", nao "2 INSTALAÇÕES") - o relatorio nao usa espaco ali. Por
isso o codigo e separado por regex (digitos no INICIO da linha), nao por
split(" ").

Varios totais aparecem no rodape (por classe de conta, por empresa, geral).
O que interessa e o "TOTAL GERAL" quando existir (soma de todas as empresas/
contas do relatorio); na falta dele, "Total empresa"; na falta dos dois,
"Total" (fecha de qualquer forma, mesmo num relatorio de uma unica empresa
sem esses rodapes extras).
"""
import re

import parsers
import pdftexto

norm_txt = parsers.norm_txt

RE_MONEY = re.compile(r"-?[\d.]+,\d{2}")
RE_CONTA = re.compile(r"^(\d+)(\D.*)$")
RE_COMPETENCIA = re.compile(r"Compet[êe]ncia\s*:\s*(\d{2}/\d{4})", re.I)
RE_CNPJ = re.compile(r"C\.?N\.?P\.?J\.?\s*:\s*([\d./-]+)", re.I)

CAMPOS = ("valor_aquisicao", "valor_original", "depreciacao_mes",
          "baixa_original", "baixa_depreciacao", "valor_depreciado",
          "saldo_a_depreciar")


def detectar(caminho):
    try:
        linhas = pdftexto.linhas_do_pdf(caminho)
    except Exception:  # noqa: BLE001 - PDF corrompido/protegido
        return False
    texto = norm_txt(" ".join(linhas[:8]))
    return "RESUMO DA DEPRECIACAO FISCAL" in texto


def _cabecalho(linhas):
    empresa, cnpj, competencia = "", "", ""
    for l in linhas[:8]:
        m = RE_CNPJ.search(l)
        if m:
            cnpj = m.group(1).strip()
        m = RE_COMPETENCIA.search(l)
        if m:
            competencia = m.group(1)
        if "LTDA" in norm_txt(l) or "S/A" in norm_txt(l) or " S A " in (" " + norm_txt(l) + " "):
            if not empresa and "PÁGINA" not in norm_txt(l) and ":" not in l.split("Página")[0]:
                empresa = re.sub(r"\s*Página.*$", "", l, flags=re.I).strip()
    return empresa, cnpj, competencia


def ler_resumo(caminho, nome_original=""):
    """
    Devolve {"arquivo", "empresa", "cnpj", "competencia", "contas": [...],
             "total": {...}}.

    Cada conta e o "total": {nome/codigo, valor_aquisicao, valor_original,
    depreciacao_mes, baixa_original, baixa_depreciacao, valor_depreciado,
    saldo_a_depreciar}. Levanta ValueError se nao parecer este relatorio.
    """
    linhas = pdftexto.linhas_do_pdf(caminho)
    texto_topo = norm_txt(" ".join(linhas[:8]))
    if "RESUMO DA DEPRECIACAO FISCAL" not in texto_topo:
        raise ValueError("nao parece o 'Resumo da Depreciacao Fiscal' "
                         "(cabecalho nao encontrado).")

    empresa, cnpj, competencia = _cabecalho(linhas)
    contas = []
    totais = {}   # rotulo normalizado -> valores, para escolher o melhor no fim

    for l in linhas:
        n = norm_txt(l)
        m = re.match(r"^(TOTAL\s+GERAL|TOTAL\s+EMPRESA|TOTAL)\s*:\s*(.+)$", l, re.I)
        if m:
            numeros = RE_MONEY.findall(m.group(2))
            if len(numeros) == len(CAMPOS):
                totais[norm_txt(m.group(1))] = _linha(numeros)
            continue
        m = RE_CONTA.match(l)
        if not m:
            continue
        numeros = RE_MONEY.findall(m.group(2))
        if len(numeros) != len(CAMPOS):
            continue
        nome = m.group(2)[:m.group(2).find(numeros[0])].strip()
        conta = {"codigo": m.group(1), "nome": nome}
        conta.update(_linha(numeros))
        contas.append(conta)

    if not contas and not totais:
        raise ValueError("nao encontrei nenhuma conta patrimonial neste PDF.")

    total = (totais.get("TOTAL GERAL") or totais.get("TOTAL EMPRESA")
             or totais.get("TOTAL"))
    if total is None:
        # Sem nenhum rodape de total (relatorio truncado?): soma as contas.
        total = {c: round(sum(x[c] for x in contas), 2) for c in CAMPOS}

    return {"arquivo": nome_original or caminho, "empresa": empresa,
            "cnpj": cnpj, "competencia": competencia, "contas": contas,
            "total": total}


def _linha(numeros):
    return {campo: parsers.parse_numero(v) for campo, v in zip(CAMPOS, numeros)}
