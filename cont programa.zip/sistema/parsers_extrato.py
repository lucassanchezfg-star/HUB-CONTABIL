# -*- coding: utf-8 -*-
"""
parsers_extrato.py - Leitura de extratos bancarios em PDF (Itau e Santander).

Saida padronizada (independente do banco):
    {
      "banco": "ITAU" | "SANTANDER",
      "agencia": "1268",
      "conta": "0097883-8",
      "periodo": ("01/06/2026", "30/06/2026"),
      "lancamentos": [ {"data","historico","documento","valor"}, ... ]
    }

Convencao de sinal: valor > 0 = ENTRADA (dinheiro entrou),
                    valor < 0 = SAIDA  (dinheiro saiu).

COMO O PDF E LIDO (ver pdftexto.py): sem pypdf, so biblioteca padrao.

ESTRUTURA DAS LINHAS (a armadilha principal)
--------------------------------------------
Quando a celula do historico tem DUAS linhas, o PDF entrega TRES linhas de
texto, com a linha que contem data+valor no MEIO:

    Pagamento De Boleto Outros Bancos      <- fragmento (acima)
    19/06/2026 -3.850,60 -522,24           <- ANCORA (data + valor + saldo)
    GRUPO TOTAL BRASIL IND DE              <- fragmento (abaixo)

Por isso o parser localiza as ANCORAS (linha que comeca com data e tem valor)
e cola nelas os fragmentos vizinhos que nao sao ancora.
"""
import re

import pdftexto
from parsers import norm_txt, parse_numero

# Valor monetario BR: exige virgula + 2 decimais.
# Assim CPF/CNPJ ("161.801.568-08", "25.227.713/0001-13") e numero de
# documento ("15050488") NAO sao confundidos com valor.
RE_VALOR = re.compile(r"-?\d{1,3}(?:\.\d{3})*,\d{2}\b")
RE_DATA = re.compile(r"^(\d{2}/\d{2}/\d{4})\b")

# Linhas que nao sao lancamento (saldos, cabecalhos, rodapes)
IGNORAR = (
    "SALDO ANTERIOR", "SALDO TOTAL DISPONIVEL DIA", "SALDO DISPONIVEL",
    "SALDO DE CONTAMAX", "SALDO DE CONTA CORRENTE", "SALDO BLOQUEADO",
    "PROVISAO DE ENCARGOS", "LIMITE CHEQUE", "SALDO DE INVESTIMENTOS",
    "DESBLOQUEIO EM", "JUROS ACUMULADOS ATE A DATA", "IOF ACUMULADO ATE A DATA",
    "PROVISAO DE SEGURO", "DATA HISTORICO", "DATA LANCAMENTOS",
    "LANCAMENTOS DO PERIODO", "CENTRAL DE ATENDIMENTO", "OUVIDORIA",
    "POSICAO EM", "ENTENDA A COMPOSICAO",
    # variante do Santander que fecha CADA DIA com uma linha de saldo
    "SALDO DO DIA",
)


# "-R$ 1.234,56" / "R$ 1.234,56" -> "-1.234,56" / "1.234,56"
#
# Uma das exportacoes do Santander escreve o valor com o simbolo da moeda e
# poe o SINAL ANTES dele. Sem tratar: (1) o "-" ficava separado do numero e
# TODO debito era lido como credito - no extrato de janeiro/2026 da FRAGA as
# saidas somavam ZERO e as entradas R$ 2.281.301,84; (2) o "R$" contava como
# texto do historico, e a linha era tratada como "ja tem historico proprio",
# impedindo a leitura da descricao que vem na linha de baixo.
RE_MOEDA = re.compile(r"(-)?\s*R\$\s*(?=\d)")


def _normalizar_moeda(linha):
    # O ESPACO tem de sobrar: trocar " R$ " por "" colava o valor no que vem
    # antes ("09551021000170 R$ 1.180,00" -> "095510210001701.180,00") e a
    # regex do valor casava "701.180,00" - lancamento de R$ 1.180,00 lido como
    # R$ 701.180,00. O sinal fica grudado no numero, o resto separado.
    return RE_MOEDA.sub(lambda m: " " + (m.group(1) or ""), linha)


# --------------------------------------------------------------------------
# Deteccao do banco
# --------------------------------------------------------------------------
def detectar_banco(caminho):
    """Retorna 'ITAU', 'SANTANDER', 'BRADESCO' ou None, pelo texto do PDF."""
    try:
        linhas = pdftexto.linhas_do_pdf(caminho)
    except Exception:  # noqa: BLE001 - arquivo corrompido/nao-PDF
        return None
    txt = norm_txt(" ".join(linhas))
    # O cabecalho do Bradesco e "Extrato Mensal / Por Periodo" e a tabela tem
    # a coluna "Dcto." - o nome do banco nem sempre aparece no texto.
    if "EXTRATO MENSAL" in txt or "DATA LANCAMENTO DCTO" in txt:
        return "BRADESCO"
    if "SANTANDER" in txt:
        return "SANTANDER"
    if "ITAU.COM.BR" in txt or "SALDO TOTAL DISPONIVEL DIA" in txt:
        return "ITAU"
    return None


# --------------------------------------------------------------------------
# Cabecalho: agencia / conta / periodo
# --------------------------------------------------------------------------
def _agencia_conta(linhas):
    """
    Extrai agencia e conta do cabecalho.
      Itau:      'Agência 1268 Conta 0097883-8'
      Santander: 'Agência: 0578 Conta: 130032809'
    O casamento e tolerante ao acento porque a fonte do Santander as vezes
    devolve 'Agincia' em vez de 'Agencia'.
    """
    ag = cc = ""
    for l in linhas[:25]:
        if not ag:
            m = re.search(r"Ag\S{0,3}ncia:?\s*([0-9]{3,6})", l, re.I)
            if m:
                ag = m.group(1)
        if not cc:
            m = re.search(r"Conta:?\s*([0-9][0-9\.\-]{3,20})", l, re.I)
            if m:
                cc = m.group(1)
        if ag and cc:
            break
    return ag, cc


def _chave_data(d):
    """'dd/mm/aaaa' -> 'aaaammdd' (ordenavel). '' quando nao for data."""
    m = re.match(r"^(\d{2})/(\d{2})/(\d{4})$", str(d or "").strip())
    return (m.group(3) + m.group(2) + m.group(1)) if m else ""


def _periodo_valido(ini, fim):
    """Um par so vale como periodo se estiver em ordem e nao for absurdo."""
    a, b = _chave_data(ini), _chave_data(fim)
    return bool(a and b and a <= b)


def _periodo(linhas):
    """
    Periodo declarado no cabecalho, quando existe e faz sentido.

    O par tem de estar EM ORDEM: na variante consolidada do Santander o
    cabecalho nao traz periodo nenhum e a busca solta pegava duas datas
    quaisquer do corpo do extrato, devolvendo coisas como
    ('27/02/2026', '20/02/2026') - um "periodo" que termina antes de comecar.
    Melhor devolver vazio e deixar quem chama decidir (ver mes_dominante).
    """
    for l in linhas[:25]:
        d = re.findall(r"\d{2}/\d{2}/\d{4}", l)
        if len(d) >= 2 and re.search(r"per\S{0,3}odo|lan\S{0,3}amentos", l, re.I):
            if _periodo_valido(d[0], d[1]):
                return d[0], d[1]
    for l in linhas[:25]:
        d = re.findall(r"\d{2}/\d{2}/\d{4}", l)
        if len(d) >= 2 and _periodo_valido(d[0], d[1]):
            return d[0], d[1]
    return "", ""


def mes_dominante(lancamentos):
    """'mm/aaaa' do mes com mais lancamentos - o mes DO extrato."""
    cont = {}
    for l in lancamentos:
        cont[l["data"][3:]] = cont.get(l["data"][3:], 0) + 1
    if not cont:
        return ""
    return max(cont.items(), key=lambda kv: (kv[1], kv[0]))[0]


def restringir_ao_periodo(dados):
    """
    Tira do extrato os lancamentos que NAO pertencem ao periodo dele.

    POR QUE: o extrato mensal do Santander vem com uma "sobra" dos primeiros
    dias do mes seguinte (o de janeiro/2026 da FRAGA traz 31 lancamentos de
    fevereiro). Importar essa sobra langa o mesmo movimento duas vezes, porque
    ele volta a aparecer no extrato do mes seguinte.

    O CRITERIO E O PERIODO DECLARADO no cabecalho, nao o mes: extrato de
    varios meses num arquivo so (o do Itau da ML cobre fev a jul) declara o
    periodo inteiro e nada e descartado. So quando o cabecalho nao traz
    periodo utilizavel e que vale o MES DOMINANTE.

    Devolve (dados, descartados) - 'dados' e o mesmo dict, com a lista de
    lancamentos ja filtrada.
    """
    lan = dados["lancamentos"]
    ini, fim = dados.get("periodo") or ("", "")
    if _periodo_valido(ini, fim):
        a, b = _chave_data(ini), _chave_data(fim)
        dentro = [l for l in lan if a <= _chave_data(l["data"]) <= b]
        criterio = "periodo %s a %s" % (ini, fim)
    else:
        mes = mes_dominante(lan)
        if not mes:
            return dados, []
        dentro = [l for l in lan if l["data"][3:] == mes]
        criterio = "mes %s" % mes
    fora = [l for l in lan if l not in dentro]
    dados["lancamentos"] = dentro
    dados["criterio_periodo"] = criterio
    return dados, fora


# --------------------------------------------------------------------------
# Nucleo: localizar ancoras e colar os fragmentos
# --------------------------------------------------------------------------
def _e_ignoravel(linha):
    t = norm_txt(linha)
    return any(k in t for k in IGNORAR)


RE_PAGINA = re.compile(r"^\d{1,3}\s*/\s*\d{1,3}$")


def _e_fragmento(linha):
    """Fragmento = continuacao do historico: sem data no inicio e sem valor."""
    if not linha or not linha.strip():
        return False
    if RE_DATA.match(linha.strip()):
        return False
    if RE_VALOR.search(linha):
        return False
    if _e_ignoravel(linha):
        return False
    if RE_PAGINA.match(linha.strip()):   # marcador de pagina "2/20"
        return False
    if not re.search(r"[A-Za-zÀ-ÿ]", linha):  # fragmento tem que ter texto
        return False
    # descartar sujeira de fonte decorativa (logo) e linhas muito curtas
    limpo = re.sub(r"[^A-Za-z0-9À-ÿ ]", "", linha)
    if len(limpo.strip()) < 3:
        return False
    ruins = sum(1 for c in linha if ord(c) > 127 and c not in "áàâãéêíóôõúüçÁÀÂÃÉÊÍÓÔÕÚÜÇº°ª")
    if ruins > max(2, len(linha) // 6):
        return False
    return True


def _proxima_ancora_pelada(linhas, inicio):
    """
    A proxima linha-ancora a partir de 'inicio' vem SEM historico proprio?

    "Pelada" = entre a data e o valor nao ha letra nenhuma. Uma ancora assim
    depende dos fragmentos vizinhos para ter historico; uma que ja tem texto,
    nao. Usado para decidir de quem e o fragmento que fica entre as duas.
    """
    for j in range(inicio, min(inicio + 4, len(linhas))):
        alvo = linhas[j].strip()
        m = RE_DATA.match(alvo)
        if not m:
            continue
        if _e_ignoravel(alvo) or not RE_VALOR.findall(alvo):
            return False
        meio = RE_VALOR.sub(" ", alvo[len(m.group(1)):])
        return not re.search(r"[A-Za-zÀ-ÿ]", meio)
    return False


# --------------------------------------------------------------------------
# BRADESCO ("Extrato Mensal / Por Periodo")
# --------------------------------------------------------------------------
# O desenho do Bradesco nao cabe no laco do Itau/Santander, que pressupoe que
# TODA linha de lancamento comeca com data. Aqui:
#
#     Data       Lancamento             Dcto.   Credito   Debito    Saldo
#     31/07/2026 SALDO ANTERIOR                                  10.981,84
#                DEP ETV DINHEIRO                <- historico (linha de cima)
#     03/08/2026                        8462971 12.037,00       23.018,84
#                9138                            <- complemento (linha de baixo)
#                DEP ETV DINHEIRO
#                                       8471870  6.450,00       29.468,84
#
#   - a DATA aparece so no primeiro lancamento do dia; os demais herdam;
#   - o texto pode vir na linha de cima, na linha de baixo, ou na PROPRIA
#     linha da ancora - e, quando vem na linha da ancora, tanto pode ser o
#     historico ("RENTAB.INVEST FACILCRED* 990077 0,07 133.226,33") como o
#     complemento ("SHOW ATACADO E COMERCIO DE 10569 -13.638,74 27.058,62");
#   - cada linha traz o SALDO CORRENTE, o que permite provar a leitura.
#
# CONFERENCIA: a cadeia de saldos (saldo da linha anterior + valor = saldo
# desta) e verificada lancamento por lancamento, e o extrato ainda declara
# "Total <creditos> <debitos> <saldo>" no fim do periodo. Medido contra o OFX
# dos mesmos 6 extratos da PRECITO: 1.905 de 1.905 lancamentos com data e
# valor iguais, cadeia fechando nos 6, e 1.905 historicos identicos.
RE_ANCORA_BRAD = re.compile(
    r"^(?P<pre>.*?)"
    r"(?:(?P<data>\d{2}/\d{2}/\d{4})\s+)?"
    # O documento tem de ser um TOKEN inteiro: sem o (?<![\d.,]) a linha
    # "Total 3.222.595,96 -3.232.939,66 0,00" casava com documento "96".
    r"(?<![\d.,])(?P<doc>\d{1,14})\s+"
    r"(?P<valor>-?\d{1,3}(?:\.\d{3})*,\d{2})\s+"
    r"(?P<saldo>-?\d{1,3}(?:\.\d{3})*,\d{2})\s*$")

RE_DIA_NA_LINHA = re.compile(r"^(\d{2}/\d{2}/\d{4})\s+(.*)$")

# Linhas que se repetem em cada pagina (o PDF tem 12 folhas).
CABECALHO_BRAD = (
    "EXTRATO MENSAL", "NOME DO USUARIO", "DATA DA OPERACAO", "FOLHA ",
    "AGENCIA | CONTA", "EXTRATO DE:", "DATA LANCAMENTO DCTO",
    "OS DADOS ACIMA TEM COMO BASE", "CNPJ:", "TOTAL ", "SALDOS INVEST",
    "DATA HISTORICO VALOR")
# Daqui para baixo comeca OUTRO extrato: o Bradesco imprime o mes pedido e,
# embaixo, os "Ultimos Lancamentos" do mes seguinte, com SALDO ANTERIOR e
# linha de totais proprios.
CORTE_BRAD = ("ULTIMOS LANCAMENTOS",)


def _e_cabecalho_brad(linha):
    t = norm_txt(linha)
    return any(c in t for c in CABECALHO_BRAD)


def parse_bradesco(caminho):
    """Le o extrato mensal do Bradesco em PDF."""
    linhas = pdftexto.linhas_do_pdf(caminho)

    fim = len(linhas)
    for i, l in enumerate(linhas):
        if any(c in norm_txt(l) for c in CORTE_BRAD):
            fim = i
            break
    corpo = linhas[:fim]

    # A tabela so comeca depois do cabecalho de colunas. Antes dele vem
    # "02647 | 0001428 -1 0,00 0,00" (agencia, conta e saldo), que tem numero
    # e dois valores e casaria como lancamento - entrava um lancamento
    # fantasma no comeco e TODO o historico saia deslocado uma posicao.
    ini = 0
    for i, l in enumerate(corpo):
        if norm_txt(l).startswith("DATA LANCAMENTO DCTO"):
            ini = i + 1
            break

    saldo_anterior = None
    for l in corpo:
        if "SALDO ANTERIOR" in norm_txt(l):
            v = RE_VALOR.findall(l)
            if v:
                saldo_anterior = round(parse_numero(v[-1]), 2)
            break

    agencia = conta = ""
    for l in corpo[:25]:
        m = re.search(r"Ag:\s*(\d+)\s*\|\s*CC:\s*([\d\s.\-]+)", l, re.I)
        if m:
            agencia = m.group(1)
            conta = re.sub(r"\s+", "", m.group(2)).strip()
            break
    periodo = ("", "")
    for l in corpo[:25]:
        if "EXTRATO DE" not in norm_txt(l):
            continue
        m = re.search(r"(\d{2}/\d{2}/\d{4})\D{1,8}(\d{2}/\d{2}/\d{4})", l)
        if m and _periodo_valido(m.group(1), m.group(2)):
            periodo = (m.group(1), m.group(2))
        break

    # --- ancoras ---
    ancoras = []
    for i, l in enumerate(corpo):
        if i < ini or _e_cabecalho_brad(l) or "|" in l:
            continue
        m = RE_ANCORA_BRAD.match(l.strip())
        if not m:
            continue
        data = m.group("data") or ""
        pre = (m.group("pre") or "").strip()
        # Quando a data E o texto vem na MESMA linha da ancora
        # ("18/08/2026 DEP ETV DINHEIRO 8485230 431,00 63.659,26"), o grupo
        # 'data' nao casa - ele exige que o documento venha logo depois - e a
        # data termina dentro do texto. Sem tirar daqui, ela ficava no
        # historico e, pior, o dia nao avancava: os lancamentos seguintes
        # herdavam o dia anterior (30 datas erradas em dois extratos).
        if not data:
            md = RE_DIA_NA_LINHA.match(pre)
            if md:
                data, pre = md.group(1), md.group(2).strip()
        ancoras.append({
            "i": i, "data": data, "doc": m.group("doc"),
            "valor": round(parse_numero(m.group("valor")), 2),
            "saldo": round(parse_numero(m.group("saldo")), 2),
            "pre": pre,
        })
    if not ancoras:
        raise ValueError(
            "nao achei lancamento neste extrato do Bradesco (esperava linhas "
            "com documento, valor e saldo).")

    def texto_entre(a, b):
        """Linhas de texto (nao-ancora) entre dois indices, com o dia delas."""
        out = []
        for j in range(a + 1, b):
            l = corpo[j].strip()
            if not l or _e_cabecalho_brad(l) or "|" in l:
                continue
            if "SALDO ANTERIOR" in norm_txt(l):
                continue
            dia = ""
            m = RE_DIA_NA_LINHA.match(l)
            if m:
                # o primeiro lancamento do dia as vezes traz a data na linha
                # do HISTORICO, nao na da ancora ("18/08/2026 DEP ETV
                # DINHEIRO"). A data sai do texto e vira o dia corrente -
                # sem isso ela ficava dentro do historico.
                dia, l = m.group(1), m.group(2).strip()
                if not l:
                    continue
            out.append((l, dia))
        return out

    vaos = []
    for n, a in enumerate(ancoras):
        anterior = ancoras[n - 1]["i"] if n else ini - 1
        vaos.append(texto_entre(anterior, a["i"]))
    sobra = texto_entre(ancoras[-1]["i"], len(corpo))

    # Quem e HISTORICO e quem e COMPLEMENTO: os vaos de DUAS linhas nao tem
    # ambiguidade ([complemento do anterior][historico deste]), e e deles que
    # sai o repertorio de formas de historico - sao poucas e repetem centenas
    # de vezes ("PAGTO ELETRON COBRANCA", "PIX ENVIADO", "TARIFA BANCARIA").
    # Complemento nunca repete assim: traz nome e data ("REM: FERA
    # DISTRIBUICAO E L 10/08").
    formas_hist = set()
    for v in vaos:
        if len(v) == 2:
            formas_hist.add(norm_txt(v[1][0]))

    lancamentos = []
    dia = ""
    for n, a in enumerate(ancoras):
        v = vaos[n]
        acima = compl_anterior = ""
        if len(v) >= 2:
            compl_anterior = v[0][0]
            acima = " ".join(x[0] for x in v[1:])
        elif len(v) == 1:
            if norm_txt(v[0][0]) in formas_hist:
                acima = v[0][0]
            else:
                compl_anterior = v[0][0]
        for _txt, d in v:
            if d:
                dia = d
        if compl_anterior and lancamentos:
            lancamentos[-1]["historico"] = re.sub(
                r"\s+", " ", lancamentos[-1]["historico"] + " " + compl_anterior).strip()
        dia = a["data"] or dia
        historico = re.sub(r"\s+", " ",
                           " ".join(x for x in (acima, a["pre"]) if x)).strip()
        lancamentos.append({"data": dia, "historico": historico,
                            "documento": a["doc"], "valor": a["valor"],
                            "saldo": a["saldo"]})
    if sobra and lancamentos:
        lancamentos[-1]["historico"] = re.sub(
            r"\s+", " ", lancamentos[-1]["historico"] + " " +
            " ".join(x[0] for x in sobra)).strip()

    # --- conferencia pela cadeia de saldos ---
    divergencias = []
    anterior = saldo_anterior
    for l in lancamentos:
        if anterior is None:
            anterior = round(l["saldo"] - l["valor"], 2)
        esperado = round(anterior + l["valor"], 2)
        if abs(esperado - l["saldo"]) > 0.01:
            divergencias.append({"data": l["data"],
                                 "saldo_calculado": esperado,
                                 "saldo_declarado": l["saldo"],
                                 "diferenca": round(esperado - l["saldo"], 2)})
        anterior = l["saldo"]

    avisos = []
    if divergencias:
        avisos.append(
            "a cadeia de saldos do proprio extrato nao fecha em %d linha(s) "
            "(a primeira e %s, diferenca de %.2f) - pode ter lancamento "
            "faltando ou lido errado."
            % (len(divergencias), divergencias[0]["data"],
               divergencias[0]["diferenca"]))

    return {
        "banco": "BRADESCO", "agencia": agencia, "conta": conta,
        "periodo": periodo, "lancamentos": lancamentos,
        "saldo_anterior": saldo_anterior,
        "saldos_dia": [], "avisos": avisos,
        "conferencia": {"tem_saldos": True, "dias": len(lancamentos),
                        # o Bradesco imprime o saldo em CADA LINHA, nao um por
                        # dia - a conferencia e linha por linha
                        "rotulo": "Cadeia de saldos do extrato, linha por "
                                  "linha (%d linhas)" % len(lancamentos),
                        "fecha": not divergencias,
                        "divergencias": divergencias,
                        "saldo_abertura": saldo_anterior,
                        "saldo_final": lancamentos[-1]["saldo"] if lancamentos else None},
    }


def parse_extrato(caminho, banco=None):
    """Le o extrato e devolve o dicionario padronizado."""
    banco = banco or detectar_banco(caminho)
    if banco == "BRADESCO":
        return parse_bradesco(caminho)
    if banco not in ("ITAU", "SANTANDER"):
        raise ValueError(
            "PDF nao reconhecido como extrato do Itau, Santander ou Bradesco.")

    linhas = [_normalizar_moeda(l) for l in pdftexto.linhas_do_pdf(caminho)]
    # Variante "extrato consolidado" do Santander: fecha cada dia com uma
    # linha "Saldo do dia Cc" e poe a DESCRICAO SEMPRE NA LINHA DE BAIXO da
    # linha de data+valor (nas outras exportacoes a descricao vem na propria
    # linha). Tratada em separado porque as duas convencoes se excluem: pegar
    # o fragmento de cima aqui rouba a descricao do lancamento anterior.
    consolidado = (banco == "SANTANDER"
                   and any("SALDO DO DIA" in norm_txt(l) for l in linhas))
    agencia, conta = _agencia_conta(linhas)
    periodo = _periodo(linhas)

    usados = set()
    lancamentos = []

    for i, linha in enumerate(linhas):
        m = RE_DATA.match(linha.strip())
        if not m:
            continue
        if _e_ignoravel(linha):
            continue
        valores = RE_VALOR.findall(linha)
        if not valores:
            continue

        data = m.group(1)
        resto = linha.strip()[len(data):]

        # valor do lancamento:
        #   2+ valores -> o ULTIMO e o saldo corrente, o penultimo e o valor
        #   1 valor    -> e o valor
        bruto_valor = valores[-2] if len(valores) >= 2 else valores[-1]
        valor = parse_numero(bruto_valor)

        # texto do meio: tira todos os valores monetarios do resto
        meio = RE_VALOR.sub(" ", resto)

        # Absorver os fragmentos vizinhos? A politica DIFERE por banco:
        #
        # ITAU: "Razao Social" e uma COLUNA separada que quebra em 2 linhas
        #   independentemente do texto de "Lancamentos" -> sempre tenta absorver.
        #
        # SANTANDER: o historico e UMA coluna so. Se a linha-ancora ja tem texto
        #   no meio, aquele texto E o historico completo e absorver vizinho
        #   grudaria o lancamento seguinte. Só absorve quando a coluna do
        #   historico esta vazia na ancora (meio sem NENHUMA letra - pode conter
        #   apenas o numero do documento).
        if consolidado:
            absorver = True          # sempre ha descricao na linha de baixo
        elif banco == "SANTANDER":
            absorver = not re.search(r"[A-Za-zÀ-ÿ]", meio)
        else:
            absorver = True

        tem_texto_proprio = bool(re.search(r"[A-Za-zÀ-ÿ]", meio))

        partes = [meio]
        if consolidado:
            # SO o fragmento de baixo, e so um
            if i + 1 < len(linhas) and (i + 1) not in usados and _e_fragmento(linhas[i + 1]):
                partes.append(linhas[i + 1])
                usados.add(i + 1)
        elif absorver:
            if i - 1 >= 0 and (i - 1) not in usados and _e_fragmento(linhas[i - 1]):
                partes.append(linhas[i - 1])
                usados.add(i - 1)
            # O fragmento ABAIXO so vem para ca se esta ancora precisar dele -
            # isto e, se a PROXIMA ancora nao estiver "pelada". No Itau o
            # rendimento da aplicacao vem como uma ancora sem texto nenhum:
            #
            #     02/02/2026 TAR/CUSTAS COBRANCA -8,49   <- tem texto proprio
            #     RENDIMENTOS REND PAGO APLIC            <- fragmento
            #     02/02/2026 0,03                        <- ancora PELADA
            #     AUT MAIS                               <- fragmento
            #
            # Pegando o fragmento sempre, a tarifa saia com o historico do
            # rendimento colado ("TAR/CUSTAS COBRANCA RENDIMENTOS REND PAGO
            # APLIC") e o rendimento ficava so com "AUT MAIS" - 26 tarifas e
            # 26 rendimentos com o historico trocado num extrato so, sem erro
            # nenhum na tela. Ancora pelada tem prioridade no fragmento.
            if (i + 1 < len(linhas) and (i + 1) not in usados
                    and _e_fragmento(linhas[i + 1])
                    and not (tem_texto_proprio
                             and _proxima_ancora_pelada(linhas, i + 1))):
                partes.append(linhas[i + 1])
                usados.add(i + 1)

        historico = re.sub(r"\s+", " ", " ".join(partes)).strip(" -")
        documento = _documento(historico)

        # No consolidado ha lancamento SEM descricao nenhuma (tarifa avulsa);
        # descartar por historico vazio perdia lancamento de verdade e o dia
        # deixava de fechar contra a linha "Saldo do dia".
        if not historico and not consolidado:
            continue
        lancamentos.append({
            "data": data,
            "historico": historico,
            "documento": documento,
            "valor": valor,
        })

    return {
        "banco": banco,
        "agencia": agencia,
        "conta": conta,
        "periodo": periodo,
        "lancamentos": lancamentos,
        **_saldos(linhas),
    }


def _saldos(linhas):
    """
    Saldos declarados pelo proprio extrato (para CONFERENCIA na tela).
    ATENCAO: saldo NUNCA entra no CSV - e informacao de tela.
      Itau:      'SALDO ANTERIOR' e a ultima 'SALDO TOTAL DISPONIVEL DIA'
      Santander: linha 'G' do quadro de composicao do saldo (ver abaixo)
    Retorna {'saldo_anterior': float|None, 'saldo_final': float|None}

    ARMADILHA (Santander): a linha do TOPO "Saldo disponivel para uso: R$
    200.269,52" NAO E o saldo de caixa - inclui o LIMITE de cheque especial
    (ex.: R$ 200.000,00 somados por cima). Contabilmente o saldo de caixa e
    a linha "G" do quadro no RODAPE do extrato:
        E - Saldo disponivel de Conta Corrente (A-B)
        F - Saldo de Investimentos com Resgate Automatico
        G - Saldo disponivel de Conta Corrente + Saldo de investimentos (E+F)
        H - Limite Cheque Empresa                    <- SO A PARTIR DAQUI
        J - Saldo Disponivel + Limite (G + H + I)     <- entra o limite
    Sem esta distincao, toda empresa com limite de cheque especial no
    Santander teria o saldo final inflado pelo limite - conferido contra o
    balancete: G bate exatamente, a linha do topo (e a "J") nao.
    O ROTULO e o VALOR vem em linhas SEPARADAS nesse quadro (rotulo numa
    linha, valor sozinho na linha seguinte) - por isso o valor e procurado
    tambem na linha seguinte, nao so na propria linha do rotulo.
    """
    anterior = final = None
    for i, l in enumerate(linhas):
        t = norm_txt(l)
        vals = RE_VALOR.findall(l)
        if anterior is None and "SALDO ANTERIOR" in t and vals:
            anterior = parse_numero(vals[-1])
        if "SALDO TOTAL DISPONIVEL DIA" in t and vals:
            final = parse_numero(vals[-1])          # fica o ultimo encontrado
        elif ("SALDO DISPONIVEL DE CONTA CORRENTE" in t
              and "SALDO DE INVESTIMENTOS" in t):
            candidatos = vals or (RE_VALOR.findall(linhas[i + 1])
                                 if i + 1 < len(linhas) else [])
            if candidatos:
                final = parse_numero(candidatos[-1])   # linha G: sempre a mais confiavel
        elif final is None and "SALDO DE CONTA CORRENTE" in t and vals:
            final = parse_numero(vals[-1])
        elif final is None and "SALDO DISPONIVEL PARA USO" in t and vals:
            final = parse_numero(vals[-1])
    return {"saldo_anterior": anterior, "saldo_final": final}


def _documento(historico):
    """Ultimo numero longo do historico (CPF/CNPJ ou nº do documento), se houver."""
    achados = re.findall(r"\b\d{6,20}\b", historico.replace(".", "").replace("-", ""))
    return achados[-1] if achados else ""
