# -*- coding: utf-8 -*-
"""
parsers_ofx.py - Leitura de extratos bancarios em OFX (Money 2000 / OFX 1.x).

POR QUE LER OFX E NAO SO O PDF
------------------------------
No PDF o lancamento e RECONSTRUIDO: o texto vem em pedacos (historico numa
linha, valor noutra, complemento numa terceira), e o leitor tem de adivinhar
onde cada um comeca e termina. Ja errou nisso - historico trocado entre
rendimento e tarifa, sinal de debito perdido, texto dentro de Form XObject
devolvendo zero linha. Um extrato de 115 paginas do Safra tem alguns milhares
de linhas de texto para 1.500 lancamentos.

No OFX cada lancamento e um REGISTRO FECHADO (<STMTTRN>) com data, valor com
sinal, documento e historico em campos proprios. Nao ha o que adivinhar, e
nao ha como "pular" um lancamento sem que a contagem de registros mude.

O PDF continua servindo: e dele que sai o TOTAL DECLARADO pelo banco
(ver core_extrato_conf), e e contra ele que a leitura do OFX e conferida.

O FORMATO NAO E XML
-------------------
OFX 1.x e SGML: as tags de valor NAO fecham -
    <TRNAMT>-1234,56
    <MEMO>PIX ENVIADO
Por isso nao da para usar ElementTree; a leitura e feita a mao, tag por tag.

TRES ARMADILHAS REAIS (vistas nos arquivos da PRECITO)
------------------------------------------------------
1. DECIMAL: o Bradesco escreve "12037,00" (virgula) e o Itau/Safra "116.28"
   (ponto). Ler tudo como ponto transformaria 12.037,00 em 12,037 - e o
   extrato fecharia com diferenca de milhares. Aqui o separador e decidido
   por valor, olhando o que ele tem.
2. VARIOS <MEMO>: o Safra manda dois (historico e complemento) e o Bradesco
   um so, ja juntado. Os dois viram um historico so, na ordem.
3. LEDGERBAL NAO E CONFIAVEL: o Itau escreveu o saldo 0,39 como
   "<BALAMT>039". O saldo declarado do OFX so e usado quando bate com a
   soma; quem manda na conferencia e o PDF.

Fora isso, o arquivo pode trazer MAIS DE UM PERIODO (o Bradesco junta o mes
mais os "Ultimos Lancamentos" do mes seguinte) - por isso a saida traz a data
de cada lancamento e quem chama restringe ao mes (ver
parsers_extrato.restringir_ao_periodo).
"""
import re

# BANKID (codigo COMPE) -> nome do banco. So para rotular; a conta contabil
# vem do cadastro, nunca daqui.
BANCOS = {
    "001": "BANCO DO BRASIL", "033": "SANTANDER", "041": "BANRISUL",
    "070": "BRB", "077": "INTER", "104": "CAIXA", "208": "BTG",
    "212": "ORIGINAL", "218": "BS2", "237": "BRADESCO", "246": "ABC",
    "260": "NUBANK", "290": "PAGSEGURO", "318": "BMG", "336": "C6",
    "341": "ITAU", "356": "REAL", "364": "GERENCIANET", "389": "MERCANTIL",
    "399": "HSBC", "422": "SAFRA", "453": "RURAL", "633": "RENDIMENTO",
    "652": "ITAU UNIBANCO", "655": "VOTORANTIM", "707": "DAYCOVAL",
    "745": "CITIBANK", "748": "SICREDI", "756": "SICOOB",
}


def _texto(caminho):
    """Le o arquivo respeitando o CHARSET declarado no cabecalho."""
    with open(caminho, "rb") as f:
        cru = f.read()
    # O cabecalho e ASCII puro, entao da para lê-lo antes de decidir o resto.
    topo = cru[:400].decode("ascii", "replace")
    cs = ""
    m = re.search(r"CHARSET:\s*(\S+)", topo)
    if m:
        cs = m.group(1).strip().upper()
    codecs_tentar = []
    if cs in ("1252", "WINDOWS-1252", "CP1252"):
        codecs_tentar = ["cp1252"]
    elif cs in ("UTF-8", "UTF8"):
        codecs_tentar = ["utf-8"]
    codecs_tentar += ["cp1252", "utf-8", "latin-1"]
    for c in codecs_tentar:
        try:
            return cru.decode(c)
        except (UnicodeDecodeError, LookupError):
            continue
    return cru.decode("latin-1", "replace")


def _num(txt):
    """
    '12037,00' -> 12037.0   |   '116.28' -> 116.28   |   '-1.234,56' -> -1234.56

    O separador decimal e decidido POR VALOR, nao pelo arquivo: o mesmo
    escritorio recebe Bradesco com virgula e Itau com ponto, e tratar todos
    como ponto lia "12037,00" como 12,037 - erro de milhares que so apareceria
    na conferencia do saldo.
    """
    t = (txt or "").strip().replace(" ", "").replace("R$", "")
    if not t:
        return None
    neg = t.startswith("-")
    t = t.lstrip("+-")
    if "," in t:
        # virgula presente = ela e o decimal; o ponto e separador de milhar
        t = t.replace(".", "").replace(",", ".")
    # so ponto: ja esta no formato do float (o milhar nunca aparece junto
    # com decimal em ponto nos arquivos que vimos)
    try:
        v = float(t)
    except ValueError:
        return None
    return -v if neg else v


def _data(txt):
    """'20260803120000[-3:GMT]' -> '03/08/2026'. Vazio quando nao der."""
    m = re.match(r"\s*(\d{4})(\d{2})(\d{2})", str(txt or ""))
    if not m:
        return ""
    a, mes, d = m.groups()
    if not ("1900" < a < "2200" and "01" <= mes <= "12" and "01" <= d <= "31"):
        return ""
    return "%s/%s/%s" % (d, mes, a)


# Registros que o banco manda como <STMTTRN> mas que sao SALDO, nao
# movimento. O Safra fecha cada dia com um "SALDO TOTAL" de tipo BALANCE.
RE_SALDO_MEMO = re.compile(r"^\s*SALDO\b", re.I)


def _e_saldo(item):
    return item["tipo"] == "BALANCE" or bool(RE_SALDO_MEMO.match(item["historico"]))


def chave_data(d):
    """'dd/mm/aaaa' -> 'aaaammdd', para ordenar e comparar datas."""
    m = re.match(r"^(\d{2})/(\d{2})/(\d{4})$", str(d or "").strip())
    return (m.group(3) + m.group(2) + m.group(1)) if m else ""


def competencia_dominante(lancamentos):
    """
    'mm/aaaa' do mes com MAIS lancamentos.

    O arquivo do Bradesco junta o mes pedido com os "Ultimos Lancamentos" do
    mes seguinte; o mes dominante e o que o extrato realmente e.
    """
    contagem = {}
    for l in lancamentos:
        k = chave_data(l.get("data"))
        if k:
            mes = "%s/%s" % (k[4:6], k[:4])
            contagem[mes] = contagem.get(mes, 0) + 1
    if not contagem:
        return ""
    return max(contagem.items(), key=lambda kv: kv[1])[0]


def restringir_ao_mes(extrato, competencia=""):
    """
    Deixa no extrato SO os lancamentos do mes dele, e devolve o que saiu.

    Motivo: o Bradesco entrega o mes pedido E os "Ultimos Lancamentos" do mes
    seguinte no mesmo arquivo (no 1428-1 o bloco de agosto fecha em 31/08 com
    saldo 638,14 e depois comeca outro, com SALDO ANTERIOR de 01/09).
    Importar os dois juntos lancaria setembro dentro de agosto.
    """
    comp = competencia or competencia_dominante(extrato["lancamentos"])
    if not comp:
        return []
    mes, ano = comp.split("/")
    alvo = ano + mes
    dentro, fora = [], []
    for l in extrato["lancamentos"]:
        k = chave_data(l.get("data"))
        (dentro if k[:6] == alvo else fora).append(l)
    extrato["lancamentos"] = dentro
    extrato["competencia"] = comp
    extrato["fora_do_mes"] = fora
    if fora:
        extrato["avisos"].append(
            "%d lancamento(s) fora de %s vieram no mesmo arquivo e ficaram "
            "DE FORA da importacao (o banco junta os primeiros dias do mes "
            "seguinte no fim do extrato)." % (len(fora), comp))
    _conferir(extrato)
    return fora


def juntar(extratos):
    """
    Junta pedacos do MESMO mes da MESMA conta num extrato so.

    Acontece de verdade: o Safra de Brasilia vem em dois arquivos, "(01 a 15)"
    e "(16 a 31)", e os dois trazem o dia 17/08 INTEIRO - 427 lancamentos
    repetidos, com os mesmos identificadores. Somar os dois arquivos contaria
    esse dia duas vezes; usar so um deixaria metade do mes de fora.

    A chave da juncao e (data, FITID), o identificador que o proprio banco da
    ao lancamento. Sem FITID, cai para data+valor+documento+historico.
    """
    grupos = {}
    for e in extratos:
        chave = (e.get("banco_id", ""), re.sub(r"\D", "", e.get("conta", "")))
        grupos.setdefault(chave, []).append(e)

    saida = []
    for chave, partes in grupos.items():
        if len(partes) == 1:
            saida.append(partes[0])
            continue
        base = dict(partes[0])
        base["arquivo"] = " + ".join(p["arquivo"] for p in partes)
        base["lancamentos"] = []
        base["saldos_dia"] = []
        base["avisos"] = []
        vistos, saldos = set(), {}
        for p in partes:
            base["avisos"].extend(p.get("avisos") or [])
            for l in p["lancamentos"]:
                k = ((l["data"], l["fitid"]) if l["fitid"] else
                     (l["data"], l["valor"], l["documento"], l["historico"]))
                if k in vistos:
                    continue
                vistos.add(k)
                base["lancamentos"].append(l)
            for s in p["saldos_dia"]:
                antigo = saldos.get(s["data"])
                if antigo is not None and abs(antigo["saldo"] - s["saldo"]) > 0.01:
                    base["avisos"].append(
                        "os arquivos discordam do saldo de %s (%.2f e %.2f) - "
                        "confira se sao do mesmo extrato."
                        % (s["data"], antigo["saldo"], s["saldo"]))
                saldos[s["data"]] = s
        base["saldos_dia"] = sorted(saldos.values(),
                                    key=lambda s: chave_data(s["data"]))
        base["lancamentos"].sort(key=lambda l: (chave_data(l["data"]), l["fitid"]))
        base["juntado_de"] = len(partes)
        _conferir(base)
        saida.append(base)
    return saida


def _limpar(s):
    """
    Junta os espacos e DESESCAPA as entidades de XML.

    O OFX do Bradesco escreve "A&amp;A PIZZARIA" para "A&A PIZZARIA". Sem
    desescapar, o nome do favorecido fica com "&amp;" no meio do historico e
    nao casa com a conta "A&A ..." do plano de contas.
    """
    t = re.sub(r"\s+", " ", str(s or "")).strip()
    if "&" in t:
        for ent, ch in (("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"),
                        ("&quot;", '"'), ("&apos;", "'"), ("&#39;", "'")):
            t = t.replace(ent, ch)
    return t


def detectar(caminho):
    """True quando o arquivo e um OFX de extrato bancario."""
    try:
        t = _texto(caminho)
    except OSError:
        return False
    return "<OFX" in t.upper() and "<STMTTRN>" in t.upper()


def ler_ofx(caminho, nome_original=""):
    """
    Devolve UMA LISTA de extratos (um por conta encontrada no arquivo):

        {"arquivo","banco","banco_id","agencia","conta","periodo",
         "saldo_declarado","lancamentos":[...],"avisos":[...]}

    Cada lancamento: {"data","historico","documento","valor","fitid","tipo"}.
    Sinal: valor > 0 = ENTRADA, valor < 0 = SAIDA (a mesma convencao do
    parsers_extrato, para os dois leitores serem intercambiaveis).
    """
    nome = nome_original or caminho.rsplit("\\", 1)[-1].rsplit("/", 1)[-1]
    texto = _texto(caminho)
    if "<STMTTRN>" not in texto.upper():
        raise ValueError(
            "este arquivo nao tem lancamentos de extrato (<STMTTRN>) - "
            "confira se e um OFX de conta corrente.")

    extratos = _percorrer(texto, nome)
    for e in extratos:
        _conferir(e)
    return extratos


def _percorrer(texto, nome):
    """
    Quebra o texto em blocos de conta (<STMTRS>) e, dentro de cada um, em
    blocos de lancamento (<STMTTRN>). Fatiar e mais simples de acertar do que
    manter estado num laco de tags - e um lancamento que nao caiba no molde
    aparece como bloco vazio, nunca some sem aviso.
    """
    extratos = []
    blocos = re.split(r"<(?:STMTRS|CCSTMTRS)>", texto)[1:]
    if not blocos:                       # arquivo sem o invólucro esperado
        blocos = [texto]
    for bloco in blocos:
        e = {"arquivo": nome, "banco": "", "banco_id": "", "agencia": "",
             "conta": "", "periodo": ("", ""), "saldo_declarado": None,
             "lancamentos": [], "saldos_dia": [], "avisos": []}

        cab = bloco.split("<BANKTRANLIST>")[0]
        e["banco_id"] = _primeira(cab, "BANKID")
        chave = e["banco_id"].lstrip("0").zfill(3)
        e["banco"] = BANCOS.get(chave, "")
        e["agencia"] = _primeira(cab, "BRANCHID")
        e["conta"] = _primeira(cab, "ACCTID")

        lista = bloco.split("<BANKTRANLIST>")
        corpo = lista[1] if len(lista) > 1 else bloco
        e["periodo"] = (_data(_primeira(corpo, "DTSTART")),
                        _data(_primeira(corpo, "DTEND")))

        m = re.search(r"<LEDGERBAL>(.*?)(?:</LEDGERBAL>|<STMTRS>|$)",
                      bloco, re.S)
        if m:
            e["saldo_declarado"] = _num(_primeira(m.group(1), "BALAMT"))

        for trecho in re.split(r"<STMTTRN>", corpo)[1:]:
            trecho = re.split(r"</STMTTRN>", trecho)[0]
            valor = _num(_primeira(trecho, "TRNAMT"))
            data = _data(_primeira(trecho, "DTPOSTED"))
            memos = [v for v in _todas(trecho, "MEMO") if v]
            if not memos:
                memos = [v for v in _todas(trecho, "NAME") if v]
            if valor is None:
                e["avisos"].append(
                    "'%s': um lancamento de %s veio sem valor (<TRNAMT>) e "
                    "ficou de fora - a soma nao vai fechar."
                    % (nome, data or "data desconhecida"))
                continue
            item = {
                "data": data,
                "historico": _limpar(" ".join(memos)),
                "documento": _limpar(_primeira(trecho, "CHECKNUM")),
                "valor": round(valor, 2),
                "fitid": _limpar(_primeira(trecho, "FITID")),
                "tipo": _primeira(trecho, "TRNTYPE").upper(),
            }
            if _e_saldo(item):
                # NAO e movimento: e o saldo do dia declarado pelo banco.
                # Somar isso junto inflaria o extrato exatamente no valor do
                # saldo de cada dia (no Safra de Cuiaba seriam 21 registros a
                # mais e R$ 57 mil de entrada que nunca existiram). Guardado
                # a parte, vira o CONFERENTE da leitura.
                e["saldos_dia"].append({"data": item["data"],
                                        "saldo": item["valor"],
                                        "rotulo": item["historico"]})
                continue
            e["lancamentos"].append(item)
        if e["lancamentos"] or e["conta"]:
            extratos.append(e)
    return extratos


def _primeira(txt, tag):
    m = re.search(r"<%s>([^<\r\n]*)" % tag, txt, re.I)
    return m.group(1).strip() if m else ""


def _todas(txt, tag):
    return [x.strip() for x in re.findall(r"<%s>([^<\r\n]*)" % tag, txt, re.I)]


def _conferir(e):
    """
    Confere a leitura contra o que o proprio arquivo declara.

    O sinal do valor e comparado com o TRNTYPE: um DEBIT com valor positivo
    (ou o contrario) e sintoma de decimal/sinal lido errado, e e melhor
    avisar do que gerar lancamento invertido.
    """
    trocados = [l for l in e["lancamentos"]
                if (l["tipo"] == "DEBIT" and l["valor"] > 0)
                or (l["tipo"] == "CREDIT" and l["valor"] < 0)]
    if trocados:
        e["avisos"].append(
            "%d lancamento(s) com sinal contrario ao tipo declarado no "
            "arquivo (ex.: DEBIT com valor positivo) - confira antes de usar."
            % len(trocados))

    # Ordenar "dd/mm/aaaa" como TEXTO da errado ("02/09/2026" vem antes de
    # "31/08/2026"), e a primeira/ultima data do extrato sairia trocada.
    datas = sorted((l["data"] for l in e["lancamentos"] if l["data"]),
                   key=chave_data)
    e["primeira_data"] = datas[0] if datas else ""
    e["ultima_data"] = datas[-1] if datas else ""
    e["entradas"] = round(sum(l["valor"] for l in e["lancamentos"]
                              if l["valor"] > 0), 2)
    e["saidas"] = round(sum(l["valor"] for l in e["lancamentos"]
                            if l["valor"] < 0), 2)
    e["total"] = round(e["entradas"] + e["saidas"], 2)
    sem_data = sum(1 for l in e["lancamentos"] if not l["data"])
    if sem_data:
        e["avisos"].append(
            "%d lancamento(s) sem data legivel (<DTPOSTED>)." % sem_data)
    _conferir_cadeia(e)
    return e


def _conferir_cadeia(e):
    """
    CONFERENCIA DIA A DIA contra o saldo que o banco declara.

    Quando o arquivo traz o saldo de cada dia, a VARIACAO entre dois dias
    seguidos tem de ser exatamente a soma dos lancamentos do dia de tras.
    Se um lancamento tiver sido pulado - ou contado duas vezes - a diferenca
    aparece no dia em que aconteceu, com nome e data.

    O saldo de ABERTURA nao vem no arquivo, entao o primeiro dia nao da para
    conferir; ele e DEDUZIDO (saldo do 1o dia menos o movimento do 1o dia) e
    fica registrado em 'saldo_abertura' para quem quiser comparar com o
    balancete.
    """
    e["conferencia"] = {"tem_saldos": False, "dias": 0, "divergencias": [],
                        "fecha": None, "saldo_abertura": None,
                        "saldo_final": None}
    saldos = [s for s in e["saldos_dia"] if chave_data(s["data"])]
    if not saldos:
        return
    saldos.sort(key=lambda s: chave_data(s["data"]))

    por_dia = {}
    for l in e["lancamentos"]:
        k = chave_data(l["data"])
        if k:
            por_dia[k] = round(por_dia.get(k, 0.0) + l["valor"], 2)

    primeiro = saldos[0]
    abertura = round(primeiro["saldo"] - por_dia.get(
        chave_data(primeiro["data"]), 0.0), 2)

    difs = []
    anterior = primeiro["saldo"]
    for s in saldos[1:]:
        mov = por_dia.get(chave_data(s["data"]), 0.0)
        esperado = round(anterior + mov, 2)
        if abs(esperado - s["saldo"]) > 0.01:
            difs.append({"data": s["data"], "saldo_declarado": s["saldo"],
                         "saldo_calculado": esperado,
                         "diferenca": round(esperado - s["saldo"], 2)})
        anterior = s["saldo"]

    # dia com movimento mas sem saldo declarado: nao da para conferir
    sem_saldo = sorted(set(por_dia) - {chave_data(s["data"]) for s in saldos})

    e["conferencia"] = {
        "tem_saldos": True, "dias": len(saldos), "divergencias": difs,
        "fecha": not difs, "saldo_abertura": abertura,
        "saldo_final": saldos[-1]["saldo"],
        "dias_sem_saldo": ["%s/%s/%s" % (d[6:], d[4:6], d[:4]) for d in sem_saldo],
    }
    if difs:
        e["avisos"].append(
            "o saldo declarado pelo banco nao fecha em %d dia(s) (o primeiro "
            "e %s, diferenca de %.2f) - pode ter lancamento faltando ou "
            "repetido nesse dia."
            % (len(difs), difs[0]["data"], difs[0]["diferenca"]))
    if sem_saldo:
        e["avisos"].append(
            "%d dia(s) com movimento nao trazem saldo declarado, entao nao "
            "foram conferidos: %s."
            % (len(sem_saldo), ", ".join(e["conferencia"]["dias_sem_saldo"][:6])))
