# -*- coding: utf-8 -*-
"""
parsers_extrato_saldo.py - Le extratos bancarios de VARIOS bancos e devolve
so o que a Auditoria de Extrato Bancario precisa: banco, agencia, conta,
saldo anterior e saldo final do periodo - nunca a lista de lancamentos (isso
e trabalho do modulo CONTABIL/Extrato Bancario, parsers_extrato.py).

Cada arquivo pode gerar MAIS DE UM registro: um extrato de conta corrente do
Bradesco, por exemplo, traz embutida a tabela "Saldos Invest Fácil" (a
aplicacao automatica ligada aquela conta) - os dois saem separados.

Saida (lista de dicts, um por "conta" encontrada no arquivo):
    {"arquivo", "tipo": "corrente"|"aplicacao", "banco", "agencia", "conta",
     "competencia", "saldo_anterior", "saldo_final", "modo", "detalhe"}

    "modo" (so em aplicacao):
      "movimento" - saldo_final = saldo_anterior + aplicacoes - resgates
                    (a MESMA formula que a contabilidade usa - bate exato)
      "direto"    - saldo_final lido de uma tabela de saldo diario do banco
                    (pode ter uma diferenca de centavos por ser um "retrato"
                    tirado em outro instante, nao um fechamento contabil)

DETECCAO SEMPRE PELO CONTEUDO, nunca pelo nome do arquivo - o mesmo banco
exporta o MESMO extrato em formatos de PDF diferentes (visto no Bradesco:
duas ferramentas de exportacao dão o mesmo dado com layouts e ate qualidade
de fonte diferentes).

ARMADILHA GERAL: alguns geradores de PDF renderizam caractere por caractere
com espacamento tao inconsistente que pdftexto.py nao consegue reconstruir
o texto com espacos corretos em NENHUM limiar (ver o comentario grande em
pdftexto._limiar_espaco - Balancete e este tipo de extrato puxam o limiar
em direcoes opostas). A saida: procurar palavra-chave e numero no texto SEM
ESPACO NENHUM (funcao `_semespaco`) - um valor monetario tem seu proprio
delimitador (",XX" = exatamente 2 casas), entao remover espaco NUNCA cola
dois numeros num só por engano.
"""
import re

import parsers
import parsers_aplicacao
import parsers_extrato
import pdftexto

norm_txt = parsers.norm_txt
parse_numero = parsers.parse_numero

RE_VALOR = re.compile(r"-?[\d.]+,\d{2}")


def _semespaco(s):
    """Maiusculo, sem acento, SEM NENHUM ESPACO - para achar rotulo/numero
    em linhas onde o PDF quebrou o texto letra a letra de forma irregular."""
    return re.sub(r"\s+", "", norm_txt(s))


def _so_digitos(s):
    return re.sub(r"\D", "", str(s or ""))


def _valores_da_linha(linha):
    return RE_VALOR.findall(linha)


def _linha_com_valor(linhas, i, minimo=1):
    """Valores da linha i; se nao tiver, tenta a linha i+1 (rotulo e valor
    em linhas separadas - padrao do quadro de saldo do Santander/Caixa)."""
    vals = _valores_da_linha(linhas[i])
    if len(vals) >= minimo:
        return vals
    if i + 1 < len(linhas):
        return _valores_da_linha(linhas[i + 1])
    return []


# --------------------------------------------------------------------------
# Banco do Brasil - conta corrente
#
# O extrato de conta corrente do BB grava DUAS linhas-marcador especiais,
# com "lote" fixo 000 (abertura) e 999 (fechamento) - reconhecidas mesmo
# quando o resto da linha vem fragmentado letra a letra, porque a busca e
# feita SEM ESPACO:
#   "30/06/2026 0000 00000 000 Saldo Anterior 0,00 C"
#   "31/07/2026 0000 00000 999 S A L D O 0,00 C"
# --------------------------------------------------------------------------
def _bb_corrente(linhas, arquivo):
    texto = _semespaco(" ".join(linhas))
    if "BBRENDEFACIL" not in texto and "BANCODOBRASIL" not in texto \
       and not re.search(r"\d{4}00000000SALDOANTERIOR", texto):
        return None

    agencia = conta = ""
    for l in linhas:
        m = re.search(r"Ag[êe]ncia\s+(\d+-?\d?)", l, re.I)
        if m:
            agencia = m.group(1)
        m = re.search(r"Conta\s+corrente\s+(\d+-?\d)", l, re.I)
        if m:
            conta = m.group(1)

    anterior = final = None
    for i, l in enumerate(linhas):
        se = _semespaco(l)
        if anterior is None and re.search(r"00000000SALDOANTERIOR", se):
            v = _valores_da_linha(l)
            if v:
                anterior = _com_sinal(v[-1], "D" in se[-3:])
        if re.search(r"00000999SALDO\b", se) or re.fullmatch(
                r".*00000999S+A+L+D+O+.*", se):
            v = _valores_da_linha(l)
            if v:
                final = _com_sinal(v[-1], se.rstrip().endswith("D"))
    if final is None:
        return None
    return {"arquivo": arquivo, "tipo": "corrente", "banco": "BANCO DO BRASIL",
            "agencia": agencia, "conta": conta, "competencia": _competencia(linhas),
            "saldo_anterior": anterior, "saldo_final": final, "modo": "",
            "detalhe": {}}


def _com_sinal(valor_txt, negativo):
    v = parse_numero(valor_txt)
    return -abs(v) if negativo else abs(v)


# --------------------------------------------------------------------------
# Bradesco - conta corrente + aplicacao automatica (Invest Facil) embutida
#
# Duas ferramentas de exportacao diferentes vistas para o MESMO banco:
#   (a) "Extrato de: Ag: NNN | CC: NNNNNNN-N" + linha "Total <cred> <deb> <sdo>"
#   (b) idem, mas fragmentado letra a letra (font diferente) - resolvido
#       buscando tudo SEM ESPACO.
# A aplicacao (Invest Facil/Plus) vem numa tabelinha "Data Historico Valor"
# dentro do MESMO arquivo, com uma linha por dia - usa-se o valor do ULTIMO
# dia (e o "retrato" mais proximo do fim do periodo que o banco mostra).
# --------------------------------------------------------------------------
def _bradesco(linhas, arquivo):
    """
    A conta corrente do Bradesco tem "varredura automatica" (Invest Facil):
    o saldo acima de um minimo e varrido TODA NOITE para a aplicacao ligada
    a conta, e volta quando precisa. Por isso a lista de lancamentos (que so
    mostra movimento de cliente, nao a varredura em si) fecha num saldo que
    NAO E o saldo contabil da conta corrente sozinha - o dinheiro "sobrou"
    na aplicacao, nao ficou ali.

    O saldo de conta corrente ISOLADO sai por DIFERENCA:
        saldo combinado (linha "Agencia | Conta Total Disponivel Total",
        que soma conta corrente + Invest Facil) MENOS o saldo do Invest
        Facil no mesmo dia = residual que ficou so na conta corrente.
    Confirmado contra o balancete: bate a poucos centavos (a diferenca que
    resta e so o instante da consulta nao ser exatamente a virada do mes).
    """
    texto = _semespaco(" ".join(linhas))
    m_ag = re.search(r"EXTRATODE:AG:(\d+)\|CC:(\d+-?\d)", texto)
    if not m_ag:
        return []
    agencia, conta = m_ag.group(1), m_ag.group(2)
    digitos_conta = _so_digitos(conta)

    saidas = []
    anterior = total_combinado = total_ledger = None
    for l in linhas:
        se = _semespaco(l)
        if anterior is None and se.startswith("SALDOANTERIOR"):
            v = _valores_da_linha(l)
            if v:
                anterior = parse_numero(v[-1])
        # linha "Agencia | Conta Total Disponivel Total": conta corrente +
        # Invest Facil somados. So a linha de DADOS tem "|" e 2+ valores -
        # a linha de CABECALHO ("Agencia | Conta Total Disponivel...") tem
        # "|" mas nenhum valor, por isso nao entra aqui por acidente.
        if "|" in l and digitos_conta in _so_digitos(l):
            v = _valores_da_linha(l)
            if len(v) >= 2:
                total_combinado = parse_numero(v[-1])
        # linha "Total <credito> <debito> <saldo>" ao fim da lista de
        # lancamentos - so o SALDO DA LISTA (nao reflete a varredura do
        # dia), guardado a parte so como informacao complementar.
        if se.startswith("TOTAL") and "AGENCIA" not in se and "DISPONIVEL" not in se:
            v = _valores_da_linha(l)
            if len(v) >= 3:
                total_ledger = parse_numero(v[-1])

    # aplicacao automatica embutida: "DD/MM/AAAA SALDO INVEST FACIL <valor>"
    dias = []
    for l in linhas:
        m = re.match(r"^(\d{2}/\d{2}/\d{4})\s+SALDO\s+INVEST\s+F[ÁA]CIL\s+([\d.,]+)$",
                     l.strip(), re.I)
        if m:
            dias.append((m.group(1), parse_numero(m.group(2))))
    dias.sort(key=lambda dv: tuple(reversed(dv[0].split("/"))))
    saldo_invest = dias[-1][1] if dias else None

    if total_combinado is not None:
        final = round(total_combinado - saldo_invest, 2) if saldo_invest is not None \
            else total_ledger
        saidas.append({"arquivo": arquivo, "tipo": "corrente", "banco": "BRADESCO",
                       "agencia": agencia, "conta": conta,
                       "competencia": _competencia(linhas),
                       "saldo_anterior": anterior, "saldo_final": final,
                       "modo": "", "detalhe": {"total_combinado": total_combinado,
                                                "saldo_ledger": total_ledger}})
    if dias:
        saidas.append({"arquivo": arquivo, "tipo": "aplicacao", "banco": "BRADESCO",
                       "agencia": agencia, "conta": conta,
                       "competencia": _competencia(linhas),
                       "saldo_anterior": dias[0][1] if len(dias) > 1 else None,
                       "saldo_final": saldo_invest, "modo": "direto",
                       "detalhe": {"data_saldo": dias[-1][0], "dias_lidos": len(dias)}})
    return saidas


# --------------------------------------------------------------------------
# Caixa Economica Federal - conta corrente ("Extrato #PESSOAL"/internet
# banking) + Fundo de Investimento (aplicacao automatica) em arquivo proprio
# --------------------------------------------------------------------------
def _caixa_corrente(linhas, arquivo):
    texto = norm_txt(" ".join(linhas))
    if "MOVIMENTACOES DESDE O DIA" not in texto or "SALDO DIA" not in texto:
        return None

    conta = ""
    for l in linhas:
        m = re.search(r"Conta:\s*([\d/-]+)", l, re.I)
        if m:
            conta = m.group(1)

    anterior = None
    for l in linhas:
        m = re.search(r"Saldo anterior a \d{2}/\d{2}/\d{4}\s+R\$\s*([\d.,]+)\s*([CD])?",
                      l, re.I)
        if m:
            anterior = _com_sinal(m.group(1), (m.group(2) or "C").upper() == "D")
            break

    final = None
    for i, l in enumerate(linhas):
        if norm_txt(l) == "SALDO DIA" and i + 1 < len(linhas):
            v = _valores_da_linha(linhas[i + 1])
            if v:
                final = _com_sinal(v[-1], linhas[i + 1].strip().upper().endswith("D"))
    if final is None:
        return None
    return {"arquivo": arquivo, "tipo": "corrente", "banco": "CAIXA ECONOMICA FEDERAL",
            "agencia": "", "conta": conta, "competencia": _competencia(linhas),
            "saldo_anterior": anterior, "saldo_final": final, "modo": "", "detalhe": {}}


def _caixa_fundo(linhas, arquivo):
    """
    "Extrato Fundo de Investimento" da Caixa (o auto-resgate/aplicacao
    ligado a conta corrente #PESSOAL).

    NAO usa a formula "anterior + aplicacoes - resgates" (que funciona bem
    para o BB Rende Facil - ver _aplicacao_rotulada): aqui o rendimento e o
    IRRF do mes ENTRAM na conta ("Saldo Anterior" + Rendimento - Resgates -
    IRRF = Saldo Bruto, confirmado batendo com o balancete ate o centavo),
    entao a formula simplificada erraria por causa disso. Le "Saldo Bruto*"
    DIRETO em vez de calcular - e o unico numero que o proprio arquivo ja
    da pronto e testado batendo com o balancete.
    """
    texto = norm_txt(" ".join(linhas))
    if "EXTRATO FUNDO DE INVESTIMENTO" not in texto and "FUNDO DE INVESTIMENTO" not in texto:
        return None

    conta = ""
    for l in linhas:
        m = re.search(r"(\d{4}\.\d{9,})", _semespaco(l).replace("CONTACORRENTE", ""))
        if m:
            conta = m.group(1)

    final = None
    for l in linhas:
        if _semespaco(l).startswith(_semespaco("Saldo Bruto")):
            v = _valores_da_linha(l)
            if v:
                final = parse_numero(v[0])
                break
    if final is None:
        return None
    return {"arquivo": arquivo, "tipo": "aplicacao", "banco": "CAIXA ECONOMICA FEDERAL",
            "agencia": "", "conta": conta, "competencia": _competencia(linhas),
            "saldo_anterior": None, "saldo_final": final, "modo": "direto",
            "detalhe": {}}


# --------------------------------------------------------------------------
# Sicredi - conta corrente
# --------------------------------------------------------------------------
def _sicredi(linhas, arquivo):
    texto = norm_txt(" ".join(linhas))
    if "COOPERATIVA" not in texto or "SICREDI" not in texto.replace(" ", ""):
        if "SICREDI" not in texto:
            return None

    cooperativa = conta = ""
    ultimo_saldo = None
    anterior = None
    for l in linhas:
        n = norm_txt(l)
        # "Lancamentos Futuros" e uma tabela SEPARADA (compromissos dos
        # proximos dias, ainda fora do periodo) - sem coluna de saldo
        # corrido. Se nao parar aqui, o ultimo valor dela (um lancamento
        # futuro qualquer) seria lido por engano como o saldo final do mes.
        if n.startswith("LANCAMENTOS FUTUROS"):
            break
        m = re.search(r"Cooperativa:\s*(\d+)", l, re.I)
        if m:
            cooperativa = m.group(1)
        m = re.search(r"Conta:\s*([\d-]+)", l, re.I)
        if m:
            conta = m.group(1)
        if anterior is None and n.startswith("SALDO ANTERIOR"):
            v = _valores_da_linha(l)
            if v:
                anterior = parse_numero(v[-1])
        # linha de lancamento normal: "DD/MM/AAAA ... <valor> <saldo>"
        if re.match(r"^\d{2}/\d{2}/\d{4}\s", l) and not n.startswith("SALDO ANTERIOR"):
            v = _valores_da_linha(l)
            if len(v) >= 1:
                ultimo_saldo = parse_numero(v[-1])
    if ultimo_saldo is None and anterior is None:
        return None
    return {"arquivo": arquivo, "tipo": "corrente", "banco": "SICREDI",
            "agencia": cooperativa, "conta": conta, "competencia": _competencia(linhas),
            "saldo_anterior": anterior,
            "saldo_final": ultimo_saldo if ultimo_saldo is not None else anterior,
            "modo": "", "detalhe": {}}


# --------------------------------------------------------------------------
# Aplicacao dedicada (ex.: "Aplicacao BB Rende Facil") - formato com
# "Saldo Anterior", "Aplicacoes no mes" e "Resgates liquidos no mes"
# rotulados explicitamente. Mesma formula contabil do Caixa Fundo (modo
# "movimento"), so que aqui os 3 numeros ja vem rotulados por extenso.
# --------------------------------------------------------------------------
def _aplicacao_rotulada(linhas, arquivo):
    texto_ss = _semespaco(" ".join(linhas))
    if "RENDEFACIL" not in texto_ss and "APLICACOESNOMES" not in texto_ss:
        return None

    banco = "BANCO DO BRASIL" if "RENDEFACIL" in texto_ss else ""
    agencia = conta = ""
    for i, l in enumerate(linhas):
        if norm_txt(l) == "AGENCIA CONTA" and i > 0:
            m = re.match(r"\s*(\d+-?\d?)\s+(\d+-?\d)\s*$", linhas[i - 1])
            if m:
                agencia, conta = m.group(1), m.group(2)

    def _valor_do_rotulo(rotulo):
        alvo = _semespaco(rotulo)
        for l in linhas:
            se = _semespaco(l)
            if se.startswith(alvo):
                v = _valores_da_linha(l)
                if v:
                    return parse_numero(v[0])
        return None

    anterior = None
    for l in linhas:
        if norm_txt(l).startswith("SALDO ANTERIOR") or "SALDOANTERIOR" in _semespaco(l)[:40]:
            v = _valores_da_linha(l)
            if v:
                anterior = parse_numero(v[0])
                break
    aplicacoes = _valor_do_rotulo("Aplicações no mês")
    resgates = _valor_do_rotulo("Resgates líquidos no mês")
    if anterior is None or aplicacoes is None or resgates is None:
        return None
    final = round(anterior + aplicacoes - resgates, 2)
    return {"arquivo": arquivo, "tipo": "aplicacao", "banco": banco or "?",
            "agencia": agencia, "conta": conta, "competencia": _competencia(linhas),
            "saldo_anterior": anterior, "saldo_final": final, "modo": "movimento",
            "detalhe": {"aplicacoes": aplicacoes, "resgates": resgates}}


# --------------------------------------------------------------------------
def _competencia(linhas):
    """
    A COMPETENCIA e o MES DO PERIODO PEDIDO, nunca a data de emissao/consulta
    do relatorio (que aparece em quase todo cabecalho e sempre e POSTERIOR -
    ex.: extrato de julho emitido em 05/08). Por isso os padroes abaixo
    exigem uma faixa "de ... a ..."/"desde ... até ..." (dois periodos
    numa mesma frase), nunca uma data solta.
    """
    padroes = (
        # "Periodo do extrato 07 / 2026" (BB) - mes e ano ja prontos
        r"Per[íi]odo\s+do\s+extrato\s+(0[1-9]|1[0-2])\s*/\s*(20\d{2})",
        # "desde o dia 01/07/2026 ate o dia 31/07/2026" (Caixa)
        r"desde\s+o\s+dia\s+\d{2}/(\d{2})/(\d{4})\D+at[ée]\s+o\s+dia\s+\d{2}/\d{2}/\d{4}",
        # "Periodo(s): 01/07/2026 a/e 31/07/2026" (Santander/Bradesco/Sicredi)
        r"Per[íi]odo[s]?\D{0,4}\d{2}/(\d{2})/(\d{4})\D+\d{2}/\d{2}/\d{4}",
        # "Entre 01/07/2026 e 31/07/2026" (Bradesco "Extrato de:")
        r"Entre\s+\d{2}/(\d{2})/(\d{4})\s+e\s+\d{2}/\d{2}/\d{4}",
    )
    texto = " ".join(linhas[:15])
    for p in padroes:
        m = re.search(p, texto, re.I)
        if m:
            return f"{m.group(1)}/{m.group(2)}"

    # Sem cabecalho de periodo (visto num extrato do BB que comeca direto
    # nos lancamentos, sem bloco de identificacao): o mes/ano MAIS FREQUENTE
    # entre as datas dd/mm/aaaa do documento inteiro - a esmagadora maioria
    # dos lancamentos de um extrato mensal cai dentro do proprio mes pedido,
    # ainda que uma ou outra data de rodape/vencimento futuro escape disso.
    contagem = {}
    for l in linhas:
        for m in re.finditer(r"\b\d{2}/(\d{2})/(20\d{2})\b", l):
            chave = f"{m.group(1)}/{m.group(2)}"
            contagem[chave] = contagem.get(chave, 0) + 1
    if contagem:
        return max(contagem.items(), key=lambda kv: kv[1])[0]
    return ""




# --------------------------------------------------------------------------
# ITAU - "extrato mensal" (o consolidado do mes, nao o extrato diario)
#
# Este layout NAO tem "itau.com.br" nem "SALDO TOTAL DISPONIVEL DIA", que sao
# as marcas do extrato diario lido por parsers_extrato.py - por isso ele caia
# como "banco nao reconhecido". A marca dele e o cabecalho da 1a linha:
#     extrato mensal ag 6466 cc 21410-0 jul 2026 001|020
#
# O SALDO VEM SEPARADO EM DUAS CONTAS, e o extrato so mostra a SOMA:
#     01. Conta Corrente e Aplicacoes Automaticas  R$ 58.041,60  R$ 25.139,94
# Na contabilidade essas duas coisas ficam em contas diferentes (a conta
# corrente e a aplicacao automatica). O que o banco varre para a aplicacao
# toda noite deixa na conta corrente apenas um valor residual - no caso da
# HAC, R$ 1,00 em todas as filiais.
#
# COMO SEPARAR, sem chutar:
#   aplicacao = o "saldo de principal aplicado" do ULTIMO dia da tabela
#               "movimentacao - aplicacoes/resgates" (ja lido por
#               parsers_aplicacao, com a conferencia contra a linha "total"
#               do proprio extrato);
#   corrente  = saldo combinado do cabecalho MENOS a aplicacao.
# Ou seja, o residual da conta corrente sai por DIFERENCA de dois numeros
# que o proprio extrato afirma - nunca de uma constante "R$ 1,00" chutada,
# que quebraria no mes em que sobrasse outro valor.
# --------------------------------------------------------------------------
RE_ITAU_MENSAL = re.compile(r"extrato\s+mensal\s+ag\s+(\d+)\s+cc\s+([\d-]+)", re.I)
RE_ITAU_COMBINADO = re.compile(
    r"Conta\s+Corrente\s+e\s+Aplica\S*\s+Autom\S*.*?"
    r"R\$\s*(-?[\d.]*\d,\d{2}).*?R\$\s*(-?[\d.]*\d,\d{2})", re.I)


def _itau_mensal(linhas, arquivo, caminho=None):
    """Devolve [corrente, aplicacao] - ou so a corrente, quando a conta nao
    tem aplicacao automatica."""
    cab = next((RE_ITAU_MENSAL.search(l) for l in linhas[:6]
                if RE_ITAU_MENSAL.search(l)), None)
    if not cab:
        return []
    agencia, conta = cab.group(1), cab.group(2)

    combinado = None
    for l in linhas[:40]:
        m = RE_ITAU_COMBINADO.search(l)
        if m:
            combinado = parse_numero(m.group(2))   # o 2o e o saldo do FIM
            break
    if combinado is None:
        return []

    competencia = parsers_aplicacao._competencia_pdf(linhas)
    saldo_aplic = None
    itens_aplic, total_aplic = parsers_aplicacao._linhas_da_tabela_pdf(linhas)
    if itens_aplic:
        saldos = [i["saldo"] for i in itens_aplic if i["saldo"] is not None]
        if saldos:
            saldo_aplic = saldos[-1]

    saidas = []
    if saldo_aplic is None:
        saidas.append({"arquivo": arquivo, "tipo": "corrente", "banco": "ITAU",
                       "agencia": agencia, "conta": conta,
                       "competencia": competencia,
                       "saldo_anterior": None, "saldo_final": round(combinado, 2),
                       "modo": "", "detalhe": {}})
        return saidas

    corrente = round(combinado - saldo_aplic, 2)
    saidas.append({"arquivo": arquivo, "tipo": "corrente", "banco": "ITAU",
                   "agencia": agencia, "conta": conta, "competencia": competencia,
                   "saldo_anterior": None, "saldo_final": corrente, "modo": "",
                   "detalhe": {"saldo_combinado": round(combinado, 2),
                               "saldo_aplicacao": round(saldo_aplic, 2)}})
    saidas.append({"arquivo": arquivo, "tipo": "aplicacao", "banco": "ITAU",
                   "agencia": agencia, "conta": conta, "competencia": competencia,
                   "saldo_anterior": None, "saldo_final": round(saldo_aplic, 2),
                   "modo": "direto",
                   "detalhe": {"origem": "ultimo saldo de principal aplicado",
                               "linhas_lidas": len(itens_aplic),
                               "confere_com_total": bool(total_aplic)}})
    return saidas


LEITORES_MULTI = (_itau_mensal, _bradesco)                  # devolvem LISTA (0, 1 ou 2 registros)
LEITORES_UM = (_bb_corrente, _caixa_corrente,   # devolvem 1 registro ou None
              _caixa_fundo, _sicredi, _aplicacao_rotulada)


def ler_extrato(caminho, nome_original=""):
    """
    Le UM arquivo e devolve uma LISTA de registros (0, 1 ou 2 - um extrato de
    conta corrente pode trazer uma aplicacao automatica embutida).

    Tenta primeiro Itau/Santander (delega para parsers_extrato.py, que ja
    faz isso desde o modulo CONTABIL - nao existe uma segunda leitura destes
    dois bancos neste arquivo). Levanta ValueError se nao reconhecer nada.
    """
    nome = nome_original or caminho
    banco_itau_santander = parsers_extrato.detectar_banco(caminho)
    if banco_itau_santander:
        e = parsers_extrato.parse_extrato(caminho, banco_itau_santander)
        return [{"arquivo": nome, "tipo": "corrente", "banco": e["banco"],
                 "agencia": e.get("agencia", ""), "conta": e.get("conta", ""),
                 "competencia": _competencia_de_periodo(e.get("periodo")),
                 "saldo_anterior": e.get("saldo_anterior"),
                 "saldo_final": e.get("saldo_final"), "modo": "", "detalhe": {}}]

    linhas = pdftexto.linhas_do_pdf(caminho)
    for fn in LEITORES_MULTI:
        r = fn(linhas, nome)
        if r:
            return r
    for fn in LEITORES_UM:
        r = fn(linhas, nome)
        if r:
            return [r]
    raise ValueError("nao reconheci este extrato (bancos aceitos: Itau, "
                     "Santander, Banco do Brasil, Bradesco, Caixa, Sicredi, "
                     "ou uma aplicacao com Saldo Anterior/Aplicacoes/Resgates).")


def detectar(caminho):
    try:
        return bool(ler_extrato(caminho))
    except Exception:  # noqa: BLE001
        return False


def _competencia_de_periodo(periodo):
    if not periodo or not periodo[0]:
        return ""
    m = re.search(r"(\d{2})/(\d{2})/(\d{4})", periodo[1] if len(periodo) > 1 else periodo[0])
    return f"{m.group(2)}/{m.group(3)}" if m else ""
