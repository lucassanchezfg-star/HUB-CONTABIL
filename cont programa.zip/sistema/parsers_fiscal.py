# -*- coding: utf-8 -*-
"""
parsers_fiscal.py - Leitura dos arquivos que alimentam a RECEITA FINANCEIRA
(modulo do departamento FISCAL).

Quatro fontes, cada uma com uma rubrica:

  TITULOS_PAGOS       -> DESCONTOS OBTIDOS
      Relatorio "TITULOS PAGOS POR EMPRESA" (um arquivo por filial).
      Valor = rodape "TOTAL DOS DESCONTOS".

  TITULOS_RECEBIDOS   -> JUROS ATIVOS
      Relatorio "TITULOS RECEBIDOS" (um arquivo por portador/modalidade).
      Valor = soma da coluna VR.JUROS de TODAS as modalidades (nao so boleto).

  ITAU_APLICACAO      -> RENDIMENTO e IRRF de aplicacao automatica
      Extrato mensal do Itau em PDF. Na secao
      "movimentacao - aplicacoes/resgates antecipados e vencimentos",
      a linha "total" traz 6 numeros:
         [0] aplicacoes realizadas   [1] principal resgatado/vencido
         [2] RENDIMENTO BRUTO PAGO   [3] IOF retido
         [4] IRRF RETIDO             [5] rendimento liquido pago
      Interessam o [2] (rendimento) e o [4] (IRRF).

  BRADESCO_APLICACAO  -> RENDIMENTO de aplicacao
      Extrato do Bradesco em PDF. Soma o CREDITO das linhas cujo historico e
      "RENTAB.INVEST FACILCRED". A linha "SALDO INVEST FACIL" e SALDO, nao
      rendimento - somar essas dobraria a rubrica.

ARMADILHAS JA RESOLVIDAS AQUI
-----------------------------
1. CSV com quebra de linha DENTRO do campo: o campo "TIPO. REC" dos titulos
   recebidos traz "DIN: 31,67\nCAR: 89,88" entre aspas. Quebrar o arquivo por
   "\n" parte o registro no meio. Por isso usamos o modulo csv da stdlib, que
   respeita as aspas.
2. Acentuacao: esses relatorios saem em latin-1 (nao UTF-8).
3. O nome do arquivo NAO identifica a filial de forma confiavel (a matriz sai
   como "MATRIZ.csv" mas o relatorio se identifica como "SANTA ROSA"). Por
   isso a filial vem da PRIMEIRA LINHA do relatorio, nao do nome do arquivo.
"""
import re

import parsers
import pdftexto

norm_txt = parsers.norm_txt
parse_numero = parsers.parse_numero

RE_VALOR = re.compile(r"-?[\d.]+,\d{2}")
RE_COMPETENCIA = re.compile(r"\b(0[1-9]|1[0-2])/(20\d{2})\b")

ROTULO_TIPO = {
    "TITULOS_PAGOS": "Titulos pagos (descontos obtidos)",
    "TITULOS_RECEBIDOS": "Titulos recebidos (juros ativos)",
    "ITAU_APLICACAO": "Extrato Itau (rendimento de aplicacao)",
    "BRADESCO_APLICACAO": "Extrato Bradesco (rendimento de aplicacao)",
}


# Leitura de tabela (.csv/.xlsx) e limpeza de celula: ficam em parsers.py,
# compartilhadas com os outros modulos que leem os mesmos relatorios.
ler_tabela = parsers.ler_tabela
_limpo = parsers.limpo


# --------------------------------------------------------------------------
# Deteccao do tipo de arquivo
# --------------------------------------------------------------------------
def detectar_tipo(caminho):
    """Retorna a chave do tipo (ver ROTULO_TIPO) ou None se nao reconhecer."""
    if caminho.lower().endswith(".pdf"):
        try:
            texto = norm_txt(" ".join(pdftexto.linhas_do_pdf(caminho)))
        except Exception:  # noqa: BLE001 - PDF corrompido/protegido
            return None
        if _e_bradesco(texto):
            return "BRADESCO_APLICACAO"
        if "APLICACOES/RESGATES" in texto or "APLICACOES AUTOMATICAS" in texto:
            return "ITAU_APLICACAO"
        return None
    try:
        linhas = ler_tabela(caminho)
    except Exception:  # noqa: BLE001 - arquivo ilegivel
        return None
    return _tipo_da_tabela(linhas)


def _e_bradesco(texto):
    """
    Reconhece o extrato do Bradesco pelo LAYOUT, nao pela marca.

    ARMADILHA: a palavra "BRADESCO" NAO aparece nesses extratos - nem no
    cabecalho, nem no rodape. Enquanto a deteccao dependia dela, so era
    reconhecido o extrato que por acaso tinha a linha "RENTAB.INVEST
    FACILCRED"; um mes SEM rendimento simplesmente nao era reconhecido,
    e o arquivo ficava de fora sem que ninguem percebesse. O que identifica
    e a linha de titulo do extrato e o cabecalho das colunas.
    """
    if "RENTAB.INVEST FACILCRED" in texto:
        return True
    tem_titulo = "EXTRATO DE: AG:" in texto
    tem_colunas = ("CREDITO (R$)" in texto and "DEBITO (R$)" in texto
                   and "SALDO (R$)" in texto)
    return tem_titulo and tem_colunas


def _tipo_da_tabela(linhas):
    for linha in linhas:
        celulas = [norm_txt(_limpo(c)) for c in linha]
        if "TOTAL DOS DESCONTOS" in celulas:
            return "TITULOS_PAGOS"
        if "VR.JUROS" in celulas:
            return "TITULOS_RECEBIDOS"
    return None


def _origem_da_tabela(linhas, nome_arquivo):
    """
    Qual filial este relatorio cobre.

    NAO serve nem a 1a linha nem o nome do arquivo: a 1a linha traz sempre a
    empresa de onde o relatorio foi EMITIDO (todos os arquivos das 5 filiais
    dizem "SANTA ROSA"), e o nome do arquivo e livre (a matriz costuma vir
    como "MATRIZ.csv" mas o sistema a chama de "SANTA ROSA"). Quem identifica
    e a linha de filtro 'Empresa : 004-... - SANTO ANTONIO'. Nos relatorios
    que saem com varias empresas juntas esse filtro vira uma lista de codigos
    ('001_002_003_...') e ai o nome do arquivo e a melhor pista disponivel.
    """
    for linha in linhas[:40]:
        texto = " ".join(_limpo(c) for c in linha)
        m = re.match(r"\s*Empresa\s*:\s*(.+)", texto, re.I)
        if not m:
            continue
        valor = m.group(1).strip()
        if "_" in valor.split("-")[0]:
            break  # lista de codigos: nao identifica uma filial
        partes = valor.split("-", 1)
        if len(partes) == 2 and partes[1].strip():
            return partes[1].strip()
        return valor
    return re.sub(r"\.[A-Za-z]+$", "", nome_arquivo)


# --------------------------------------------------------------------------
# Extracao de cada rubrica
# --------------------------------------------------------------------------
def _descontos(linhas):
    """
    Valor do rodape "TOTAL DOS DESCONTOS".

    Vale a ULTIMA ocorrencia: o relatorio pode ter um bloco por atividade e o
    fechamento geral no fim.
    """
    valor = None
    for linha in linhas:
        celulas = [_limpo(c) for c in linha]
        for i, c in enumerate(celulas):
            if norm_txt(c) == "TOTAL DOS DESCONTOS":
                for prox in celulas[i + 1:]:
                    if prox:
                        valor = parse_numero(prox)
                        break
    return valor


def _juros(linhas):
    """
    Soma da coluna VR.JUROS.

    O indice da coluna e reaproveitado ate o proximo cabecalho, porque o
    relatorio repete o cabecalho a cada quebra (por portador/atividade) e a
    posicao da coluna pode mudar entre os blocos.
    """
    idx = None
    total = 0.0
    achou = False
    for linha in linhas:
        celulas = [_limpo(c) for c in linha]
        cabecalho = [norm_txt(c) for c in celulas]
        if "VR.JUROS" in cabecalho:
            idx = cabecalho.index("VR.JUROS")
            achou = True
            continue
        if idx is None or len(celulas) <= idx:
            continue
        bruto = celulas[idx]
        if not bruto or not re.search(r"\d", bruto):
            continue
        total += parse_numero(bruto)
    return round(total, 2) if achou else None


def _itau(linhas_pdf):
    """
    (rendimento_bruto, irrf) da linha "total" da secao de aplicacoes.

    So conta depois de entrar na secao "movimentacao - aplicacoes/resgates":
    antes dela existe uma linha "totalizador de aplicacoes automaticas", que
    tambem comeca com "total" mas e outro numero (movimento, nao rendimento).
    """
    dentro = False
    for linha in linhas_pdf:
        n = norm_txt(linha)
        if "APLICACOES/RESGATES" in n and "MOVIMENTACAO" in n:
            dentro = True
            continue
        if not dentro:
            continue
        if not re.match(r"^TOTAL\b", n) or n.startswith("TOTALIZADOR"):
            continue
        nums = RE_VALOR.findall(linha)
        if len(nums) >= 6:
            return parse_numero(nums[2]), parse_numero(nums[4])
    return None, None


def _bradesco(linhas_pdf):
    """
    Soma dos creditos "RENTAB.INVEST FACILCRED".

    A linha e '<historico> <documento> <credito> <saldo>': o credito e o
    PENULTIMO numero. Pegar o ultimo traria o SALDO da aplicacao.
    """
    total = 0.0
    achou = False
    for linha in linhas_pdf:
        if "RENTAB.INVEST FACILCRED" not in norm_txt(linha):
            continue
        nums = RE_VALOR.findall(linha)
        if len(nums) >= 2:
            total += parse_numero(nums[-2])
            achou = True
    return round(total, 2) if achou else None


RE_MES_EXPLICITO = re.compile(r"M[EÊ]S\s*:?\s*(0[1-9]|1[0-2])/(20\d{2})", re.I)
MESES = ["JAN", "FEV", "MAR", "ABR", "MAI", "JUN",
         "JUL", "AGO", "SET", "OUT", "NOV", "DEZ"]
RE_MES_NOME = re.compile(r"\b(%s)\w*\.?\s*/?\s*(20\d{2})\b" % "|".join(MESES))


def _competencia_das_linhas(textos):
    """
    mm/aaaa do relatorio (so sugestao para a tela; o usuario pode corrigir).

    Um rotulo explicito vale mais que a contagem de datas: no extrato do Itau
    a data de EMISSAO ("05/11/2025") se repete no rodape das 42 paginas e
    ganharia de qualquer data do mes de referencia. Ordem de confianca:
    "mes 10/2025" > "out 2025" (cabecalho do extrato) > data mais frequente.
    """
    for t in textos:
        m = RE_MES_EXPLICITO.search(t)
        if m:
            return f"{m.group(1)}/{m.group(2)}"
    for t in textos:
        m = RE_MES_NOME.search(norm_txt(t))
        if m:
            return "%02d/%s" % (MESES.index(m.group(1)) + 1, m.group(2))
    contagem = {}
    for t in textos:
        for mes, ano in RE_COMPETENCIA.findall(t):
            chave = f"{mes}/{ano}"
            contagem[chave] = contagem.get(chave, 0) + 1
    if not contagem:
        return ""
    return max(contagem.items(), key=lambda kv: kv[1])[0]


# --------------------------------------------------------------------------
# API
# --------------------------------------------------------------------------
def ler_arquivo(caminho, nome_original=""):
    """
    Le UM arquivo e devolve o que ele contribui para a receita financeira:

      {"tipo", "rotulo", "origem", "competencia",
       "descontos", "juros", "itau_rendimento", "itau_irrf", "bradesco"}

    Levanta ValueError se o arquivo nao for de nenhum dos quatro tipos.
    """
    tipo = detectar_tipo(caminho)
    if tipo is None:
        raise ValueError(
            "arquivo nao reconhecido (esperado: titulos pagos, titulos "
            "recebidos, ou extrato Itau/Bradesco em PDF).")

    nome = nome_original or caminho
    item = {"tipo": tipo, "rotulo": ROTULO_TIPO[tipo], "arquivo": nome,
            "origem": "", "competencia": "", "aviso": "",
            "descontos": None, "juros": None,
            "itau_rendimento": None, "itau_irrf": None, "bradesco": None}

    if tipo in ("ITAU_APLICACAO", "BRADESCO_APLICACAO"):
        linhas = pdftexto.linhas_do_pdf(caminho)
        item["origem"] = re.sub(r"\.[Pp][Dd][Ff]$", "", nome)
        item["competencia"] = _competencia_das_linhas(linhas)
        if tipo == "ITAU_APLICACAO":
            rend, irrf = _itau(linhas)
            # Conta SEM aplicacao no mes (ex.: conta garantida) nao e erro:
            # entra com zero para o arquivo aparecer na composicao.
            item["itau_rendimento"] = 0.0 if rend is None else rend
            item["itau_irrf"] = 0.0 if irrf is None else irrf
            if rend is None:
                item["aviso"] = ("sem a secao de aplicacoes/resgates - "
                                 "conta sem aplicacao no mes; entrou como zero.")
        else:
            valor = _bradesco(linhas)
            item["bradesco"] = 0.0 if valor is None else valor
            if valor is None:
                item["aviso"] = ("sem linha 'RENTAB.INVEST FACILCRED' - "
                                 "sem rendimento no mes; entrou como zero.")
        return item

    linhas = ler_tabela(caminho)
    item["origem"] = _origem_da_tabela(linhas, nome)
    item["competencia"] = _competencia_das_linhas(
        [" ".join(_limpo(c) for c in l) for l in linhas[:40]])
    if tipo == "TITULOS_PAGOS":
        item["descontos"] = _descontos(linhas)
        if item["descontos"] is None:
            raise ValueError("relatorio sem o rodape 'TOTAL DOS DESCONTOS'.")
    else:
        item["juros"] = _juros(linhas)
        if item["juros"] is None:
            raise ValueError("relatorio sem a coluna 'VR.JUROS'.")
    return item
