# -*- coding: utf-8 -*-
"""
parsers_fornecedores.py - Le o relatorio "POSICAO CONTABIL DE CONTAS A PAGAR"
(um por filial, .xlsx exportado do sistema da loja).

FORMA DO RELATORIO
------------------
    linha 1     razao social da empresa
    linha 3     titulo do relatorio
    linhas 5-19 os filtros usados, entre eles "Empresa : 005-... - ENSEADA"
    linha 21    cabecalho: FORNECEDOR | ATIVIDADE | C.P.F./C.N.P.J. |
                PLAN. CONTAS | DUPLICATA | EMP | BOL | DTA.CAD | DTA.VENC | VALOR
    linha 22..  uma linha por DUPLICATA
    no fim      bloco "RESUMO" com o aging: VENCIDOS e A VENCER, cada um em
                quatro faixas (ate 30 dias, 31-180, 181-360, 361+)

O CABECALHO E ACHADO PELOS NOMES DAS COLUNAS, nunca por numero de linha: a
quantidade de linhas de filtro muda conforme a consulta feita na loja.

A FILIAL SAI DE DENTRO DO ARQUIVO (linha "Empresa : NNN-..."), nao do nome
dele - o nome e escolhido a mao por quem exporta e varia de mes para mes.

CONFERENCIA EMBUTIDA: o proprio relatorio fecha com o aging. A soma das
duplicatas lidas e comparada com a soma das faixas; divergencia = alguma
linha se perdeu na leitura, e o modulo avisa em vez de consolidar errado.

NAO CONFUNDIR COM OS VIZINHOS: na mesma pasta ficam "CONTAS A RECEBER" e
"CHEQUES", que tem cabecalho CLIENTE em vez de FORNECEDOR. Eles sao
recusados com mensagem propria, para ninguem consolidar recebimento junto
com pagamento.
"""
import os
import re
import unicodedata
import zipfile

import parsers

# Nome da coluna -> chave interna (comparado sem acento e sem pontuacao).
COLUNAS = {
    "FORNECEDOR": "fornecedor",
    "ATIVIDADE": "atividade",
    "CPFCNPJ": "cnpj",
    "PLANCONTAS": "plano_contas",
    "DUPLICATA": "duplicata",
    "EMP": "empresa",
    "BOL": "boleto",
    "DTACAD": "dta_cad",
    "DTAVENC": "dta_venc",
    "VALOR": "valor",
}
OBRIGATORIAS = ("fornecedor", "duplicata", "valor")

RE_EMPRESA = re.compile(r"empresa\s*:\s*([0-9_]+)\s*[-_]?\s*(.*)$", re.I)
RE_DATA = re.compile(r"^\d{2}/\d{2}/\d{4}$")
GRUPOS_AGING = ("VENCIDOS", "A VENCER")


def _chave(texto):
    t = unicodedata.normalize("NFKD", str(texto or ""))
    t = "".join(c for c in t if not unicodedata.combining(c))
    return re.sub(r"[^A-Z0-9]", "", t.upper())


def _num(v):
    if isinstance(v, (int, float)):
        return round(float(v), 2)
    return round(parsers.parse_numero(str(v)), 2)


def _separar_codigo(texto):
    """'00004817-ARCELORMITTAL BRASIL S.A.' -> ('00004817', 'ARCELORMITTAL...')."""
    t = str(texto or "").strip()
    m = re.match(r"^(\d+)\s*-\s*(.*)$", t)
    return (m.group(1), m.group(2).strip()) if m else ("", t)


def _filial(linhas_topo):
    """(codigo_empresa, nome_da_filial) da linha 'Empresa : NNN-...'."""
    for cel in linhas_topo:
        txt = str(cel.get("A") or "").strip()
        m = RE_EMPRESA.match(txt)
        if not m:
            continue
        codigo = m.group(1).strip()
        resto = m.group(2).strip()
        # "H A C MATERIAIS ... - ENSEADA" -> a filial e o que vem DEPOIS do
        # ultimo tracinho. Nem todo relatorio traz esse sufixo (o do GALPAO
        # vem so com a razao social): nesse caso devolve vazio, e quem exibe
        # identifica a filial pelo CODIGO - inventar um nome a partir da
        # razao social daria "H A C MATERIAIS" para varias filiais
        # diferentes, o que e pior que nao ter nome.
        nome = resto.rsplit("-", 1)[-1].strip() if "-" in resto else ""
        return codigo, nome
    return "", ""


def _achar_cabecalho(linhas):
    for rn, cells in linhas:
        mapa = {}
        for col, val in cells.items():
            alvo = COLUNAS.get(_chave(val))
            if alvo:
                mapa.setdefault(alvo, col)
        if all(o in mapa for o in OBRIGATORIAS):
            return rn, mapa
        # o vizinho errado: mesmo desenho, mas de CLIENTE
        if _chave(cells.get("A")) == "CLIENTE":
            raise ValueError(
                "este relatorio e de CLIENTE (contas a receber ou cheques), "
                "nao de FORNECEDOR - o modulo de Fornecedores le a POSICAO "
                "CONTABIL DE CONTAS A PAGAR.")
    return None, None


def _aging(linhas):
    """[{'grupo','periodo','total'}] do bloco RESUMO do fim do relatorio."""
    faixas = []
    for _rn, cells in linhas:
        grupo = str(cells.get("A") or "").strip().upper()
        if grupo not in GRUPOS_AGING:
            continue
        total = cells.get("C")
        if total in (None, ""):
            continue
        faixas.append({"grupo": grupo,
                       "periodo": re.sub(r"\s+", " ", str(cells.get("B") or "")).strip(),
                       "total": _num(total)})
    return faixas


def detectar(caminho):
    try:
        return bool(ler_posicao(caminho)["itens"])
    except Exception:  # noqa: BLE001
        return False


def ler_posicao(caminho, nome_original=""):
    """
    Devolve {"arquivo","codigo_empresa","filial","itens":[...],"aging":[...],
             "total_detalhe","total_aging","avisos":[...]}.

    Cada item: {fornecedor_codigo, fornecedor, atividade, cnpj, plano_contas,
                duplicata, empresa, boleto, dta_cad, dta_venc, valor}.
    """
    nome = nome_original or os.path.basename(caminho)
    with zipfile.ZipFile(caminho) as z:
        shared = parsers._carregar_shared_strings(z)
        for aba in parsers._abas_do_xlsx(caminho):
            sp = parsers._sheet_path_por_nome(z, aba)
            if not sp:
                continue
            linhas = list(parsers._linhas_xml(z, sp, shared))
            cab_rn, cols = _achar_cabecalho(linhas)
            if cab_rn is None:
                continue

            codigo, filial = _filial([c for rn, c in linhas if rn < cab_rn])
            itens = []
            for rn, cells in linhas:
                if rn <= cab_rn:
                    continue
                bruto = str(cells.get(cols["fornecedor"]) or "").strip()
                valor = cells.get(cols["valor"])
                if not bruto or valor in (None, ""):
                    continue
                if bruto.upper() in GRUPOS_AGING:
                    continue          # ja e o bloco do resumo
                cod_forn, nome_forn = _separar_codigo(bruto)
                if not cod_forn:
                    continue          # linha de titulo/rodape solta
                item = {"fornecedor_codigo": cod_forn, "fornecedor": nome_forn}
                for chave in ("atividade", "cnpj", "plano_contas", "duplicata",
                              "empresa", "boleto", "dta_cad", "dta_venc"):
                    item[chave] = re.sub(
                        r"\s+", " ", str(cells.get(cols.get(chave)) or "")).strip()
                item["valor"] = _num(valor)
                itens.append(item)

            if not itens:
                continue
            faixas = _aging(linhas)
            total_det = round(sum(i["valor"] for i in itens), 2)
            total_ag = round(sum(f["total"] for f in faixas), 2)
            avisos = []
            if faixas and abs(total_det - total_ag) > 0.01:
                avisos.append(
                    "'%s': a soma das duplicatas que li (%.2f) nao bate com o "
                    "resumo do proprio relatorio (%.2f) — pode ter linha "
                    "faltando na leitura." % (nome, total_det, total_ag))
            if not faixas:
                avisos.append(
                    "'%s': o relatorio nao trouxe o bloco de resumo (aging), "
                    "entao nao ha como conferir a leitura contra ele."
                    % nome)
            # rotulo = como a filial aparece na tela e na planilha
            rotulo = filial or ("Empresa %s" % codigo if codigo else "(sem filial)")
            return {"arquivo": nome, "codigo_empresa": codigo, "filial": filial,
                    "rotulo": rotulo,
                    "itens": itens, "aging": faixas,
                    "total_detalhe": total_det, "total_aging": total_ag,
                    "avisos": avisos}

    raise ValueError(
        "nao achei a tabela da POSICAO CONTABIL DE CONTAS A PAGAR neste "
        "arquivo (esperava o cabecalho com FORNECEDOR, DUPLICATA e VALOR).")
