# -*- coding: utf-8 -*-
"""
core_relatorio_auditoria.py - Monta o RELATORIO DE AUDITORIA no mesmo
desenho do modelo do escritorio (o "Relatorio de Auditoria Tributaria"):

    JB QUALITY  |  cabecalho e subtitulo
    empresa, CNPJ, periodo, competencia e o ID da conferencia
    faixa de situacao ("CONFERENCIA INTEGRALMENTE VALIDADA")
    RESUMO DAS VALIDACOES ....... um selo por bloco auditado
    CONFRONTACAO DOS VALORES .... item a item, com diferenca e status
    OBSERVACOES DA AUDITORIA .... o que precisa de olho humano
    "Auditoria confirmada em: <data/hora>" + rodape com paginacao

SAI EM HTML, NAO EM PDF: o relatorio e' aberto no navegador e vira PDF pelo
proprio "Imprimir > Salvar como PDF" (Ctrl+P), que ja respeita as quebras de
pagina definidas aqui no CSS de impressao. Escrever um gerador de PDF na
mao custaria muito mais e daria menos fidelidade de fonte/cor que o modelo
exige - e o app inteiro roda sem dependencia externa, entao nao ha
biblioteca de PDF disponivel.

A ORDEM DOS BLOCOS e a da conferencia: extrato bancario, aplicacao,
estoque, cartao, depreciacao e alugueis (ver core_confrontacao_final.MODULOS).
"""
import datetime
import html
import re

ROTULO_STATUS = {
    "bate": ("VALIDADO", "ok"),
    "nao_bate": ("NAO VALIDADO", "erro"),
    "atencao": ("VERIFICAR", "alerta"),
    "nao_enviado": ("NAO ENVIADO", "neutro"),
    "detalhe": ("COMPOSICAO", "neutro"),
}

def _e(t):
    return html.escape(str(t if t is not None else ""))


def _brl(v):
    """1234567.8 -> 'R$ 1.234.567,80'. Formata em en-US e troca os
    separadores, porque locale pt-BR nao esta garantido na maquina."""
    if v is None:
        return "-"
    return "R$ " + ("{:,.2f}".format(v).replace(",", "\x00")
                    .replace(".", ",").replace("\x00", "."))


def identificador(agora=None):
    """ID da conferencia, no formato do modelo: 20260814-143032-6."""
    agora = agora or datetime.datetime.now()
    return agora.strftime("%Y%m%d-%H%M%S-") + str(agora.microsecond % 10)


def _situacao_geral(resumo):
    if resumo.get("itens", 0) == 0:
        return "SEM ITENS CONFERIDOS", "neutro"
    if resumo.get("nao_batem", 0):
        return "CONFERENCIA COM DIVERGENCIAS", "erro"
    if resumo.get("atencao", 0):
        return "CONFERENCIA COM PONTOS A VERIFICAR", "alerta"
    return "CONFERENCIA INTEGRALMENTE VALIDADA", "ok"


def _bloco_resumo(modulos):
    celulas = []
    for m in modulos:
        rot, classe = ROTULO_STATUS.get(m["status"], (m["status"], "neutro"))
        celulas.append(
            '<div class="selo"><span class="selo-nome">%s</span>'
            '<span class="tag %s">%s</span></div>' % (_e(m["nome"]), classe, rot))
    return "".join(celulas)


def _tabela_confrontacao(linhas, modulos):
    """
    UMA TABELA POR MODULO, nao uma lista corrida. A conciliacao e feita
    bloco a bloco do balancete (bancos, aplicacoes, estoque, ...), entao o
    relatorio precisa ter a mesma forma: cada bloco com o seu cabecalho, o
    seu subtotal e o seu selo. Tudo junto numa tabela so obriga quem confere
    a ficar caçando as linhas do bloco no meio das outras.
    """
    if not linhas:
        return '<p class="vazio">Nenhum item conferido.</p>'

    ordem = [m["nome"] for m in modulos]
    por_modulo = {}
    for l in linhas:
        por_modulo.setdefault(l["modulo"], []).append(l)
    # modulo que apareceu nas linhas mas nao esta no placar entra no fim
    for nome in por_modulo:
        if nome not in ordem:
            ordem.append(nome)

    selo = {m["nome"]: m for m in modulos}
    out = []
    for nome in ordem:
        do_bloco = por_modulo.get(nome)
        if not do_bloco:
            continue
        m = selo.get(nome, {})
        rot_m, classe_m = ROTULO_STATUS.get(m.get("status", ""), ("", "neutro"))
        placar = ""
        if m:
            placar = ("%d item(ns) · %d validado(s) · %d divergente(s) · %d a verificar"
                      % (m.get("itens", 0), m.get("batem", 0),
                         m.get("nao_batem", 0), m.get("atencao", 0)))
        out.append('<div class="bloco"><div class="bloco-topo">'
                   '<span class="bloco-nome">%s</span>'
                   '<span class="tag %s">%s</span></div>'
                   '<div class="bloco-placar">%s</div>'
                   % (_e(nome), classe_m, rot_m, _e(placar)))
        out.append('<table class="conf">'
                   '<colgroup><col style="width:29%"><col style="width:23%">'
                   '<col style="width:14%"><col style="width:14%">'
                   '<col style="width:12%"><col style="width:9%"></colgroup>'
                   '<thead><tr>'
                   '<th>Item auditado</th><th>Conta</th>'
                   '<th class="num">Relatorio</th><th class="num">Balancete</th>'
                   '<th class="num">Diferenca</th><th>Status</th>'
                   '</tr></thead><tbody>')
        soma_rel = soma_bal = 0.0
        conta_itens = 0
        for l in do_bloco:
            rot, classe = ROTULO_STATUS.get(l["status"], (l["status"], "neutro"))
            extra = (' <span class="obs">%s</span>' % _e(l["observacao"]))                 if l.get("observacao") else ""
            out.append(
                '<tr class="l-%s"><td>%s%s</td><td class="cod">%s</td>'
                '<td class="num">%s</td><td class="num">%s</td>'
                '<td class="num">%s</td><td><span class="tag %s">%s</span></td></tr>'
                % (classe, _e(l["item"]), extra, _e(l["conta"] or "-"),
                   _brl(l["relatorio"]), _brl(l["balancete"]), _brl(l["diferenca"]),
                   classe, rot))
            # Fora da soma: "detalhe" (composicao de um item ja somado) e a
            # linha marcada como total, que JA E' a soma do bloco - somar ela
            # junto dobrava o subtotal.
            if l["status"] != "detalhe" and not l.get("total"):
                soma_rel += l["relatorio"] or 0.0
                soma_bal += l["balancete"] or 0.0
                conta_itens += 1
        if conta_itens > 1:
            dif = round(soma_rel - soma_bal, 2)
            out.append('<tr class="soma"><td colspan="2">Soma do bloco</td>'
                       '<td class="num">%s</td><td class="num">%s</td>'
                       '<td class="num">%s</td><td></td></tr>'
                       % (_brl(round(soma_rel, 2)), _brl(round(soma_bal, 2)), _brl(dif)))
        out.append("</tbody></table></div>")
    return "".join(out)


def _lista(itens, vazio):
    if not itens:
        return '<p class="vazio">%s</p>' % _e(vazio)
    return "<ul class='bullets'>" + "".join("<li>%s</li>" % _e(i) for i in itens) + "</ul>"


def montar_html(resultado, empresa, cnpj, periodo, competencia, documentos=None,
                escritorio="JB QUALITY", agora=None):
    """
    resultado: o devolvido por core_confrontacao_final.confrontar()
    documentos: ACEITO E IGNORADO. A secao "Documentos utilizados" saiu do
        relatorio a pedido do escritorio: ocupava meia pagina repetindo nomes
        de arquivo que ja aparecem no cabecalho de cada bloco, e atrapalhava
        na hora de imprimir. O parametro continua na assinatura so para nao
        quebrar quem ja chama a funcao.
    """
    agora = agora or datetime.datetime.now()
    resumo = resultado["resumo"]
    situacao, classe_sit = _situacao_geral(resumo)
    conf_id = identificador(agora)

    # observacoes = os avisos do motor (o que precisa de olho humano)
    observacoes = list(resultado.get("avisos") or [])

    cabecalho_id = " · ".join(x for x in [
        ("CNPJ: " + cnpj) if cnpj else "",
        ("Periodo: " + periodo) if periodo else "",
        ("Competencia: " + competencia) if competencia else "",
        "Conferencia: " + conf_id,
    ] if x)

    return _MOLDE % {
        "escritorio": _e(escritorio),
        "empresa": _e(empresa or "(empresa nao identificada)"),
        "identificacao": _e(cabecalho_id),
        "situacao": _e(situacao),
        "classe_sit": classe_sit,
        "resumo_selos": _bloco_resumo(resultado["modulos"]),
        "placar": "%d item(ns): %d validado(s), %d divergente(s), %d a verificar"
                  % (resumo.get("itens", 0), resumo.get("batem", 0),
                     resumo.get("nao_batem", 0), resumo.get("atencao", 0)),
        "tabela": _tabela_confrontacao(resultado["linhas"], resultado["modulos"]),
        "observacoes": _lista(observacoes, "Sem observacoes: nenhum ponto "
                                           "pendente foi levantado na conferencia."),
        "confirmado": agora.strftime("%Y-%m-%dT%H:%M:%S"),
    }


def competencia_do_periodo(periodo):
    """'01/07/2026 - 31/07/2026' -> '07/2026'. O balancete traz o periodo por
    extenso; a competencia e' o mes dele."""
    m = re.search(r"\d{2}/(\d{2})/(\d{4})", str(periodo or ""))
    return "%s/%s" % (m.group(1), m.group(2)) if m else str(periodo or "")


def nome_arquivo(empresa, competencia):
    emp = re.sub(r"[^A-Za-z0-9]+", "_", str(empresa or "EMPRESA")).strip("_").upper()
    comp = re.sub(r"[^0-9A-Za-z]+", "-", competencia_do_periodo(competencia)).strip("-")
    return ("Relatorio_Auditoria_%s_%s.html" % (comp, emp)).replace("__", "_")


_MOLDE = """<!doctype html>
<html lang="pt-br"><head><meta charset="utf-8">
<title>Relatorio de Auditoria — %(empresa)s</title>
<style>
  :root{--navy:#161f45;--gold:#c9a96a;--linha:#e3e6f2;--suave:#6b7280}
  *{box-sizing:border-box}
  body{margin:0;background:#eef0f5;color:#1c2340;
       font-family:Inter,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;font-size:12px}
  .folha{width:210mm;min-height:297mm;margin:14px auto;background:#fff;padding:16mm 14mm;
         box-shadow:0 6px 22px rgba(20,25,80,.14);position:relative}
  .topo{display:flex;align-items:baseline;gap:10px;border-bottom:3px solid var(--navy);
        padding-bottom:8px}
  .topo .marca{font-size:20px;font-weight:800;color:var(--navy);letter-spacing:.5px}
  .topo .sub{font-size:10.5px;font-weight:700;color:var(--gold);
             text-transform:uppercase;letter-spacing:.7px}
  h1{font-size:15px;margin:14px 0 3px;color:var(--navy)}
  .ident{font-size:10.5px;color:var(--suave);margin-bottom:14px}
  .faixa{padding:10px 14px;border-radius:6px;font-weight:800;font-size:13px;
         letter-spacing:.4px;text-align:center;margin-bottom:16px}
  .faixa.ok{background:#e1f5ea;color:#1e6b3c;border:1px solid #a9dcc0}
  .faixa.erro{background:#fbe4e4;color:#a3341f;border:1px solid #eeb4ad}
  .faixa.alerta{background:#fdeed9;color:#7a5a1f;border:1px solid #f0d3a0}
  .faixa.neutro{background:#f1f2f7;color:#4b5162;border:1px solid #dcdfeb}
  h2{font-size:11px;text-transform:uppercase;letter-spacing:.9px;color:var(--navy);
     margin:18px 0 8px;padding-bottom:4px;border-bottom:1px solid var(--linha)}
  .selos{display:flex;flex-wrap:wrap;gap:8px}
  .selo{flex:1 1 30%%;min-width:150px;border:1px solid var(--linha);border-radius:6px;
        padding:8px 10px;display:flex;justify-content:space-between;align-items:center;gap:8px}
  .selo-nome{font-weight:700;font-size:11px}
  .tag{font-size:9.5px;font-weight:800;padding:3px 8px;border-radius:20px;white-space:nowrap}
  .tag.ok{background:#e1f5ea;color:#1e6b3c}
  .tag.erro{background:#fbe4e4;color:#a3341f}
  .tag.alerta{background:#fdeed9;color:#7a5a1f}
  .tag.neutro{background:#f1f2f7;color:#4b5162}
  .placar{font-size:10.5px;color:var(--suave);margin:6px 0 0}
  .bloco{margin-top:12px;page-break-inside:avoid}
  .bloco-topo{display:flex;justify-content:space-between;align-items:center;
              background:#f4f6fb;border-left:4px solid var(--navy);
              padding:6px 10px;border-radius:4px 4px 0 0}
  .bloco-nome{font-weight:800;font-size:11.5px;color:var(--navy)}
  .bloco-placar{font-size:9.5px;color:var(--suave);padding:3px 10px 5px}
  tr.soma td{background:#f7f8fc;font-weight:800;border-top:2px solid var(--linha)}
  .obs{display:block;font-size:9px;color:#7a5a1f;font-style:italic}
  /* table-layout FIXO: sem isso o navegador dimensiona as colunas pelo
     conteudo, e uma unica celula longa estoura a largura da folha. Foi o que
     aconteceu com a Depreciacao, cuja coluna CONTA junta seis contas numa
     celula so: a tabela passava da margem do A4 e a coluna do item ficava
     tao estreita que quebrava uma palavra por linha. Com largura fixa, a
     celula longa quebra em varias linhas e o bloco continua dentro da folha. */
  table.conf{width:100%%;border-collapse:collapse;font-size:10.5px;margin-top:4px;
             table-layout:fixed}
  table.conf th{background:var(--navy);color:#fff;text-align:left;padding:6px 7px;
                font-size:9.5px;text-transform:uppercase;letter-spacing:.3px}
  table.conf td{padding:5px 7px;border-bottom:1px solid #eef0f6;vertical-align:top}
  table.conf tr.l-erro td{background:#fdf3f2}
  table.conf tr.l-alerta td{background:#fdf8ef}
  .num{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
  /* A conta QUEBRA de linha: quando o item cobre varias contas (depreciacao),
     a lista inteira cabe na coluna em vez de esticar a tabela. */
  .cod{color:var(--suave);overflow-wrap:anywhere;font-size:9.5px}
  table.conf td{overflow-wrap:break-word}
  ul.bullets{margin:4px 0 0;padding-left:16px}
  ul.bullets li{margin-bottom:4px;line-height:1.45}
  .vazio{color:var(--suave);font-style:italic;margin:4px 0 0}
  .confirmado{margin-top:18px;font-size:10px;color:var(--suave)}
  .rodape{margin-top:6px;padding-top:6px;border-top:1px solid var(--linha);
          font-size:9px;color:var(--suave);display:flex;justify-content:space-between}
  @media print{
    body{background:#fff}
    .folha{width:auto;min-height:0;margin:0;padding:12mm;box-shadow:none}
    .quebra{page-break-before:always}
    table.conf{page-break-inside:auto}
    table.conf tr{page-break-inside:avoid}
    thead{display:table-header-group}
  }
  @page{size:A4;margin:10mm}
</style>
</head><body>
<div class="folha">
  <div class="topo"><span class="marca">%(escritorio)s</span>
    <span class="sub">Gestao Contabil — Relatorio de Auditoria Contabil</span></div>
  <h1>%(empresa)s</h1>
  <div class="ident">%(identificacao)s</div>
  <div class="faixa %(classe_sit)s">%(situacao)s</div>

  <h2>Resumo das validacoes</h2>
  <div class="selos">%(resumo_selos)s</div>
  <p class="placar">%(placar)s</p>

  <h2>Confrontacao dos valores</h2>
  %(tabela)s

  <h2>Observacoes da auditoria</h2>
  %(observacoes)s

  <div class="confirmado">Auditoria confirmada em: %(confirmado)s</div>
  <div class="rodape">
    <span>Relatorio gerado pelo Sistema Interno de Conferencia — %(escritorio)s Gestao Contabil</span>
    <span>Documento de uso interno</span>
  </div>
</div>
</body></html>
"""
