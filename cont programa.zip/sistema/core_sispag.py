# -*- coding: utf-8 -*-
"""
core_sispag.py - SISPAG do Itau -> lancamentos contabeis.

REGRA DO LANCAMENTO (uma linha por pagamento efetuado):

    Data    = data do pagamento
    Debito  = conta do FAVORECIDO, achada no plano de contas da empresa
    Credito = conta do SISPAG cadastrada na empresa (na ML e a 735,
              "SISPAG FORNECEDORES ITAU") - MUDA DE EMPRESA PARA EMPRESA,
              por isso e cadastro, nunca numero fixo no codigo
    Valor   = valor pago
    Historico = "PAGAMENTO REF. A SISPAG <nome da conta paga>"

COMO A CONTA DO FAVORECIDO E ACHADA, nesta ordem:

  1. DE-PARA cadastrado (tela De-Para): padrao contido no nome do favorecido.
     E' o unico criterio em que alguem DISSE qual e a conta - por isso vem
     primeiro e nao e' discutido.
  2. PLANO DE CONTAS da empresa: nome do favorecido x nome da conta, com os
     dois normalizados (sem acento, sem pontuacao, sem LTDA/ME/EPP/SA...).
     Aceita nome exato ou um sendo comeco do outro - o SISPAG as vezes corta
     o nome. So vale se o resultado for UNICO: dois candidatos = nao achou.
  3. Nao achou -> CONTA DE RECLASSIFICAR cadastrada (na ML, a 700
     "LANCAMENTOS A CLASSIFICAR"). Nada e' jogado fora e nada e' chutado.

CONTAS DE CAIXA/BANCO FICAM DE FORA do casamento (grupo 1.1.01...). O
favorecido de um pagamento nao e' a conta bancaria da propria empresa, e o
plano tem contas com nome de banco ("CAIXA ECONOMICA FEDERAL") que casariam
por acaso com favorecidos como a Caixa recebendo um tributo - lancar no
banco em vez da despesa seria um erro dificil de achar depois.
"""
import io
import re
import unicodedata

import core_cartao
import xlsxescreve
from xlsxescreve import Aba, Cabecalho, Dinheiro, Negrito, Titulo

# Sufixos societarios: nao distinguem uma empresa da outra e atrapalham o
# casamento ("KARCHER INDUSTRIA E COMERCIO LTDA." x "...LTDA").
SUFIXOS = ("LTDA", "EPP", "ME", "MEI", "EIRELI", "SA", "S A", "CIA",
           "COMPANHIA", "EM RECUPERACAO JUDICIAL")

# Grupo do DISPONIVEL (caixa e bancos) - fora do casamento, ver docstring.
PREFIXO_DISPONIVEL = "1.1.01"

MIN_PREFIXO = 10   # letras minimas para aceitar casamento por comeco de nome


def _norm(texto):
    """MAIUSCULO, sem acento, sem pontuacao, espacos colapsados."""
    t = unicodedata.normalize("NFKD", str(texto or ""))
    t = "".join(c for c in t if not unicodedata.combining(c))
    t = re.sub(r"[^A-Za-z0-9 ]", " ", t.upper())
    return re.sub(r"\s+", " ", t).strip()


def _chave_nome(texto):
    """
    Nome pronto para comparar: sem os sufixos societarios do fim e sem o
    codigo numerico que alguns planos colocam na frente do nome
    ("218811 HUSQVARNA DO BRASIL ICPFJ LTDA" -> "HUSQVARNA DO BRASIL ICPFJ").
    """
    t = _norm(texto)
    t = re.sub(r"^\d{3,}\s+", "", t)
    mudou = True
    while mudou:
        mudou = False
        for suf in SUFIXOS:
            if t.endswith(" " + suf):
                t = t[: -(len(suf) + 1)].strip()
                mudou = True
    return t


def _e_de_fornecedores(classificacao, grupos):
    """
    A conta esta dentro de um grupo chamado FORNECEDORES?

    Serve de desempate: no plano da ML o mesmo fornecedor aparece DUAS vezes,
    uma em "2.1.01.01 FORNECEDORES" (passivo, a certa para um pagamento) e
    outra numa conta solta do ativo (1.1.20.10). Sem o desempate os dois
    candidatos empatavam e o pagamento caia em reclassificar sem necessidade.
    """
    partes = str(classificacao or "").split(".")
    for i in range(len(partes), 0, -1):
        nome = grupos.get(".".join(partes[:i]))
        if nome and "FORNECEDOR" in _norm(nome):
            return True
    return False


def contas_candidatas(plano_contas, fora=()):
    """
    Contas do plano que podem receber o debito de um pagamento: analiticas,
    fora do grupo do disponivel e fora das contas ja usadas na regra
    (credito do SISPAG, conta de reclassificar).
    """
    fora_norm = {str(c or "").strip() for c in fora if str(c or "").strip()}
    grupos = {c.get("classificacao"): c.get("nome")
              for c in plano_contas or [] if (c.get("tipo") or "A") == "S"}
    saida = []
    for c in plano_contas or []:
        if (c.get("tipo") or "A") != "A":
            continue
        classif = str(c.get("classificacao", ""))
        if classif.startswith(PREFIXO_DISPONIVEL):
            continue
        if c.get("codigo") in fora_norm or classif in fora_norm:
            continue
        chave = _chave_nome(c.get("nome"))
        if len(chave) < 4:
            continue
        saida.append({"codigo": c.get("codigo", ""),
                      "classificacao": classif,
                      "nome": c.get("nome", ""), "chave": chave,
                      "fornecedor": _e_de_fornecedores(classif, grupos)})
    return saida


def _desempatar(achados):
    """Empate resolvido pela conta que esta no grupo FORNECEDORES."""
    forn = [c for c in achados if c.get("fornecedor")]
    return forn if len(forn) == 1 else achados


def _casar_plano(favorecido, candidatas):
    """(conta, motivo) ou (None, motivo_da_falha)."""
    alvo = _chave_nome(favorecido)
    if len(alvo) < 4:
        return None, "nome do favorecido curto demais para casar"

    exatas = _desempatar([c for c in candidatas if c["chave"] == alvo])
    if len(exatas) == 1:
        return exatas[0], "nome igual ao da conta no plano"
    if len(exatas) > 1:
        return None, "mais de uma conta com esse nome no plano (%s)" % \
            ", ".join(c["codigo"] for c in exatas[:4])

    if len(alvo) >= MIN_PREFIXO:
        pref = _desempatar([c for c in candidatas
                            if len(c["chave"]) >= MIN_PREFIXO
                            and (c["chave"].startswith(alvo)
                                 or alvo.startswith(c["chave"]))])
        if len(pref) == 1:
            return pref[0], "nome do plano comeca igual (nome cortado no SISPAG)"
        if len(pref) > 1:
            return None, "mais de uma conta comeca com esse nome (%s)" % \
                ", ".join(c["codigo"] for c in pref[:4])
    return None, "nao achei o favorecido no plano de contas"


PREFIXO_HISTORICO = "PAGAMENTO REF. A SISPAG"


def _historico(favorecido, nome_conta):
    """
    "PAGAMENTO REF. A SISPAG <conta paga>" - o nome da CONTA, nao o do
    favorecido, porque e o nome da conta que o contador reconhece no razao e
    porque o SISPAG corta o nome em 30 caracteres ("3MC LOCADORA DE
    EQUIPAMENTOS L"), enquanto o plano tem o nome inteiro.

    Sem conta achada (foi para a reclassificar) entra o nome do favorecido:
    e a unica identificacao que sobra, e e justamente ela que faz falta na
    hora de reclassificar o lancamento depois.
    """
    nome = (nome_conta or "").strip() or (favorecido or "").strip()
    return core_cartao._maiusculo("%s %s" % (PREFIXO_HISTORICO, nome)).strip()


def _casar_depara(favorecido, depara):
    """Casa pelo De-Para cadastrado; o padrao MAIS LONGO ganha (mais especifico)."""
    alvo = _norm(favorecido)
    achados = []
    for d in depara or []:
        padrao = _norm(d.get("padrao"))
        conta = str(d.get("conta") or "").strip()
        if padrao and conta and padrao in alvo:
            achados.append((len(padrao), d))
    if not achados:
        return None
    achados.sort(key=lambda x: -x[0])
    return achados[0][1]


def conciliar(itens, cfg, tudo_reclassificar=False):
    """
    itens: lista de parsers_sispag.ler_sispag()["itens"] (varios arquivos ja
           concatenados).
    cfg:   cadastro da empresa.
    tudo_reclassificar: joga TODO pagamento na conta de reclassificar, sem
           procurar conta nenhuma. Serve para quem prefere lancar tudo numa
           conta so e separar depois no proprio sistema contabil.

    Devolve {"lancamentos": [...], "linhas": [...], "resumo": {...},
             "avisos": [...]}.
    Cada linha traz de onde saiu a conta, para a planilha de conferencia.
    """
    contas = cfg.get("contas") or {}
    # A empresa pode estar cadastrada por codigo REDUZIDO ou por
    # CLASSIFICACAO; o mesmo criterio dos outros modulos (ver
    # core_francesinha.contas_da_empresa), para o CSV sair no codigo que o
    # sistema contabil dessa empresa espera.
    modo = cfg.get("modo_codigo", "reduzido")

    def _cod(chave):
        c = contas.get(chave) or {}
        valor = (c.get("classificacao") if modo == "classificacao"
                 else c.get("reduzido")) or c.get("reduzido") \
            or c.get("classificacao") or ""
        return valor.strip()

    credito = _cod("sispag_credito")
    reclass = _cod("sispag_reclassificar") or _cod("pendencia")

    avisos = []
    if not credito:
        avisos.append("Falta cadastrar a CONTA DE CREDITO do SISPAG nesta "
                      "empresa (em Cadastro). Sem ela o CSV nao pode ser "
                      "gerado — na ML essa conta e a 735.")
    if not reclass:
        avisos.append("Falta cadastrar a CONTA DE RECLASSIFICAR do SISPAG. "
                      "Sem ela, pagamento sem conta no plano fica sem debito "
                      "— na ML essa conta e a 700.")

    candidatas = contas_candidatas(cfg.get("plano_contas"), fora=(credito, reclass))
    if not candidatas and not tudo_reclassificar:
        avisos.append("Esta empresa nao tem PLANO DE CONTAS carregado (tela "
                      "De-Para). Sem ele todo pagamento cai na conta de "
                      "reclassificar.")

    depara = cfg.get("depara") or []
    linhas, lancamentos = [], []
    por_origem = {"depara": 0, "plano": 0, "reclassificar": 0}

    for it in sorted(itens, key=_ordem):
        favorecido = it["favorecido"]
        conta = origem = motivo = ""
        nome_conta = ""

        if tudo_reclassificar:
            conta, origem = reclass, "reclassificar"
            motivo = "opcao 'deixar tudo em reclassificar' ligada"
            d = None
        else:
            d = _casar_depara(favorecido, depara)
        if d:
            conta, origem = str(d.get("conta") or "").strip(), "depara"
            nome_conta = str(d.get("nome") or "").strip()
            motivo = "De-Para cadastrado (padrao '%s')" % d.get("padrao", "")
        elif not tudo_reclassificar:
            achado, motivo = _casar_plano(favorecido, candidatas)
            if achado:
                conta, origem = achado["codigo"], "plano"
                nome_conta = achado["nome"]
            else:
                conta, origem = reclass, "reclassificar"

        por_origem[origem] += 1
        historico = _historico(favorecido, nome_conta)
        linhas.append({
            "data": it["data"], "valor": it["valor"], "favorecido": favorecido,
            "cnpj_favorecido": it.get("cnpj_favorecido", ""),
            "tipo": it.get("tipo", ""), "conta_pagadora": it.get("conta_pagadora", ""),
            "debito": conta, "credito": credito, "nome_conta": nome_conta,
            "origem": origem, "motivo": motivo, "historico": historico,
            "arquivo": it.get("arquivo", ""),
        })
        lancamentos.append({"data": it["data"], "debito": conta,
                            "credito": credito, "valor": it["valor"],
                            "historico": historico})

    # UM registro por FORNECEDOR (nao por pagamento): e assim que a tela de
    # cadastro trabalha - se o mesmo fornecedor aparece 24 vezes, quem cadastra
    # digita a conta UMA vez e as 24 linhas passam a ir para ela.
    fornecedores = {}
    for l in linhas:
        if l["origem"] != "reclassificar":
            continue
        f = fornecedores.setdefault(l["favorecido"], {
            "favorecido": l["favorecido"], "cnpj": l["cnpj_favorecido"],
            "pagamentos": 0, "total": 0.0, "motivo": l["motivo"]})
        f["pagamentos"] += 1
        f["total"] = round(f["total"] + l["valor"], 2)
    # maior valor primeiro: e por onde vale a pena comecar a cadastrar
    fornecedores = sorted(fornecedores.values(), key=lambda f: -f["total"])

    resumo = {
        "itens": len(linhas),
        "fornecedores_sem_conta": len(fornecedores),
        "total": round(sum(l["valor"] for l in linhas), 2),
        "por_depara": por_origem["depara"],
        "por_plano": por_origem["plano"],
        "reclassificar": por_origem["reclassificar"],
        "total_reclassificar": round(
            sum(l["valor"] for l in linhas if l["origem"] == "reclassificar"), 2),
        "credito": credito,
        "conta_reclassificar": reclass,
    }
    if por_origem["reclassificar"] and not tudo_reclassificar:
        avisos.append(
            "%d pagamento(s), somando %s, foram para a conta de reclassificar "
            "(%s) porque o favorecido nao foi achado no plano de contas. Eles "
            "estao listados na planilha de conferencia — cadastre o De-Para "
            "desses nomes e gere de novo para eles irem direto."
            % (por_origem["reclassificar"],
               _brl(resumo["total_reclassificar"]), reclass or "?"))
    return {"lancamentos": lancamentos, "linhas": linhas,
            "fornecedores": fornecedores, "resumo": resumo, "avisos": avisos}


def _ordem(it):
    d = it["data"]
    try:
        dia, mes, ano = d.split("/")
        return (ano + mes + dia, it["favorecido"])
    except ValueError:
        return (d, it["favorecido"])


def _brl(v):
    return "R$ " + ("{:,.2f}".format(v or 0.0).replace(",", "\x00")
                    .replace(".", ",").replace("\x00", "."))


def csv_bytes(resultado):
    """CSV no layout de importacao: Data;Debito;Credito;Valor;;Historico."""
    return core_cartao.csv_bytes(resultado["lancamentos"])


ORIGEM_ROTULO = {"depara": "De-Para cadastrado",
                 "plano": "Plano de contas",
                 "reclassificar": "RECLASSIFICAR"}


def planilha_bytes(resultado, empresa, periodo):
    """
    Planilha de conferencia: uma aba com todo pagamento e de onde saiu a
    conta, e uma aba so com o que caiu em reclassificar - que e' a lista de
    trabalho de quem vai cadastrar o De-Para.
    """
    r = resultado["resumo"]
    cab = ["Data", "Favorecido", "CPF/CNPJ", "Tipo de pagamento",
           "Debito", "Nome da conta", "Credito", "Valor", "Historico",
           "Origem da conta", "Observacao", "Arquivo"]

    def corpo(linhas):
        return [[l["data"], l["favorecido"], l["cnpj_favorecido"], l["tipo"],
                 l["debito"], l["nome_conta"], l["credito"], Dinheiro(l["valor"]),
                 l["historico"], ORIGEM_ROTULO.get(l["origem"], l["origem"]),
                 l["motivo"], l["arquivo"]] for l in linhas]

    todos = resultado["linhas"]
    pendentes = [l for l in todos if l["origem"] == "reclassificar"]

    abas = [Aba("SISPAG", [
        [Titulo("SISPAG — lancamentos gerados")],
        [Negrito("Empresa"), empresa], [Negrito("Periodo"), periodo],
        [Negrito("Conta de credito"), r["credito"]],
        [Negrito("Conta de reclassificar"), r["conta_reclassificar"]],
        [Negrito("Pagamentos"), r["itens"],
         Negrito("Total"), Dinheiro(r["total"])],
        [Negrito("Pelo De-Para"), r["por_depara"],
         Negrito("Pelo plano"), r["por_plano"],
         Negrito("A reclassificar"), r["reclassificar"]],
        [],
        [Cabecalho(c) for c in cab],
    ] + corpo(todos))]

    if pendentes:
        abas.append(Aba("A CLASSIFICAR", [
            [Titulo("Favorecidos sem conta no plano — cadastre o De-Para")],
            [Negrito("Pagamentos"), len(pendentes),
             Negrito("Total"), Dinheiro(r["total_reclassificar"])],
            [],
            [Cabecalho(c) for c in cab],
        ] + corpo(pendentes)))

    buf = io.BytesIO()
    xlsxescreve.escrever(buf, abas)
    return buf.getvalue()


def nome_arquivo(empresa, periodo, ext):
    base = re.sub(r"[^A-Za-z0-9]+", "_", core_cartao._maiusculo(empresa)).strip("_")
    per = (periodo or "").replace("/", "-")
    return "%s_SISPAG_%s.%s" % (base, per or "periodo", ext)
