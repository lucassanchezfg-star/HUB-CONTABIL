"""Leitor minimo de .xls antigo (BIFF8 dentro de um Compound File Binary / OLE2), so com
stdlib. Sem xlrd/olefile - o .xls classico e' um "sistema de arquivos" binario proprio (OLE2)
com um stream 'Workbook' dentro, e esse stream e' uma sequencia de registros BIFF (tipo+tamanho+
dados). Cobre o suficiente pra ler uma planilha simples exportada por um sistema tipo Dominio:
BOUNDSHEET, SST (+CONTINUE), LABELSST, NUMBER, RK, MULRK, LABEL, FORMULA (resultado em cache).
"""
import struct

SECTOR_FREE = 0xFFFFFFFF
SECTOR_ENDOFCHAIN = 0xFFFFFFFE
SECTOR_FATSECT = 0xFFFFFFFD
SECTOR_DIFSECT = 0xFFFFFFFC


class _OleFile:
    def __init__(self, data):
        self.data = data
        header = data[:512]
        if header[:8] != b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1':
            raise ValueError('Não é um arquivo OLE2/Compound File válido (.xls antigo).')
        (self.sector_shift, self.mini_sector_shift) = struct.unpack('<HH', header[30:34])
        self.sector_size = 1 << self.sector_shift
        self.mini_sector_size = 1 << self.mini_sector_shift
        (self.num_fat_sectors,) = struct.unpack('<I', header[44:48])
        (self.first_dir_sector,) = struct.unpack('<I', header[48:52])
        (self.mini_stream_cutoff,) = struct.unpack('<I', header[56:60])
        (self.first_minifat_sector,) = struct.unpack('<I', header[60:64])
        (self.num_minifat_sectors,) = struct.unpack('<I', header[64:68])
        (self.first_difat_sector,) = struct.unpack('<I', header[68:72])
        (self.num_difat_sectors,) = struct.unpack('<I', header[72:76])

        difat = list(struct.unpack('<109I', header[76:76 + 109 * 4]))
        sector = self.first_difat_sector
        while sector not in (SECTOR_ENDOFCHAIN, SECTOR_FREE) and self.num_difat_sectors:
            buf = self._sector(sector)
            entries = struct.unpack('<128I', buf)
            difat.extend(entries[:127])
            sector = entries[127]

        self.fat = []
        for sid in difat:
            if sid in (SECTOR_FREE, SECTOR_ENDOFCHAIN, SECTOR_FATSECT, SECTOR_DIFSECT):
                continue
            buf = self._sector(sid)
            n = self.sector_size // 4
            self.fat.extend(struct.unpack(f'<{n}I', buf))

        self.directory = self._read_chain(self.first_dir_sector)
        self.entries = self._parse_directory(self.directory)

        root = next(e for e in self.entries if e['type'] == 5)
        self.mini_stream = None
        if root['size'] > 0:
            full = self._read_chain(root['start'])
            self.mini_stream = full[:root['size']]

        self.minifat = []
        if self.num_minifat_sectors:
            buf = self._read_chain(self.first_minifat_sector)
            n = len(buf) // 4
            self.minifat = list(struct.unpack(f'<{n}I', buf))

    def _sector(self, sid):
        start = 512 + sid * self.sector_size
        return self.data[start:start + self.sector_size]

    def _read_chain(self, start_sid):
        out = bytearray()
        sid = start_sid
        seen = set()
        while sid not in (SECTOR_ENDOFCHAIN, SECTOR_FREE) and sid not in seen:
            seen.add(sid)
            out += self._sector(sid)
            sid = self.fat[sid] if sid < len(self.fat) else SECTOR_ENDOFCHAIN
        return bytes(out)

    def _read_mini_chain(self, start_sid, size):
        out = bytearray()
        sid = start_sid
        seen = set()
        while sid not in (SECTOR_ENDOFCHAIN, SECTOR_FREE) and sid not in seen:
            seen.add(sid)
            off = sid * self.mini_sector_size
            out += self.mini_stream[off:off + self.mini_sector_size]
            sid = self.minifat[sid] if sid < len(self.minifat) else SECTOR_ENDOFCHAIN
        return bytes(out[:size]) if size else bytes(out)

    def _parse_directory(self, raw):
        entries = []
        for i in range(0, len(raw), 128):
            chunk = raw[i:i + 128]
            if len(chunk) < 128:
                break
            name_len = struct.unpack('<H', chunk[64:66])[0]
            name = chunk[:max(name_len - 2, 0)].decode('utf-16-le', 'ignore') if name_len > 2 else ''
            obj_type = chunk[66]
            start_sector = struct.unpack('<I', chunk[116:120])[0]
            size = struct.unpack('<Q', chunk[120:128])[0]
            entries.append({'name': name, 'type': obj_type, 'start': start_sector, 'size': size})
        return entries

    def read_stream(self, name):
        entry = next((e for e in self.entries if e['name'].lower() == name.lower() and e['type'] == 2), None)
        if not entry:
            return None
        if entry['size'] < self.mini_stream_cutoff:
            return self._read_mini_chain(entry['start'], entry['size'])
        return self._read_chain(entry['start'])[:entry['size']]


def _rk_to_float(rk_bytes):
    value = struct.unpack('<i', rk_bytes)[0]
    is_int = value & 0x02
    is_100 = value & 0x01
    value &= ~0x03
    if is_int:
        num = value >> 2
    else:
        num = struct.unpack('<d', b'\x00\x00\x00\x00' + struct.pack('<i', value))[0]
    if is_100:
        num = num / 100.0
    return float(num)


def _parse_sst(blocos):
    """
    blocos = [corpo do SST, corpo de cada CONTINUE que o segue] - SEPARADOS,
    nunca concatenados. Devolve a lista de strings.

    POR QUE NAO DA PARA CONCATENAR: quando uma string nao cabe inteira no
    registro, ela continua no CONTINUE seguinte - e esse CONTINUE comeca com
    1 BYTE DE FLAG dizendo se o RESTO da string vem compactado (1 byte por
    caractere) ou largo (2 bytes, UTF-16). A codificacao pode ate MUDAR no
    meio da mesma string. Colando os blocos, esse byte de controle e' lido
    como se fosse texto e desalinha TUDO dali para frente.

    Sintoma real (francesinha do BB, 520 strings em 2 blocos): 452 strings
    saiam embaralhadas e as celulas afetadas chegavam VAZIAS na planilha -
    nome do pagador e "Seu Numero" sumiam em ~20 linhas, sem erro nenhum.
    Silencioso, que e o pior tipo de bug num leitor de arquivo.
    """
    bi = 0
    data = blocos[0]
    datalen = len(data)
    _total, unique = struct.unpack('<II', data[:8])
    pos = 8
    strings = []

    def _proximo_bloco(com_flag):
        """Vai para o proximo bloco. com_flag=True quando estamos NO MEIO de
        uma string (o 1o byte do CONTINUE e' o flag de codificacao do resto);
        com_flag=False quando o bloco anterior acabou certinho no fim de uma
        string (o proximo ja comeca com uma string nova, sem flag)."""
        nonlocal bi, data, datalen, pos
        bi += 1
        data = blocos[bi]
        datalen = len(data)
        pos = 1 if com_flag else 0
        return data[0] if com_flag else 0

    def _pular(n):
        """Pula n bytes crus (richtext/phonetic), atravessando blocos."""
        nonlocal pos
        while n > 0:
            cabem = min(datalen - pos, n)
            pos += cabem
            n -= cabem
            if n > 0:
                if bi + 1 >= len(blocos):
                    return
                _proximo_bloco(False)

    for _ in range(unique):
        if pos >= datalen:
            if bi + 1 >= len(blocos):
                break
            _proximo_bloco(False)
        if pos + 3 > datalen:
            break
        char_count, flags = struct.unpack('<HB', data[pos:pos + 3])
        pos += 3
        is_wide = flags & 0x01
        rt_count = 0
        phon_size = 0
        if flags & 0x08:          # richtext
            rt_count = struct.unpack('<H', data[pos:pos + 2])[0]
            pos += 2
        if flags & 0x04:          # phonetic
            phon_size = struct.unpack('<I', data[pos:pos + 4])[0]
            pos += 4

        partes = []
        faltam = char_count
        while True:
            if is_wide:
                cabem = min((datalen - pos) >> 1, faltam)
                partes.append(data[pos:pos + 2 * cabem].decode('utf-16-le', 'ignore'))
                pos += 2 * cabem
            else:
                cabem = min(datalen - pos, faltam)
                partes.append(data[pos:pos + cabem].decode('latin-1', 'ignore'))
                pos += cabem
            faltam -= cabem
            if faltam <= 0:
                break
            if bi + 1 >= len(blocos):
                break
            is_wide = _proximo_bloco(True) & 0x01
        strings.append(''.join(partes))
        _pular(rt_count * 4 + phon_size)
    return strings


def read_sheet(path, sheet_index=0):
    """Devolve uma lista de linhas (cada uma uma lista de valores str/float), na ordem lida."""
    with open(path, 'rb') as f:
        data = f.read()
    ole = _OleFile(data)
    wb = ole.read_stream('Workbook') or ole.read_stream('Book')
    if wb is None:
        raise ValueError('Stream Workbook/Book não encontrado no arquivo .xls.')

    # 1a passada: percorre os registros globais pra achar SST (+ CONTINUE) e BOUNDSHEET.
    pos = 0
    sst_strings = []
    boundsheets = []
    pending_sst = None
    while pos + 4 <= len(wb):
        rec_type, rec_len = struct.unpack('<HH', wb[pos:pos + 4])
        body = wb[pos + 4:pos + 4 + rec_len]
        if rec_type == 0x000A:  # EOF dos globais
            pos += 4 + rec_len
            break
        if rec_type == 0x00FC:  # SST
            pending_sst = [body]
        elif rec_type == 0x003C and pending_sst is not None:  # CONTINUE (segue o SST)
            pending_sst.append(body)   # SEPARADO - ver _parse_sst
        elif rec_type == 0x0085:  # BOUNDSHEET
            offset = struct.unpack('<I', body[0:4])[0]
            name_len = body[6]
            name_flags = body[7]
            raw_name = body[8:8 + (name_len * 2 if name_flags & 1 else name_len)]
            nome = raw_name.decode('utf-16-le', 'ignore') if name_flags & 1 else raw_name.decode('latin-1', 'ignore')
            boundsheets.append({'offset': offset, 'nome': nome})
        else:
            if rec_type not in (0x003C,):
                pending_sst = pending_sst  # mantem, so CONTINUE gruda no SST
        pos += 4 + rec_len
    if pending_sst is not None:
        sst_strings = _parse_sst(pending_sst)

    if not boundsheets:
        raise ValueError('Nenhuma planilha encontrada (BOUNDSHEET) no arquivo .xls.')
    sheet_offset = boundsheets[sheet_index]['offset']

    # 2a passada: le os registros da planilha escolhida, a partir do offset que o BOUNDSHEET
    # informou. Alguns geradores de .xls (sistemas proprios tipo ERP, nao o Excel oficial) nao
    # colocam um BOF logo no inicio do substream da planilha - o BOF pode aparecer NO MEIO dos
    # registros, entao nao da pra usar "achou outro BOF" como sinal de fim. O sinal real de fim
    # e' o EOF (0x000A) que fecha esse substream.
    linhas = {}
    pos = sheet_offset
    while pos + 4 <= len(wb):
        rec_type, rec_len = struct.unpack('<HH', wb[pos:pos + 4])
        body = wb[pos + 4:pos + 4 + rec_len]
        if rec_type == 0x00FD:  # LABELSST
            r, c, _xf, isst = struct.unpack('<HHHI', body[:10])
            linhas.setdefault(r, {})[c] = sst_strings[isst] if isst < len(sst_strings) else ''
        elif rec_type == 0x0203:  # NUMBER
            r, c, _xf = struct.unpack('<HHH', body[:6])
            (val,) = struct.unpack('<d', body[6:14])
            linhas.setdefault(r, {})[c] = val
        elif rec_type == 0x027E:  # RK
            r, c, _xf = struct.unpack('<HHH', body[:6])
            val = _rk_to_float(body[6:10])
            linhas.setdefault(r, {})[c] = val
        elif rec_type == 0x00BD:  # MULRK
            r, first_c = struct.unpack('<HH', body[:4])
            n = (len(body) - 6) // 6
            for i in range(n):
                off = 4 + i * 6
                _xf = struct.unpack('<H', body[off:off + 2])[0]
                val = _rk_to_float(body[off + 2:off + 6])
                linhas.setdefault(r, {})[first_c + i] = val
        elif rec_type == 0x0204:  # LABEL (string direta, sem SST)
            r, c, _xf, strlen = struct.unpack('<HHHH', body[:8])
            flags = body[8]
            raw = body[9:9 + (strlen * 2 if flags & 1 else strlen)]
            texto = raw.decode('utf-16-le', 'ignore') if flags & 1 else raw.decode('latin-1', 'ignore')
            linhas.setdefault(r, {})[c] = texto
        elif rec_type == 0x0006:  # FORMULA (usa o resultado em cache)
            r, c, _xf = struct.unpack('<HHH', body[:6])
            result_bytes = body[6:14]
            if result_bytes[6:8] == b'\xff\xff':
                if result_bytes[0] == 0:
                    linhas.setdefault(r, {})[c] = ''  # string calculada - viria num STRING seguinte
            else:
                (val,) = struct.unpack('<d', result_bytes)
                linhas.setdefault(r, {})[c] = val
        pos += 4 + rec_len
        if rec_type == 0x000A:
            break

    if not linhas:
        return []
    max_row = max(linhas.keys())
    max_col = max(c for cols in linhas.values() for c in cols.keys())
    saida = []
    for r in range(max_row + 1):
        cols = linhas.get(r, {})
        saida.append([cols.get(c, '') for c in range(max_col + 1)])
    return saida


def ler_como_dicts(path, sheet_index=0):
    linhas = read_sheet(path, sheet_index)
    if not linhas:
        return []
    cabecalho = [str(h).strip() for h in linhas[0]]
    out = []
    for linha in linhas[1:]:
        linha = list(linha) + [''] * (len(cabecalho) - len(linha))
        out.append(dict(zip(cabecalho, linha)))
    return out
