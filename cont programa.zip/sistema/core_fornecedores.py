# -*- coding: utf-8 -*-
"""
core_fornecedores.py - Consolida as POSICOES CONTABEIS DE CONTAS A PAGAR das
filiais numa planilha so.

O QUE FAZ HOJE: le os relatorios (um por filial) e junta. Nada de lancamento
contabil nem de conciliacao ainda - as regras serao combinadas depois. Por
isso este modulo NAO inventa conta nenhuma: so soma o que veio dos
relatorios e mostra de onde cada numero saiu.

A PLANILHA SAI COM:
  CONSOLIDADO      - uma linha por filial (duplicatas, total, vencido, a
                     vencer) e o total geral
  AGING            - as faixas de vencimento por filial, lado a lado
  POR FORNECEDOR   - o mesmo fornecedor somado ENTRE AS FILIAIS (a chave e o
                     CNPJ, nao o nome: o mesmo fornecedor aparece com nome
                     escrito de formas diferentes em filiais diferentes)
  uma aba por filial - o detalhe duplicata por duplicata, como veio

CONFERENCIA: cada relatorio traz o proprio resumo por faixa de vencimento, e
o leitor ja compara a soma das duplicatas com ele (ver
parsers_fornecedores). Aqui a soma das filiais e comparada com o total geral
das faixas - se as duas nao fecharem, o modulo avisa em vez de entregar
consolidado errado.
"""
import io
import re
import unicodedata

import xlsxescreve
from xlsxescreve import Aba, Cabecalho, Dinheiro, Negrito, Titulo

TOLERANCIA = 0.01

# Ordem em que as faixas aparecem no relatorio da loja.
ORDEM_GRUPO = {"VENCIDOS": 0, "A VENCER": 1}


def _letra(i):
    """Indice de coluna (0=A) -> letra, para as larguras."""
    letras, i = "", i + 1
    while i > 0:
        i, resto = divmod(i - 1, 26)
        letras = chr(65 + resto) + letras
    return letras


def _so_digitos(s):
    return re.sub(r"\D", "", str(s or ""))


def _nome_chave(s):
    t = unicodedata.normalize("NFKD", str(s or ""))
    t = "".join(c for c in t if not unicodedata.combining(c))
    return re.sub(r"[^A-Z0-9]", "", t.upper())


def _chave_fornecedor(item):
    """
    ('cnpj'|'nome', chave) para juntar o mesmo fornecedor entre as filiais.

    O CNPJ e a chave preferida porque o MESMO fornecedor tem codigo diferente
    em cada filial (cada loja cadastra o seu) e o nome vem escrito de formas
    diferentes ("Dexco S.A." x "DEXCO SA").

    MAS CNPJ ZERADO NAO E IDENTIDADE, E CAMPO EM BRANCO DISFARCADO. Nesta
    base, 12 cadastros diferentes (RESTAURANTE, PET SHOP, RECEITA FEDERAL,
    TRIBUNAL DE JUSTICA...) estao todos com 00000000000000, e 3 com
    00000000000. Aceitar isso como chave juntaria fornecedores que nao tem
    nada a ver um com o outro numa linha so. Nesse caso a juncao passa a ser
    pelo NOME - o codigo nao serve, porque muda de filial para filial.
    """
    d = _so_digitos(item.get("cnpj"))
    if len(d) in (11, 14) and set(d) != {"0"}:
        return "cnpj", d
    return "nome", _nome_chave(item.get("fornecedor")) or "(sem nome)"


def consolidar(relatorios):
    """
    relatorios: lista de parsers_fornecedores.ler_posicao().

    Devolve {"filiais":[...], "aging":[...], "fornecedores":[...],
             "resumo":{...}, "avisos":[...]}.
    """
    avisos = []
    for r in relatorios:
        avisos.extend(r.get("avisos") or [])

    # --- mesma filial enviada duas vezes seria soma em dobro ---
    vistos = {}
    filiais = []
    for r in relatorios:
        chave = r.get("codigo_empresa") or r.get("rotulo")
        if chave in vistos:
            avisos.append(
                "A filial %s veio em dois arquivos ('%s' e '%s'). O segundo "
                "foi IGNORADO - somar os dois dobraria o saldo dela."
                % (r.get("rotulo"), vistos[chave], r.get("arquivo")))
            continue
        vistos[chave] = r.get("arquivo")

        venc = round(sum(f["total"] for f in r["aging"]
                         if f["grupo"] == "VENCIDOS"), 2)
        a_venc = round(sum(f["total"] for f in r["aging"]
                           if f["grupo"] == "A VENCER"), 2)
        filiais.append({
            "codigo_empresa": r.get("codigo_empresa", ""),
            "rotulo": r.get("rotulo", ""),
            "arquivo": r.get("arquivo", ""),
            "duplicatas": len(r["itens"]),
            "fornecedores": len({_chave_fornecedor(i) for i in r["itens"]}),
            "total": r["total_detalhe"],
            "vencido": venc,
            "a_vencer": a_venc,
            "itens": r["itens"],
            "aging": r["aging"],
        })
    filiais.sort(key=lambda f: f["codigo_empresa"] or f["rotulo"])

    # --- aging juntando as filiais, na ordem do relatorio ---
    faixas = {}
    for f in filiais:
        for fx in f["aging"]:
            k = (fx["grupo"], fx["periodo"])
            faixas.setdefault(k, {"grupo": fx["grupo"], "periodo": fx["periodo"],
                                  "por_filial": {}, "total": 0.0})
            faixas[k]["por_filial"][f["rotulo"]] = round(
                faixas[k]["por_filial"].get(f["rotulo"], 0.0) + fx["total"], 2)
            faixas[k]["total"] = round(faixas[k]["total"] + fx["total"], 2)
    aging = sorted(faixas.values(),
                   key=lambda x: (ORDEM_GRUPO.get(x["grupo"], 9), x["periodo"]))

    # --- o mesmo fornecedor somado entre as filiais ---
    forn = {}
    for f in filiais:
        for i in f["itens"]:
            tipo, k = _chave_fornecedor(i)
            d = forn.setdefault((tipo, k), {
                "juntado_por": tipo,
                "cnpj": i.get("cnpj", "") if tipo == "cnpj" else "",
                "nome": i.get("fornecedor", ""), "atividade": i.get("atividade", ""),
                "duplicatas": 0, "total": 0.0, "por_filial": {}})
            d["duplicatas"] += 1
            d["total"] = round(d["total"] + i["valor"], 2)
            d["por_filial"][f["rotulo"]] = round(
                d["por_filial"].get(f["rotulo"], 0.0) + i["valor"], 2)
            # nome mais longo ganha: costuma ser o cadastro mais completo
            if len(i.get("fornecedor") or "") > len(d["nome"]):
                d["nome"] = i["fornecedor"]
    fornecedores = sorted(forn.values(), key=lambda d: -d["total"])

    total_filiais = round(sum(f["total"] for f in filiais), 2)
    total_aging = round(sum(fx["total"] for fx in aging), 2)
    if aging and abs(total_filiais - total_aging) > TOLERANCIA:
        avisos.append(
            "O total das filiais (%.2f) nao fecha com o total das faixas de "
            "vencimento (%.2f)." % (total_filiais, total_aging))

    por_nome = sum(1 for d in fornecedores if d["juntado_por"] == "nome")
    if por_nome:
        avisos.append(
            "%d fornecedores foram juntados pelo NOME porque o relatorio nao "
            "trouxe CNPJ valido para eles (campo em branco ou zerado). "
            "Confira na aba POR FORNECEDOR se algum deveria ser separado."
            % por_nome)

    resumo = {
        "filiais": len(filiais),
        "duplicatas": sum(f["duplicatas"] for f in filiais),
        "fornecedores": len(fornecedores),
        "fornecedores_por_nome": por_nome,
        "total": total_filiais,
        "vencido": round(sum(f["vencido"] for f in filiais), 2),
        "a_vencer": round(sum(f["a_vencer"] for f in filiais), 2),
        "fecha": not aging or abs(total_filiais - total_aging) <= TOLERANCIA,
    }
    return {"filiais": filiais, "aging": aging, "fornecedores": fornecedores,
            "resumo": resumo, "avisos": avisos}


def planilha_bytes(res, empresa, competencia=""):
    """A planilha de consolidacao (bytes de .xlsx)."""
    r = res["resumo"]
    rotulos = [f["rotulo"] for f in res["filiais"]]
    abas = []

    # ---- CONSOLIDADO ----
    linhas = [
        [Titulo("Contas a pagar — consolidado das filiais")],
        [Negrito("Empresa"), empresa],
        [Negrito("Competencia"), competencia or "(nao informada)"],
        [Negrito("Filiais"), r["filiais"], Negrito("Duplicatas"), r["duplicatas"],
         Negrito("Fornecedores"), r["fornecedores"]],
        [],
        [Cabecalho(c) for c in ("Cod.", "Filial", "Duplicatas", "Fornecedores",
                                "Vencido", "A vencer", "Total", "Arquivo")],
    ]
    for f in res["filiais"]:
        linhas.append([f["codigo_empresa"], f["rotulo"], f["duplicatas"],
                       f["fornecedores"], Dinheiro(f["vencido"]),
                       Dinheiro(f["a_vencer"]), Dinheiro(f["total"]), f["arquivo"]])
    linhas.append([Negrito("TOTAL"), "", r["duplicatas"], r["fornecedores"],
                   Dinheiro(r["vencido"]), Dinheiro(r["a_vencer"]),
                   Dinheiro(r["total"]), ""])
    if not r["fecha"]:
        linhas += [[], [Negrito("ATENCAO: o total das filiais nao fecha com as "
                                "faixas de vencimento — conferir antes de usar.")]]
    abas.append(Aba("CONSOLIDADO", linhas,
                    larguras={"B": 24, "C": 12, "D": 14, "E": 16, "F": 16,
                              "G": 16, "H": 46}))

    # ---- AGING ----
    linhas = [[Titulo("Faixas de vencimento por filial")], []]
    linhas.append([Cabecalho("Situacao"), Cabecalho("Periodo")] +
                  [Cabecalho(x) for x in rotulos] + [Cabecalho("Total")])
    for fx in res["aging"]:
        linhas.append([fx["grupo"], fx["periodo"]] +
                      [Dinheiro(fx["por_filial"].get(x, 0.0)) for x in rotulos] +
                      [Dinheiro(fx["total"])])
    linhas.append([Negrito("TOTAL"), ""] +
                  [Dinheiro(next((f["total"] for f in res["filiais"]
                                  if f["rotulo"] == x), 0.0)) for x in rotulos] +
                  [Dinheiro(r["total"])])
    larg = {"A": 12, "B": 22}
    for n in range(len(rotulos) + 1):         # C, D, E... uma por filial + Total
        larg[_letra(2 + n)] = 16
    abas.append(Aba("AGING", linhas, larguras=larg))

    # ---- POR FORNECEDOR ----
    linhas = [[Titulo("Fornecedores somados entre as filiais")],
              [Negrito("Juntado por"),
               "CNPJ quando o relatorio trouxe um valido; NOME quando o campo "
               "veio em branco ou zerado (%d casos) — nesses, confira se "
               "algum deveria ficar separado"
               % r.get("fornecedores_por_nome", 0)], []]
    linhas.append([Cabecalho(c) for c in ("Juntado por", "CNPJ/CPF", "Fornecedor",
                                          "Atividade", "Duplicatas")] +
                  [Cabecalho(x) for x in rotulos] + [Cabecalho("Total")])
    for d in res["fornecedores"]:
        linhas.append([d["juntado_por"].upper(), d["cnpj"], d["nome"],
                       d["atividade"], d["duplicatas"]] +
                      [Dinheiro(d["por_filial"].get(x, 0.0)) for x in rotulos] +
                      [Dinheiro(d["total"])])
    linhas.append([Negrito("TOTAL"), "", "", "", r["duplicatas"]] +
                  [Dinheiro(next((f["total"] for f in res["filiais"]
                                  if f["rotulo"] == x), 0.0)) for x in rotulos] +
                  [Dinheiro(r["total"])])
    larg = {"A": 12, "B": 20, "C": 44, "D": 22, "E": 12}
    for n in range(len(rotulos) + 1):
        larg[_letra(5 + n)] = 16
    abas.append(Aba("POR FORNECEDOR", linhas, larguras=larg))

    # ---- uma aba por filial, com o detalhe como veio ----
    # nome de aba repetido faz o Excel recusar o arquivo: quem resolve isso e
    # xlsxescreve.nomes_unicos(), chamado por escrever().
    for f in res["filiais"]:
        linhas = [[Titulo("%s — contas a pagar" % f["rotulo"])],
                  [Negrito("Arquivo"), f["arquivo"]],
                  [Negrito("Duplicatas"), f["duplicatas"],
                   Negrito("Total"), Dinheiro(f["total"])], []]
        linhas.append([Cabecalho(c) for c in (
            "Cod.", "Fornecedor", "CNPJ/CPF", "Atividade", "Plano de contas",
            "Duplicata", "Emp", "Boleto", "Cadastro", "Vencimento", "Valor")])
        for i in f["itens"]:
            linhas.append([i["fornecedor_codigo"], i["fornecedor"], i["cnpj"],
                           i["atividade"], i["plano_contas"], i["duplicata"],
                           i["empresa"], i["boleto"], i["dta_cad"],
                           i["dta_venc"], Dinheiro(i["valor"])])
        linhas.append([Negrito("TOTAL")] + [""] * 9 + [Dinheiro(f["total"])])
        abas.append(Aba(f["rotulo"], linhas,
                        larguras={"B": 42, "C": 20, "D": 22, "E": 16,
                                  "F": 16, "I": 12, "J": 12, "K": 14}))

    buf = io.BytesIO()
    xlsxescreve.escrever(buf, abas)
    return buf.getvalue()


def nome_arquivo(empresa, competencia=""):
    base = re.sub(r"[^A-Za-z0-9]+", "_", str(empresa or "empresa")).strip("_")
    per = (competencia or "").replace("/", "-")
    return "%s_CONTAS_A_PAGAR_%s.xlsx" % (base, per or "consolidado")
