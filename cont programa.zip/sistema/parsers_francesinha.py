# -*- coding: utf-8 -*-
"""
parsers_francesinha.py - Le a "Francesinha" do Banco do Brasil (relacao de
boletos, .xls exportado direto do BB) usando xls_lite (stdlib puro).

COLUNAS LOCALIZADAS PELO CABECALHO, nunca por letra fixa: o BB muda a ordem
e a quantidade de colunas conforme o filtro usado na exportacao.

A ultima linha do arquivo e' a de TOTAL (so tem os dois somatorios, sem
numero de boleto) - ela nao e' boleto e fica fora da lista de itens, mas os
totais dela sao devolvidos para conferencia contra a soma dos itens.
"""
import re

import xls_lite

# Cabecalho -> chave interna. A comparacao e' feita sem acento e sem espaco
# (o BB as vezes exporta "Valor Liquidacao", as vezes "Valor Liquidação").
COLUNAS = {
    "NOMEDOPAGADOR": "pagador",
    "SEUNUMERO": "seu_numero",
    "SITUACAO": "situacao",
    "DATASITUACAO": "data_situacao",
    "VALOR": "valor",
    "VALORLIQUIDACAO": "valor_liquidacao",
    "VENCIMENTO": "vencimento",
    "NOSSONUMERO": "nosso_numero",
}
OBRIGATORIAS = ("seu_numero", "valor", "valor_liquidacao", "data_situacao")


def _chave(texto):
    """Cabecalho -> chave de comparacao (maiusculo, sem acento, sem espaco).
    O .xls do BB vem em latin-1, entao os acentos chegam como bytes soltos -
    remover tudo que nao e' letra/numero e' mais seguro que tentar
    normalizar acento a acento."""
    s = str(texto or "").upper()
    for de, para in (("Á", "A"), ("À", "A"), ("Â", "A"), ("Ã", "A"),
                     ("É", "E"), ("Ê", "E"), ("Í", "I"), ("Ó", "O"),
                     ("Ô", "O"), ("Õ", "O"), ("Ú", "U"), ("Ç", "C")):
        s = s.replace(de, para)
    return re.sub(r"[^A-Z0-9]", "", s)


def numero_limpo(codigo):
    """'000002568D' -> '2568'. Tira tudo que nao e' digito (inclusive a
    letra final do BB) e depois os zeros a esquerda."""
    so_digitos = re.sub(r"\D", "", str(codigo or ""))
    return so_digitos.lstrip("0")


def detectar(caminho):
    """Confirma pelo CONTEUDO que e' uma francesinha do BB."""
    try:
        linhas = xls_lite.read_sheet(caminho)
    except Exception:  # noqa: BLE001
        return False
    if not linhas:
        return False
    presentes = {COLUNAS[_chave(v)] for v in linhas[0] if _chave(v) in COLUNAS}
    return all(c in presentes for c in OBRIGATORIAS)


def ler_francesinha(caminho, nome_original=""):
    """
    Devolve {"arquivo", "itens": [...], "total_valor", "total_liquidacao",
             "total_arquivo": {...} | None}.
    Cada item: {"linha", "pagador", "seu_numero", "numero", "situacao",
                "data_situacao", "valor", "valor_liquidacao", "juros"}
    """
    nome = nome_original or caminho
    linhas = xls_lite.read_sheet(caminho)
    if not linhas:
        raise ValueError("planilha vazia.")

    col = {}
    for j, valor in enumerate(linhas[0]):
        chave = COLUNAS.get(_chave(valor))
        if chave and chave not in col:
            col[chave] = j
    faltando = [c for c in OBRIGATORIAS if c not in col]
    if faltando:
        raise ValueError(
            "nao parece a francesinha do BB — nao achei a(s) coluna(s): "
            + ", ".join(faltando) + ".")

    def celula(linha, chave):
        j = col.get(chave)
        return linha[j] if j is not None and j < len(linha) else ""

    def numero(v):
        if isinstance(v, (int, float)):
            return float(v)
        s = str(v or "").strip().replace(".", "").replace(",", ".")
        try:
            return float(s)
        except ValueError:
            return 0.0

    itens = []
    total_arquivo = None
    for i, linha in enumerate(linhas[1:], start=2):
        if not any(str(v).strip() for v in linha):
            continue
        seu_numero = str(celula(linha, "seu_numero") or "").strip()
        data_sit = str(celula(linha, "data_situacao") or "").strip()
        valor = numero(celula(linha, "valor"))
        liquidacao = numero(celula(linha, "valor_liquidacao"))

        # Linha de TOTAL: so os somatorios, sem boleto identificado.
        if not seu_numero and not data_sit:
            if valor or liquidacao:
                total_arquivo = {"valor": round(valor, 2),
                                 "valor_liquidacao": round(liquidacao, 2)}
            continue

        itens.append({
            "linha": i,
            "pagador": str(celula(linha, "pagador") or "").strip(),
            "seu_numero": seu_numero,
            "numero": numero_limpo(seu_numero),
            "situacao": str(celula(linha, "situacao") or "").strip(),
            "data_situacao": data_sit,
            "valor": round(valor, 2),
            "valor_liquidacao": round(liquidacao, 2),
            "juros": round(liquidacao - valor, 2),
        })

    if not itens:
        raise ValueError("nenhum boleto encontrado na planilha.")

    return {"arquivo": nome, "itens": itens,
            "total_valor": round(sum(i["valor"] for i in itens), 2),
            "total_liquidacao": round(sum(i["valor_liquidacao"] for i in itens), 2),
            "total_arquivo": total_arquivo}
