# -*- coding: utf-8 -*-
"""
parsers_extrato_decl.py - Tira do PDF do extrato SO os numeros que o banco
declara: saldo anterior, saldo de cada dia e a linha de totais.

PARA QUE SERVE
--------------
Os lancamentos vem do OFX, que e exato (ver parsers_ofx). O que falta e uma
PROVA de que nada se perdeu no caminho - e essa prova o banco ja imprime no
proprio extrato:

    Bradesco   "Total 3.222.595,96 -3.232.939,66 638,14"
               (creditos, debitos e saldo final do periodo)
    Itau       "31 / jul SALDO ANTERIOR 411,14"
               "04 / ago SALDO TOTAL DISPON#VEL DIA 231,83"   (um por dia)
    Safra      "03/08 SALDO TOTAL 2.432,84"                   (um por dia)

Ler SO essas linhas e muito mais seguro do que reconstruir 23 mil
lancamentos a partir do texto: sao poucas linhas, com formato fixo, e um erro
de leitura aqui aparece como divergencia - nunca como numero errado passando
por certo.

DUAS ARMADILHAS REAIS
---------------------
1. O PDF do Bradesco traz DOIS extratos: o mes pedido e, embaixo, um bloco
   "Ultimos Lancamentos" com os primeiros dias do mes seguinte (com SALDO
   ANTERIOR proprio e outra linha "Total"). Pegar a ultima linha "Total"
   daria os totais de setembro para conferir agosto. Aqui so o PRIMEIRO
   bloco e lido.
2. A fonte do Itau devolve "DISPON#VEL" em vez de "DISPONIVEL" e escreve a
   data como "04 / ago" (sem ano). O ano sai da linha de periodo.
"""
import re

import pdftexto
from parsers import norm_txt, parse_numero

RE_VALOR = re.compile(r"-?\d{1,3}(?:\.\d{3})*,\d{2}")
MESES = {"JAN": "01", "FEV": "02", "MAR": "03", "ABR": "04", "MAI": "05",
         "JUN": "06", "JUL": "07", "AGO": "08", "SET": "09", "OUT": "10",
         "NOV": "11", "DEZ": "12"}

# Onde o segundo extrato comeca, no PDF do Bradesco.
CORTE_BRADESCO = ("ULTIMOS LANCAMENTOS",)


def _num(s):
    return round(parse_numero(s), 2)


def detectar_banco(linhas):
    """Nome do banco a partir do texto do PDF, ou '' quando nao reconhecer."""
    t = norm_txt(" ".join(linhas[:60]))
    if "BANCO SAFRA" in t or "EXTRATO DE MOVIMENTACAO" in t:
        return "SAFRA"
    if "EXTRATO MENSAL" in t or "BRADESCO" in t:
        return "BRADESCO"
    if "SANTANDER" in t:
        return "SANTANDER"
    if "ITAU.COM.BR" in t or "SALDO TOTAL DISPON" in t.replace("#", "I"):
        return "ITAU"
    t2 = norm_txt(" ".join(linhas))
    for nome in ("SAFRA", "BRADESCO", "SANTANDER"):
        if nome in t2:
            return nome
    if "ITAU" in t2:
        return "ITAU"
    return ""


def _periodo(linhas):
    """(ini, fim) em dd/mm/aaaa, da linha de periodo do extrato."""
    for l in linhas[:40]:
        t = norm_txt(l)
        m = re.search(r"(\d{2}/\d{2}/\d{4})\D{1,12}?(\d{2}/\d{2}/\d{4})", t)
        if m and ("PERIODO" in t or "ENTRE" in t or "EXTRATO" in t
                  or "LANCAMENTOS" in t):
            return m.group(1), m.group(2)
    for l in linhas[:40]:
        m = re.search(r"(\d{2}/\d{2}/\d{4})\D{1,12}?(\d{2}/\d{2}/\d{4})", l)
        if m:
            return m.group(1), m.group(2)
    return "", ""


def _ano_mes_padrao(periodo):
    """('08','2026') a partir do periodo, para completar datas sem ano."""
    ini = periodo[0] or periodo[1]
    m = re.match(r"^(\d{2})/(\d{2})/(\d{4})$", ini or "")
    return (m.group(2), m.group(3)) if m else ("", "")


def _data_dd_mmm(txt, ano):
    """'04 / ago' -> '04/08/aaaa'."""
    m = re.match(r"\s*(\d{1,2})\s*/\s*([A-Za-z]{3})", txt)
    if not m:
        return ""
    mes = MESES.get(norm_txt(m.group(2))[:3])
    if not mes or not ano:
        return ""
    return "%02d/%s/%s" % (int(m.group(1)), mes, ano)


def _data_dd_mm(txt, mes_padrao, ano):
    """'03/08' -> '03/08/aaaa'; 'dd/mm/aaaa' passa direto."""
    m = re.match(r"\s*(\d{2})/(\d{2})/(\d{4})", txt)
    if m:
        return m.group(0)
    m = re.match(r"\s*(\d{2})/(\d{2})(?!/)", txt)
    if m and ano:
        return "%s/%s/%s" % (m.group(1), m.group(2), ano)
    return ""


def ler_declarado(caminho, nome_original=""):
    """
    Devolve o que o PDF DECLARA:

        {"arquivo","banco","periodo","saldo_anterior","saldos_dia":[...],
         "totais":{"creditos","debitos","saldo_final"}|None,"avisos":[...]}

    Nao devolve lancamento nenhum - de proposito. Quem lanca e o OFX.
    """
    nome = nome_original or caminho.replace("\\", "/").rsplit("/", 1)[-1]
    linhas = pdftexto.linhas_do_pdf(caminho)
    banco = detectar_banco(linhas)
    per = _periodo(linhas)
    mes_p, ano = _ano_mes_padrao(per)
    out = {"arquivo": nome, "banco": banco, "periodo": per,
           "saldo_anterior": None, "saldos_dia": [], "totais": None,
           "avisos": []}

    # ---- corta o segundo extrato do Bradesco ----
    fim = len(linhas)
    if banco == "BRADESCO":
        for i, l in enumerate(linhas):
            if any(c in norm_txt(l) for c in CORTE_BRADESCO):
                fim = i
                break
    corpo = linhas[:fim]

    for l in corpo:
        t = norm_txt(l).replace("#", "I")

        if out["saldo_anterior"] is None and "SALDO ANTERIOR" in t:
            v = RE_VALOR.findall(l)
            if v:
                out["saldo_anterior"] = _num(v[-1])
            continue

        # saldo do dia (Itau e Safra)
        if "SALDO TOTAL DISPONIVEL DIA" in t or re.search(r"\bSALDO TOTAL\b", t):
            v = RE_VALOR.findall(l)
            if not v:
                continue
            data = _data_dd_mmm(l, ano) or _data_dd_mm(l, mes_p, ano)
            if data:
                out["saldos_dia"].append({"data": data, "saldo": _num(v[-1])})
            continue

        # linha de totais (Bradesco): creditos, debitos, saldo
        if out["totais"] is None and re.match(r"^\s*Total\b", l):
            v = RE_VALOR.findall(l)
            if len(v) >= 3:
                out["totais"] = {"creditos": _num(v[0]), "debitos": _num(v[1]),
                                 "saldo_final": _num(v[2])}

    if not out["saldos_dia"] and out["totais"] is None:
        out["avisos"].append(
            "'%s': este PDF nao imprime saldo por dia nem linha de totais, "
            "entao nao da para conferir a leitura contra ele." % nome)
    return out


def conferir(extrato, declarado):
    """
    Confronta um extrato (do OFX) com o que o PDF declara.

    Devolve {"fecha","itens":[...],"divergencias":[...]}, onde cada item e uma
    comparacao nomeada - para a tela poder mostrar O QUE foi conferido, nao
    so um "ok".
    """
    itens, difs = [], []

    def cmp(rotulo, calculado, declarado_v):
        if declarado_v is None:
            return
        d = round((calculado or 0.0) - declarado_v, 2)
        it = {"rotulo": rotulo, "calculado": round(calculado or 0.0, 2),
              "declarado": declarado_v, "diferenca": d, "fecha": abs(d) <= 0.01}
        itens.append(it)
        if not it["fecha"]:
            difs.append(it)

    tot = declarado.get("totais")
    if tot:
        cmp("Creditos do periodo", extrato.get("entradas"), tot["creditos"])
        cmp("Debitos do periodo", extrato.get("saidas"), tot["debitos"])
        ant = declarado.get("saldo_anterior")
        if ant is not None:
            cmp("Saldo final", round(ant + (extrato.get("total") or 0.0), 2),
                tot["saldo_final"])

    # cadeia diaria: saldo do dia anterior + movimento do dia = saldo do dia
    sd = [s for s in declarado.get("saldos_dia") or [] if s.get("data")]
    if sd:
        from parsers_ofx import chave_data
        sd = sorted(sd, key=lambda s: chave_data(s["data"]))
        por_dia = {}
        for l in extrato.get("lancamentos") or []:
            k = chave_data(l["data"])
            if k:
                por_dia[k] = round(por_dia.get(k, 0.0) + l["valor"], 2)
        ant = declarado.get("saldo_anterior")
        if ant is None:
            # sem saldo anterior impresso, a cadeia comeca no 1o dia declarado
            ant = round(sd[0]["saldo"] - por_dia.get(
                chave_data(sd[0]["data"]), 0.0), 2)
        anterior = ant
        for s in sd:
            mov = por_dia.get(chave_data(s["data"]), 0.0)
            cmp("Saldo de " + s["data"], round(anterior + mov, 2), s["saldo"])
            anterior = s["saldo"]

    return {"fecha": not difs, "itens": itens, "divergencias": difs,
            "conferido": len(itens)}
