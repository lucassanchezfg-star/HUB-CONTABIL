# -*- coding: utf-8 -*-
"""
pdftexto.py - Extracao de texto de PDF usando SOMENTE a biblioteca padrao.

Motivo: o proxy corporativo bloqueia 'pip install', entao nao ha pypdf.
Ver README (secao "Por que nao usa Flask/openpyxl").

O que faz:
  1. Varre o arquivo e descomprime os streams FlateDecode (zlib).
  2. Identifica os "content streams" (os que tem operadores de texto).
  3. Interpreta os operadores de texto (BT/ET, Tm, Td, TD, T*, Tj, TJ, ', ")
     guardando a posicao (x, y) de cada pedaco de texto.
  4. Agrupa os pedacos por linha (mesmo y) e ordena por x -> devolve linhas.

Codificacao das fontes:
  - Extrato Santander: strings literais legiveis -> decodifica direto.
  - Extrato Itau / Plano de Contas: fonte CID, strings em hex (<0088...>) ->
    precisa do ToUnicode CMap embutido no PDF.

    ARMADILHA: um PDF pode ter VARIAS fontes CID (ex.: "Tahoma" normal e
    "Tahoma,Bold" para os titulos), CADA UMA com seu proprio ToUnicode CMap.
    Os codigos de fontes diferentes NAO SAO COMPARAVEIS entre si (o codigo
    0x0088 pode ser 'A' numa fonte e outro caractere completamente diferente
    na outra). Se todos os CMaps forem mesclados num unico mapa, os codigos
    que colidem saem trocados -> texto sai "embaralhado" de forma consistente
    (nao aleatoria), sintoma facil de confundir com "fonte nao suportada".
    A solucao correta e rastrear qual fonte esta ATIVA (operador 'Tf') e usar
    o CMap daquela fonte especifica para decodificar cada string.
"""
import re
import zlib

# --------------------------------------------------------------------------
# 1) Streams
# --------------------------------------------------------------------------
def _streams_com_offset(raw):
    """
    Devolve [(offset_no_arquivo, bytes_do_stream), ...] para todo stream do
    PDF, descomprimindo quando sao FlateDecode. O offset serve pra casar cada
    content stream com o /Font mais proximo (ver _cmaps_por_recurso).

    NEM TODO PDF comprime o content stream. Alguns geradores (ex.: o export de
    "Alteracao da Estrutura do Plano de Contas", PDF 1.3) gravam o texto SEM
    filtro nenhum -> tentar so zlib.decompress descartaria esses streams
    silenciosamente (ficariam vazios). Por isso, quando a descompressao falha,
    devolve os bytes CRUS: se for texto legivel, o filtro por 'Tj'/'TJ' em
    linhas_do_pdf() ainda vai reconhecer como content stream; se for binario
    (imagem/fonte), o tokenizador nao vai extrair nada coerente dali.
    """
    out = []
    for m in re.finditer(rb"stream\r?\n", raw):
        ini = m.end()
        fim = raw.find(b"endstream", ini)
        if fim == -1:
            continue
        dados = raw[ini:fim].rstrip(b"\r\n")
        try:
            out.append((m.start(), zlib.decompress(dados)))
            continue
        except zlib.error:
            pass
        try:  # stream truncado/com lixo no fim: aproveita o que der
            parcial = zlib.decompressobj().decompress(dados)
        except zlib.error:
            parcial = b""
        out.append((m.start(), parcial or dados))
    return out


def _streams(raw):
    """So os bytes (sem offset) - usado onde a posicao no arquivo nao importa."""
    return [s for _off, s in _streams_com_offset(raw)]


def _expandir_objstm(raw):
    """
    Traz para a superficie os objetos guardados dentro de OBJECT STREAMS
    (/Type /ObjStm) - devolve `raw` com esses objetos anexados no fim, no
    formato normal "N 0 obj ... endobj".

    POR QUE ISSO IMPORTA: do PDF 1.5 em diante o gerador pode COMPRIMIR os
    objetos que nao sao stream (arvore de paginas, dicionarios de /Font, os
    ponteiros de /ToUnicode) dentro de um ObjStm. Quem procura "/Type /Page"
    ou "/Font" nos bytes crus do arquivo simplesmente NAO ACHA NADA - foi o
    que aconteceu com o extrato do Banco do Brasil: nenhuma pagina resolvia,
    a resolucao de fonte por recurso caia fora e o texto passava a ser
    decodificado pelo CMap "que parecesse melhor". Resultado: cada string
    saia com a fonte errada e LETRAS SUMIAM sem erro nenhum - inclusive o
    "C" que marca os creditos no extrato.

    Os content streams nao precisam disso (a especificacao proibe stream
    dentro de ObjStm), entao so os dicionarios voltam a ficar visiveis - que
    e exatamente o que falta para casar cada Tf com o seu ToUnicode.
    """
    if b"/ObjStm" not in raw:
        return raw
    extras = []
    for m in re.finditer(rb"/Type\s*/ObjStm", raw):
        # o dicionario do objeto vai do "<<" anterior ate o "stream"
        ini_dic = raw.rfind(b"<<", 0, m.start())
        ini_stream = raw.find(b"stream", m.end())
        if ini_dic == -1 or ini_stream == -1:
            continue
        dic = raw[ini_dic:ini_stream]
        m_n = re.search(rb"/N\s+(\d+)", dic)
        m_first = re.search(rb"/First\s+(\d+)", dic)
        if not (m_n and m_first):
            continue
        corpo = re.match(rb"stream\r?\n", raw[ini_stream:])
        if not corpo:
            continue
        pos = ini_stream + corpo.end()
        fim = raw.find(b"endstream", pos)
        if fim == -1:
            continue
        try:
            dados = zlib.decompress(raw[pos:fim].rstrip(b"\r\n"))
        except zlib.error:
            continue

        n, first = int(m_n.group(1)), int(m_first.group(1))
        cabecalho = dados[:first].split()
        if len(cabecalho) < 2 * n:
            continue
        pares = [(int(cabecalho[2 * i]), int(cabecalho[2 * i + 1]))
                 for i in range(n)]
        for i, (num, rel) in enumerate(pares):
            ini = first + rel
            fim_obj = first + pares[i + 1][1] if i + 1 < len(pares) else len(dados)
            corpo_obj = dados[ini:fim_obj].strip()
            if corpo_obj:
                extras.append(b"\n%d 0 obj\n%s\nendobj\n" % (num, corpo_obj))
    return raw + b"".join(extras) if extras else raw


# --------------------------------------------------------------------------
# 1b) Resolucao de fonte por posicao no arquivo (Tf -> /Font -> ToUnicode)
# --------------------------------------------------------------------------
def _blocos_font(raw):
    """
    [(offset, {nome_do_recurso: numero_do_objeto_da_fonte}), ...] em ordem de
    aparicao no arquivo.

    ARMADILHA: o MESMO nome de recurso (ex.: '/F0') pode apontar para objetos
    DIFERENTES em paginas diferentes do mesmo PDF (visto num extrato onde a
    pagina 1 usa '/F0' = objeto 33, e outra pagina usa '/F0' = objeto 37 -
    fontes completamente diferentes). Por isso NAO se pode montar um mapa
    global nome->objeto: cada content stream tem que usar o bloco /Font MAIS
    PROXIMO dele no arquivo (ver _cmaps_por_recurso), nunca um mapa unico.
    """
    blocos = []
    for m in re.finditer(rb"/Font\s*<<(.*?)>>", raw, re.S):
        pares = {}
        for nome, obj in re.findall(rb"/([A-Za-z0-9_+-]+)\s+(\d+)\s+0\s+R", m.group(1)):
            pares[nome.decode("latin-1")] = int(obj)
        if pares:
            blocos.append((m.start(), pares))
    return blocos


def _achar_objeto(raw, num):
    """
    Match do 'N 0 obj' do objeto N, pegando a ULTIMA ocorrencia no arquivo.

    Um PDF pode ser gravado em REVISOES: o arquivo mantem a versao antiga do
    objeto e acrescenta a nova no fim. Vale sempre a ultima.
    """
    ultimo = None
    for m in re.finditer(rb"(?<![0-9])%d\s+0\s+obj\b" % num, raw):
        ultimo = m
    return ultimo


def _dict_do_objeto(raw, num):
    """Texto do dicionario 'N 0 obj << ... >>' (antes de 'stream' ou 'endobj')."""
    m = _achar_objeto(raw, num)
    if not m:
        return b""
    fim_obj = raw.find(b"endobj", m.end())
    fim_stream = raw.find(b"stream", m.end())
    fim = fim_obj if fim_obj != -1 else len(raw)
    if fim_stream != -1 and fim_stream < fim:
        fim = fim_stream
    return raw[m.end():fim]


def _stream_do_objeto(raw, num):
    """Bytes do stream do objeto N (descomprime FlateDecode; crus se nao comprimido)."""
    par = _stream_com_offset_do_objeto(raw, num)
    return par[1] if par else None


def _stream_com_offset_do_objeto(raw, num):
    """(offset_no_arquivo, bytes) do stream do objeto N, ou None."""
    m = _achar_objeto(raw, num)
    if not m:
        return None
    ini_stream = raw.find(b"stream", m.end())
    fim_obj = raw.find(b"endobj", m.end())
    if ini_stream == -1 or (fim_obj != -1 and ini_stream > fim_obj):
        return None
    ini = ini_stream + len(b"stream")
    if raw[ini:ini + 2] == b"\r\n":
        ini += 2
    elif raw[ini:ini + 1] in (b"\n", b"\r"):
        ini += 1
    fim = raw.find(b"endstream", ini)
    if fim == -1:
        return None
    dados = raw[ini:fim].rstrip(b"\r\n")
    try:
        return (ini_stream, zlib.decompress(dados))
    except zlib.error:
        pass
    try:
        parcial = zlib.decompressobj().decompress(dados)
    except zlib.error:
        parcial = b""
    return (ini_stream, parcial or dados)


def _cmap_da_fonte(raw, num_objeto_fonte, cache):
    """CMap ToUnicode da fonte (objeto N), com cache entre chamadas."""
    if num_objeto_fonte in cache:
        return cache[num_objeto_fonte]
    dic = _dict_do_objeto(raw, num_objeto_fonte)
    m = re.search(rb"/ToUnicode\s+(\d+)\s+0\s+R", dic)
    cmap = {}
    if m:
        s = _stream_do_objeto(raw, int(m.group(1)))
        if s:
            cmap = _cmap_de_stream(s)
    cache[num_objeto_fonte] = cmap
    return cmap


def _cmaps_por_recurso(raw, offset_stream, blocos_font, cache):
    """
    {nome_do_recurso: cmap} do bloco /Font mais proximo e ANTERIOR ao content
    stream em offset_stream (geradores tipicamente escrevem os recursos da
    pagina antes do content stream que os usa). Vazio se nao achar nenhum
    bloco antes (nesse caso, quem chama cai no CMap de fallback por 'achou').
    """
    escolhido = None
    for offset, pares in blocos_font:
        if offset <= offset_stream:
            escolhido = pares
        else:
            break
    if not escolhido:
        return {}
    return {nome: _cmap_da_fonte(raw, obj, cache) for nome, obj in escolhido.items()}


# --------------------------------------------------------------------------
# 1c) Arvore de paginas: quais streams sao REALMENTE o conteudo do documento
# --------------------------------------------------------------------------
def _fontes_do_blob(blob):
    """{nome_do_recurso: numero_do_objeto} a partir de um '/Font << ... >>'."""
    m = re.search(rb"/Font\s*<<(.*?)>>", blob, re.S)
    if not m:
        return {}
    return {n.decode("latin-1"): int(o) for n, o in
            re.findall(rb"/([A-Za-z0-9_+-]+)\s+(\d+)\s+0\s+R", m.group(1))}


def _refs(blob):
    """Numeros dos objetos referenciados ('4 0 R' / '[10 0 R 15 0 R]')."""
    return [int(n) for n in re.findall(rb"(\d+)\s+0\s+R", blob)]


def _paginas_do_documento(raw):
    """
    [(numeros_dos_content_streams, {recurso: objeto_da_fonte}), ...] na ordem
    das paginas, seguindo /Root -> /Pages -> /Kids. Lista vazia se a arvore
    nao resolver (ai quem chama varre todos os streams, como antes).

    POR QUE seguir a arvore em vez de varrer o arquivo: um PDF pode guardar
    MAIS DE UMA REVISAO (o arquivo mantem os objetos da versao anterior e o
    trailer novo aponta so para os novos). Varrer todo 'stream' le as DUAS
    revisoes e DUPLICA o documento inteiro - visto num extrato Bradesco, onde
    cada lancamento aparecia 2x; qualquer soma feita em cima desse texto sairia
    DOBRADA, e em silencio. Seguir a arvore da ultima revisao le cada pagina
    exatamente uma vez. Bonus: a pagina traz o proprio /Resources /Font, que e
    a resposta exata para "qual fonte e este /F1" (melhor que o palpite por
    proximidade de offset em _cmaps_por_recurso).
    """
    raizes = list(re.finditer(rb"/Root\s+(\d+)\s+0\s+R", raw))
    if not raizes:
        return []
    catalogo = _dict_do_objeto(raw, int(raizes[-1].group(1)))
    m = re.search(rb"/Pages\s+(\d+)\s+0\s+R", catalogo)
    if not m:
        return []

    paginas = []
    vistos = set()

    def visitar(num, fontes_herdadas):
        if num in vistos or len(vistos) > 5000:  # trava anti-ciclo
            return
        vistos.add(num)
        dic = _dict_do_objeto(raw, num)
        fontes = _fontes_do_blob(dic) or fontes_herdadas
        if not fontes:
            # /Resources pode ser uma referencia em vez de dicionario inline
            r = re.search(rb"/Resources\s+(\d+)\s+0\s+R", dic)
            if r:
                fontes = _fontes_do_blob(_dict_do_objeto(raw, int(r.group(1))))
        kids = re.search(rb"/Kids\s*\[(.*?)\]", dic, re.S)
        if kids:
            for filho in _refs(kids.group(1)):
                visitar(filho, fontes)
            return
        conteudo = re.search(rb"/Contents\s*(\[.*?\]|\d+\s+0\s+R)", dic, re.S)
        if conteudo:
            nums = _refs(conteudo.group(1))
            extra, fontes_xo = _form_xobjects(raw, dic, num)
            paginas.append((nums + extra, {**fontes_xo, **(fontes or {})}))

    visitar(int(m.group(1)), {})
    return paginas


def _form_xobjects(raw, dic_pagina, num_pagina, _profund=0):
    """
    Numeros dos FORM XOBJECTS desenhados pela pagina, e as fontes deles.

    Alguns geradores nao colocam o texto no /Contents da pagina: o content so
    faz "/Fm0 Do" e o texto de verdade mora num XObject de formulario. Sem
    seguir esses objetos a pagina parece VAZIA - foi o que aconteceu com os
    extratos Santander de janeiro e fevereiro/2026 da FRAGA, que devolviam
    ZERO linha enquanto os outros meses liam normal. Dois meses inteiros
    sumiriam da contabilizacao sem nenhuma mensagem de erro.

    Devolve ([numeros_de_objeto], {recurso_de_fonte: numero_do_objeto}).
    """
    if _profund > 3:                      # XObject pode aninhar; trava simples
        return [], {}
    blob = dic_pagina
    r = re.search(rb"/Resources\s+(\d+)\s+0\s+R", blob)
    if r:
        blob = _dict_do_objeto(raw, int(r.group(1)))
    m = re.search(rb"/XObject\s*<<(.*?)>>", blob, re.S)
    if not m:
        return [], {}

    nums, fontes = [], {}
    for _nome, obj in re.findall(rb"/([A-Za-z0-9_+-]+)\s+(\d+)\s+0\s+R", m.group(1)):
        n = int(obj)
        if n == num_pagina:
            continue
        d = _dict_do_objeto(raw, n)
        if b"/Subtype" in d and b"/Form" not in d:
            continue                      # imagem: nao tem texto
        nums.append(n)
        fontes.update(_fontes_do_blob(d))
        rr = re.search(rb"/Resources\s+(\d+)\s+0\s+R", d)
        if rr:
            fontes.update(_fontes_do_blob(_dict_do_objeto(raw, int(rr.group(1)))))
        filhos, f2 = _form_xobjects(raw, d, n, _profund + 1)
        nums.extend(filhos)
        fontes.update(f2)
    return nums, fontes


# --------------------------------------------------------------------------
# 2) ToUnicode CMap (varios por documento, NUNCA mesclados num so dict)
# --------------------------------------------------------------------------
def _cmaps_do_documento(sts):
    """
    Devolve a lista dos CMaps ToUnicode distintos encontrados no documento
    (um por fonte). NAO mescla: cada fonte fica no seu proprio dict, porque
    o mesmo codigo numerico significa caracteres DIFERENTES em fontes
    diferentes (ver nota no topo do arquivo). Qual cmap usar em cada string e
    decidido em '_texto_de_bytes', testando todos e ficando com o que decodifica
    mais codigos (evita depender de resolver /Font e /Tf, que variam demais
    de estrutura entre os geradores de PDF).
    """
    cmaps = []
    vistos = set()
    for s in sts:
        if b"beginbfchar" not in s and b"beginbfrange" not in s:
            continue
        m = _cmap_de_stream(s)
        if not m:
            continue
        chave = frozenset(m.items())
        if chave in vistos:
            continue
        vistos.add(chave)
        cmaps.append(m)
    return cmaps


def _cmap_de_stream(s):
    """Le um stream ToUnicode e devolve {codigo_int: texto}."""
    mapa = {}
    txt = s.decode("latin-1", "replace")

    # beginbfchar: <src> <dst>
    for bloco in re.findall(r"beginbfchar(.*?)endbfchar", txt, re.S):
        for src, dst in re.findall(r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", bloco):
            mapa[int(src, 16)] = _hex_para_texto(dst)

    # beginbfrange: <ini> <fim> <dst>  |  <ini> <fim> [<d1> <d2> ...]
    for bloco in re.findall(r"beginbfrange(.*?)endbfrange", txt, re.S):
        for ini, fim, dst in re.findall(
                r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", bloco):
            a, b = int(ini, 16), int(fim, 16)
            base = int(dst, 16)
            for i in range(a, min(b, a + 65535) + 1):
                mapa[i] = chr(base + (i - a))
        for ini, _fim, lista in re.findall(
                r"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*\[(.*?)\]", bloco, re.S):
            a = int(ini, 16)
            for k, dst in enumerate(re.findall(r"<([0-9A-Fa-f]+)>", lista)):
                mapa[a + k] = _hex_para_texto(dst)
    return mapa


def _hex_para_texto(h):
    """'0041' -> 'A' ; UTF-16BE (pode ter mais de um code unit)."""
    if len(h) % 2:
        h = "0" + h
    b = bytes.fromhex(h)
    if len(b) >= 2:
        try:
            return b.decode("utf-16-be")
        except UnicodeDecodeError:
            pass
    return b.decode("latin-1", "replace")


# --------------------------------------------------------------------------
# 3) Tokenizacao e interpretacao do content stream
# --------------------------------------------------------------------------
_TOKEN = re.compile(rb"""
      (?P<str>\((?:\\.|[^\\()])*\))      # string literal ( ... )
    | (?P<hex><[0-9A-Fa-f\s]*>)          # string hex     < ... >
    | (?P<arr>\[)                        # inicio de array
    | (?P<arrf>\])                       # fim de array
    | (?P<name>/[^\s/\[\]<>()]+)         # nome /Xyz
    | (?P<num>[-+]?[0-9]*\.?[0-9]+)      # numero
    | (?P<op>[A-Za-z'"*][A-Za-z0-9*'"]*) # operador
""", re.X | re.S)

_ESCAPES = {b"n": b"\n", b"r": b"\r", b"t": b"\t", b"b": b"\b",
            b"f": b"\f", b"(": b"(", b")": b")", b"\\": b"\\"}


def _decod_literal(tok):
    """Converte b'(...)' em bytes, resolvendo escapes do PDF."""
    corpo = tok[1:-1]
    out = bytearray()
    i = 0
    while i < len(corpo):
        c = corpo[i:i + 1]
        if c == b"\\" and i + 1 < len(corpo):
            nxt = corpo[i + 1:i + 2]
            if nxt in _ESCAPES:
                out += _ESCAPES[nxt]
                i += 2
                continue
            if nxt in b"01234567":  # octal \ddd - SO digitos octais (0-7)
                # \8 e \9 NAO sao escape valido (a especificacao do PDF diz
                # que backslash seguido de algo fora da lista de escapes e'
                # ignorado, sobrando so o caractere) - aceitar qualquer
                # ASCII "digit" aqui already gerava \8/\9 como base octal
                # invalida (ValueError), travando a leitura do PDF inteiro.
                j = i + 1
                oct_ = b""
                while j < len(corpo) and len(oct_) < 3 and corpo[j:j + 1] in b"01234567":
                    oct_ += corpo[j:j + 1]
                    j += 1
                out.append(int(oct_, 8) & 0xFF)
                i = j
                continue
            if nxt in (b"\n", b"\r"):  # continuacao de linha
                i += 2
                continue
            out += nxt
            i += 2
            continue
        out += c
        i += 1
    return bytes(out)


def _texto_de_bytes(b, cmaps, preferido=None):
    """
    Decodifica bytes de uma string PDF em texto.
    Devolve (texto, indice_do_cmap_usado_ou_None).

    'cmaps' e uma LISTA de CMaps distintos (um por fonte do documento). Testa
    CADA um (2 bytes por caractere, jeito CID) e fica com o que acerta mais
    codigos. Isso decide qual fonte "e a certa" para esta string SEM precisar
    resolver o dict /Font do PDF - estrutura que varia bastante entre geradores
    (e algumas nem expoem o recurso de forma que se ache por regex simples).

    ARMADILHA: quando o documento tem VARIOS cmaps pequenos (visto num extrato
    com 7 fontes, cada uma com so 3 a 56 entradas) E o texto e desenhado
    CARACTERE POR CARACTERE (cada Tj decodifica so 1 char), o "acha mais
    codigos" empata direto — uma string de 1 caractere so pode pontuar 0 ou 1
    em qualquer cmap que tenha aquele codigo, e varios cmaps costumam ter o
    MESMO codigo mapeado para coisas diferentes. Sem desempate, o resultado sai
    "aleatorio" (na pratica, sempre o primeiro cmap da lista) e o texto vira
    uma mistura de letras erradas. O desempate certo: caracteres VIZINHOS quase
    sempre pertencem ao MESMO campo/fonte, entao em caso de empate preferimos
    o cmap que decodificou a ULTIMA string ('preferido') — isso "cola" a fonte
    ao longo de um campo inteiro (data, valor, nome) mesmo desenhado aos
    pedacinhos. Sem preferencia (inicio do documento), fica com o cmap de MAIS
    entradas entre os empatados (mais generico, mais provavel de ser o corpo).
    """
    candidatos = []  # (score, indice, texto)
    if len(b) >= 2 and len(b) % 2 == 0:
        for idx, cmap in enumerate(cmaps):
            if not cmap:
                continue
            chars, achou = [], 0
            for i in range(0, len(b), 2):
                cod = (b[i] << 8) | b[i + 1]
                if cod in cmap:
                    chars.append(cmap[cod])
                    achou += 1
                else:
                    chars.append("")
            if achou > 0:
                candidatos.append((achou, idx, "".join(chars)))
    if candidatos:
        melhor = max(c[0] for c in candidatos)
        empatados = [c for c in candidatos if c[0] == melhor]
        if len(empatados) == 1:
            _, idx, txt = empatados[0]
            return txt, idx
        for _score, idx, txt in empatados:
            if idx == preferido:
                return txt, idx
        _, idx, txt = max(empatados, key=lambda c: len(cmaps[c[1]]))
        return txt, idx
    # 1 byte por caractere (fonte simples com Differences, sem CID)
    for idx, cmap in enumerate(cmaps):
        if not cmap:
            continue
        chars = [cmap.get(x, "") for x in b]
        if any(chars):
            return "".join(chars), idx
    return b.decode("latin-1", "replace"), None


def _texto_com_cmap_unico(b, cmap):
    """
    Decodifica 'b' usando UM cmap especifico e conhecido (fonte ja resolvida
    via Tf + /Font, sem ambiguidade). Devolve None quando nenhum codigo bateu,
    para o chamador cair no CMap de fallback por 'achou' (ver _texto_de_bytes).
    """
    if not cmap:
        return None
    if len(b) >= 2 and len(b) % 2 == 0:
        chars = [cmap.get((b[i] << 8) | b[i + 1], "") for i in range(0, len(b), 2)]
        if any(chars):
            return "".join(chars)
    chars = [cmap.get(x, "") for x in b]
    return "".join(chars) if any(chars) else None


def _itens_do_content(stream, cmaps_fallback, cmaps_por_recurso=None):
    """
    Interpreta o content stream e devolve [(y, x, texto), ...].
    Rastreia a posicao pelo Tm/Td/TD/T* e a FONTE ATIVA pelo operador 'Tf'.

    Prioridade de decodificacao de cada string:
      1. Se a fonte ativa (nome do operador Tf) foi RESOLVIDA em
         'cmaps_por_recurso' (bloco /Font mais proximo deste content stream —
         ver _cmaps_por_recurso), usa ESSE cmap especifico: sem ambiguidade.
      2. Senao (fonte nao resolvida, ou o PDF nao expoe /Font de forma
         encontravel — caso real visto no extrato do Itau), cai no fallback
         por 'achou mais codigos' + preferencia pela fonte anterior, testando
         'cmaps_fallback' (lista de todos os CMaps do documento).

    cmaps_fallback: lista de CMaps distintos do documento (_cmaps_do_documento).
    cmaps_por_recurso: {nome_do_recurso ('F0'...): cmap} deste content stream
                       especifico (_cmaps_por_recurso), ou None/{} se nao houver.
    """
    itens = []
    x = y = 0.0
    lx = ly = 0.0        # inicio da linha corrente
    leading = 0.0
    pilha = []           # operandos pendentes
    em_array = False
    array = []
    cmap_pref = None      # "fonte colada" do fallback: ver _texto_de_bytes
    fonte_ativa = None     # nome do recurso da fonte selecionada pelo ultimo Tf
    cmaps_por_recurso = cmaps_por_recurso or {}

    def decodificar(b):
        nonlocal cmap_pref
        cmap_exato = cmaps_por_recurso.get(fonte_ativa)
        if cmap_exato:
            txt = _texto_com_cmap_unico(b, cmap_exato)
            if txt is not None:
                return txt
        txt, cmap_pref = _texto_de_bytes(b, cmaps_fallback, cmap_pref)
        return txt

    for m in _TOKEN.finditer(stream):
        tipo = m.lastgroup
        tok = m.group()

        if tipo == "arr":
            em_array, array = True, []
            continue
        if tipo == "arrf":
            em_array = False
            pilha.append(("array", array))
            continue
        if tipo == "str":
            val = ("str", _decod_literal(tok))
            (array if em_array else pilha).append(val)
            continue
        if tipo == "hex":
            h = re.sub(rb"\s", b"", tok[1:-1])
            if len(h) % 2:
                h += b"0"
            val = ("str", bytes.fromhex(h.decode("ascii")))
            (array if em_array else pilha).append(val)
            continue
        if tipo == "num":
            val = ("num", float(tok))
            (array if em_array else pilha).append(val)
            continue
        if tipo == "name":
            (array if em_array else pilha).append(("name", tok))
            continue
        if tipo != "op":
            continue

        op = tok.decode("latin-1")
        nums = [v for t, v in pilha if t == "num"]

        if op == "BT":
            x = y = lx = ly = 0.0
        elif op == "Tf":
            for t, v in pilha:
                if t == "name":
                    fonte_ativa = v.decode("latin-1").lstrip("/") if isinstance(v, bytes) else v
                    break
        elif op == "Tm" and len(nums) >= 6:
            lx, ly = nums[-2], nums[-1]
            x, y = lx, ly
        elif op in ("Td", "TD") and len(nums) >= 2:
            lx, ly = lx + nums[-2], ly + nums[-1]
            x, y = lx, ly
            if op == "TD":
                leading = -nums[-1]
        elif op == "TL" and nums:
            leading = nums[-1]
        elif op == "T*":
            ly -= leading
            x, y = lx, ly
        elif op in ("Tj", "'", '"'):
            if op in ("'", '"'):
                ly -= leading
                x, y = lx, ly
            for t, v in reversed(pilha):
                if t == "str":
                    txt = decodificar(v)
                    if txt.strip():
                        itens.append((y, x, txt))
                    break
        elif op == "TJ":
            for t, v in reversed(pilha):
                if t == "array":
                    partes = [decodificar(vv) for tt, vv in v if tt == "str"]
                    txt = "".join(partes)
                    if txt.strip():
                        itens.append((y, x, txt))
                    break

        pilha = []
    return itens


# --------------------------------------------------------------------------
# 4) API publica
# --------------------------------------------------------------------------
def _conteudo_das_paginas(raw):
    """
    [(offset, bytes_da_pagina, {recurso: objeto_da_fonte}), ...] — uma entrada
    por PAGINA, seguindo a arvore (ver _paginas_do_documento). Quando o
    /Contents e um ARRAY, o PDF manda tratar as partes como um unico fluxo
    (um operador pode comecar numa parte e terminar na seguinte), por isso as
    partes sao concatenadas. Lista vazia = arvore nao resolveu.
    """
    paginas = []
    for nums, fontes in _paginas_do_documento(raw):
        partes, offset = [], None
        for n in nums:
            par = _stream_com_offset_do_objeto(raw, n)
            if not par:
                continue
            if offset is None:
                offset = par[0]
            partes.append(par[1])
        if partes:
            paginas.append((offset, b"\n".join(partes), fontes))
    return paginas


def linhas_do_pdf(caminho, tolerancia_y=2.0):
    """
    Devolve as linhas de texto do PDF, na ordem em que aparecem na pagina.

    tolerancia_y: pedacos de texto com y proximo sao considerados a MESMA linha
    (extratos usam celulas com pequena variacao vertical).

    DUAS PASSADAS: geradores de PDF diferem MUITO em como desenham o texto.
    Alguns desenham a palavra inteira num Tj so (gap quase 0 entre palavras
    coladas por acaso); outros desenham CADA CARACTERE num Tj separado (visto
    num extrato com gap de ~5 a 8,5 unidades ENTRE LETRAS da mesma palavra, e
    150+ unidades entre campos). Um limiar fixo de "gap = espaco" nao serve
    para os dois ao mesmo tempo: um valor pequeno funciona pro 1o caso e
    quebra o 2o em letra-por-letra (derruba ate a deteccao de "SANTANDER");
    um valor grande resolve o 2o mas cola palavras que deviam ter espaco no
    1o. Por isso a 1a passada so extrai os itens (y,x,texto) e mede os GAPS
    reais deste documento especifico, achando o "salto" natural entre gaps
    pequenos (dentro do campo) e gaps grandes (entre campos) — a 2a passada
    junta as linhas usando esse limiar calculado.
    """
    raw = open(caminho, "rb").read()
    # Objetos comprimidos em ObjStm ficam invisiveis para as buscas por
    # "/Type /Page" e "/Font" - sem expandir, a resolucao de fonte falha e o
    # texto sai com letras faltando (ver _expandir_objstm).
    raw = _expandir_objstm(raw)
    sts_off = _streams_com_offset(raw)
    cmaps = _cmaps_do_documento([s for _off, s in sts_off])
    blocos_font = _blocos_font(raw)
    cache_fonte = {}

    conteudos = _conteudo_das_paginas(raw) or [(off, s, None) for off, s in sts_off]
    conteudos = [(off, s, fontes) for off, s, fontes in conteudos
                 if b"Tj" in s or b"TJ" in s or b"'" in s]

    itens_por_stream = []
    todos_itens = []
    for off, st, fontes in conteudos:
        if fontes:
            cmaps_rec = {n: _cmap_da_fonte(raw, o, cache_fonte)
                         for n, o in fontes.items()}
        else:
            cmaps_rec = _cmaps_por_recurso(raw, off, blocos_font, cache_fonte)
        itens = _itens_do_content(st, cmaps, cmaps_rec)
        itens_por_stream.append(itens)
        todos_itens.extend(itens)

    limiar = _limiar_espaco(todos_itens, tolerancia_y)

    linhas = []
    for itens in itens_por_stream:
        if not itens:
            continue
        # agrupar por y (do topo para baixo: y maior primeiro)
        itens.sort(key=lambda it: (-it[0], it[1]))
        atual_y = None
        buffer = []
        for yy, xx, txt in itens:
            if atual_y is None or abs(yy - atual_y) <= tolerancia_y:
                buffer.append((xx, txt))
                atual_y = yy if atual_y is None else atual_y
            else:
                linhas.append(_junta(buffer, limiar))
                buffer = [(xx, txt)]
                atual_y = yy
        if buffer:
            linhas.append(_junta(buffer, limiar))
    return [l for l in linhas if l.strip()]


def _limiar_espaco(itens, tolerancia_y, padrao=3.0):
    """
    Estima, a partir da distribuicao real dos gaps horizontais deste
    documento, o limiar que separa "mesmo campo" de "campo diferente"
    (ver nota em linhas_do_pdf). Metodo: agrupa os itens em linhas (mesmo y),
    calcula os gaps consecutivos de cada linha, e acha onde os gaps ordenados
    dao o MAIOR SALTO proporcional — esse salto e a fronteira entre "gaps
    pequenos" (dentro do campo) e "gaps grandes" (entre campos).

    SEM SALTO CLARO: mantem a constante (3) - JA TENTADO um fallback por
    percentil aqui (achava o percentil 95 dos gaps do documento), e PIOROU
    outro documento real (Balancete) em vez de ajudar. O Balancete tambem
    cai neste "sem salto claro", mas por um motivo OPOSTO ao de um extrato
    letra-por-letra: ali quase todo campo JA sai inteiro num Tj so (nao ha
    fragmentacao por caractere), entao QUALQUER gap acima de ~3 e um
    separador de campo legitimo - um percentil alto acaba pegando um gap
    ENORME de uma unica secao com fonte diferente (o cabecalho da tabela,
    que por acaso E' renderizado letra a letra) e aplicando esse limiar alto
    ao documento INTEIRO, colando campos que deveriam ficar separados
    (`"700 1.1.01.01.0002"` -> `"7001.1.01.01.0002"`, quebrando a regex que
    espera codigo e classificacao separados por espaco).

    Ou seja: um documento pode MISTURAR estilos de renderizacao (secoes
    letra-por-letra e secoes campo-inteiro-por-Tj) e nesse caso NENHUM
    numero global serve aos dois ao mesmo tempo. Resolver isso de verdade
    exigiria um limiar POR LINHA/POR FONTE, nao por documento - fora do
    escopo deste modulo. Quem le um extrato deste tipo (ver
    parsers_extrato_saldo.py) contorna lendo o TOTAL/SALDO com o texto
    SEM ESPACOS (a formatacao ",XX" do valor monetario ja delimita o numero
    sozinha, entao remover espaco nao junta numeros errados).
    """
    if not itens:
        return padrao
    itens = sorted(itens, key=lambda it: (-it[0], it[1]))
    gaps = []
    atual_y, xs = None, []
    for y, x, _t in itens:
        if atual_y is None or abs(y - atual_y) <= tolerancia_y:
            xs.append(x)
            atual_y = y if atual_y is None else atual_y
        else:
            gaps.extend(_gaps_ordenados(xs))
            xs = [x]
            atual_y = y
    gaps.extend(_gaps_ordenados(xs))

    gaps = sorted(g for g in gaps if g > 0.01)
    if len(gaps) < 20:
        return padrao
    melhor_i, melhor_razao = None, 3.0  # exige salto de pelo menos 3x
    for i in range(len(gaps) - 1):
        razao = gaps[i + 1] / gaps[i]
        if razao > melhor_razao:
            melhor_razao, melhor_i = razao, i
    if melhor_i is None:
        return _limiar_letra_a_letra(gaps, padrao)
    return (gaps[melhor_i] + gaps[melhor_i + 1]) / 2.0


def _limiar_letra_a_letra(gaps, padrao):
    """
    Ultimo recurso, so para o documento DESENHADO LETRA A LETRA com passo
    constante: a constante 'padrao' fica ABAIXO do gap entre letras e mete um
    espaco entre cada caractere ("P i x R e c e b i d o").

    Como reconhecer sem estragar os outros: nesse desenho os gaps formam um
    AGRUPAMENTO APERTADO em torno do avanco da fonte - metade deles cabe numa
    faixa estreitissima (no extrato Santander de janeiro/2026 da FRAGA:
    p25=7,87 p50=8,01 p75=8,23) e a constante 3 esta fora, abaixo. Nos
    documentos que hoje funcionam com a constante a distribuicao e LARGA
    (Itau: p50=56 p75=137; plano de contas: p50=13 p75=169), porque ali cada
    campo ja sai inteiro num Tj e todo gap e' separador de campo - esses NAO
    entram aqui.

    So dispara quando as duas coisas valem: o grosso dos gaps esta acima da
    constante E o agrupamento e' apertado. O limiar vira um pouco acima do
    p75, ficando entre o gap DE LETRA e o gap DE PALAVRA.
    """
    if len(gaps) < 40:
        return padrao
    p25 = gaps[len(gaps) // 4]
    p50 = gaps[len(gaps) // 2]
    p75 = gaps[3 * len(gaps) // 4]
    if p50 > padrao and (p75 - p25) <= 0.25 * p50:
        return p75 * 1.1
    return padrao


def _gaps_ordenados(xs):
    xs = sorted(xs)
    return [xs[i + 1] - xs[i] for i in range(len(xs) - 1)]


def _junta(buffer, limiar=3.0):
    """Ordena os pedacos de uma linha por x e junta em texto."""
    buffer.sort(key=lambda p: p[0])
    partes = []
    ultimo_fim = None
    for x, txt in buffer:
        if ultimo_fim is not None and x - ultimo_fim > limiar:
            partes.append(" ")
        partes.append(txt)
        ultimo_fim = x
    return re.sub(r"[ \t]+", " ", "".join(partes)).strip()


def texto_do_pdf(caminho):
    """Todo o texto do PDF, uma linha por '\\n'."""
    return "\n".join(linhas_do_pdf(caminho))
