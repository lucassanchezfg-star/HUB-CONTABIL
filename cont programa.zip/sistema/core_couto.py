# -*- coding: utf-8 -*-
"""
core_couto.py - As REGRAS de cada um dos quatro relatorios tratados.

Sao quatro modulos separados de proposito: cada relatorio tem a sua regra
de leitura, e so quem esta olhando um relatorio de cada vez consegue dizer
se a regra dele esta certa.

    PAGAMENTOS      Titulos Pagos     D conta do fornecedor  / C banco
    RECEBIMENTOS    Titulos Recebidos D banco ou cobranca    / C clientes
                                      (+ juros em conta propria)
    BANCO SISTEMA   conta corrente do ERP - so o que NAO veio dos titulos
    RESUMO CAIXA    caixa da loja     D banco/portador       / C a forma

O QUE UM RELATORIO LE E O QUE O OUTRO NAO LE
--------------------------------------------
Os quatro se sobrepoem: o mesmo pagamento aparece nos Titulos Pagos E no
Banco Sistema. Lancar os dois contaria a despesa duas vezes. A divisao,
aprendida do que a integracao ja gerou em 08/2026 e conferida linha a linha
contra ela (5.042 de 5.051 linhas, 99,8%):

    Banco Sistema, DEBITO : entra so o que NAO comeca com "Pag. " - o que
                            comeca ja foi lancado pelos Titulos Pagos.
                            Excecao: as contas do ERP marcadas como "so
                            banco" (a taxa de cartao, por exemplo) entram
                            mesmo assim, porque elas nao saem nos titulos.
    Banco Sistema, CREDITO: entra tudo, menos "ESTORNO BX. CT. PAGAR".
    Titulos Pagos         : nao lanca as contas marcadas "so banco".
    Resumo de Caixa       : nao lanca as linhas de especie TF, que sao a
                            transferencia do caixa para o banco - essa
                            perna ja vem pelo extrato bancario.

Os 9 casos em que a regra e a integracao discordaram sao todos estornos de
centavos; ficam anotados como aviso em vez de escondidos.
"""
import re
import unicodedata

import parsers_couto as pcu

RE_PAG = re.compile(r"^\s*Pag\.\s", re.I)
RE_ESTORNO = re.compile(r"^\s*ESTORNO\s+BX\.\s*CT\.", re.I)

# no relatorio de recebidos, o historico separa duas destinacoes diferentes
RE_AGRUPAMENTO = re.compile(r"AGRUPAMENTO", re.I)


def _chave(texto):
    t = unicodedata.normalize("NFKD", str(texto or ""))
    t = "".join(c for c in t if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", re.sub(r"[^A-Z0-9 ]", " ", t.upper())).strip()


def _so_digitos(texto):
    return re.sub(r"\D", "", str(texto or ""))


def chave_fornecedor(item):
    """
    Como um fornecedor (ou cliente) e identificado no de-para.

    Pelo CNPJ/CPF quando ele existe e e valido - o nome muda de grafia
    entre um relatorio e outro, o documento nao. Quando nao ha documento,
    pelo nome, ja sem o codigo que o ERP prefixa ("00003415-ESTORIL...").
    """
    d = _so_digitos(item.get("cnpj"))
    if len(d) in (11, 14) and set(d) != {"0"}:
        return "doc:" + d
    nome = item.get("fornecedor") or item.get("cliente") or ""
    nome = re.sub(r"^\s*\d{4,}\s*-\s*", "", str(nome))
    return "nome:" + _chave(nome)


# ==========================================================================
# As regras, com os valores de partida. Ficam no cadastro da empresa
# (cfg["couto"]) para poderem ser mudadas sem mexer no programa.
# ==========================================================================
REGRAS_PADRAO = {
    # as contas que os quatro modulos usam
    "contas": {
        "clientes": "",           # a conta de clientes (o credito dos recebidos)
        "pendencia": "",          # para onde vai o que nao tem de-para
        "transferencia": "",      # transferencia entre contas da empresa
        "juros_recebidos": "",    # os juros dos titulos recebidos
        "cobranca": "",           # boletos em agrupamento (ainda nao no banco)
        "descontos_obtidos": "",  # o desconto conseguido ao pagar um titulo
        "juros_pagos": "",        # o juro pago por pagar um titulo em atraso
    },
    # conta do ERP -> conta contabil, quando ela nao depende do fornecedor
    "erp": {},
    # contas do ERP que SO o Banco Sistema le (nao saem pelos titulos)
    "erp_so_banco": ["04.02.014"],
    # fornecedor/cliente -> conta contabil (a chave e chave_fornecedor)
    "fornecedores": {},
    # loja -> conta de caixa dela
    "caixas": {},
    # QUAIS formas do Resumo de Caixa este modulo lanca. So o dinheiro: o
    # cartao e a ordem de pagamento entram pelos relatorios deles
    "formas_lancadas": ["DINHEIRO"],
    # texto do historico do caixa -> conta contabil da contrapartida
    "caixa_historicos": {},
}


def regras_de(cfg):
    """As regras da empresa, com o que faltar preenchido pelo padrao."""
    r = {k: (dict(v) if isinstance(v, dict) else list(v))
         for k, v in REGRAS_PADRAO.items()}
    for k, v in (cfg.get("couto") or {}).items():
        if isinstance(v, dict) and isinstance(r.get(k), dict):
            r[k].update(v)
        elif v:
            r[k] = v
    return r


def _conta_banco(cfg, leitura):
    """
    A conta contabil do banco/portador do arquivo.

    Vem do cadastro de bancos da empresa: o arquivo diz o banco e a filial
    ("BANCO SISTEMA ITAU MATRIZ"), e o cadastro diz qual conta contabil e
    aquela conta corrente.
    """
    alvo_banco = pcu._chave(leitura.get("banco"))
    alvo_filial = leitura.get("filial") or ""
    achados = []
    for b in cfg.get("bancos") or []:
        if alvo_banco and pcu._chave(b.get("banco")) != alvo_banco:
            continue
        # a loja vem escrita de varios jeitos no nome da conta ("STO ANTONIO"
        # contra "SANTO ANTONIO"), entao os dois lados sao reduzidos a loja
        # que mencionam antes de comparar
        dele = (pcu.filial_no_texto(b.get("filial_nome") or b.get("apelido") or "")
                or pcu.filial_no_texto(b.get("nome")))
        if alvo_filial and dele == alvo_filial:
            return b
        achados.append(b)
    return achados[0] if len(achados) == 1 else None


# ==========================================================================
# O HISTORICO
# ==========================================================================
# O historico tem de dizer COM QUEM foi o movimento. O campo HISTORICO dos
# relatorios nem sempre diz: em "REF. AO DOCUMENTO No 000137078769NF1
# EMITIDO EM 16/07/2026" nao ha nome nenhum, e quem le o razao depois nao
# tem como saber que aquilo foi a EBAZAR.COM.BR. Por isso o historico e
# MONTADO, no mesmo desenho que a integracao ja usa:
#
#   PAGAMENTO <duplicata> <fornecedor>
#   DESCONTO REF. <duplicata> <fornecedor>
#   RECEBIMENTO <cliente> - <historico do titulo>
#   JUROS REF. <historico do titulo>
#
# O nome vai SEMPRE, e a observacao que o operador digitou entra depois -
# nunca no lugar dele.
RE_CODIGO_NOME = re.compile(r"^\s*\d{3,}\s*-\s*")


def _sem_codigo(nome):
    """'00009489-COND. ED. BIARRITZ' -> 'COND. ED. BIARRITZ'."""
    return RE_CODIGO_NOME.sub("", str(nome or "")).strip()


def _juntar(*partes):
    return " ".join(p for p in (str(x or "").strip() for x in partes) if p)


def _hist_pagamento(item, prefixo="PAGAMENTO"):
    """PAGAMENTO <duplicata> <fornecedor> - o fornecedor com o codigo dele,
    como a integracao escreve ('00000206-M FIX COMERCIAL LTDA')."""
    base = _juntar(prefixo, item.get("duplicata"), item.get("fornecedor"))
    # sem fornecedor nenhum nao da para montar nada: vale o que o relatorio
    # trouxer, mesmo que seja so a observacao
    return base if item.get("fornecedor") else (item.get("historico") or base)


def _hist_recebimento(item):
    """RECEBIMENTO <cliente> - <historico do titulo>."""
    cliente = _sem_codigo(item.get("cliente"))
    hist = (item.get("historico") or "").strip()
    if cliente and hist:
        return "RECEBIMENTO %s - %s" % (cliente, hist)
    return _juntar("RECEBIMENTO", cliente) or hist


def _hist_caixa(item):
    """
    No caixa o nome esta dentro do proprio historico ('00099337-MENACKER
    ENGENHARIA'), e o documento diz de que venda foi.
    """
    hist = (item.get("historico") or "").strip()
    doc = (item.get("documento") or "").strip()
    # "-LC", "-TF" e so a especie, sem numero de documento nenhum: nao vale
    # como complemento e ficaria pendurado no fim do historico
    if not re.search(r"\d", doc.split("-")[0]):
        doc = ""
    if RE_CODIGO_NOME.match(hist):          # e um cliente
        return _juntar("RECEBIMENTO", _sem_codigo(hist), "-" if doc else "", doc)
    if item.get("transferencia") or hist.upper().startswith(("REF. TRANSF", "TF ")):
        return hist                          # a transferencia ja se explica
    return _juntar(hist, doc)


def _hist_banco_sistema(item):
    """
    O extrato do ERP nao tem nome de contraparte em lugar nenhum - o que
    identifica o movimento e a conta do plano dele. Entao vao os dois: a
    observacao de quem lancou e o plano ('RECEBIMENTO CLIENTE 0201001 -
    RECEBIMENTO CLIENTES').
    """
    return _juntar(item.get("historico"), item.get("plano_nome"))


def _filial_da_loja(cfg, loja):
    """
    O codigo da filial de uma loja, para a coluna de filial da importacao.

    O Resumo de Caixa nao tem banco nenhum - e o caixa da loja -, entao o
    codigo vem do cadastro de bancos: a conta corrente daquela mesma loja ja
    carrega o codigo dela. Quando duas contas da loja discordarem, nao se
    escolhe uma: fica vazio, e a coluna de filial vem em branco em vez de
    vir errada.
    """
    codigos = {str(b.get("filial") or "").strip()
               for b in cfg.get("bancos") or []
               if pcu.filial_no_texto(b.get("nome")) == loja
               and str(b.get("filial") or "").strip()}
    return codigos.pop() if len(codigos) == 1 else ""


def _novo(data, debito, credito, valor, historico, filial="", origem="", **ex):
    l = {"data": data, "debito": str(debito or ""), "credito": str(credito or ""),
         "valor": round(float(valor), 2), "historico": historico,
         "filial": str(filial or ""), "origem": origem}
    l.update(ex)
    return l


def _prova(conf, rotulo, calculado, declarado):
    d = round((calculado or 0.0) - (declarado or 0.0), 2)
    conf.append({"rotulo": rotulo, "calculado": round(calculado or 0.0, 2),
                 "declarado": round(declarado or 0.0, 2), "diferenca": d,
                 "fecha": abs(d) <= 0.01})


# ==========================================================================
# 1) PAGAMENTOS - Titulos Pagos
# ==========================================================================
def apurar_pagamentos(leitura, cfg, regras=None):
    """
    Um lancamento por titulo pago: D a conta do fornecedor, C o banco.

    A conta do fornecedor sai, nesta ordem, do de-para do fornecedor (por
    CNPJ), do de-para da conta do ERP, e por ultimo da conta de pendencia.
    A ordem importa: dois fornecedores da mesma conta do ERP podem ter
    contas contabeis diferentes, entao o de-para do fornecedor tem de
    ganhar do da conta do ERP, nunca o contrario.
    """
    r = regras or regras_de(cfg)
    avisos = list(leitura.get("avisos") or [])
    banco = _conta_banco(cfg, leitura)
    c_banco = str((banco or {}).get("conta_contabil") or "")
    filial = str((banco or {}).get("filial") or "")
    if not c_banco:
        avisos.append(
            "Nao achei no cadastro a conta contabil do banco deste arquivo "
            "(%s %s) - sem ela os lancamentos ficam sem contrapartida."
            % (leitura.get("banco") or "?", leitura.get("filial") or "?"))
    pend = str(r["contas"].get("pendencia") or "")
    c_desc = str(r["contas"].get("descontos_obtidos") or "")
    c_juros = str(r["contas"].get("juros_pagos") or "")
    so_banco = set(r.get("erp_so_banco") or [])

    lancamentos, linhas, sem_conta, sem_conta_dif = [], [], [], []
    for i in leitura["itens"]:
        # o que so o Banco Sistema le nao sai por aqui
        if i.get("conta_erp") in so_banco:
            linhas.append(dict(i, entra=False, motivo="so pelo Banco Sistema",
                               conta=""))
            continue
        chave = chave_fornecedor(i)
        conta = (r["fornecedores"].get(chave)
                 or r["erp"].get(i.get("conta_erp") or "")
                 or "")
        de_onde = ("fornecedor" if r["fornecedores"].get(chave)
                   else "conta do ERP" if conta else "pendencia")
        if not conta:
            conta = pend
            sem_conta.append(i)
        linhas.append(dict(i, entra=True, motivo="", conta=conta,
                           chave=chave, de_onde=de_onde))
        extra = dict(chave=chave, conta_erp=i.get("conta_erp"),
                     fornecedor=i.get("fornecedor"), de_onde=de_onde,
                     linha=i["linha"])
        # VAL.PAG = VAL.ORI + VAL.DIF. Quando houve desconto ou juros, a
        # partida tem TRES pernas: o fornecedor baixa pelo valor ORIGINAL,
        # o banco paga o VALOR PAGO e a diferenca vai para a conta de
        # desconto ou de juros. Sem isso, o desconto obtido nunca aparece
        # no resultado - ele some dentro da conta do fornecedor.
        dif = round(i.get("diferenca") or 0.0, 2)
        conta_dif = c_desc if dif < 0 else c_juros
        if dif and conta_dif and i.get("valor_original") is not None:
            lancamentos.append(_novo(
                i["data"], conta, "", i["valor_original"],
                _hist_pagamento(i), filial, "PAGAMENTOS",
                perna="titulo", **extra))
            lancamentos.append(_novo(
                i["data"], "", c_banco, i["valor"],
                _hist_pagamento(i), filial, "PAGAMENTOS",
                perna="banco", **extra))
            lancamentos.append(_novo(
                i["data"], "" if dif < 0 else conta_dif,
                conta_dif if dif < 0 else "", abs(dif),
                _hist_pagamento(i, "DESCONTO REF." if dif < 0 else "JUROS REF."),
                filial, "PAGAMENTOS",
                perna="desconto" if dif < 0 else "juros", **extra))
            continue
        if dif and not conta_dif:
            sem_conta_dif.append(i)
        lancamentos.append(_novo(
            i["data"], conta, c_banco, i["valor"], _hist_pagamento(i),
            filial, "PAGAMENTOS", perna="titulo", **extra))

    conf = []
    rod = leitura.get("rodape") or {}
    if rod.get("modalidades"):
        # a prova e a soma de TUDO que o relatorio traz, lancado ou nao:
        # o que ficou de fora saiu por regra, nao por falha de leitura
        _prova(conf, "Total do relatorio (todas as modalidades)",
               leitura["total"], round(sum(rod["modalidades"].values()), 2))
    # so a perna do banco e comparavel com o total pago: as pernas de
    # titulo e de desconto somam o valor ORIGINAL, que e maior
    pago = round(sum(l["valor"] for l in lancamentos
                     if l["credito"] == c_banco), 2)
    _prova(conf, "Lancado + deixado para o Banco Sistema",
           round(pago + sum(x["valor"] for x in leitura["itens"]
                            if x.get("conta_erp") in so_banco), 2),
           leitura["total"])
    # so se prova o desconto e o juro quando a conta deles existe: sem
    # conta nao ha perna, e cobrar uma prova que nao tem como passar so
    # faria a tela dizer "nao fecha" o mes inteiro
    if c_desc and rod.get("descontos") is not None:
        _prova(conf, "Descontos obtidos",
               round(sum(l["valor"] for l in lancamentos
                         if l.get("perna") == "desconto"), 2),
               rod["descontos"])
    if c_juros and rod.get("juros") is not None:
        _prova(conf, "Juros pagos",
               round(sum(l["valor"] for l in lancamentos
                         if l.get("perna") == "juros"), 2), rod["juros"])
    if sem_conta_dif:
        avisos.append(
            "%d titulo(s) tem desconto ou juros (R$ %.2f no total) e sairam "
            "sem essa perna, porque a conta de descontos obtidos / juros "
            "pagos nao esta cadastrada. O desconto fica escondido dentro da "
            "conta do fornecedor."
            % (len(sem_conta_dif),
               sum(abs(i.get("diferenca") or 0.0) for i in sem_conta_dif)))

    if sem_conta:
        avisos.append(
            "%d titulo(s), somando R$ %.2f, ficaram na conta de pendencia "
            "por nao ter de-para - sao %d fornecedor(es) diferentes."
            % (len(sem_conta), sum(i["valor"] for i in sem_conta),
               len({chave_fornecedor(i) for i in sem_conta})))
        if not pend:
            avisos.append("E a conta de pendencia nao esta cadastrada, entao "
                          "esses lancamentos sairiam SEM conta a debito.")
    return _fechar("PAGAMENTOS", leitura, lancamentos, linhas, conf, avisos,
                   {"banco": c_banco, "filial": filial,
                    "sem_depara": len(sem_conta)})


# ==========================================================================
# 2) RECEBIMENTOS - Titulos Recebidos
# ==========================================================================
def apurar_recebimentos(leitura, cfg, regras=None):
    """
    Cada titulo recebido vira uma partida de duas ou tres pernas:

        D  banco (ou a conta de cobranca)   valor recebido
        C  clientes                         valor recebido menos os juros
        C  juros recebidos                  os juros, quando houver

    OS JUROS SAO PERNA PROPRIA. O VR.REC ja vem com eles dentro; jogar o
    valor inteiro contra clientes baixaria do cliente mais do que ele
    devia, e a receita de juros nunca apareceria.

    O DEBITO depende do HISTORICO, e isso foi conferido: os 574 titulos de
    08/2026 da Matriz se dividem em 459 com "REF. AGRUPAMENTO", que vao
    para a conta de cobranca, e 115 com "REFERENTE A FATURAMENTO", que vao
    direto para o banco. Nao ha um terceiro caso.
    """
    r = regras or regras_de(cfg)
    avisos = list(leitura.get("avisos") or [])
    banco = _conta_banco(cfg, leitura)
    c_banco = str((banco or {}).get("conta_contabil") or "")
    filial = str((banco or {}).get("filial") or "")
    c_cli = str(r["contas"].get("clientes") or "")
    c_jur = str(r["contas"].get("juros_recebidos") or "")
    c_cob = str(r["contas"].get("cobranca") or "")

    for rot, v in (("clientes", c_cli), ("juros recebidos", c_jur),
                   ("cobranca", c_cob), ("banco", c_banco)):
        if not v:
            avisos.append("A conta de %s nao esta cadastrada nas regras deste "
                          "modulo." % rot)

    lancamentos, linhas = [], []
    n_cob = n_ban = 0
    for i in leitura["itens"]:
        agrupamento = bool(RE_AGRUPAMENTO.search(i.get("historico") or ""))
        debito = c_cob if agrupamento else c_banco
        if agrupamento:
            n_cob += 1
        else:
            n_ban += 1
        juros = round(i.get("juros") or 0.0, 2)
        principal = round(i["valor"] - juros, 2)
        linhas.append(dict(i, entra=True, conta=debito,
                           destino="cobranca" if agrupamento else "banco",
                           principal=principal))
        lancamentos.append(_novo(i["data"], debito, c_cli, principal,
                                 _hist_recebimento(i), filial, "RECEBIMENTOS",
                                 cliente=i.get("cliente"),
                                 linha=i["linha"], perna="principal"))
        if juros:
            lancamentos.append(_novo(
                i["data"], debito, c_jur, juros,
                _juntar("JUROS REF.", i.get("historico")), filial,
                "RECEBIMENTOS", cliente=i.get("cliente"),
                linha=i["linha"], perna="juros"))

    if leitura.get("total_desconto"):
        avisos.append(
            "Este relatorio traz R$ %.2f de DESCONTO concedido. O modulo "
            "ainda nao lanca desconto - nos arquivos de 08/2026 ele era zero "
            "em todos, entao a regra dele nunca pode ser conferida. Cadastre "
            "a conta e avise antes de importar este mes."
            % leitura["total_desconto"])

    conf = []
    _prova(conf, "Titulos recebidos lidos",
           round(sum(l["valor"] for l in lancamentos), 2), leitura["total"])
    _prova(conf, "Juros separados do principal",
           round(sum(l["valor"] for l in lancamentos
                     if l.get("perna") == "juros"), 2),
           leitura.get("total_juros") or 0.0)
    return _fechar("RECEBIMENTOS", leitura, lancamentos, linhas, conf, avisos,
                   {"banco": c_banco, "filial": filial,
                    "pela_cobranca": n_cob, "pelo_banco": n_ban})


# ==========================================================================
# 3) BANCO SISTEMA - a conta corrente do ERP
# ==========================================================================
def apurar_banco_sistema(leitura, cfg, regras=None):
    """
    So o que NAO veio pelos titulos (ver o cabecalho deste arquivo).

    D banco / C conta   quando entrou dinheiro
    D conta / C banco   quando saiu
    """
    r = regras or regras_de(cfg)
    avisos = list(leitura.get("avisos") or [])
    banco = _conta_banco(cfg, leitura)
    c_banco = str((banco or {}).get("conta_contabil") or "")
    filial = str((banco or {}).get("filial") or "")
    pend = str(r["contas"].get("pendencia") or "")
    so_banco = set(r.get("erp_so_banco") or [])
    if not c_banco:
        avisos.append(
            "Nao achei no cadastro a conta contabil do banco deste arquivo "
            "(%s %s)." % (leitura.get("banco") or "?",
                          leitura.get("filial") or "?"))

    lancamentos, linhas = [], []
    n_fora = 0
    for i in leitura["itens"]:
        saida = bool(i["debito"])
        if saida:
            entra = (i.get("conta_erp") in so_banco
                     or not RE_PAG.match(i.get("historico") or ""))
            motivo = "" if entra else "ja veio pelos Titulos Pagos"
        else:
            entra = not RE_ESTORNO.match(i.get("historico") or "")
            motivo = "" if entra else "estorno de baixa de titulo"
        conta = r["erp"].get(i.get("conta_erp") or "") or ""
        if entra and not conta:
            conta = pend
        linhas.append(dict(i, entra=entra, motivo=motivo, conta=conta))
        if not entra:
            n_fora += 1
            continue
        hist = _hist_banco_sistema(i)
        if saida:
            lancamentos.append(_novo(i["data"], conta, c_banco, i["debito"],
                                     hist, filial, "BANCO SISTEMA",
                                     conta_erp=i.get("conta_erp"),
                                     linha=i["linha"], lado="saida"))
        else:
            lancamentos.append(_novo(i["data"], c_banco, conta, i["credito"],
                                     hist, filial, "BANCO SISTEMA",
                                     conta_erp=i.get("conta_erp"),
                                     linha=i["linha"], lado="entrada"))

    conf = []
    rod = leitura.get("rodape") or {}
    if rod:
        _prova(conf, "Debitos do relatorio", leitura["total_debito"],
               rod.get("debito"))
        _prova(conf, "Creditos do relatorio", leitura["total_credito"],
               rod.get("credito"))
        _prova(conf, "Saldo final pela cadeia do rodape",
               round((rod.get("saldo_anterior") or 0.0)
                     + (rod.get("credito") or 0.0)
                     - (rod.get("debito") or 0.0), 2),
               rod.get("saldo_final"))
    _prova(conf, "Lancado + deixado para os titulos",
           round(sum(l["valor"] for l in lancamentos)
                 + sum(abs(i["valor"]) for i, x in zip(leitura["itens"], linhas)
                       if not x["entra"]), 2),
           round(leitura["total_debito"] + leitura["total_credito"], 2))

    sem = [l for l in lancamentos if not l["debito"] or not l["credito"]]
    if sem:
        avisos.append("%d lancamento(s) sairam com um dos lados vazio - falta "
                      "cadastrar a conta." % len(sem))
    return _fechar("BANCO SISTEMA", leitura, lancamentos, linhas, conf, avisos,
                   {"banco": c_banco, "filial": filial,
                    "deixados_para_os_titulos": n_fora})


# ==========================================================================
# 4) RESUMO CAIXA
# ==========================================================================
def apurar_resumo_caixa(leitura, cfg, regras=None):
    """
    ESTE RELATORIO SO LANCA A FORMA DINHEIRO.

    O Resumo de Caixa mostra tudo que passou pelo balcao - dinheiro, cartao
    e ordem de pagamento -, mas so o dinheiro pertence a conta de caixa da
    loja. O cartao vira credito a receber na administradora e a ordem de
    pagamento cai direto no banco; os dois entram pelos seus proprios
    relatorios. Lancar as tres formas aqui triplicaria a receita.

    Conferido nos quatro Resumos de 08/2026 contra o que a integracao
    gerou: 880 entradas na Matriz, 262 na Enseada, 598 em Santo Antonio e
    333 em Santos - os mesmos numeros, nas quatro lojas.

    Quem manda o dinheiro para dentro e para fora:
        valor positivo            D caixa da loja / C a contrapartida
        valor negativo e as TF    D a contrapartida / C caixa da loja
    A TF e a transferencia do caixa da loja para o caixa central ou para o
    portador; ela E lancada (o dinheiro sai mesmo do caixa da loja).
    """
    r = regras or regras_de(cfg)
    avisos = list(leitura.get("avisos") or [])
    formas_lancadas = [f for f in pcu.FORMAS_CAIXA
                       if f in (r.get("formas_lancadas") or ["DINHEIRO"])]
    c_cli = str(r["contas"].get("clientes") or "")
    pend = str(r["contas"].get("pendencia") or "")
    loja = leitura.get("filial") or ""
    caixa = str((r.get("caixas") or {}).get(loja) or "")
    filial = _filial_da_loja(cfg, loja)
    if not caixa:
        avisos.append(
            "Nao ha conta de caixa cadastrada para a loja '%s' - sem ela os "
            "lancamentos ficam sem contrapartida. Cadastre nas regras deste "
            "modulo." % (leitura.get("filial") or "?"))

    lancamentos, linhas = [], []
    for i in leitura["itens"]:
        valor = round(sum(v for f, v in i["formas"].items()
                          if f in formas_lancadas), 2)
        if not valor:
            fora = sorted(set(i["formas"]) - set(formas_lancadas))
            linhas.append(dict(
                i, entra=False,
                motivo=("so %s - entra pelo relatorio proprio" % ", ".join(fora))
                if fora else "nao moveu dinheiro (a prazo ou credito)"))
            continue
        conta = _contrapartida_caixa(i, r, c_cli, pend)
        linhas.append(dict(i, entra=True, motivo="", conta=conta,
                           valor_lancado=valor))
        # valor negativo nao se lanca com sinal: inverte-se o par
        if valor >= 0:
            deb, cre, v = caixa, conta, valor
        else:
            deb, cre, v = conta, caixa, -valor
        lancamentos.append(_novo(
            i["data"], deb, cre, v, _hist_caixa(i), filial,
            "RESUMO CAIXA", linha=i["linha"], especie=i.get("especie"),
            lado="entrada" if valor >= 0 else "saida"))

    conf = []
    rod = leitura.get("rodape") or {}
    for forma in pcu.FORMAS_CAIXA:
        lin = rod.get(pcu._chave(pcu.FORMA_NO_RODAPE[forma])) if rod else None
        if not lin:
            continue
        lido = round(sum(i["formas"].get(forma, 0.0) for i in leitura["itens"]), 2)
        rot = ("Movimento em %s (lancado)" if forma in formas_lancadas
               else "Movimento em %s (nao e deste relatorio)") % forma
        _prova(conf, rot, lido, lin["movimento"])
    entradas = round(sum(l["valor"] for l in lancamentos
                         if l["lado"] == "entrada"), 2)
    saidas = round(sum(l["valor"] for l in lancamentos if l["lado"] == "saida"), 2)
    # o caixa do mes fecha no mesmo saldo: o que entrou tem de sair
    _prova(conf, "O que entrou no caixa e o que saiu", entradas, saidas)
    if not filial:
        avisos.append(
            "Os lancamentos da loja '%s' saem sem o codigo de filial: nao "
            "achei no cadastro de bancos uma conta unica dessa loja de onde "
            "tirar o codigo." % (loja or "?"))
    return _fechar("RESUMO CAIXA", leitura, lancamentos, linhas, conf, avisos,
                   {"filial": filial, "loja": loja, "caixa": caixa,
                    "entradas": entradas, "saidas": saidas,
                    "formas_lancadas": ", ".join(formas_lancadas)})


def _contrapartida_caixa(item, regras, c_clientes, pendencia):
    """
    Contra o que o dinheiro do caixa entra ou sai.

    A regra e por HISTORICO, do jeito que o resto do sistema ja faz: a
    primeira regra cadastrada cujo texto aparecer no historico da linha. O
    recebimento comum (o cliente no historico) cai em clientes; o que nao
    casar com nada vai para a pendencia, nunca para um chute.
    """
    hist = _chave(item.get("historico"))
    for texto, conta in sorted((regras.get("caixa_historicos") or {}).items(),
                               key=lambda x: -len(x[0])):
        if _chave(texto) and _chave(texto) in hist:
            return str(conta)
    # "00099337-MENACKER ENGENHARIA": o ERP prefixa o codigo do cliente
    if re.match(r"^\d{5,}\s*-", str(item.get("historico") or "").strip()):
        return c_clientes or pendencia
    return pendencia


# ==========================================================================
def _fechar(modulo, leitura, lancamentos, linhas, conf, avisos, extra):
    for c in conf:
        if not c["fecha"]:
            avisos.append("%s: apurei %.2f e o relatorio diz %.2f (diferenca "
                          "de %.2f)." % (c["rotulo"], c["calculado"],
                                         c["declarado"], c["diferenca"]))
    resumo = {"modulo": modulo, "arquivo": leitura.get("arquivo"),
              "banco_nome": leitura.get("banco"), "filial_nome": leitura.get("filial"),
              "linhas_lidas": len(leitura["itens"]),
              "linhas_lancadas": sum(1 for l in linhas if l.get("entra")),
              "lancamentos": len(lancamentos),
              "total": round(sum(l["valor"] for l in lancamentos), 2),
              # sem lancamento nenhum nao ha o que fechar
              "fecha": bool(lancamentos) and all(c["fecha"] for c in conf)}
    resumo.update(extra)
    return {"modulo": modulo, "lancamentos": lancamentos, "linhas": linhas,
            "conferencia": conf, "resumo": resumo, "avisos": avisos}


APURADORES = {
    "TITULOS PAGOS": ("PAGAMENTOS", apurar_pagamentos),
    "TITULOS RECEBIDOS": ("RECEBIMENTOS", apurar_recebimentos),
    "BANCO SISTEMA": ("BANCO SISTEMA", apurar_banco_sistema),
    "RESUMO DE CAIXA": ("RESUMO CAIXA", apurar_resumo_caixa),
}

# o modulo da tela -> o tipo de relatorio que ele aceita
TIPO_DO_MODULO = {
    "pagamentos": "TITULOS PAGOS",
    "recebimentos": "TITULOS RECEBIDOS",
    "banco_sistema": "BANCO SISTEMA",
    "resumo_caixa": "RESUMO DE CAIXA",
}
ROTULO_DO_MODULO = {
    "pagamentos": "Pagamentos", "recebimentos": "Recebimentos",
    "banco_sistema": "Banco Sistema", "resumo_caixa": "Resumo de Caixa",
}


def apurar(leitura, cfg, regras=None):
    """Chama o apurador do tipo de relatorio que foi lido."""
    tipo = leitura.get("tipo")
    if tipo not in APURADORES:
        raise ValueError("nao tenho regra para o relatorio '%s'." % tipo)
    return APURADORES[tipo][1](leitura, cfg, regras)


# ==========================================================================
# Aprender de-paras do que a integracao ja gerou
# ==========================================================================
RE_TXT_LANC = re.compile(r"^\|6100\|")


def ler_txt_ottimizza(conteudo):
    """
    Os lancamentos de um TXT de importacao do Ottimizza.

    O arquivo e latin-1 e cada lancamento e uma linha
    |6100|data|debito|credito|valor||historico||filial||. Um dos lados vem
    vazio quando a partida tem mais de duas pernas.
    """
    if isinstance(conteudo, bytes):
        conteudo = conteudo.decode("latin-1", "replace")
    out = []
    for linha in conteudo.splitlines():
        if not RE_TXT_LANC.match(linha):
            continue
        p = linha.split("|")
        if len(p) < 8:
            continue
        try:
            valor = round(float(p[5].replace(".", "").replace(",", ".")), 2)
        except ValueError:
            continue
        out.append({"data": p[2].strip(), "debito": p[3].strip(),
                    "credito": p[4].strip(), "valor": valor,
                    "historico": p[7].strip(),
                    "filial": p[9].strip() if len(p) > 9 else ""})
    return out


def _chave_do_item(modulo, item):
    """Por qual chave o de-para deste modulo e guardado."""
    if modulo == "pagamentos":
        return chave_fornecedor(item)
    if modulo == "banco_sistema":
        return item.get("conta_erp") or ""
    if modulo == "resumo_caixa":
        # no caixa a contrapartida e decidida pelo texto do historico; um
        # historico que comeca com o codigo do cliente e recebimento comum
        # e nao vira regra - a conta dele ja e a de clientes
        hist = item.get("historico") or ""
        return "" if RE_CODIGO_NOME.match(hist) else _chave(hist)
    return ""


def _texto_de_busca(modulo, item):
    """O pedaco que tem de aparecer no historico do TXT para o par valer."""
    if modulo == "pagamentos":
        return _chave(_sem_codigo(item.get("fornecedor")))
    if modulo == "resumo_caixa":
        return _chave(item.get("historico"))
    return ""


def aprender(modulo, leitura, lancamentos_txt, regras, contas_proprias=(),
             nao_ensinam=()):
    """
    Aprende os de-paras a partir de um TXT que o Ottimizza ja gerou deste
    mesmo relatorio.

    O par e feito por DATA + VALOR, e conferido pelo HISTORICO: o texto que
    identifica a linha (o nome do fornecedor, o texto do caixa) tem de
    aparecer no historico do lancamento do TXT. Sem essa conferencia, dois
    pagamentos do mesmo valor no mesmo dia trocariam de conta em silencio -
    e foi exatamente assim que 566 lancamentos foram parar na conta errada
    numa outra empresa.

    A conta aprendida e o lado que NAO e a conta propria (o banco, o caixa).

    So entra o que for UNANIME: se a mesma chave aparecer com duas contas
    diferentes, nenhuma e cadastrada. Cadastrar a mais frequente esconderia
    a duvida justamente onde ela importa.
    """
    import collections
    proprias = {str(c) for c in contas_proprias if c}
    # a conta de pendencia nao e resposta, e a falta de uma: cadastra-la
    # como de-para congelaria o fornecedor nela para sempre, e ele sumiria
    # da lista do que ainda falta resolver
    vedadas = {str(c) for c in nao_ensinam if c}
    porkey = collections.defaultdict(list)
    for t in lancamentos_txt:
        porkey[(t["data"], abs(t["valor"]))].append(t)

    vistos = collections.defaultdict(collections.Counter)
    casados = sem_par = sem_historico = 0
    for i in leitura["itens"]:
        chave = _chave_do_item(modulo, i)
        if not chave:
            continue
        fila = porkey.get((i["data"], abs(round(i.get("valor") or 0, 2))))
        if not fila:
            sem_par += 1
            continue
        procurado = _texto_de_busca(modulo, i)
        escolhido = None
        for t in fila:
            if not procurado or procurado in _chave(t["historico"]):
                escolhido = t
                break
        if escolhido is None:
            sem_historico += 1
            continue
        fila.remove(escolhido)
        conta = next((c for c in (escolhido["debito"], escolhido["credito"])
                      if c and c not in proprias), "")
        if conta and conta not in vedadas:
            vistos[chave][conta] += 1
            casados += 1

    grupo = {"pagamentos": "fornecedores", "banco_sistema": "erp",
             "resumo_caixa": "caixa_historicos"}.get(modulo, "")
    ja_tem = (regras.get(grupo) or {}) if grupo else {}
    novos, ambiguos = {}, []
    for chave, contas in vistos.items():
        if chave in ja_tem:
            continue
        if len(contas) == 1:
            novos[chave] = list(contas)[0]
        else:
            ambiguos.append({"chave": chave, "contas": dict(contas)})
    return {"grupo": grupo, "novos": novos, "ambiguos": ambiguos,
            "casados": casados, "sem_par": sem_par,
            "sem_historico": sem_historico}


# ==========================================================================
# Saida
# ==========================================================================
CABECALHO_CSV = "Data;Debito;Credito;Valor;;Historico;;Filial"


def montar_csv(lancamentos):
    import core_cartao
    linhas = [CABECALHO_CSV]
    for l in lancamentos:
        linhas.append(";".join([
            l["data"], str(l["debito"]), str(l["credito"]),
            core_cartao.fmt_valor(l["valor"], "2dec"),
            "",
            core_cartao._maiusculo(l["historico"], acentos=False),
            "",
            str(l.get("filial") or ""),
        ]))
    return "\r\n".join(linhas) + "\r\n"


def csv_bytes(lancamentos):
    return montar_csv(lancamentos).encode("utf-8-sig")


def nome_csv(empresa_slug, modulo, competencia):
    comp = str(competencia or "").replace("/", "-")
    mod = re.sub(r"[^A-Z]+", "_", str(modulo or "").upper()).strip("_")
    return "%s_%s_%s.csv" % (empresa_slug, mod or "COUTO", comp or "mes")
