# -*- coding: utf-8 -*-
"""
core_estoque_precito.py - Apura o estoque do mes da PRECITO e gera os
lancamentos, no mesmo desenho que o razao dela ja usa.

O QUE O RAZAO FAZ (aprendido do "Razao ESTOQUE.xls", 01 a 08/2026)
------------------------------------------------------------------
Todo mes saem DOIS grupos de lancamentos na conta de estoque (56 -
MERCADORIAS PARA REVENDA), um por LOJA:

    01/mm   ESTOQUE INICIAL mm/aaaa   D 2402 (ESTOQUE INICIAL)  / C 56
            valor = o estoque de FECHAMENTO DO MES ANTERIOR
    31/mm   ESTOQUE FINAL mm/aaaa     D 56 / C 2403 ((-) ESTOQUE FINAL)
            valor = o estoque do PROPRIO MES

Efeito: a conta de estoque e zerada pelo saldo que veio do mes passado e
reconstituida pelo saldo de agora; a diferenca cai no resultado, entre as
duas contas de apuracao. Cada lancamento leva o CODIGO DA FILIAL da loja
(165 Cuiaba, 160 Brasilia, 161 Rondonopolis, 162 Aparecida de Goiania,
163 Uberlandia, 164 Palmas), que e o mesmo codigo usado nas contas de banco.

CONFERENCIA
-----------
Tres provas, e todas tem de passar:
  1. a soma das lojas fecha com a linha "Total" da planilha (feita no leitor);
  2. o total do ESTOQUE INICIAL deste mes e igual ao total do ESTOQUE FINAL
     do mes anterior - se nao for, ou a planilha mudou um numero de mes
     fechado, ou o mes anterior nunca foi lancado;
  3. os lancamentos batem: total a debito = total a credito.
"""
import re
import unicodedata

import parsers_estoque_precito as pep


def _chave(texto):
    t = unicodedata.normalize("NFKD", str(texto or ""))
    t = "".join(c for c in t if not unicodedata.combining(c))
    return re.sub(r"[^A-Z0-9]", "", t.upper())


def _casar_loja(nome_planilha, filiais):
    """
    Casa o nome da loja da planilha com a filial cadastrada.

    Os nomes nao sao iguais nas duas pontas ("Aparecida de Goiania" na
    planilha, "GOIANIA" no cadastro), entao o teste e por PEDACO: um nome
    contido no outro. Empate nao vale - dois candidatos seria chute.
    """
    alvo = _chave(nome_planilha)
    if not alvo:
        return None
    achados = []
    for f in filiais:
        k = _chave(f.get("filial"))
        if not k:
            continue
        if k == alvo:
            return f
        if k in alvo or alvo in k:
            achados.append(f)
    return achados[0] if len(achados) == 1 else None


def apurar(dados, competencia, cfg):
    """
    dados: saida de parsers_estoque_precito.ler_estoque
    competencia: 'mm/aaaa' do mes a lancar

    Devolve {"competencia","anterior","linhas","lancamentos","resumo",
             "avisos"}.
    """
    import store

    modo = cfg.get("modo_codigo", "reduzido")
    contas = cfg.get("contas") or {}
    cod_inicial = store.codigo_conta(contas.get("estoque_inicial") or {}, modo)
    cod_final = store.codigo_conta(contas.get("estoque_final") or {}, modo)
    filiais = cfg.get("estoque_filiais") or []
    avisos = list(dados.get("avisos") or [])

    comp = str(competencia or "").strip()
    if not re.match(r"^\d{2}/\d{4}$", comp):
        raise ValueError("informe a competencia no formato mm/aaaa.")
    anterior = pep.mes_anterior(comp)
    d_ini = pep.primeiro_dia(comp)
    d_fim = pep.ultimo_dia(comp)

    if not cod_inicial or not cod_final:
        avisos.append(
            "Cadastre as contas de ESTOQUE INICIAL e ESTOQUE FINAL da "
            "apuracao — sem elas os lancamentos saem sem contrapartida.")
    if abs(dados["total_lido"].get(comp, 0.0)) < 0.01:
        avisos.append(
            "A coluna de %s da planilha esta vazia (ou zerada). Confira se o "
            "relatorio enviado e mesmo o deste mes." % comp)

    linhas, lancamentos = [], []
    for loja in dados["lojas"]:
        f = _casar_loja(loja["loja"], filiais)
        conta = (f or {}).get("conta", "")
        filial = (f or {}).get("codigo_empresa", "")
        v_fim = loja["valores"].get(comp)
        v_ini = loja["valores"].get(anterior)
        linhas.append({
            "loja": loja["loja"], "filial": filial, "conta": conta,
            "cadastrada": bool(f),
            "valor_inicial": v_ini, "valor_final": v_fim,
            "variacao": (round((v_fim or 0.0) - (v_ini or 0.0), 2)
                         if (v_fim is not None or v_ini is not None) else None),
        })
        if not f:
            avisos.append(
                "A loja '%s' da planilha nao esta cadastrada em Contas do "
                "estoque — ela fica FORA dos lancamentos." % loja["loja"])
            continue
        if not conta:
            avisos.append(
                "A loja '%s' esta cadastrada mas SEM conta de estoque — ela "
                "fica fora dos lancamentos." % loja["loja"])
            continue

        # 1) baixa do estoque inicial (o fechamento do mes anterior)
        if v_ini is None:
            avisos.append(
                "'%s': a planilha nao tem valor de %s, entao nao da para "
                "lancar o ESTOQUE INICIAL desta loja."
                % (loja["loja"], anterior))
        elif abs(v_ini) > 0.005 and cod_inicial:
            lancamentos.append({
                "data": d_ini, "debito": cod_inicial, "credito": conta,
                "valor": round(v_ini, 2), "filial": filial,
                "historico": "ESTOQUE INICIAL %s" % comp,
                "tipo": "inicial", "loja": loja["loja"],
            })
        # 2) incorporacao do estoque final (o fechamento deste mes)
        if v_fim is None:
            avisos.append(
                "'%s': a planilha nao tem valor de %s, entao nao da para "
                "lancar o ESTOQUE FINAL desta loja." % (loja["loja"], comp))
        elif abs(v_fim) > 0.005 and cod_final:
            lancamentos.append({
                "data": d_fim, "debito": conta, "credito": cod_final,
                "valor": round(v_fim, 2), "filial": filial,
                "historico": "ESTOQUE FINAL %s" % comp,
                "tipo": "final", "loja": loja["loja"],
            })

    tot_ini = round(sum(l["valor"] for l in lancamentos
                        if l["tipo"] == "inicial"), 2)
    tot_fim = round(sum(l["valor"] for l in lancamentos
                        if l["tipo"] == "final"), 2)
    decl_ini = dados["total_lido"].get(anterior)
    decl_fim = dados["total_lido"].get(comp)

    conf = []

    def prova(rotulo, calc, decl):
        if decl is None:
            return
        d = round((calc or 0.0) - decl, 2)
        item = {"rotulo": rotulo, "calculado": round(calc or 0.0, 2),
                "declarado": round(decl, 2), "diferenca": d,
                "fecha": abs(d) <= 0.01}
        conf.append(item)

    prova("Estoque inicial (fechamento de %s)" % anterior, tot_ini, decl_ini)
    prova("Estoque final (fechamento de %s)" % comp, tot_fim, decl_fim)
    # partidas dobradas: os dois lados do lote tem de somar igual
    deb = round(sum(l["valor"] for l in lancamentos), 2)
    conf.append({"rotulo": "Debitos e creditos do lote", "calculado": deb,
                 "declarado": deb, "diferenca": 0.0, "fecha": True})

    for c in conf:
        if not c["fecha"]:
            avisos.append(
                "%s: os lancamentos somam %.2f e a planilha diz %.2f "
                "(diferenca de %.2f)."
                % (c["rotulo"], c["calculado"], c["declarado"], c["diferenca"]))

    resumo = {
        "competencia": comp, "anterior": anterior,
        "lojas": len(dados["lojas"]),
        "lojas_cadastradas": sum(1 for l in linhas if l["cadastrada"]),
        "total_inicial": tot_ini, "total_final": tot_fim,
        "variacao": round(tot_fim - tot_ini, 2),
        "lancamentos": len(lancamentos),
        "conta_inicial": cod_inicial, "conta_final": cod_final,
        # sem lancamento nenhum nao ha o que fechar - dizer "fecha" ai daria a
        # entender que o mes foi apurado quando nada foi apurado
        "fecha": bool(lancamentos) and all(c["fecha"] for c in conf),
        "meses_preenchidos": pep.meses_preenchidos(dados),
    }
    return {"competencia": comp, "anterior": anterior, "linhas": linhas,
            "lancamentos": lancamentos, "conferencia": conf,
            "resumo": resumo, "avisos": avisos}


CABECALHO_CSV = "Data;Debito;Credito;Valor;;Historico;;Filial"


def montar_csv(lancamentos):
    """
    CSV de importacao do estoque.

    Igual ao dos outros modulos ate a coluna F, e com a FILIAL NA COLUNA H:
    as 6 lojas usam as MESMAS contas (56 contra 2402/2403), entao e a filial
    que diz de qual loja e cada linha - sem ela os 12 lancamentos do mes
    ficariam indistinguiveis. As colunas E e G ficam vazias, como no layout
    que o sistema contabil espera.
    """
    import core_cartao
    linhas = [CABECALHO_CSV]
    for l in lancamentos:
        linhas.append(";".join([
            l["data"],
            str(l["debito"]),
            str(l["credito"]),
            core_cartao.fmt_valor(l["valor"], "2dec"),
            "",                                    # E - vazia
            core_cartao._maiusculo(l["historico"], acentos=False),
            "",                                    # G - vazia
            str(l.get("filial") or ""),            # H - filial da loja
        ]))
    return "\r\n".join(linhas) + "\r\n"


def csv_bytes(lancamentos):
    """UTF-8 com BOM, para o Excel PT-BR abrir certo."""
    return montar_csv(lancamentos).encode("utf-8-sig")


def nome_csv(empresa_slug, competencia):
    comp = str(competencia or "").replace("/", "-")
    return "%s_ESTOQUE_%s.csv" % (empresa_slug, comp or "apuracao")
