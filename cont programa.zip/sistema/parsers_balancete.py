# -*- coding: utf-8 -*-
"""
parsers_balancete.py - Leitura do BALANCETE (PDF) - usado pelo modulo
AUDITORIA para confrontar saldos de outros relatorios contra a contabilidade.

Formato (uma linha por conta, o cabecalho se repete a cada pagina):

    Codigo Classificacao Descricao da conta Saldo Anterior Debito Credito Saldo Atual

    132 1.2.04 IMOBILIZADO 1.554.646,61 0,00 21.965,39 1.532.681,22
    150 1.2.04.09 (-) DEPRECIACAO/ AMORTIZACAO/ EXAUSTAO ACUMULADA (958.323,08) 0,00 21.965,39 (980.288,47)

ARMADILHAS
----------
1. CONTA CONTRA (Ativo redutor, Resultado) vem com o saldo ENTRE PARENTESES:
   "(958.323,08)" = -958.323,08. Sem tratar isso, a depreciacao acumulada
   entraria como POSITIVA e qualquer soma/comparacao saia errada.
2. O CABECALHO SE REPETE em toda pagina ("Empresa: ... Folha: 000N",
   "CONSOLIDADO (...)", a propria linha de cabecalho) - preciso ignorar essas
   linhas, nao tentar casar como conta.
3. O CODIGO da conta e um numero interno do sistema (ex.: "150"), DIFERENTE
   da CLASSIFICACAO contabil (ex.: "1.2.04.09"). Quem identifica a conta para
   quem le o balancete e a classificacao + descricao, nao o codigo interno.
4. Depois das contas vem o "RESUMO DO BALANCETE" (Receitas/Custos e Despesas/
   Resultado) - linhas com o MESMO formato de 4 numeros mas SEM classificacao
   numerica, entao a mesma regex de conta (que exige codigo+classificacao no
   inicio da linha) ja as ignora sozinha.
"""
import re

import parsers

norm_txt = parsers.norm_txt

RE_MONEY = re.compile(r"\(?-?[\d.]+,\d{2}\)?")
RE_CONTA = re.compile(r"^(\d+)\s+(\d+(?:\.\d+)*)\s+(.+)$")
IGNORAR = ("CÓDIGO CLASSIFICAÇÃO", "EMPRESA:", "CONSOLIDADO", "C.N.P.J.",
           "PERÍODO:", "BALANCETE", "RESUMO DO BALANCETE", "RECEITAS",
           "CUSTOS E DESPESAS", "CONTAS DEVEDORAS", "CONTAS CREDORAS",
           "RESULTADO DO MES", "RESULTADO DO EXERCICIO",
           "SISTEMA LICENCIADO")


def _valor(token):
    neg = token.startswith("(") and token.endswith(")")
    v = parsers.parse_numero(token.strip("()"))
    return -v if neg else v


def detectar(caminho):
    """True se o arquivo e um balancete (varre so o texto, nao GERA a lista)."""
    try:
        linhas = _linhas_pdf(caminho)
    except Exception:  # noqa: BLE001 - PDF corrompido/protegido
        return False
    texto = norm_txt(" ".join(linhas[:15]))
    return "BALANCETE" in texto and "SALDO ANTERIOR" in texto


def _linhas_pdf(caminho):
    import pdftexto
    return pdftexto.linhas_do_pdf(caminho)


def _empresa_e_periodo(linhas):
    empresa, cnpj, periodo = "", "", ""
    for l in linhas[:10]:
        m = re.match(r"\s*Empresa\s*:\s*(.+?)\s+Folha\s*:", l, re.I)
        if m:
            empresa = m.group(1).strip()
        m = re.search(r"C\.?N\.?P\.?J\.?\s*:\s*([\d./-]+)", l, re.I)
        if m:
            cnpj = m.group(1).strip()
        m = re.search(r"Per[íi]odo\s*:\s*(.+)", l, re.I)
        if m:
            periodo = m.group(1).strip()
    return empresa, cnpj, periodo


def ler_balancete(caminho, nome_original=""):
    """
    Devolve {"arquivo", "empresa", "cnpj", "periodo", "contas": [...]}.

    Cada conta: {codigo, classificacao, descricao, saldo_anterior, debito,
                 credito, saldo_atual}. Levanta ValueError se nao parecer
    um balancete.
    """
    linhas = _linhas_pdf(caminho)
    empresa, cnpj, periodo = _empresa_e_periodo(linhas)
    contas = []
    for l in linhas:
        n = norm_txt(l)
        if any(n.startswith(p) or n == p for p in IGNORAR):
            continue
        m = RE_CONTA.match(l.strip())
        if not m:
            continue
        numeros = RE_MONEY.findall(m.group(3))
        if len(numeros) != 4:
            continue
        descricao = m.group(3)[:m.group(3).find(numeros[0])].strip()
        contas.append({
            "codigo": m.group(1),
            "classificacao": m.group(2),
            "descricao": descricao,
            "saldo_anterior": _valor(numeros[0]),
            "debito": _valor(numeros[1]),
            "credito": _valor(numeros[2]),
            "saldo_atual": _valor(numeros[3]),
        })

    if not contas:
        raise ValueError("nao encontrei nenhuma linha de conta neste PDF "
                         "(esperado um balancete com Saldo Anterior/Debito/"
                         "Credito/Saldo Atual).")
    return {"arquivo": nome_original or caminho, "empresa": empresa,
            "cnpj": cnpj, "periodo": periodo, "contas": contas}


def buscar(contas, contem=(), nao_contem=()):
    """
    Contas cuja DESCRICAO contem TODAS as palavras de 'contem' e NENHUMA de
    'nao_contem' (comparacao maiuscula/sem acento). Usado para achar a conta
    certa por palavra-chave, sem depender do codigo/classificacao - que
    variam de empresa para empresa.
    """
    out = []
    for c in contas:
        d = norm_txt(c["descricao"])
        if all(norm_txt(p) in d for p in contem) and \
           not any(norm_txt(p) in d for p in nao_contem):
            out.append(c)
    return out


def folhas(contas):
    """
    Remove contas que sao ANCESTRAIS de outra conta NA MESMA LISTA - evita
    contar 2x quando o balancete lista tanto o grupo sintetico quanto a
    conta analitica com o MESMO saldo (ex.: achar 'DEPRECIA' bate em
    '4.5.02.03 DEPRECIACOES E AMORTIZACOES' (grupo) E em
    '4.5.02.03.0001 DEPRECIACAO E AMORTIZACAO' (conta) - somar as duas
    dobraria o valor). So filtra DENTRO do que foi passado: se so o grupo
    apareceu na lista (a analitica nao bateu na busca por algum motivo),
    ele fica, para nao apagar o unico resultado.
    """
    classifs = [c["classificacao"] for c in contas]

    def e_ancestral_de_alguem(classif):
        return any(outro != classif and outro.startswith(classif + ".")
                  for outro in classifs)

    return [c for c in contas if not e_ancestral_de_alguem(c["classificacao"])]
