# -*- coding: utf-8 -*-
"""
parsers_sispag.py - Le o "Resultado da busca" do SISPAG do Itau (xlsx).

O relatorio tem 4 linhas de filtro no topo, uma linha de grupo ("Dados do
pagador" / "Dados do pagamento") e so entao o cabecalho de verdade. Por isso
o cabecalho e achado PELOS NOMES DAS COLUNAS, nunca por numero de linha fixo:
o Itau muda a quantidade de linhas de filtro conforme a busca.

DO RELATORIO INTEIRO SO TRES COISAS VIRAM LANCAMENTO (o que o escritorio
pediu): DATA DO PAGAMENTO, VALOR PAGO e NOME DO FAVORECIDO. O resto
(CPF/CNPJ, banco, autorizantes, horarios) e' lido junto porque ajuda na
conferencia e no casamento da conta, mas nao entra no lancamento.

STATUS: so entra o que foi "Efetuado". Pagamento agendado, cancelado ou
recusado nao virou dinheiro saindo da conta - lancar isso sujaria o
balancete. Nos 4 arquivos reais da ML, 59 de 659 linhas eram "Nao Efetuado".
"""
import os
import re
import unicodedata
import zipfile

import parsers

# Nome da coluna -> chave interna. A comparacao e' feita sem acento, sem
# espaco e em maiusculo (ver _chave), porque o Itau escreve "Data do
# pagamento" numa exportacao e "DATA DO PAGAMENTO" em outra.
COLUNAS = {
    "CPFCNPJPAGADOR": "cnpj_pagador",
    "AGENCIAPAGADORA": "agencia_pagadora",
    "CONTAPAGADORA": "conta_pagadora",
    "NOMEDACONTAPAGADORA": "nome_pagador",
    "TIPODEPAGAMENTO": "tipo",
    "LOTE": "lote",
    "NOMEFAVORECIDO": "favorecido",
    "CPFCNPJFAVORECIDO": "cnpj_favorecido",
    "BANCOINSTITUICAOFAVORECIDO": "banco_favorecido",
    "DATADOPAGAMENTO": "data",
    "VALORPAGO": "valor",
    "STATUS": "status",
    # Variante "Detalhado Sispag" (a que sai em .xls do internet banking):
    # mesmas colunas, outros rotulos.
    "FAVORECIDOBENEFICIARIO": "favorecido",
    "CPFCNPJ": "cnpj_favorecido",
    "REFERENCIADAEMPRESA": "referencia",
    "VALORR": "valor",              # "valor (R$)"
}
OBRIGATORIAS = ("favorecido", "data", "valor", "status")

RE_DATA = re.compile(r"^(\d{2})/(\d{2})/(\d{4})")


def _chave(texto):
    t = unicodedata.normalize("NFKD", str(texto or ""))
    t = "".join(c for c in t if not unicodedata.combining(c))
    return re.sub(r"[^A-Z0-9]", "", t.upper())


def _num(v):
    if isinstance(v, (int, float)):
        return round(float(v), 2)
    return round(parsers.parse_numero(v), 2)


def _efetuado(status):
    return _chave(status) == "EFETUADO"


def _achar_cabecalho(linhas):
    """(numero_da_linha, {chave_interna: coluna}) do cabecalho do relatorio."""
    for rn, cells in linhas:
        mapa = {}
        for col, val in cells.items():
            alvo = COLUNAS.get(_chave(val))
            if alvo:
                mapa.setdefault(alvo, col)
        if all(o in mapa for o in OBRIGATORIAS):
            return rn, mapa
    return None, None


def _data(v):
    """
    Data da celula como 'dd/mm/aaaa'.

    No .xlsx a data chega como TEXTO ("31/08/2026"), mas no .xls antigo ela
    pode chegar como o NUMERO DE SERIE do Excel (46265). Tratar o numero como
    texto faria a linha ser descartada como "rodape" - o relatorio inteiro
    viria vazio, sem erro nenhum.
    """
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        if 20000 < float(v) < 80000:      # faixa de datas plausiveis
            import datetime
            base = datetime.date(1899, 12, 30)   # inclui o bug do ano 1900
            return (base + datetime.timedelta(days=int(v))).strftime("%d/%m/%Y")
    return str(v or "").strip()


def _letra_col(i):
    """0 -> 'A', 26 -> 'AA' (a mesma nomenclatura das colunas do xlsx)."""
    letras, i = "", i + 1
    while i > 0:
        i, resto = divmod(i - 1, 26)
        letras = chr(65 + resto) + letras
    return letras


def _abas(caminho):
    """
    Itera as abas do arquivo como [(numero_da_linha, {coluna: valor})].

    ACEITA OS DOIS FORMATOS de .xls que o Itau exporta:
      - .xlsx (zip de XMLs) - o do internet banking novo
      - .xls  antigo (BIFF8 dentro de OLE2) - o que vem do "Detalhado Sispag"
        da PRECITO. Sem isso o leitor estourava com "File is not a zip file",
        que nao diz nada a quem so quer importar o relatorio.
    """
    if zipfile.is_zipfile(caminho):
        with zipfile.ZipFile(caminho) as z:
            shared = parsers._carregar_shared_strings(z)
            for aba in parsers._abas_do_xlsx(caminho):
                sp = parsers._sheet_path_por_nome(z, aba)
                if not sp:
                    continue
                yield list(parsers._linhas_xml(z, sp, shared))
        return

    import xls_lite
    indice = 0
    while True:
        try:
            rows = xls_lite.read_sheet(caminho, indice)
        except (IndexError, ValueError):
            break
        except Exception:  # noqa: BLE001 - nao e .xls antigo tambem
            break
        if rows is None:
            break
        yield [(rn, {_letra_col(i): v for i, v in enumerate(linha)
                     if v not in (None, "")})
               for rn, linha in enumerate(rows, start=1)]
        indice += 1
        if indice > 20:          # nenhum relatorio destes tem tantas abas
            break


def detectar(caminho):
    try:
        return bool(ler_sispag(caminho)["itens"])
    except Exception:  # noqa: BLE001
        return False


def ler_sispag(caminho, nome_original=""):
    """
    Devolve {"arquivo", "itens": [...], "descartados": n, "periodo": "mm/aaaa",
             "contas_pagadoras": [...]}.

    Cada item: {data (dd/mm/aaaa), valor, favorecido, cnpj_favorecido, tipo,
                conta_pagadora, status}.
    """
    nome = nome_original or os.path.basename(caminho)
    for linhas in _abas(caminho):
        cab_rn, cols = _achar_cabecalho(linhas)
        if cab_rn is None:
            continue

        itens, descartados = [], 0
        for rn, cells in linhas:
            if rn <= cab_rn:
                continue
            data = _data(cells.get(cols["data"]))
            if not RE_DATA.match(data):
                continue        # linha de rodape/total, nao e pagamento
            valor = cells.get(cols["valor"])
            if valor in (None, ""):
                continue
            status = str(cells.get(cols["status"]) or "").strip()
            if not _efetuado(status):
                descartados += 1
                continue
            itens.append({
                "data": data[:10],
                "valor": _num(valor),
                "favorecido": str(cells.get(cols["favorecido"]) or "").strip(),
                "cnpj_favorecido": str(
                    cells.get(cols.get("cnpj_favorecido")) or "").strip(),
                "tipo": str(cells.get(cols.get("tipo")) or "").strip(),
                "conta_pagadora": str(
                    cells.get(cols.get("conta_pagadora")) or "").strip(),
                "status": status,
                "arquivo": nome,
            })
        if itens or descartados:
            periodos = {i["data"][3:] for i in itens}
            return {
                "arquivo": nome,
                "itens": itens,
                "descartados": descartados,
                "periodo": sorted(periodos)[0] if len(periodos) == 1 else "",
                "contas_pagadoras": sorted(
                    {i["conta_pagadora"] for i in itens if i["conta_pagadora"]}),
                }
    raise ValueError(
        "nao achei a tabela do SISPAG neste arquivo (esperava as colunas "
        "'Nome favorecido', 'Data do pagamento', 'Valor pago' e 'Status').")
