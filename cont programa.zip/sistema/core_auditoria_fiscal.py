# -*- coding: utf-8 -*-
"""
core_auditoria_fiscal.py - Confronta o "Resumo por Acumulador" (fiscal, um
.xls por filial) com o Balancete.

CADASTRO POR FILIAL (cfg["fiscal_acumuladores"] = {filial: {acumulador:
{descricao, conta_d, conta_c, desconsiderar}}}): o MESMO codigo de
acumulador pode significar contas diferentes em cada filial, entao o
cadastro nunca solta o codigo sem saber de qual filial. Quando aparece um
(filial, acumulador) nunca visto, ele e' registrado automaticamente SEM
conta (conta_d=conta_c=None, desconsiderar=False) - o contador completa
depois em /aud_fiscal_acumuladores; ate la, se teve movimento no periodo,
aparece como PENDENCIA (nunca entra silenciosamente na confrontacao).
"desconsiderar" e' uma decisao manual do contador (ex.: acumulador que so
serve de informativo, sem lancamento contabil correspondente) - uma vez
marcado, nunca mais gera pendencia nem entra na soma.

CONFRONTACAO: por CLASSIFICACAO da conta (o contador digita a classificacao
do balancete direto, ex. "3.1.01.01.0002"), contra o DEBITO/CREDITO do
periodo (nao o saldo_atual) - um acumulador fiscal e' um movimento do mes.
"""
import parsers_balancete as bal

TOLERANCIA = 0.01


def _so_digitos(s):
    return "".join(ch for ch in str(s or "") if ch.isdigit()).lstrip("0")


def achar_conta(contas_balancete, classificacao):
    """Acha a conta do balancete pela classificacao cadastrada (exata
    primeiro, depois por digitos - cobre zeros a esquerda/pontuacao)."""
    classificacao = (classificacao or "").strip()
    if not classificacao:
        return None
    for c in contas_balancete:
        if c["classificacao"].strip() == classificacao:
            return c
    alvo = _so_digitos(classificacao)
    if not alvo:
        return None
    for c in contas_balancete:
        if _so_digitos(c["classificacao"]) == alvo:
            return c
    return None


def processar(itens_por_filial, cadastro, balancete):
    """
    itens_por_filial: {filial: [itens...]} - itens vem de
        parsers_acumulador.ler_resumo_acumulador()["itens"].
    cadastro: cfg["fiscal_acumuladores"] (dict mutavel - ganha entradas
        novas quando aparece um acumulador nunca visto; quem chama decide
        se salva essa mudanca no cadastro da empresa).
    balancete: parsers_balancete.ler_balancete().

    Devolve {"pendencias": [...], "confrontacoes": [...], "avisos": [...],
             "cadastro_mudou": bool}.
    """
    pendencias = []
    agregados = {}  # {(classificacao, 'debito'|'credito'): valor}
    cadastro_mudou = False

    for filial, itens in itens_por_filial.items():
        mapa = cadastro.setdefault(filial, {})
        for item in itens:
            cod = item["codigo"]
            valor = item["valor_contabil"]
            if cod not in mapa:
                mapa[cod] = {"descricao": item["descricao"], "conta_d": None,
                            "conta_c": None, "desconsiderar": False}
                cadastro_mudou = True
            entrada = mapa[cod]
            if not entrada.get("descricao"):
                entrada["descricao"] = item["descricao"]
                cadastro_mudou = True

            if entrada.get("desconsiderar"):
                continue
            if not entrada.get("conta_d") and not entrada.get("conta_c"):
                if abs(valor) > 0.005:
                    pendencias.append({"filial": filial, "acumulador": cod,
                                       "descricao": item["descricao"],
                                       "valor": round(valor, 2),
                                       "secao": item["secao"]})
                continue
            if entrada.get("conta_d"):
                chave = (entrada["conta_d"], "debito")
                agregados[chave] = agregados.get(chave, 0.0) + valor
            if entrada.get("conta_c"):
                chave = (entrada["conta_c"], "credito")
                agregados[chave] = agregados.get(chave, 0.0) + valor

    contas_bal = balancete["contas"]
    classificacoes = sorted({classificacao for classificacao, _lado in agregados})
    confrontacoes = []
    avisos = []
    for classificacao in classificacoes:
        conta = achar_conta(contas_bal, classificacao)
        fiscal_d = round(agregados.get((classificacao, "debito"), 0.0), 2)
        fiscal_c = round(agregados.get((classificacao, "credito"), 0.0), 2)
        if conta is None:
            avisos.append(f"A conta '{classificacao}' (cadastrada num acumulador) "
                          f"nao foi encontrada no balancete.")
        bal_d = conta["debito"] if conta else None
        bal_c = conta["credito"] if conta else None

        # LADO PRINCIPAL: uma conta so recebe acumulador de um lado (compra
        # cai no debito, venda no credito). Mostrar as duas colunas poluiria
        # a tela com um lado que e' zero por natureza - entao o quadro exibe
        # o lado que TEM movimento, e o outro fica no detalhe.
        if abs(fiscal_d) >= abs(fiscal_c):
            lado, fiscal, bal_valor = "Debito", fiscal_d, bal_d
        else:
            lado, fiscal, bal_valor = "Credito", fiscal_c, bal_c
        diferenca = round(fiscal - bal_valor, 2) if bal_valor is not None else None

        confrontacoes.append({
            "classificacao": classificacao,
            "descricao": conta["descricao"] if conta else None,
            "lado": lado,
            "fiscal": fiscal,
            "balancete": bal_valor,
            "diferenca": diferenca,
            "status": _status(fiscal, bal_valor),
            # saldo do balancete: contexto (nao entra na conferencia - o
            # acumulador e' movimento do mes, o saldo e' acumulado do ano)
            "saldo_atual": conta["saldo_atual"] if conta else None,
            # os dois lados completos, para quem quiser conferir o detalhe
            "fiscal_debito": fiscal_d, "balancete_debito": bal_d,
            "fiscal_credito": fiscal_c, "balancete_credito": bal_c,
        })

    total_fiscal = round(sum(c["fiscal"] for c in confrontacoes), 2)
    total_balancete = round(sum(c["balancete"] or 0.0 for c in confrontacoes), 2)
    resumo = {
        "contas": len(confrontacoes),
        "batem": sum(1 for c in confrontacoes if c["status"] == "bate"),
        "nao_batem": sum(1 for c in confrontacoes if c["status"] == "nao_bate"),
        "sem_conta": sum(1 for c in confrontacoes if c["status"] == "conta_nao_encontrada"),
        "pendencias": len(pendencias),
        "valor_pendente": round(sum(abs(p["valor"]) for p in pendencias), 2),
        "total_fiscal": total_fiscal,
        "total_balancete": total_balancete,
        "total_diferenca": round(total_fiscal - total_balancete, 2),
        "total_contas_balancete": len(contas_bal),
    }

    return {"pendencias": pendencias, "confrontacoes": confrontacoes,
            "resumo": resumo, "avisos": avisos, "cadastro_mudou": cadastro_mudou}


def _status(fiscal, balancete_valor):
    if balancete_valor is None:
        return "conta_nao_encontrada"
    return "bate" if abs(round(fiscal - balancete_valor, 2)) <= TOLERANCIA else "nao_bate"


TOLERANCIA_PRE_VALIDACAO = 1.00


def aplicar_validacoes(confrontacoes, validacoes):
    """
    Anexa a cada linha o status de revisao do contador (marcada como
    conferida + observacao). O que ja foi revisado ANTES manda: uma linha
    com validacao salva mantem exatamente o que o contador deixou ali.

    So quando a linha e' NOVA (nunca revisada) ela nasce pre-marcada, e so
    se a diferenca couber em R$ 1,00 - assim o contador nao precisa clicar
    uma a uma no que obviamente bate, e sobra tempo para o que diverge.
    `validacoes` e' modificado no lugar (ganha as linhas novas).
    """
    for c in confrontacoes:
        cod = c["classificacao"]
        v = validacoes.get(cod)
        if v is None:
            dif = c["diferenca"]
            v = {"validado": dif is not None and abs(dif) <= TOLERANCIA_PRE_VALIDACAO,
                 "observacao": ""}
            validacoes[cod] = v
        c["validado"] = bool(v.get("validado"))
        c["observacao"] = v.get("observacao") or ""
    return confrontacoes


ROTULO_STATUS = {"bate": "BATE", "nao_bate": "NAO BATE",
                 "conta_nao_encontrada": "CONTA NAO ACHADA", "sem_movimento": "-"}


def montar_planilha(resultado, empresa, competencia):
    import io
    import xlsxescreve
    from xlsxescreve import Aba, Cabecalho, Dinheiro, Negrito, Titulo

    linhas = [[Titulo(f"AUDITORIA FISCAL — {empresa}")]]
    if competencia:
        linhas.append([Negrito(f"Competencia: {competencia}")])
    linhas.append([])
    resumo = resultado.get("resumo") or {}
    if resumo:
        linhas.append([Negrito(
            f"{resumo.get('contas', 0)} conta(s) confrontada(s) — "
            f"{resumo.get('batem', 0)} batem, {resumo.get('nao_batem', 0)} nao batem, "
            f"{resumo.get('pendencias', 0)} acumulador(es) pendente(s)")])
        linhas.append([])

    linhas.append([Cabecalho("Conta"), Cabecalho("Descricao"), Cabecalho("Lado"),
                   Cabecalho("Fiscal"), Cabecalho("Balancete"), Cabecalho("Diferenca"),
                   Cabecalho("Situacao"), Cabecalho("Conferido"), Cabecalho("Observacao"),
                   Cabecalho("Saldo no balancete")])
    for c in resultado["confrontacoes"]:
        linhas.append([
            c["classificacao"], c["descricao"] or "-", c["lado"],
            Dinheiro(c["fiscal"]),
            Dinheiro(c["balancete"]) if c["balancete"] is not None else "-",
            Dinheiro(c["diferenca"]) if c["diferenca"] is not None else "-",
            ROTULO_STATUS.get(c["status"], c["status"]),
            "SIM" if c.get("validado") else "",
            c.get("observacao") or "",
            Dinheiro(c["saldo_atual"]) if c["saldo_atual"] is not None else "-",
        ])
    if resumo:
        linhas.append([Negrito("TOTAL"), "", "",
                       Dinheiro(resumo.get("total_fiscal", 0.0)),
                       Dinheiro(resumo.get("total_balancete", 0.0)),
                       Dinheiro(resumo.get("total_diferenca", 0.0)), "", "", "", ""])
    if resultado["pendencias"]:
        linhas.append([])
        linhas.append([Negrito(f"Pendencias ({len(resultado['pendencias'])}) - acumulador "
                               f"sem conta cadastrada, com movimento no periodo")])
        linhas.append([Cabecalho("Filial"), Cabecalho("Acumulador"), Cabecalho("Descricao"),
                       Cabecalho("Valor"), Cabecalho("Secao")])
        for p in resultado["pendencias"]:
            linhas.append([p["filial"], p["acumulador"], p["descricao"],
                           Dinheiro(p["valor"]), p["secao"]])
    if resultado["avisos"]:
        linhas.append([])
        linhas.append([Negrito("Avisos")])
        for a in resultado["avisos"]:
            linhas.append([a])
    aba = Aba("AUDITORIA FISCAL", linhas,
             larguras={"A": 20, "B": 36, "C": 10, "D": 16, "E": 16, "F": 14,
                       "G": 14, "H": 11, "I": 40, "J": 18})
    buf = io.BytesIO()
    xlsxescreve.escrever(buf, [aba])
    return buf.getvalue()


def nome_arquivo(empresa, competencia):
    partes = ["AUDITORIA FISCAL"]
    if empresa:
        partes.append(empresa)
    if competencia:
        partes.append(str(competencia).replace("/", "-"))
    return " ".join(partes) + ".xlsx"
