# -*- coding: utf-8 -*-
"""
core_fiscal.py - Apuracao da RECEITA FINANCEIRA (departamento FISCAL).

Soma as quatro rubricas lidas por parsers_fiscal e monta o CSV do relatorio
"RECEITAS FINANCEIRAS PARA O FISCAL".

REGRA DE TOTAL: o IRRF retido NAO entra no total. Ele e imposto retido na
fonte sobre o rendimento, informado em COLUNA SEPARADA no relatorio do
fiscal - somar o IRRF ao total inflaria a receita e ainda contaria o
rendimento em duplicidade (o IRRF ja esta dentro do rendimento bruto).
"""
import parsers
import core_cartao
import xlsxescreve
from xlsxescreve import Aba, Cabecalho, Dinheiro, Negrito, Obs, Titulo

CABECALHO = "Rubrica;Valor"

RUBRICAS = [
    ("descontos", "DESCONTOS OBTIDOS"),
    ("juros", "JUROS ATIVOS"),
    ("itau_rendimento", "RENDIMENTOS S/ APLICACAO - ITAU"),
    ("bradesco", "RENDIMENTOS S/ APLICACAO - BRADESCO"),
]

# Fora do total (ver docstring do modulo).
INFORMATIVAS = [("itau_irrf", "IRRF RETIDO S/ APLICACAO - ITAU")]


def apurar(itens):
    """
    itens: lista devolvida por parsers_fiscal.ler_arquivo (um por arquivo).

    Devolve {"descontos", "juros", "itau_rendimento", "itau_irrf",
             "bradesco", "total", "competencia", "por_rubrica"}.
    """
    soma = {"descontos": 0.0, "juros": 0.0, "itau_rendimento": 0.0,
            "itau_irrf": 0.0, "bradesco": 0.0}
    por_rubrica = {k: [] for k in soma}

    for item in itens:
        for chave in soma:
            valor = item.get(chave)
            if valor is None:
                continue
            soma[chave] += valor
            por_rubrica[chave].append({
                "arquivo": item.get("arquivo", ""),
                "origem": item.get("origem", ""),
                "valor": round(valor, 2),
                "aviso": item.get("aviso", ""),
            })

    resultado = {k: round(v, 2) for k, v in soma.items()}
    resultado["total"] = round(sum(resultado[k] for k, _r in RUBRICAS), 2)
    resultado["competencia"] = _competencia(itens)
    resultado["por_rubrica"] = por_rubrica
    return resultado


def _competencia(itens):
    """Competencia mais frequente entre os arquivos lidos ('' se nao houver)."""
    contagem = {}
    for item in itens:
        c = (item.get("competencia") or "").strip()
        if c:
            contagem[c] = contagem.get(c, 0) + 1
    if not contagem:
        return ""
    return max(contagem.items(), key=lambda kv: kv[1])[0]


def divergencia_de_competencia(itens):
    """Competencias diferentes achadas (aviso de arquivo de outro mes na pilha)."""
    achadas = sorted({(i.get("competencia") or "").strip()
                      for i in itens if (i.get("competencia") or "").strip()})
    return achadas if len(achadas) > 1 else []


def montar_csv(apuracao, competencia=""):
    """Texto do CSV do relatorio (';' como separador, valor no padrao BR)."""
    comp = (competencia or apuracao.get("competencia") or "").strip()
    linhas = ["RECEITAS FINANCEIRAS PARA O FISCAL"]
    if comp:
        linhas.append(f"COMPETENCIA: {comp}")
    linhas.append("")
    linhas.append(CABECALHO)
    for chave, rotulo in RUBRICAS:
        linhas.append(f"{rotulo};{core_cartao.fmt_valor(apuracao[chave])}")
    linhas.append(f"TOTAL DAS RECEITAS FINANCEIRAS;"
                  f"{core_cartao.fmt_valor(apuracao['total'])}")
    linhas.append("")
    for chave, rotulo in INFORMATIVAS:
        linhas.append(f"{rotulo};{core_cartao.fmt_valor(apuracao[chave])}")
    return "\r\n".join(linhas) + "\r\n"


def csv_bytes(apuracao, competencia=""):
    """CSV em UTF-8 COM BOM (abre certo no Excel PT-BR), igual aos outros modulos."""
    return montar_csv(apuracao, competencia).encode("utf-8-sig")


def nome_arquivo(competencia=""):
    comp = (competencia or "").strip().replace("/", "-")
    if comp:
        return f"RECEITAS FINANCEIRAS PARA O FISCAL {comp}.csv"
    return "RECEITAS FINANCEIRAS PARA O FISCAL.csv"


def nome_arquivo_xlsx(competencia=""):
    comp = (competencia or "").strip().replace("/", "-")
    if comp:
        return f"RECEITAS FINANCEIRAS PARA O FISCAL {comp}.xlsx"
    return "RECEITAS FINANCEIRAS PARA O FISCAL.xlsx"


# --------------------------------------------------------------------------
# Planilha no MODELO DO FISCAL
# --------------------------------------------------------------------------
OBS_1 = ("Obs: VALORES LANCADOS COMO RENDIMENTO NA INTENCAO DE AJUSTAR O SALDO "
         "CONTABIL DA APLICACAO PODERA NAO SER TRIBUTADO, VERIFIQUE COM SEU LIDER.")
OBS_2 = ("Obs: RENDIMENTO DE APLICACOES EM INSTITUICOES FINANCEIRAS DEVERA SER "
         "ACOMPANHADO DA INFORMACAO DO CNPJ DA INSTITUICAO, VALOR DO RENDIMENTO "
         "E IRRF SE HOUVER.")


def _valor_da_instituicao(origem, apuracao):
    """(valor, irrf) que o sistema apurou para aquela instituicao."""
    if origem == "itau":
        return apuracao["itau_rendimento"], apuracao["itau_irrf"]
    if origem == "bradesco":
        return apuracao["bradesco"], 0.0
    return None, None      # preenchido a mao (ex.: sobras Sicredi)


def montar_planilha(apuracao, cfg, competencia=""):
    """
    Monta a planilha do fiscal e devolve (abas, linhas_para_a_tela).

    O layout segue o modelo do escritorio: coluna A vazia, conteudo de B a E -
    NATUREZA DO RENDIMENTO | VALOR | IRRF | CNPJ INSTITUICAO FINANCEIRA.

    O CNPJ da instituicao NAO sai do extrato: vem do cadastro por empresa. Uma
    instituicao cadastrada SEM valor apurado (as sobras do Sicredi, por
    exemplo) entra assim mesmo, com a linha em branco para preencher a mao -
    sumir da planilha seria pior do que aparecer vazia.
    """
    comp = (competencia or apuracao.get("competencia") or "").strip()
    razao = (cfg.get("razao_social") or cfg.get("empresa") or "").strip()
    cnpj_empresa = (cfg.get("cnpj") or "").strip()

    linhas = [
        [None, Titulo(razao), Titulo(f"COMPETENCIA: {comp}" if comp else "COMPETENCIA:")],
        [None, Negrito(f"CNPJ: {cnpj_empresa}" if cnpj_empresa else "CNPJ:")],
        [None, Cabecalho("NATUREZA DO RENDIMENTO"), Cabecalho("VALOR"),
         Cabecalho("IRRF"), Cabecalho("CNPJ INSTITUICAO FINANCEIRA")],
        [None, "DESCONTOS OBTIDOS", Dinheiro(apuracao["descontos"]), Dinheiro(0)],
        [None, "JUROS ATIVOS", Dinheiro(apuracao["juros"]), Dinheiro(0)],
    ]
    detalhe = [
        {"natureza": "DESCONTOS OBTIDOS", "valor": apuracao["descontos"],
         "irrf": 0.0, "cnpj": "", "manual": False},
        {"natureza": "JUROS ATIVOS", "valor": apuracao["juros"],
         "irrf": 0.0, "cnpj": "", "manual": False},
    ]

    sem_cnpj = []
    for inst in (cfg.get("instituicoes") or []):
        natureza = inst.get("descricao") or (
            f"{inst['nome']} - RENDIMENTOS S/ APLICACAO FINANCEIRA")
        valor, irrf = _valor_da_instituicao(inst.get("origem", ""), apuracao)
        manual = valor is None
        linhas.append([
            None, natureza,
            None if manual else Dinheiro(valor),
            None if manual else Dinheiro(irrf),
            inst.get("cnpj", ""),
        ])
        detalhe.append({"natureza": natureza,
                        "valor": None if manual else round(valor, 2),
                        "irrf": None if manual else round(irrf, 2),
                        "cnpj": inst.get("cnpj", ""), "manual": manual})
        if not inst.get("cnpj"):
            sem_cnpj.append(inst["nome"])

    primeira_obs = len(linhas) + 3
    while len(linhas) < primeira_obs - 1:
        linhas.append([])
    linhas.append([None, "*SE NECESSARIO INSERIR MAIS LINHAS"])
    linhas.append([None, Obs(OBS_1)])
    linhas.append([None, Obs(OBS_2)])

    n_obs1 = len(linhas) - 1
    n_obs2 = len(linhas)
    abas = [Aba("RECEITAS FINANCEIRAS", linhas,
                larguras={"A": 3, "B": 52, "C": 14, "D": 12, "E": 28},
                merges=[f"C1:E1", f"B{n_obs1}:E{n_obs1}", f"B{n_obs2}:E{n_obs2 + 1}"])]
    return abas, {"linhas": detalhe, "sem_cnpj": sem_cnpj,
                  "razao_social": razao, "cnpj": cnpj_empresa,
                  "competencia": comp}


def planilha_bytes(apuracao, cfg, competencia=""):
    """Planilha do fiscal em bytes (.xlsx) + o detalhamento para a tela."""
    import io
    abas, detalhe = montar_planilha(apuracao, cfg, competencia)
    buf = io.BytesIO()
    xlsxescreve.escrever(buf, abas)
    return buf.getvalue(), detalhe
