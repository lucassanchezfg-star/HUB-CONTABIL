# -*- coding: utf-8 -*-
"""
core_auditoria_depreciacao.py - Confronta o RESUMO DA DEPRECIACAO FISCAL
(relatorio do Patrimonial) com o BALANCETE, e monta o quadro do que bate e
do que nao bate.

DUAS LINHAS DE CONFERENCIA, POR DESENHO (nao e um confronto generico):

  1. SALDO ACUMULADO DE DEPRECIACAO
     Resumo "Valor ja depreciado" (total) x Balancete: saldo atual da(s)
     conta(s) de depreciacao acumulada (Ativo, contra-conta, saldo negativo
     no balancete - por isso comparado em VALOR ABSOLUTO).
     NORMALMENTE NAO BATE — e o caso ja avisado pelo usuario: divergencia por
     implantacao de saldo (o saldo inicial lancado na contabilidade na hora
     de migrar de outro sistema raramente reproduz o acumulado exato do
     controle patrimonial). O modulo aponta a DIFERENCA, nao tenta zera-la.

  2. DEPRECIACAO DO MES (o movimento, nao o acumulado)
     Resumo "Depreciacao do mes" (total) x Balancete: debito lancado na
     conta de DESPESA de depreciacao do mes (e, de conferencia, o credito
     lancado na conta acumulada - pela partida dobrada, os dois tem que ser
     iguais entre si TAMBEM, nao so contra o resumo).
     Este item costuma bater exatamente: e o lancamento feito no mes, sem
     historico de saldo anterior para divergir.

COMO AS CONTAS SAO ACHADAS NO BALANCETE: por PALAVRA-CHAVE na descricao
("DEPRECIA"), nunca por codigo/classificacao (que mudam de empresa para
empresa). Dentro do que a busca encontrar, so entram as contas-FOLHA
(parsers_balancete.folhas) - um balancete costuma listar tanto o grupo
sintetico quanto a conta analitica com o MESMO saldo, e somar as duas
dobraria o valor.

"ACUMULADA" na descricao separa a conta de Ativo (contra-conta) da conta de
despesa. Sem essa palavra ali, o modulo nao teria como distinguir as duas so
pela busca "DEPRECIA" - por isso, quando nenhuma conta bate esse criterio, o
resultado sai como aviso (pendencia de classificacao) em vez de um numero
adivinhado.
"""
import parsers_balancete as bal
import xlsxescreve
from xlsxescreve import Aba, Cabecalho, Dinheiro, Negrito, Titulo

TOLERANCIA = 0.01  # so cobre arredondamento de centavos - divergencia real tem que aparecer


def _achar_contas(contas_balancete):
    """(contas_acumulada, contas_despesa) - ambas listas de conta-FOLHA."""
    todas = bal.folhas(bal.buscar(contas_balancete, contem=["DEPRECIA"]))
    acumulada = [c for c in todas if "ACUMULADA" in bal.norm_txt(c["descricao"])]
    despesa = [c for c in todas if "ACUMULADA" not in bal.norm_txt(c["descricao"])]
    return acumulada, despesa


def _linha(item, valor_resumo, valor_balancete, contas, observacao="",
           obs_so_se_divergir=False):
    """
    obs_so_se_divergir: a observacao e' uma EXPLICACAO DE DIVERGENCIA - so
    aparece quando existe divergencia. Antes ela saia sempre, e o relatorio
    mostrava um paragrafo explicando "por que a diferenca e esperada" embaixo
    de uma linha com diferenca de R$ 0,00: texto longo, sem nada a explicar,
    espremendo a coluna do item.
    """
    if not contas:
        return {"item": item, "resumo": round(valor_resumo, 2), "balancete": None,
                "diferenca": None, "status": "conta_nao_encontrada",
                "contas_balancete": [], "observacao": observacao}
    dif = round(valor_resumo - valor_balancete, 2)
    status = "bate" if abs(dif) <= TOLERANCIA else "nao_bate"
    if obs_so_se_divergir and status == "bate":
        observacao = ""
    return {"item": item, "resumo": round(valor_resumo, 2),
            "balancete": round(valor_balancete, 2), "diferenca": dif,
            "status": status, "observacao": observacao,
            "contas_balancete": [{"classificacao": c["classificacao"],
                                  "descricao": c["descricao"]} for c in contas]}


def conciliar(resumo, balancete):
    """
    resumo: devolvido por parsers_depreciacao.ler_resumo
    balancete: devolvido por parsers_balancete.ler_balancete

    Devolve {"quadro": [linha1, linha2], "avisos": [...]}.
    """
    acumulada, despesa = _achar_contas(balancete["contas"])
    avisos = []

    saldo_acumulado_bal = sum(abs(c["saldo_atual"]) for c in acumulada)
    linha_saldo = _linha(
        "Saldo acumulado de depreciacao",
        resumo["total"]["valor_depreciado"], saldo_acumulado_bal, acumulada,
        "Diferenca esperada se o saldo inicial veio de implantacao. "
        "Conferir a linha 'Depreciacao do mes'.",
        obs_so_se_divergir=True)

    debito_despesa = sum(c["debito"] for c in despesa)
    credito_acumulada = sum(c["credito"] for c in acumulada)
    contas_mes = despesa or acumulada
    valor_balancete_mes = debito_despesa if despesa else credito_acumulada
    linha_mes = _linha(
        "Depreciacao do mes", resumo["total"]["depreciacao_mes"],
        valor_balancete_mes, contas_mes)

    if despesa and acumulada and abs(debito_despesa - credito_acumulada) > TOLERANCIA:
        avisos.append(
            f"O debito lancado na despesa de depreciacao ({debito_despesa:.2f}) "
            f"e o credito lancado na depreciacao acumulada ({credito_acumulada:.2f}) "
            f"deveriam ser iguais entre si (partida dobrada) e nao sao — "
            f"confira se nao ha lancamento de depreciacao fora dessas duas contas.")
    if not acumulada:
        avisos.append("Nao achei no balancete uma conta com 'DEPRECIA' e "
                      "'ACUMULADA' na descricao (Ativo, contra-conta) — a "
                      "linha 'Saldo acumulado' ficou sem numero do balancete.")
    if not despesa:
        avisos.append("Nao achei no balancete uma conta de DESPESA de "
                      "depreciacao (com 'DEPRECIA' mas sem 'ACUMULADA' na "
                      "descricao) — a linha 'Depreciacao do mes' usou o "
                      "credito da conta acumulada como alternativa.")

    return {"quadro": [linha_saldo, linha_mes], "avisos": avisos}


ROTULO_STATUS = {"bate": "BATE", "nao_bate": "NAO BATE",
                 "conta_nao_encontrada": "CONTA NAO ACHADA NO BALANCETE"}


def montar_planilha(resultado, resumo, balancete):
    """Planilha do quadro (o mesmo conteudo mostrado na tela)."""
    empresa = resumo.get("empresa") or balancete.get("empresa") or ""
    linhas = [[Titulo(f"AUDITORIA DE DEPRECIACAO — {empresa}")]]
    if resumo.get("competencia"):
        linhas.append([Negrito(f"Competencia: {resumo['competencia']}")])
    linhas.append([])
    linhas.append([Cabecalho("Item"), Cabecalho("Resumo Depreciacao"),
                   Cabecalho("Balancete"), Cabecalho("Diferenca"),
                   Cabecalho("Situacao"), Cabecalho("Conta(s) no balancete")])
    for l in resultado["quadro"]:
        contas_txt = "; ".join(f"{c['classificacao']} {c['descricao']}"
                               for c in l["contas_balancete"])
        linhas.append([
            l["item"],
            Dinheiro(l["resumo"]),
            Dinheiro(l["balancete"]) if l["balancete"] is not None else "-",
            Dinheiro(l["diferenca"]) if l["diferenca"] is not None else "-",
            ROTULO_STATUS.get(l["status"], l["status"]),
            contas_txt,
        ])
    if resultado["avisos"]:
        linhas.append([])
        linhas.append([Negrito("Avisos")])
        for a in resultado["avisos"]:
            linhas.append([a])
    aba = Aba("AUDITORIA DEPRECIACAO", linhas,
             larguras={"A": 34, "B": 18, "C": 18, "D": 14, "E": 26, "F": 44})
    return [aba]


def planilha_bytes(resultado, resumo, balancete):
    import io
    buf = io.BytesIO()
    xlsxescreve.escrever(buf, montar_planilha(resultado, resumo, balancete))
    return buf.getvalue()


def nome_arquivo(empresa, competencia):
    partes = ["AUDITORIA DEPRECIACAO"]
    if empresa:
        partes.append(empresa)
    if competencia:
        partes.append(competencia.replace("/", "-"))
    return " ".join(partes) + ".xlsx"
