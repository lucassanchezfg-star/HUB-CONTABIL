# -*- coding: utf-8 -*-
"""
xlsxescreve.py - Gera arquivos .xlsx usando SOMENTE a biblioteca padrao.

Contrapartida do leitor: assim como nao ha openpyxl para LER (ver README,
"Por que nao usa Flask/openpyxl"), tambem nao ha para ESCREVER. Um .xlsx e um
zip de XMLs, entao da para montar com zipfile + strings.

O esqueleto segue o de um .xlsx real gerado pelo sistema do cliente, para o
Excel abrir sem a caixa de "conteudo ilegivel".

COMO ESCREVER: cada aba recebe um ITERADOR de linhas, e cada linha e uma lista
de valores. O conteudo e gravado direto no zip conforme sai do iterador
(ZipFile.open(..., "w")), sem montar a planilha inteira na memoria - um
inventario de estoque passa de 40 mil linhas POR FILIAL, e segurar as quatro
de uma vez seria centenas de MB.

Tipos aceitos numa celula:
    None            -> celula vazia
    int / float     -> numero  (e o que faz SOMA/SUM funcionar)
    Formula("...")  -> formula (ex.: Formula("SUM('ENSEADA'!H25:H1048576)"))
    qualquer outro  -> texto

TEXTO QUE PARECE NUMERO CONTINUA TEXTO. O relatorio de origem traz "184,0400"
como texto; se for repassado assim, a formula de soma devolve zero e a
planilha parece certa - erro silencioso. Quem le e quem converte para float,
aqui so entra numero de verdade.
"""
import re
import zipfile

NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS_PKG = "http://schemas.openxmlformats.org/package/2006/relationships"
NS_CT = "http://schemas.openxmlformats.org/package/2006/content-types"

# Caracteres de controle que o Excel recusa dentro de <t> (quebram o arquivo).
_CONTROLE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")
# Proibidos em nome de aba pelo proprio Excel.
_PROIBIDO_ABA = re.compile(r"[\[\]:*?/\\]")


class Formula(str):
    """Marca uma string como formula: Formula(\"SUM(C4:C7)\")."""


# Indices dos estilos declarados em _styles(), na mesma ordem.
E_NORMAL, E_NEGRITO, E_DINHEIRO, E_CABECALHO, E_OBS, E_TITULO = 0, 1, 2, 3, 4, 5


class Cel(object):
    """Valor com estilo: Cel(1234.5, E_DINHEIRO)."""

    def __init__(self, valor, estilo=E_NORMAL):
        self.valor = valor
        self.estilo = estilo


def Negrito(v):
    return Cel(v, E_NEGRITO)


def Dinheiro(v):
    return Cel(v, E_DINHEIRO)


def Cabecalho(v):
    return Cel(v, E_CABECALHO)


def Obs(v):
    return Cel(v, E_OBS)


def Titulo(v):
    return Cel(v, E_TITULO)


class Aba(object):
    """
    nome    : titulo da aba (saneado para as regras do Excel)
    linhas  : iteravel de listas de valores (ver tipos no topo do modulo)
    larguras: {letra_da_coluna: largura} - opcional, so aparencia
    merges  : ['B14:E14', ...] - celulas mescladas
    """

    def __init__(self, nome, linhas, larguras=None, merges=None):
        self.nome = nome
        self.linhas = linhas
        self.larguras = larguras or {}
        self.merges = merges or []


def escrever(caminho_ou_buffer, abas):
    """Grava o .xlsx com as abas na ordem dada."""
    with zipfile.ZipFile(caminho_ou_buffer, "w", zipfile.ZIP_DEFLATED) as z:
        nomes = nomes_unicos([a.nome for a in abas])
        z.writestr("[Content_Types].xml", _content_types(len(abas)))
        z.writestr("_rels/.rels", _rels_raiz())
        z.writestr("xl/workbook.xml", _workbook(nomes))
        z.writestr("xl/_rels/workbook.xml.rels", _rels_workbook(len(abas)))
        z.writestr("xl/styles.xml", _styles())
        for i, aba in enumerate(abas, start=1):
            _escrever_aba(z, f"xl/worksheets/sheet{i}.xml", aba)


# --------------------------------------------------------------------------
# Aba (streaming)
# --------------------------------------------------------------------------
def _escrever_aba(z, nome_no_zip, aba):
    with z.open(nome_no_zip, "w") as f:
        w = f.write
        w(b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>')
        w(f'<worksheet xmlns="{NS}">'.encode("utf-8"))
        if aba.larguras:
            w(b"<cols>")
            for letra, larg in sorted(aba.larguras.items()):
                n = _indice_col(letra)
                w(f'<col min="{n}" max="{n}" width="{larg}" customWidth="1"/>'
                  .encode("utf-8"))
            w(b"</cols>")
        w(b"<sheetData>")
        for n_linha, valores in enumerate(aba.linhas, start=1):
            celulas = []
            for n_col, valor in enumerate(valores):
                if valor is None or valor == "":
                    continue
                celulas.append(_celula(_letra_col(n_col) + str(n_linha), valor))
            if celulas:
                w(f'<row r="{n_linha}">'.encode("utf-8"))
                w("".join(celulas).encode("utf-8"))
                w(b"</row>")
        w(b"</sheetData>")
        if aba.merges:
            # mergeCells vem DEPOIS de sheetData: fora de ordem, o Excel
            # recusa o arquivo inteiro.
            w(f'<mergeCells count="{len(aba.merges)}">'.encode("utf-8"))
            for ref in aba.merges:
                w(f'<mergeCell ref="{ref}"/>'.encode("utf-8"))
            w(b"</mergeCells>")
        w(b"</worksheet>")


def _celula(ref, valor):
    estilo = 0
    if isinstance(valor, Cel):
        estilo, valor = valor.estilo, valor.valor
        if valor is None or valor == "":
            return f'<c r="{ref}" s="{estilo}"/>'
    s = f' s="{estilo}"' if estilo else ""
    if isinstance(valor, Formula):
        return f'<c r="{ref}"{s}><f>{_esc(valor)}</f></c>'
    if isinstance(valor, bool):          # antes de int: bool e subclasse de int
        return f'<c r="{ref}"{s} t="b"><v>{1 if valor else 0}</v></c>'
    if isinstance(valor, (int, float)):
        return f'<c r="{ref}"{s}><v>{_num(valor)}</v></c>'
    # inlineStr evita ter de montar o sharedStrings (que exigiria guardar
    # todos os textos do arquivo na memoria antes de gravar qualquer aba).
    return (f'<c r="{ref}"{s} t="inlineStr"><is>'
            f'<t xml:space="preserve">{_esc(valor)}</t></is></c>')


def _num(v):
    if isinstance(v, int):
        return str(v)
    s = repr(float(v))
    return s[:-2] if s.endswith(".0") else s


def _esc(s):
    s = _CONTROLE.sub("", str(s))
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;"))


def _letra_col(i):
    letras = ""
    i += 1
    while i > 0:
        i, resto = divmod(i - 1, 26)
        letras = chr(65 + resto) + letras
    return letras


def _indice_col(letra):
    n = 0
    for c in letra.upper():
        n = n * 26 + (ord(c) - 64)
    return n


def nome_de_aba(nome):
    """Sanea um nome para as regras do Excel (<=31 chars, sem []:*?/\\)."""
    limpo = _PROIBIDO_ABA.sub(" ", str(nome or "")).strip()
    limpo = re.sub(r"\s+", " ", limpo)[:31].strip("'")
    return limpo or "Planilha"


def nomes_unicos(nomes):
    """Aba com nome repetido faz o Excel recusar o arquivo inteiro."""
    vistos = {}
    saida = []
    for n in nomes:
        base = nome_de_aba(n)
        if base not in vistos:
            vistos[base] = 1
            saida.append(base)
            continue
        vistos[base] += 1
        sufixo = f" ({vistos[base]})"
        saida.append(base[:31 - len(sufixo)] + sufixo)
    return saida


def ref_aba(nome):
    """Nome de aba dentro de uma formula: 'ENSEADA'!H25 (apostrofo dobrado)."""
    return "'" + nome_de_aba(nome).replace("'", "''") + "'"


# --------------------------------------------------------------------------
# Partes fixas do pacote
# --------------------------------------------------------------------------
def _content_types(n_abas):
    overrides = "".join(
        f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType='
        f'"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        for i in range(1, n_abas + 1))
    return (
        f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<Types xmlns="{NS_CT}">'
        f'<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        f'<Default Extension="xml" ContentType="application/xml"/>'
        f'<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        f'<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        f'{overrides}</Types>')


def _rels_raiz():
    return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            f'<Relationships xmlns="{NS_PKG}">'
            f'<Relationship Id="rId1" Type="{NS_REL}/officeDocument" '
            f'Target="xl/workbook.xml"/></Relationships>')


def _workbook(nomes):
    abas = "".join(
        f'<sheet name="{_esc(n)}" sheetId="{i}" state="visible" r:id="rId{i}"/>'
        for i, n in enumerate(nomes, start=1))
    # fullCalcOnLoad: as formulas sao gravadas SEM valor calculado (nao ha
    # motor de calculo aqui). Sem esta marca, o Excel abriria as celulas de
    # total em branco ate alguem editar a planilha.
    return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            f'<workbook xmlns="{NS}" xmlns:r="{NS_REL}">'
            f'<workbookPr/><bookViews><workbookView activeTab="0"/></bookViews>'
            f'<sheets>{abas}</sheets>'
            f'<calcPr calcId="124519" fullCalcOnLoad="1"/></workbook>')


def _rels_workbook(n_abas):
    rels = "".join(
        f'<Relationship Id="rId{i}" Type="{NS_REL}/worksheet" '
        f'Target="worksheets/sheet{i}.xml"/>' for i in range(1, n_abas + 1))
    rels += (f'<Relationship Id="rId{n_abas + 1}" Type="{NS_REL}/styles" '
             f'Target="styles.xml"/>')
    return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            f'<Relationships xmlns="{NS_PKG}">{rels}</Relationships>')


def _styles():
    """
    Estilos do arquivo (o Excel exige styles.xml mesmo sem formatacao).
    A ORDEM em cellXfs e o indice usado em Cel(...) - ver as constantes
    E_NORMAL / E_NEGRITO / ... no topo do modulo.
    """
    return (
        f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<styleSheet xmlns="{NS}">'
        # 164 = numero contabil com 2 casas e separador de milhar
        f'<numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.00"/></numFmts>'
        f'<fonts count="3">'
        f'<font><sz val="11"/><name val="Calibri"/></font>'
        f'<font><b/><sz val="11"/><name val="Calibri"/></font>'
        f'<font><b/><sz val="12"/><name val="Calibri"/></font>'
        f'</fonts>'
        f'<fills count="3"><fill><patternFill patternType="none"/></fill>'
        f'<fill><patternFill patternType="gray125"/></fill>'
        f'<fill><patternFill patternType="solid"><fgColor rgb="FFD9E2F3"/>'
        f'<bgColor indexed="64"/></patternFill></fill></fills>'
        f'<borders count="2">'
        f'<border><left/><right/><top/><bottom/><diagonal/></border>'
        f'<border><left style="thin"/><right style="thin"/><top style="thin"/>'
        f'<bottom style="thin"/><diagonal/></border>'
        f'</borders>'
        f'<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        f'<cellXfs count="6">'
        f'<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
        f'<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
        f'<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0"'
        f' applyNumberFormat="1" applyBorder="1"/>'
        f'<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0"'
        f' applyFont="1" applyFill="1" applyBorder="1"/>'
        f'<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"'
        f' applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf>'
        f'<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
        f'</cellXfs>'
        f'<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
        f'</styleSheet>')
