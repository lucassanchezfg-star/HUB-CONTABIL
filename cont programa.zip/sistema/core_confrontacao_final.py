# -*- coding: utf-8 -*-
"""
core_confrontacao_final.py - Junta as auditorias que hoje sao feitas UMA A
UMA (extrato bancario, aplicacao, taxa de cartao, depreciacao e fiscal)
numa conferencia so: o Balancete e' enviado UMA VEZ e confrontado contra
todos os relatorios de uma vez, saindo um CHECKLIST unico do que bate e do
que nao bate.

NAO REIMPLEMENTA REGRA NENHUMA. Cada modulo continua com o seu proprio
motor, ja testado contra arquivos reais - aqui so:
  1. chama o motor de cada modulo que recebeu arquivo;
  2. traduz a saida de cada um (que tem formato proprio) para UMA linha de
     checklist no mesmo formato;
  3. soma o placar por modulo e no geral.
Mudou a regra de um modulo? Muda no motor dele e este arquivo acompanha
sozinho - por isso a traducao aqui e' rasa de proposito.

MODULO NAO ENVIADO NAO E' MODULO QUE BATE: quem nao recebeu arquivo sai no
checklist como "nao enviado", nunca somado como conferido. Um checklist que
esconde o que nao foi conferido e' pior que nao ter checklist.
"""
import io

import core_auditoria_cartao
import core_auditoria_depreciacao
import core_auditoria_extrato
import core_estoque
import xlsxescreve
from xlsxescreve import Aba, Cabecalho, Dinheiro, Negrito, Titulo

# Ordem em que os modulos aparecem no checklist: a mesma ordem em que a
# conferencia costuma ser feita na pratica (caixa/bancos primeiro, fiscal
# por ultimo).
MODULOS = (
    ("extrato", "Extrato Bancario"),
    ("aplicacao", "Aplicacao"),
    ("estoque", "Estoque"),
    ("cartao", "Taxa Cartao"),
    ("depreciacao", "Depreciacao"),
    ("alugueis", "Alugueis a Pagar"),
)

TOLERANCIA_ESTOQUE = 0.01   # so arredondamento de centavo

# Status normalizado (cada motor tem o seu vocabulario proprio):
#   bate      - confere
#   nao_bate  - diverge de verdade, tem que olhar
#   atencao   - nao deu para conferir (conta nao cadastrada/nao achada,
#               acumulador pendente, extrato sem conta correspondente)
_PARA_ATENCAO = {"conta_nao_encontrada", "conta_nao_cadastrada",
                 "sem_conta_balancete", "sem_extrato", "sem_grupo"}


def _status(bruto):
    if bruto in ("bate", "nao_bate", "detalhe"):
        return bruto
    return "atencao"


def _conta_do_balancete(contas, codigo):
    """Acha a conta pelo codigo cadastrado (o reduzido do plano) ou pela
    classificacao, aceitando zeros a esquerda."""
    alvo = str(codigo or "").strip()
    if not alvo:
        return None
    so_dig = alvo.lstrip("0")
    for c in contas:
        if c["codigo"].strip() == alvo or c["codigo"].strip().lstrip("0") == so_dig:
            return c
    for c in contas:
        if c["classificacao"].strip() == alvo:
            return c
    return None


def _conferir_estoque(inventarios, cfg, balancete, avisos):
    """
    Confere o inventario de cada filial contra a conta de estoque dela no
    balancete, e fecha com a soma de todas.

    A CONTA DE CADA FILIAL VEM DO CADASTRO (o mesmo de Estoque Citel:
    codigo da empresa no Citel -> conta contabil). E preciso porque o NOME
    nao serve de chave: na HAC a filial "SANTA ROSA" e a "MATRIZ" do
    balancete - casar por nome erraria de conta.
    """
    contas_bal = balancete["contas"]
    filiais_cad = cfg.get("estoque_filiais") or []
    linhas = []
    soma_inv = 0.0
    soma_bal = 0.0
    conferiveis = 0

    for inv in core_estoque.ordenar(inventarios, filiais_cad):
        cad = core_estoque.casar_conta(inv, filiais_cad)
        nome = inv.get("filial") or "(sem filial)"
        total = round(inv.get("total_bruto", inv.get("total", 0.0)), 2)
        soma_inv += total
        if not cad or not (cad.get("conta") or "").strip():
            avisos.append(
                "Estoque: a filial '%s' (empresa %s) nao tem conta cadastrada em "
                "'Contas do estoque' — o inventario dela (%.2f) nao pode ser "
                "conferido contra o balancete." % (nome, inv.get("codigo_empresa") or "?", total))
            linhas.append(_linha("Estoque", nome, "", total, None, None,
                                 "conta_nao_cadastrada"))
            continue
        conta = _conta_do_balancete(contas_bal, cad["conta"])
        if conta is None:
            avisos.append("Estoque: a conta '%s' (filial %s) nao foi encontrada no "
                          "balancete." % (cad["conta"], nome))
            linhas.append(_linha("Estoque", nome, cad["conta"], total, None, None,
                                 "conta_nao_encontrada"))
            continue
        dif = round(total - conta["saldo_atual"], 2)
        soma_bal += conta["saldo_atual"]
        conferiveis += 1
        linhas.append(_linha(
            "Estoque", "%s — %s" % (nome, conta["descricao"]), conta["classificacao"],
            total, round(conta["saldo_atual"], 2), dif,
            "bate" if abs(dif) <= TOLERANCIA_ESTOQUE else "nao_bate"))

    if conferiveis:
        dif = round(soma_inv - soma_bal, 2)
        linhas.append(_linha(
            "Estoque", "TOTAL dos inventarios x contas de estoque", "",
            round(soma_inv, 2), round(soma_bal, 2), dif,
            "bate" if abs(dif) <= TOLERANCIA_ESTOQUE * max(conferiveis, 1) else "nao_bate",
            total=True))
    return linhas


TOLERANCIA_ALUGUEIS = 0.01


def _conferir_alugueis(dados_alug, balancete, avisos):
    """
    Confronta o LIQUIDO provisionado na planilha de alugueis com a conta
    "Alugueis a pagar" do PASSIVO.

    O saldo que tem de bater e o do FIM do periodo (saldo_atual): e o que
    ficou provisionado e sera pago no mes seguinte - as datas de pagamento
    da planilha sao todas do mes seguinte.

    Quando o total da planilha bate com o saldo ANTERIOR em vez do atual, o
    aviso diz isso com todas as letras: nao e' coincidencia, e' sinal de que
    a planilha ficou na versao do mes passado. Sem apontar isso, a
    divergencia apareceria como um numero solto e daria trabalho de achar.
    """
    contas = [c for c in balancete["contas"]
              if c["classificacao"].startswith("2")
              and "ALUGU" in c["descricao"].upper()
              and "PAGAR" in c["descricao"].upper()]
    total = dados_alug["total_liquido"]

    if not contas:
        avisos.append("Alugueis: nao achei no balancete uma conta de passivo com "
                      "'ALUGUEIS' e 'PAGAR' na descricao — sem como conferir.")
        return [_linha("Alugueis a Pagar", "Provisao da planilha (liquido)", "",
                       total, None, None, "conta_nao_encontrada")]

    conta = min(contas, key=lambda c: len(c["classificacao"]))
    saldo = round(conta["saldo_atual"], 2)
    dif = round(total - saldo, 2)
    obs = ""
    if abs(dif) > TOLERANCIA_ALUGUEIS:
        if abs(total - round(conta["saldo_anterior"], 2)) <= TOLERANCIA_ALUGUEIS:
            obs = ("O total da planilha e' igual ao saldo ANTERIOR (%.2f), nao ao "
                   "do fim do periodo — a planilha parece ser a do mes passado."
                   % conta["saldo_anterior"])
            avisos.append("Alugueis: " + obs)
        else:
            avisos.append("Alugueis: a provisao da planilha (%.2f) nao bate com a "
                          "conta %s (%.2f) — diferenca de %.2f."
                          % (total, conta["classificacao"], saldo, dif))

    linhas = [_linha("Alugueis a Pagar",
                     "Provisao (liquido) x %s" % conta["descricao"],
                     conta["classificacao"], total, saldo, dif,
                     "bate" if abs(dif) <= TOLERANCIA_ALUGUEIS else "nao_bate", obs)]

    # detalhe por locatario: nao entra no placar, mas mostra de onde vem o total
    for i in dados_alug["itens"]:
        linhas.append(_linha("Alugueis a Pagar",
                             "  %s (%s)" % (i["locatario"], i["tipo"] or "-"),
                             "", i["liquido"], None, None, "detalhe",
                             ("IRRF %.2f" % i["irrf"]) if i["irrf"] else ""))
    return linhas


def _linha(modulo, item, conta, relatorio, balancete, diferenca, status,
           observacao="", total=False):
    """
    total=True marca a linha que JA E' a soma do bloco (o "TOTAL do grupo no
    balancete"). Quem exibe precisa saber disso para nao somar duas vezes: a
    tela e o relatorio fecham cada bloco com um subtotal proprio, e sem a
    marca a linha de total entrava na propria soma, dobrando o valor.
    """
    return {"modulo": modulo, "item": item, "conta": conta or "",
            "relatorio": relatorio, "balancete": balancete,
            "diferenca": diferenca, "status": _status(status),
            "observacao": observacao or "", "total": bool(total)}


def confrontar(balancete, cfg, dados):
    """
    balancete: parsers_balancete.ler_balancete() - UM so, compartilhado.
    cfg: cadastro da empresa (contas de cartao, acumuladores fiscais...).
    dados: o que foi enviado, por modulo (chave ausente/vazia = modulo nao
        enviado, e o checklist diz isso):
          "depreciacao": resumo de parsers_depreciacao.ler_resumo, ou None
          "extratos":    lista de registros de parsers_extrato_saldo
          "cartao":      resumo de core_cartao.resumo_por_operadora
          "estoque":     inventarios de parsers_estoque
          "alugueis":   planilha de parsers_alugueis

    Devolve {"linhas": [...], "modulos": [...], "resumo": {...},
             "avisos": [...]}.
    """
    linhas = []
    avisos = []
    enviados = set()
    cadastro_mudou = False

    # --- Extrato bancario + Aplicacao (o motor devolve os dois juntos) ---
    extratos = dados.get("extratos") or []
    if extratos:
        r = core_auditoria_extrato.conciliar(
            extratos, balancete, (cfg or {}).get("bancos"))
        avisos.extend(r["avisos"])
        for tipo, rotulo in (("corrente", "Extrato Bancario"), ("aplicacao", "Aplicacao")):
            grupo = r["grupos"].get(tipo)
            if not grupo:
                continue
            if any(e["tipo"] == tipo for e in extratos):
                enviados.add(tipo)
            for l in grupo["linhas"]:
                nome = l["banco"] + (f" - {l['conta_extrato']}" if l["conta_extrato"] else "")
                linhas.append(_linha(
                    rotulo, nome, l["balancete_classificacao"], l["extrato_saldo"],
                    l["balancete_saldo"], l["diferenca"], l["status"]))
            linhas.append(_linha(
                rotulo, "TOTAL do grupo no balancete", grupo.get("balancete_classificacao"),
                grupo["extrato_total"], grupo["balancete_total"], grupo["diferenca"],
                grupo["status"], total=True))

    # --- Estoque (inventarios x contas de estoque do balancete) ---
    inventarios = dados.get("estoque") or []
    if inventarios:
        enviados.add("estoque")
        linhas.extend(_conferir_estoque(inventarios, cfg, balancete, avisos))

    # --- Taxa de cartao ---
    cartao = dados.get("cartao") or {}
    if cartao:
        enviados.add("cartao")
        r = core_auditoria_cartao.conciliar(cartao, cfg, balancete)
        avisos.extend(r["avisos"])
        for l in r["quadro"]:
            linhas.append(_linha("Taxa Cartao", l["item"], l["codigo_configurado"],
                                l["relatorio"], l["balancete"], l["diferenca"],
                                l["status"], l.get("observacao")))

    # --- Depreciacao ---
    resumo_dep = dados.get("depreciacao")
    if resumo_dep:
        enviados.add("depreciacao")
        r = core_auditoria_depreciacao.conciliar(resumo_dep, balancete)
        avisos.extend(r["avisos"])
        for l in r["quadro"]:
            contas = "; ".join(c["classificacao"] for c in l["contas_balancete"])
            linhas.append(_linha("Depreciacao", l["item"], contas, l["resumo"],
                                l["balancete"], l["diferenca"], l["status"],
                                l.get("observacao")))

    # --- Alugueis a pagar (planilha de provisao x conta do passivo) ---
    alugueis = dados.get("alugueis")
    if alugueis:
        enviados.add("alugueis")
        linhas.extend(_conferir_alugueis(alugueis, balancete, avisos))

    # --- placar por modulo ---
    modulos = []
    for chave, nome in MODULOS:
        do_modulo = [l for l in linhas if l["modulo"] == nome]
        if chave not in enviados and not do_modulo:
            modulos.append({"chave": chave, "nome": nome, "enviado": False,
                           "itens": 0, "batem": 0, "nao_batem": 0, "atencao": 0,
                           "status": "nao_enviado"})
            continue
        do_modulo = [l for l in do_modulo if l["status"] != "detalhe"]
        batem = sum(1 for l in do_modulo if l["status"] == "bate")
        nao_batem = sum(1 for l in do_modulo if l["status"] == "nao_bate")
        atencao = sum(1 for l in do_modulo if l["status"] == "atencao")
        modulos.append({
            "chave": chave, "nome": nome, "enviado": True, "itens": len(do_modulo),
            "batem": batem, "nao_batem": nao_batem, "atencao": atencao,
            "status": "nao_bate" if nao_batem else ("atencao" if atencao else "bate"),
        })

    conferidos = [m for m in modulos if m["enviado"]]
    resumo = {
        "modulos_enviados": len(conferidos),
        "modulos_total": len(MODULOS),
        # linhas "detalhe" sao composicao (ex.: cada locatario dentro do
        # total de alugueis) - aparecem no relatorio, mas nao sao ITEM
        # conferido: contar dobraria o placar.
        "itens": sum(1 for l in linhas if l["status"] != "detalhe"),
        "batem": sum(1 for l in linhas if l["status"] == "bate"),
        "nao_batem": sum(1 for l in linhas if l["status"] == "nao_bate"),
        "atencao": sum(1 for l in linhas if l["status"] == "atencao"),
    }
    resumo["tudo_bate"] = (resumo["nao_batem"] == 0 and resumo["atencao"] == 0
                           and resumo["itens"] > 0)
    return {"linhas": linhas, "modulos": modulos, "resumo": resumo,
            "avisos": avisos, "cadastro_mudou": cadastro_mudou}


ROTULO_STATUS = {"bate": "BATE", "nao_bate": "NAO BATE", "atencao": "VERIFICAR",
                 "nao_enviado": "NAO ENVIADO"}


def montar_planilha(resultado, empresa, periodo):
    """Planilha de CHECKLIST: o placar por modulo em cima e, embaixo, item a
    item o que bate e o que nao bate."""
    r = resultado["resumo"]
    linhas = [[Titulo(f"CHECKLIST DE CONFRONTACAO — {empresa}")]]
    if periodo:
        linhas.append([Negrito(f"Periodo: {periodo}")])
    linhas.append([Negrito(
        f"{r['itens']} item(ns) conferido(s): {r['batem']} batem, "
        f"{r['nao_batem']} nao batem, {r['atencao']} a verificar "
        f"({r['modulos_enviados']} de {r['modulos_total']} modulos enviados)")])
    linhas.append([])

    linhas.append([Cabecalho("Modulo"), Cabecalho("Itens"), Cabecalho("Batem"),
                   Cabecalho("Nao batem"), Cabecalho("A verificar"), Cabecalho("Situacao")])
    for m in resultado["modulos"]:
        linhas.append([m["nome"], m["itens"], m["batem"], m["nao_batem"], m["atencao"],
                       ROTULO_STATUS.get(m["status"], m["status"])])
    linhas.append([])

    linhas.append([Cabecalho("Modulo"), Cabecalho("Item"), Cabecalho("Conta"),
                   Cabecalho("Relatorio"), Cabecalho("Balancete"), Cabecalho("Diferenca"),
                   Cabecalho("Situacao"), Cabecalho("Observacao")])
    for l in resultado["linhas"]:
        linhas.append([
            l["modulo"], l["item"], l["conta"],
            Dinheiro(l["relatorio"]) if l["relatorio"] is not None else "-",
            Dinheiro(l["balancete"]) if l["balancete"] is not None else "-",
            Dinheiro(l["diferenca"]) if l["diferenca"] is not None else "-",
            ROTULO_STATUS.get(l["status"], l["status"]),
            l["observacao"],
        ])

    if resultado["avisos"]:
        linhas.append([])
        linhas.append([Negrito("Avisos")])
        for a in resultado["avisos"]:
            linhas.append([a])

    aba = Aba("CHECKLIST", linhas,
             larguras={"A": 20, "B": 46, "C": 20, "D": 16, "E": 16, "F": 14,
                       "G": 14, "H": 52})
    buf = io.BytesIO()
    xlsxescreve.escrever(buf, [aba])
    return buf.getvalue()


def nome_arquivo(empresa, periodo):
    partes = ["CHECKLIST CONFRONTACAO"]
    if empresa:
        partes.append(empresa)
    if periodo:
        partes.append(str(periodo).replace("/", "-"))
    return " ".join(partes) + ".xlsx"
