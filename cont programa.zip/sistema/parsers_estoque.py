# -*- coding: utf-8 -*-
"""
parsers_estoque.py - Leitura do INVENTARIO FISICO do sistema Citel.

Entrada: um arquivo por filial (.xlsx ou .csv - os dois tem o mesmo desenho).

    L1   H A C MATERIAIS PARA CONSTRUCAO LTDA - SANTA ROSA   <- quem EMITIU
    L3   INVENTARIO FISICO - TABELAS DE INVENTARIO 05/08/2026 15:42
    L8   Empresa : 005-H A C MATERIAIS ... - ENSEADA         <- de QUEM e
    L21  Tabela de Inventario (I_*) : 2026 / Julho           <- competencia
    L24  COD.;DESCRICAO DO PRODUTO;CLASS. IPI;UNID;LITROS/QUILOS;QTDE;UNITARIO;TOTAL
    L25+ dados

TRES ARMADILHAS DESTE RELATORIO
-------------------------------
1. A FILIAL NAO ESTA NA LINHA 1 nem no nome do arquivo. A linha 1 traz sempre
   a empresa que emitiu o relatorio ("SANTA ROSA") - em TODOS os arquivos,
   inclusive no da ENSEADA. Quem identifica e a linha "Empresa : 005-...".
   O nome do arquivo e livre e ja se sabe que muda (a matriz ora e "MATRIZ",
   ora "SANTA ROSA").
2. O CABECALHO NAO ESTA NUMA LINHA FIXA. Antes dele vem a lista de filtros do
   relatorio, que varia com as opcoes escolhidas na emissao. Por isso o
   cabecalho e PROCURADO pelas colunas, e a linha onde ele cair define onde
   os dados comecam - o que tambem alimenta a formula de soma do consolidado.
3. TODO VALOR VEM COMO TEXTO ("184,0400"), inclusive no .xlsx (as celulas sao
   t="inlineStr"). Repassar assim para a planilha final faria a formula de
   soma devolver ZERO com a planilha parecendo correta. As colunas numericas
   sao convertidas para numero de verdade - e sao escolhidas PELO NOME da
   coluna, nao pela posicao.
"""
import os
import re

import parsers

norm_txt = parsers.norm_txt
limpo = parsers.limpo

# Colunas que precisam virar numero (comparadas normalizadas, sem acento).
COLUNAS_NUMERICAS = {"LITROS/QUILOS", "QTDE", "UNITARIO", "TOTAL", "VALOR TOTAL"}
COLUNA_TOTAL = "TOTAL"
# Assinatura do relatorio: o cabecalho tem que ter estas colunas.
COLUNAS_OBRIGATORIAS = ("DESCRICAO DO PRODUTO", "TOTAL")

MESES = {"JANEIRO": 1, "FEVEREIRO": 2, "MARCO": 3, "ABRIL": 4, "MAIO": 5,
         "JUNHO": 6, "JULHO": 7, "AGOSTO": 8, "SETEMBRO": 9, "OUTUBRO": 10,
         "NOVEMBRO": 11, "DEZEMBRO": 12}


def _acha_cabecalho(linhas, limite=80):
    """(indice_da_linha, [nomes das colunas]) do cabecalho, ou (None, [])."""
    for i, linha in enumerate(linhas[:limite]):
        nomes = [norm_txt(limpo(c)) for c in linha]
        if all(col in nomes for col in COLUNAS_OBRIGATORIAS):
            return i, nomes
    return None, []


def _filtro(linhas, rotulo, limite=80):
    """Valor de uma linha de filtro do relatorio ('Empresa : 005-...')."""
    alvo = norm_txt(rotulo)
    for linha in linhas[:limite]:
        texto = " ".join(limpo(c) for c in linha)
        if ":" not in texto:
            continue
        esq, dir_ = texto.split(":", 1)
        if norm_txt(esq) == alvo:
            return dir_.strip()
    return ""


def _empresa_e_filial(linhas, nome_arquivo):
    """
    (codigo_empresa, nome_completo, filial) a partir de
    'Empresa : 005-H A C MATERIAIS PARA CONSTRUCAO LTDA - ENSEADA'.

    A filial e o ultimo trecho depois do '-'. Quando a empresa nao tem sufixo
    de filial (matriz cadastrada so com a razao social), esse ultimo trecho e
    a propria razao social - dai a checagem por LTDA/S.A. e por tamanho, que
    faz cair no nome do arquivo em vez de virar uma "filial" chamada
    "H A C MATERIAIS PARA CONSTRUCAO LTDA".
    """
    bruto = _filtro(linhas, "Empresa")
    codigo, nome = "", bruto
    m = re.match(r"\s*(\d{1,4})\s*-\s*(.+)", bruto)
    if m:
        codigo, nome = m.group(1), m.group(2).strip()

    filial = ""
    if "-" in nome:
        cauda = nome.rsplit("-", 1)[1].strip()
        n = norm_txt(cauda)
        if cauda and len(cauda) <= 30 and not re.search(r"\bLTDA\b|\bS[/.]?A\b", n):
            filial = cauda
    if not filial:
        filial = re.sub(r"\.[A-Za-z]+$", "", os.path.basename(nome_arquivo)).strip()
    return codigo, nome, filial.upper()


def _competencia(linhas):
    """'2026 / Julho' -> '07/2026'. Vazio se o relatorio nao trouxer."""
    bruto = _filtro(linhas, "Tabela de Inventario (I_*)")
    if not bruto:
        for linha in linhas[:80]:
            texto = " ".join(limpo(c) for c in linha)
            if "TABELA DE INVENTARIO" in norm_txt(texto) and ":" in texto:
                bruto = texto.split(":", 1)[1]
                break
    m = re.search(r"(\d{4})\s*/\s*([A-Za-zÇç]+)", bruto or "")
    if m and norm_txt(m.group(2)) in MESES:
        return "%02d/%s" % (MESES[norm_txt(m.group(2))], m.group(1))
    m = re.search(r"\b(0[1-9]|1[0-2])/(20\d{2})\b", bruto or "")
    return f"{m.group(1)}/{m.group(2)}" if m else ""


def detectar(caminho):
    """True se o arquivo e um inventario fisico do Citel."""
    try:
        linhas = parsers.ler_tabela(caminho)
    except Exception:  # noqa: BLE001 - arquivo ilegivel/corrompido
        return False
    i, _nomes = _acha_cabecalho(linhas)
    if i is None:
        return False
    topo = norm_txt(" ".join(limpo(c) for l in linhas[:i] for c in l))
    return "INVENTARIO FISICO" in topo


def ler_inventario(caminho, nome_original=""):
    """
    Devolve o inventario de UMA filial:

      {"arquivo", "codigo_empresa", "empresa", "filial", "competencia",
       "colunas", "col_total" (letra), "linha_dados" (1-based),
       "linhas" (TODAS as linhas do relatorio, com os numeros convertidos),
       "itens", "itens_com_saldo", "total"}

    Levanta ValueError se nao for um inventario.
    """
    nome = nome_original or os.path.basename(caminho)
    linhas = parsers.ler_tabela(caminho)
    i_cab, colunas = _acha_cabecalho(linhas)
    if i_cab is None:
        raise ValueError("nao parece um inventario fisico do Citel (nao achei "
                         "o cabecalho com 'DESCRICAO DO PRODUTO' e 'TOTAL').")

    idx_num = {j for j, c in enumerate(colunas) if c in COLUNAS_NUMERICAS}
    try:
        idx_total = colunas.index(COLUNA_TOTAL)
    except ValueError:
        raise ValueError("inventario sem a coluna 'TOTAL'.")

    saida = []
    total = 0.0
    itens = 0
    com_saldo = 0
    for n, linha in enumerate(linhas):
        if n <= i_cab:
            saida.append([limpo(c) for c in linha])
            continue
        if not any(limpo(c) for c in linha):
            saida.append([])
            continue
        convertida = []
        for j, celula in enumerate(linha):
            texto = limpo(celula)
            if j in idx_num and texto:
                convertida.append(parsers.parse_numero(texto))
            else:
                convertida.append(texto)
        saida.append(convertida)
        itens += 1
        if len(convertida) > idx_total and isinstance(convertida[idx_total], float):
            total += convertida[idx_total]
            if convertida[idx_total]:
                com_saldo += 1

    codigo, empresa, filial = _empresa_e_filial(linhas, nome)
    return {
        "arquivo": nome,
        "codigo_empresa": codigo,
        "empresa": empresa,
        "filial": filial,
        "competencia": _competencia(linhas),
        "colunas": colunas,
        "col_total": _letra(idx_total),
        "linha_dados": i_cab + 2,      # 1-based, primeira linha DEPOIS do cabecalho
        "linhas": saida,
        "itens": itens,
        "itens_com_saldo": com_saldo,
        "total": round(total, 2),
        # Soma SEM arredondar. O consolidado tem de somar os totais crus e so
        # entao arredondar - e o que a formula do Excel faz. Somar os totais
        # ja arredondados dava 1 centavo a mais no total geral, ou seja, a tela
        # mostrava um numero e a planilha baixada mostrava outro.
        "total_bruto": total,
    }


def _letra(i):
    letras = ""
    i += 1
    while i > 0:
        i, resto = divmod(i - 1, 26)
        letras = chr(65 + resto) + letras
    return letras
