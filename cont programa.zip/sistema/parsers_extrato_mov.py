# -*- coding: utf-8 -*-
"""
parsers_extrato_mov.py - Reconstroi a base bancaria a partir do extrato em
PDF: UMA linha por movimentacao, com data, documento, historico, valor e
natureza (credito/debito).

COMO O EXTRATO E DESENHADO (Bradesco, "Extrato de: Ag: NN | CC: NNNNN-N"):
cada movimentacao ocupa ATE 3 linhas de texto, com a linha de valores no
meio:

    PAGTO ELETRON COBRANCA              <- historico
    466 -160,00 19.821,95               <- ANCORA: [data] dcto valor saldo
    FAVARO ROCHA INFORMATICA LTDA       <- complemento (a contraparte!)

As vezes o historico vem NA PROPRIA ancora ("RENTAB.INVEST FACILCRED* 15432
0,02 23.318,83"). A ancora e' reconhecida por terminar em DOIS valores
monetarios (o da movimentacao e o saldo).

A DATA SO APARECE NA PRIMEIRA MOVIMENTACAO DO DIA - as seguintes herdam a
ultima data vista.

O QUE NAO E MOVIMENTACAO (e por que nao entra):
  - "SALDO ANTERIOR", "SALDO INVEST FACIL": tem UM valor so, entao nem
    chegam a ser ancora;
  - a linha "Total ...": FECHA o periodo pedido. Tudo que vem depois dela
    e' de OUTRO periodo (o extrato anexa os "ultimos lancamentos" do mes
    seguinte) ou o quadro "Saldos Invest Facil/Plus" - por isso a leitura
    PARA nessa linha, em vez de tentar filtrar linha a linha depois.

O BANCO NAO SAI DAQUI. Este extrato nao diz em lugar nenhum qual e' a
instituicao (o unico "BRADESCO" no arquivo e o nome de um FORNECEDOR numa
transacao - usar isso como codigo do banco seria justamente o acidente que
se quer evitar). O codigo do banco vem do controle financeiro/cadastro,
nunca deste arquivo e nunca da agencia ou da conta.
"""
import re

import parsers
import pdftexto

norm_txt = parsers.norm_txt

RE_VALOR = re.compile(r"-?\d{1,3}(?:\.\d{3})*,\d{2}")
RE_DATA = re.compile(r"^(\d{2}/\d{2}/\d{4})\b")
RE_CABECALHO = re.compile(r"lan[çc]amento.*dcto", re.I)
RE_TOTAL = re.compile(r"^total\b", re.I)


def _centavos(txt):
    """'-1.265,36' -> -126536 (inteiro). A conciliacao trabalha em centavos
    inteiros para nao acumular erro de arredondamento de float."""
    neg = txt.strip().startswith("-")
    digitos = re.sub(r"\D", "", txt)
    v = int(digitos or 0)
    return -v if neg else v


def _e_ancora(linha):
    vals = RE_VALOR.findall(linha)
    if len(vals) < 2:
        return None
    # os DOIS ultimos valores tem que estar no fim da linha
    if not re.search(RE_VALOR.pattern + r"\s+" + RE_VALOR.pattern + r"\s*$", linha):
        return None
    return vals


def _quebrar_ancora(linha):
    """-> (data|'', texto_inline, documento, valor_centavos, saldo_centavos)"""
    s = linha.strip()
    data = ""
    m = RE_DATA.match(s)
    if m:
        data = m.group(1)
        s = s[m.end():].strip()
    vals = RE_VALOR.findall(s)
    valor, saldo = vals[-2], vals[-1]
    # tudo antes dos dois valores finais
    corte = re.search(re.escape(valor) + r"\s+" + re.escape(saldo) + r"\s*$", s)
    meio = s[:corte.start()].strip() if corte else ""
    documento = ""
    partes = meio.split()
    if partes and re.fullmatch(r"\d+", partes[-1]):
        documento = partes[-1]
        partes = partes[:-1]
    return data, " ".join(partes).strip(), documento, _centavos(valor), _centavos(saldo)


def _cabecalho(linhas):
    """agencia, conta e periodo do extrato."""
    ag = cc = ini = fim = ""
    for l in linhas[:20]:
        m = re.search(r"Ag:\s*(\d+)\s*\|\s*CC:\s*([\d\s.-]+?)\s*\|", l, re.I)
        if m:
            ag, cc = m.group(1), re.sub(r"\s+", "", m.group(2))
        m = re.search(r"Entre\s+(\d{2}/\d{2}/\d{4})\s+e\s+(\d{2}/\d{2}/\d{4})", l, re.I)
        if m:
            ini, fim = m.group(1), m.group(2)
    return ag, cc, ini, fim


def detectar(caminho):
    try:
        with open(caminho, "rb") as f:
            if f.read(5) != b"%PDF-":
                return False
        linhas = pdftexto.linhas_do_pdf(caminho)
    except Exception:  # noqa: BLE001
        return False
    return any(RE_CABECALHO.search(l) for l in linhas[:40])


def _ler_bradesco(linhas, nome):
    """Layout Bradesco - ver o cabecalho do modulo."""
    inicio = next((i for i, l in enumerate(linhas) if RE_CABECALHO.search(l)), None)
    if inicio is None:
        return None

    # 1) Delimita o trecho do periodo pedido: da linha do cabecalho ate a
    #    linha "Total", que o fecha.
    fim = len(linhas)
    total_relatorio = None
    for i in range(inicio + 1, len(linhas)):
        if RE_TOTAL.match(linhas[i].strip()):
            vals = RE_VALOR.findall(linhas[i])
            if len(vals) >= 2:
                total_relatorio = {"creditos": _centavos(vals[0]),
                                   "debitos": _centavos(vals[1])}
            fim = i
            break
    trecho = linhas[inicio + 1:fim]

    # 2) Acha as ancoras e casa cada uma com o seu historico.
    ancoras = []
    for i, l in enumerate(trecho):
        if _e_ancora(l):
            ancoras.append(i)
    consumidas = set()
    brutos = []
    for i in ancoras:
        data, inline, doc, valor, saldo = _quebrar_ancora(trecho[i])
        historico = ""
        if re.search(r"[A-Za-zÀ-ÿ]", inline):
            historico = inline           # historico veio na propria ancora
        else:
            for j in range(i - 1, -1, -1):
                if j in ancoras or j in consumidas:
                    break
                if trecho[j].strip():
                    historico = trecho[j].strip()
                    consumidas.add(j)
                break
        brutos.append({"pos": i, "data": data, "documento": doc,
                       "historico": historico, "valor": valor, "saldo": saldo})

    # 3) Complemento = a(s) linha(s) de texto entre esta ancora e a proxima
    #    que nao foram consumidas como historico de outra.
    for n, b in enumerate(brutos):
        proxima = brutos[n + 1]["pos"] if n + 1 < len(brutos) else len(trecho)
        extras = [trecho[j].strip() for j in range(b["pos"] + 1, proxima)
                  if j not in consumidas and j not in ancoras and trecho[j].strip()]
        b["complemento"] = " ".join(extras).strip()

    # 4) Herda a data do dia e monta a saida.
    movimentos = []
    ultima_data = ""
    for n, b in enumerate(brutos):
        if b["data"]:
            ultima_data = b["data"]
        if not ultima_data:
            continue                      # movimento antes da 1a data: descarta
        movimentos.append({
            "id": "EXT%04d" % (n + 1),
            "data": ultima_data,
            "documento": b["documento"],
            "historico": b["historico"],
            "complemento": b["complemento"],
            "valor": b["valor"],
            "natureza": "C" if b["valor"] > 0 else "D",
            "saldo": b["saldo"],
            "_linha": inicio + 1 + b["pos"],
        })

    ag, cc, ini, fim_p = _cabecalho(linhas)
    creditos = sum(m["valor"] for m in movimentos if m["valor"] > 0)
    debitos = sum(m["valor"] for m in movimentos if m["valor"] < 0)

    avisos = []
    if total_relatorio:
        if creditos != total_relatorio["creditos"]:
            avisos.append("A soma dos creditos que li (%.2f) nao bate com o total "
                          "do extrato (%.2f)." % (creditos / 100.0,
                                                  total_relatorio["creditos"] / 100.0))
        if debitos != total_relatorio["debitos"]:
            avisos.append("A soma dos debitos que li (%.2f) nao bate com o total "
                          "do extrato (%.2f)." % (debitos / 100.0,
                                                  total_relatorio["debitos"] / 100.0))
    else:
        avisos.append("O extrato nao trouxe a linha 'Total' — nao consegui "
                      "conferir a leitura contra o proprio relatorio.")

    competencia = ""
    if ini:
        p = ini.split("/")
        competencia = f"{p[1]}/{p[2]}"

    return {"arquivo": nome, "agencia": ag, "conta": cc,
            "periodo": (ini, fim_p), "competencia": competencia,
            "movimentos": movimentos, "total_creditos": creditos,
            "total_debitos": debitos, "total_relatorio": total_relatorio,
            "banco_sugerido": "237",   # layout proprio do Bradesco
            "avisos": avisos}


# --------------------------------------------------------------------------
# BANCO DO BRASIL - "BB Cash / Extrato de conta corrente"
#
# Layout bem diferente do Bradesco: cada movimentacao cabe numa LINHA SO,
# ja com a natureza marcada por um "C" (credito) ou "D" (debito) depois do
# valor - no PDF isso aparece colorido, azul e vermelho:
#
#     05/06/2026 000013105 Pagamento de Boleto 60.501 301,24 D
#     ^data      ^lote     ^historico          ^dcto  ^valor ^natureza
#
# A CONTRAPARTE vem na linha IMEDIATAMENTE ANTERIOR ("EMPRESA BRASILEIRA DE
# CORREIOS E TELEG"), diferente do Bradesco, onde vem na de baixo.
#
# ARMADILHA DO SALDO COLADO: quando o extrato mostra o saldo do dia, ele sai
# GRUDADO no marcador - "1.159,72 C24.123,63 C". Um padrao que exigisse
# espaco (ou \b) depois do C/D perderia justamente essas linhas, e sem erro
# nenhum: some dinheiro do total e a conciliacao "quase fecha". Foi o que
# aconteceu na primeira leitura deste extrato - 4 creditos sumiram, exatos
# R$ 6.501,72.
#
# CONFERENCIA: o BB nao imprime "total de creditos/debitos", mas imprime o
# "Saldo Anterior" e o "S A L D O" final. Entao a conta que fecha a leitura
# e a do proprio extrato: anterior + creditos - debitos == saldo final.
# --------------------------------------------------------------------------
RE_BB_MOV = re.compile(
    r"^(\d{2}/\d{2}/\d{4})\s+(\d+)\s+(.+?)\s+([\d.]+)\s+"
    r"([\d.]*\d,\d{2})\s*([CD])(?![A-Za-z])")
RE_BB_SALDO = re.compile(
    r"^(\d{2}/\d{2}/\d{4})\s+\d+\s+0*\s*(Saldo Anterior|S\s*A\s*L\s*D\s*O)\s+"
    r"([\d.]*\d,\d{2})\s*([CD])", re.I)
RE_BB_ASSINATURA = re.compile(
    r"BB\s*Cash|Extrato de conta corrente|Ag\.\s*origem", re.I)


def _bb_cabecalho(linhas):
    """agencia, conta e competencia do extrato do BB."""
    ag = cc = comp = ""
    texto = " ".join(linhas)
    m = re.search(r"Ag[êe]ncia\s+([\d-]+)", texto, re.I)
    if m:
        ag = m.group(1)
    m = re.search(r"Conta\s+corrente\s+([\d-]+)", texto, re.I)
    if m:
        cc = m.group(1)
    m = re.search(r"(\d{2})\s*/\s*(\d{4})", texto)
    if m:
        comp = f"{m.group(1)}/{m.group(2)}"
    return ag, cc, comp


def _ler_banco_do_brasil(linhas, nome):
    """Layout Banco do Brasil - ver o comentario do bloco acima."""
    if not any(RE_BB_ASSINATURA.search(l) for l in linhas):
        return None

    saldo_anterior = saldo_final = None
    for l in linhas:
        m = RE_BB_SALDO.match(l.strip())
        if not m:
            continue
        valor = _centavos(m.group(3))
        if valor and m.group(4).upper() == "D":
            valor = -valor
        if re.match(r"saldo\s*anterior", m.group(2), re.I):
            saldo_anterior = valor
        else:
            saldo_final = valor

    movimentos = []
    for i, l in enumerate(linhas):
        s = l.strip()
        if RE_BB_SALDO.match(s):
            continue
        m = RE_BB_MOV.match(s)
        if not m:
            continue
        data, _lote, historico, documento, valor_txt, natureza = m.groups()
        if re.search(r"saldo\s*anterior|s\s*a\s*l\s*d\s*o", historico, re.I):
            continue
        valor = _centavos(valor_txt)
        # a contraparte vem na linha ANTERIOR, quando ela nao for outro
        # lancamento nem um pedaco do cabecalho da tabela
        complemento = ""
        if i:
            ant = linhas[i - 1].strip()
            if ant and not RE_BB_MOV.match(ant) and not RE_BB_SALDO.match(ant) \
               and not RE_BB_ASSINATURA.search(ant):
                complemento = ant
        movimentos.append({
            "id": "EXT%04d" % (len(movimentos) + 1),
            "data": data,
            "documento": documento.replace(".", ""),
            "historico": historico.strip(),
            "complemento": complemento,
            "valor": valor if natureza.upper() == "C" else -valor,
            "natureza": natureza.upper(),
            "saldo": None,
            "_linha": i,
        })

    if not movimentos:
        return None

    # o extrato vem em ordem decrescente de data: repoe a ordem cronologica
    def _chave(m):
        d = m["data"].split("/")
        return (d[2], d[1], d[0], m["_linha"])
    movimentos.sort(key=_chave)
    for n, mv in enumerate(movimentos, start=1):
        mv["id"] = "EXT%04d" % n

    creditos = sum(m["valor"] for m in movimentos if m["valor"] > 0)
    debitos = sum(m["valor"] for m in movimentos if m["valor"] < 0)

    avisos = []
    total_relatorio = None
    if saldo_anterior is not None and saldo_final is not None:
        fechado = saldo_anterior + creditos + debitos
        if fechado != saldo_final:
            avisos.append(
                "A leitura nao fecha com o saldo do proprio extrato: "
                "%.2f (anterior) + %.2f (creditos) - %.2f (debitos) = %.2f, "
                "mas o extrato termina em %.2f."
                % (saldo_anterior / 100.0, creditos / 100.0, abs(debitos) / 100.0,
                   fechado / 100.0, saldo_final / 100.0))
        else:
            total_relatorio = {"creditos": creditos, "debitos": debitos}
    else:
        avisos.append("O extrato nao trouxe Saldo Anterior e saldo final — nao "
                      "consegui conferir a leitura contra o proprio relatorio.")

    ag, cc, comp = _bb_cabecalho(linhas)
    ini = fim = ""
    if comp:
        mes, ano = comp.split("/")
        ini = f"01/{mes}/{ano}"
        datas = [m["data"] for m in movimentos]
        fim = max(datas, key=lambda d: (d[6:], d[3:5], d[:2])) if datas else ""

    return {"arquivo": nome, "agencia": ag, "conta": cc,
            "periodo": (ini, fim), "competencia": comp,
            "movimentos": movimentos, "total_creditos": creditos,
            "total_debitos": debitos, "total_relatorio": total_relatorio,
            # o LAYOUT e' o formato proprio do BB - isso identifica a
            # instituicao com seguranca (nada a ver com achar o nome de um
            # banco solto no texto, que poderia ser um fornecedor). Serve so
            # de RESERVA: se o controle financeiro trouxer a coluna Bco
            # preenchida, quem manda e ela.
            "banco_sugerido": "001",
            "avisos": avisos}


# Ordem de tentativa. Cada leitor devolve None quando o arquivo nao e' do
# layout dele, entao acrescentar banco novo aqui e uma linha.
LEITORES = (_ler_banco_do_brasil, _ler_bradesco)


def ler_extrato(caminho, nome_original=""):
    """
    Devolve {"arquivo","agencia","conta","periodo","competencia",
             "movimentos":[...], "total_creditos","total_debitos",
             "total_relatorio", "avisos":[...]}
    Cada movimento: {"id","data","documento","historico","complemento",
                     "valor" (centavos, sinal), "natureza": "C"|"D",
                     "saldo", "_linha"}

    O LAYOUT E DESCOBERTO PELO CONTEUDO, nunca pelo nome do arquivo.
    """
    nome = nome_original or caminho
    linhas = pdftexto.linhas_do_pdf(caminho)
    for leitor in LEITORES:
        dados = leitor(linhas, nome)
        if dados:
            return dados
    raise ValueError("nao reconheci o layout deste extrato (hoje leio "
                     "Bradesco e Banco do Brasil).")
