# -*- coding: utf-8 -*-
"""
core_estoque_apuracao.py - Apuracao do estoque (inventario periodico) e os
lancamentos contabeis que ela gera.

O modulo Estoque Citel ja consolidava o estoque de UM mes. A apuracao precisa
de DOIS: o estoque INICIAL (inventario do mes anterior) e o FINAL (o do mes),
porque e a troca de um pelo outro que forma o CMV do periodo:

    CMV = Estoque Inicial + Compras - Estoque Final

Dai os DOIS lancamentos por filial, na ordem em que a apuracao acontece:
    1) BAIXA do estoque inicial ......  D conta_inicial   C conta (Ativo)
    2) INCORPORACAO do estoque final .  D conta (Ativo)   C conta_final

Depois dos dois, a conta de Ativo fica exatamente com o saldo do inventario
final, e as duas contas de resultado carregam o efeito no CMV. Por isso sao
TRES contas por filial no cadastro (Ativo, inicial e final), nao uma so.

DE ONDE VEM CADA VALOR: do relatorio do Citel ou digitado a mao. O valor
DIGITADO TEM PRIORIDADE - se a pessoa se deu ao trabalho de digitar, foi
porque quis (e se os dois existirem e forem diferentes, sai aviso dizendo
qual foi usado). A origem de cada numero vai no relatorio de conferencia,
para nunca restar duvida de onde saiu.

NUNCA LANCA PELA METADE: filial sem conta cadastrada, ou sem o valor de um
dos lados, nao gera lancamento nenhum daquele lado - fica de fora e sai
avisada. Meio lancamento e' pior que lancamento nenhum.
"""
import core_cartao
import parsers
from xlsxescreve import Aba, Cabecalho, Dinheiro, Negrito, Titulo

# O CSV sai no MESMO formato de importacao do modulo Vendas de Cartao -
# cabecalho "Data;Debito;Credito;Valor;;Historico" (coluna E vazia de
# proposito), valor com virgula decimal e UTF-8 com BOM. O historico usa a
# funcao do proprio core_cartao em vez de uma copia: e' ela que define como o
# texto vai para o importador (maiusculo e SEM ACENTO), e uma copia aqui
# acabaria divergindo no dia em que a regra mudasse la.
CABECALHO_CSV = core_cartao.CABECALHO

ULTIMO_DIA = {1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30,
              7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31}

ROTULO_ORIGEM = {"relatorio": "relatorio Citel", "manual": "digitado",
                 "faltando": "FALTANDO"}


def data_do_lancamento(competencia):
    """'07/2026' -> '31/07/2026' (o inventario e sempre do ultimo dia do mes)."""
    partes = (competencia or "").split("/")
    if len(partes) != 2 or not partes[0].strip().isdigit() or not partes[1].strip().isdigit():
        return ""
    mes, ano = int(partes[0]), int(partes[1])
    if not 1 <= mes <= 12:
        return ""
    dia = ULTIMO_DIA[mes]
    if mes == 2 and (ano % 4 == 0 and (ano % 100 != 0 or ano % 400 == 0)):
        dia = 29
    return "%02d/%02d/%04d" % (dia, mes, ano)


def chave_filial(cadastro):
    """Chave de casamento: o CODIGO da empresa quando existe (nao muda), o
    nome so como alternativa (o nome do arquivo/filial muda todo mes - visto
    na CAMD: 'MATRIZ' em junho, 'FL 01' em julho, mesma empresa 037)."""
    cod = str(cadastro.get("codigo_empresa") or "").strip().lstrip("0")
    return "#" + cod if cod else parsers.norm_txt(cadastro.get("filial"))


def _indexar(inventarios):
    idx = {}
    for inv in inventarios or []:
        cod = (inv.get("codigo_empresa") or "").lstrip("0")
        if cod:
            idx.setdefault("#" + cod, inv)
        nome = parsers.norm_txt(inv.get("filial"))
        if nome:
            idx.setdefault(nome, inv)
    return idx


def contas_da_apuracao(cfg):
    """
    As contrapartidas de RESULTADO da apuracao. Sao UNICAS da empresa (nao
    por filial): o CMV e' apurado no resultado da empresa, enquanto a conta
    de ESTOQUE (Ativo) e' que se divide por filial no balancete.
    Devolve {"inicial": codigo, "final": codigo}.
    """
    contas = cfg.get("contas") or {}
    modo = cfg.get("modo_codigo", "reduzido")

    def _cod(chave):
        c = contas.get(chave) or {}
        valor = ((c.get("classificacao") if modo == "classificacao" else c.get("reduzido"))
                 or c.get("reduzido") or c.get("classificacao") or "")
        return valor.strip()

    return {"inicial": _cod("estoque_inicial"), "final": _cod("estoque_final")}


def montar_saldos(inv_final, inv_inicial, filiais_cadastradas, manuais=None):
    """
    Junta, por filial cadastrada, o estoque inicial e o final.

    manuais: {chave: {"inicial": float|None, "final": float|None}} - chave no
        mesmo formato de chave_filial ("#037" ou o nome normalizado).
    Devolve (saldos, avisos).
    """
    manuais = manuais or {}
    idx_f = _indexar(inv_final)
    idx_i = _indexar(inv_inicial)
    avisos = []
    saldos = []
    usados_f, usados_i = set(), set()

    for cad in (filiais_cadastradas or []):
        chave = chave_filial(cad)
        nome = cad.get("filial") or cad.get("codigo_empresa") or chave
        f = idx_f.get(chave)
        i = idx_i.get(chave)
        if f is not None:
            usados_f.add(id(f))
        if i is not None:
            usados_i.add(id(i))
        man = manuais.get(chave) or {}

        def _escolher(do_relatorio, digitado, rotulo):
            if digitado is not None:
                if do_relatorio is not None and abs(digitado - do_relatorio) > 0.01:
                    avisos.append(
                        "%s: o %s digitado (%s) e diferente do relatorio do Citel "
                        "(%s). Usei o DIGITADO." % (nome, rotulo,
                                                    _brl(digitado), _brl(do_relatorio)))
                return digitado, "manual"
            if do_relatorio is not None:
                return do_relatorio, "relatorio"
            return None, "faltando"

        v_i, o_i = _escolher(i.get("total_bruto") if i else None,
                            man.get("inicial"), "estoque inicial")
        v_f, o_f = _escolher(f.get("total_bruto") if f else None,
                            man.get("final"), "estoque final")

        saldos.append({
            "filial": nome,
            "codigo_empresa": str(cad.get("codigo_empresa") or "").strip(),
            "chave": chave,
            "conta": cad.get("conta", ""),
            "valor_inicial": round(v_i, 2) if v_i is not None else None,
            "valor_final": round(v_f, 2) if v_f is not None else None,
            "origem_inicial": o_i,
            "origem_final": o_f,
            "variacao": (round(v_f - v_i, 2)
                        if (v_i is not None and v_f is not None) else None),
        })

    # Inventario enviado que nao casou com filial cadastrada nao pode sumir
    # em silencio: o total dele ficaria de fora dos lancamentos sem ninguem ver.
    for inv in (inv_final or []):
        if id(inv) not in usados_f:
            avisos.append("O inventario FINAL '%s' (empresa %s) nao casou com "
                          "nenhuma filial cadastrada — ficou de fora."
                          % (inv.get("arquivo"), inv.get("codigo_empresa") or "?"))
    for inv in (inv_inicial or []):
        if id(inv) not in usados_i:
            avisos.append("O inventario INICIAL '%s' (empresa %s) nao casou com "
                          "nenhuma filial cadastrada — ficou de fora."
                          % (inv.get("arquivo"), inv.get("codigo_empresa") or "?"))
    return saldos, avisos


def gerar_lancamentos(saldos, competencia, contas_apuracao):
    """
    Dois lancamentos por filial, contra as contas de resultado da empresa
    (contas_apuracao = {"inicial": codigo, "final": codigo}).
    Devolve (lancamentos, avisos).
    """
    data = data_do_lancamento(competencia)
    comp = (competencia or "").strip()
    lancamentos = []
    avisos = []
    contas_apuracao = contas_apuracao or {}

    for s in saldos:
        nome = s["filial"]
        if not s["conta"]:
            avisos.append("%s: sem a conta de ESTOQUE do balancete no De-Para da "
                          "apuracao — nenhum lancamento gerado para esta filial." % nome)
            continue
        for rotulo, campo_valor, campo_conta, debita_estoque in (
                ("ESTOQUE INICIAL", "valor_inicial", "inicial", False),
                ("ESTOQUE FINAL", "valor_final", "final", True)):
            valor = s[campo_valor]
            contrapartida = contas_apuracao.get(campo_conta) or ""
            if valor is None:
                avisos.append("%s: %s nao informado (nem relatorio, nem digitado) — "
                              "lancamento nao gerado." % (nome, rotulo.lower()))
                continue
            if not contrapartida:
                aviso = ("Sem a conta de %s no De-Para da apuracao — nenhum "
                         "lancamento desse tipo foi gerado." % rotulo.lower())
                if aviso not in avisos:      # e' uma conta so da empresa:
                    avisos.append(aviso)     # avisar uma vez, nao por filial
                continue
            if round(valor, 2) == 0:
                continue
            lancamentos.append({
                "data": data,
                "debito": s["conta"] if debita_estoque else contrapartida,
                "credito": contrapartida if debita_estoque else s["conta"],
                "valor": round(valor, 2),
                # maiusculo e sem acento, igual ao CSV do Vendas de Cartao
                "historico": core_cartao._maiusculo(
                    ("%s %s %s" % (rotulo, nome, comp)).strip()),
                "filial": nome,
                "tipo": "final" if debita_estoque else "inicial",
            })
    return lancamentos, avisos


def resumo_apuracao(saldos, lancamentos):
    tot_i = round(sum(s["valor_inicial"] or 0.0 for s in saldos), 2)
    tot_f = round(sum(s["valor_final"] or 0.0 for s in saldos), 2)
    return {
        "filiais": len(saldos),
        "total_inicial": tot_i,
        "total_final": tot_f,
        "variacao": round(tot_f - tot_i, 2),
        "lancamentos": len(lancamentos),
        "sem_inicial": [s["filial"] for s in saldos if s["valor_inicial"] is None],
        "sem_final": [s["filial"] for s in saldos if s["valor_final"] is None],
    }


def _brl(v):
    return ("%.2f" % v).replace(".", ",")


def montar_csv(lancamentos):
    """CSV de importacao, no MESMO layout do modulo Vendas de Cartao:
    Data;Debito;Credito;Valor;;Historico (a coluna E fica vazia de proposito)."""
    linhas = [CABECALHO_CSV]
    for l in lancamentos:
        linhas.append(";".join([l["data"], l["debito"], l["credito"],
                                _brl(l["valor"]), "", l["historico"]]))
    return "\r\n".join(linhas) + "\r\n"


def csv_bytes(lancamentos):
    return montar_csv(lancamentos).encode("utf-8-sig")


def aba_apuracao(saldos, lancamentos, competencia, contas_apuracao=None):
    """Aba de CONFERENCIA: de onde saiu cada numero e o que foi lancado."""
    c = contas_apuracao or {}
    titulo = "APURACAO DO ESTOQUE" + ((" — %s" % competencia) if competencia else "")
    linhas = [[Titulo(titulo)]]
    linhas.append([Negrito("Contas da apuracao:"),
                   "estoque inicial = %s" % (c.get("inicial") or "(nao cadastrada)"),
                   "estoque final = %s" % (c.get("final") or "(nao cadastrada)")])
    linhas.append([])
    linhas.append([Cabecalho("Filial"), Cabecalho("Codigo"), Cabecalho("Conta estoque"),
                   Cabecalho("Estoque inicial"), Cabecalho("Origem"),
                   Cabecalho("Estoque final"), Cabecalho("Origem"), Cabecalho("Variacao")])
    for s in saldos:
        linhas.append([
            s["filial"], s["codigo_empresa"], s["conta"],
            Dinheiro(s["valor_inicial"]) if s["valor_inicial"] is not None else "-",
            ROTULO_ORIGEM.get(s["origem_inicial"], s["origem_inicial"]),
            Dinheiro(s["valor_final"]) if s["valor_final"] is not None else "-",
            ROTULO_ORIGEM.get(s["origem_final"], s["origem_final"]),
            Dinheiro(s["variacao"]) if s["variacao"] is not None else "-",
        ])
    r = resumo_apuracao(saldos, lancamentos)
    linhas.append([Negrito("TOTAL"), "", "", Dinheiro(r["total_inicial"]), "",
                   Dinheiro(r["total_final"]), "", Dinheiro(r["variacao"])])
    linhas.append([])
    linhas.append([Cabecalho("Lancamentos gerados")])
    linhas.append([Cabecalho("Data"), Cabecalho("Debito"), Cabecalho("Credito"),
                   Cabecalho("Valor"), Cabecalho("Historico")])
    for l in lancamentos:
        linhas.append([l["data"], l["debito"], l["credito"],
                       Dinheiro(l["valor"]), l["historico"]])

    return Aba("APURACAO", linhas,
               larguras={"A": 26, "B": 10, "C": 14, "D": 16, "E": 15,
                         "F": 16, "G": 15, "H": 16})


def nome_csv(competencia=""):
    comp = (competencia or "").strip().replace("/", "-")
    return ("apuracao_estoque_%s.csv" % comp) if comp else "apuracao_estoque.csv"
