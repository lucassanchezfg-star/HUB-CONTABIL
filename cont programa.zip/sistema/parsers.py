# -*- coding: utf-8 -*-
"""
parsers.py - Deteccao da operadora + leitura dos relatorios de venda de cartao.

Saida padronizada (independente da operadora):
    vendas = [ {"data": "dd/mm/aaaa", "bruto": float, "tarifa": float}, ... ]
    Somente vendas com status APROVADO entram na lista.

Deteccao (pela aba em xl/workbook.xml):
    - aba "CARTOES" (CARTÕES) -> GETNET
    - aba "vendas"           -> REDE

GETNET: xlsx com <dimension ref="A1"/> INVALIDO e strings inline (t="inlineStr"),
        o que faz o openpyxl ler a planilha como VAZIA. Por isso lemos direto do
        XML (zipfile + ElementTree), pegando o sheet pelo nome via workbook.xml + rels.
REDE:   xlsx padrao com sharedStrings -> lido com openpyxl.
CIELO:  aceita tambem o mesmo relatorio "Detalhado de vendas Cielo" exportado
        em PDF (nao so o xlsx) - ver parse_cielo_pdf.
"""
import csv
import io
import re
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from datetime import datetime, date, timedelta

import pdftexto

NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
      "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
NS_M = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
NS_R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"


# --------------------------------------------------------------------------
# Normalizacao de texto e numeros
# --------------------------------------------------------------------------
def norm_txt(s):
    """Maiusculas, sem acento, espacos colapsados. Para comparar cabecalho/status."""
    if s is None:
        return ""
    s = str(s)
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = re.sub(r"\s+", " ", s).strip().upper()
    return s


def parse_numero(v):
    """
    Aceita numero (float/int), "398.0" (ponto), "1.234,56" e "1234,56" (virgula BR).
    Retorna float. Vazio/None -> 0.0.
    """
    if v is None:
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    if s == "" or s == "-":
        return 0.0
    # remover simbolos de moeda e espacos
    s = s.replace("R$", "").replace(" ", "").replace("\xa0", "")
    tem_virgula = "," in s
    tem_ponto = "." in s
    if tem_virgula and tem_ponto:
        # formato BR: ponto = milhar, virgula = decimal -> "1.234,56"
        s = s.replace(".", "").replace(",", ".")
    elif tem_virgula:
        # so virgula -> decimal BR "1234,56"
        s = s.replace(",", ".")
    # so ponto (ex.: "398.0") ou sem separador -> ja esta ok
    try:
        return float(s)
    except ValueError:
        # ultima tentativa: manter apenas digitos, sinal e ponto
        s2 = re.sub(r"[^0-9.\-]", "", s)
        try:
            return float(s2)
        except ValueError:
            return 0.0


def _excel_serial_para_data(serial):
    """Converte serial de data do Excel (base 1900) para date."""
    # Excel: 1 = 1899-12-31 (com o bug do ano 1900 bissexto -> base 1899-12-30)
    base = date(1899, 12, 30)
    try:
        return base + timedelta(days=int(float(serial)))
    except (ValueError, TypeError):
        return None


def _fmt_data(d):
    """date/datetime -> 'dd/mm/aaaa'."""
    if isinstance(d, datetime):
        d = d.date()
    if isinstance(d, date):
        return d.strftime("%d/%m/%Y")
    return None


# --------------------------------------------------------------------------
# Deteccao da operadora
# --------------------------------------------------------------------------
def _abas_do_xlsx(caminho):
    """Retorna lista de nomes de aba (originais) lendo xl/workbook.xml."""
    with zipfile.ZipFile(caminho) as z:
        try:
            xml = z.read("xl/workbook.xml")
        except KeyError:
            return []
    root = ET.fromstring(xml)
    nomes = []
    for sh in root.iter(NS_M + "sheet"):
        nomes.append(sh.get("name", ""))
    return nomes


def _e_pdf(caminho):
    try:
        with open(caminho, "rb") as f:
            return f.read(5) == b"%PDF-"
    except OSError:
        return False


def detectar_operadora(caminho):
    """Retorna 'GETNET', 'REDE', 'CIELO' ou 'STONE' conforme o conteudo do
    arquivo. GetNet/Rede/Stone e o Cielo em planilha vem por xlsx (aba em
    xl/workbook.xml); o Cielo tambem pode vir como PDF do mesmo relatorio
    (ver parse_cielo_pdf)."""
    if _e_pdf(caminho):
        try:
            return "CIELO" if _cielo_pdf_signature(pdftexto.linhas_do_pdf(caminho)) else None
        except Exception:  # noqa: BLE001 - PDF corrompido/ilegivel
            return None
    try:
        abas = [norm_txt(a) for a in _abas_do_xlsx(caminho)]
    except (zipfile.BadZipFile, ET.ParseError, OSError):
        return None
    # CIELO primeiro: a aba do Cielo se chama "vendas_cielo_historico_detalhe1",
    # que contem "VENDAS" mas nao e igual a "VENDAS" (aba da Rede).
    if any("CIELO" in a for a in abas):
        return "CIELO"
    if "CARTOES" in abas:
        return "GETNET"
    if "VENDAS" in abas:
        return "REDE"
    # STONE: aba "Report" (nome genérico), por isso confirmamos pelo cabecalho.
    if "REPORT" in abas and _tem_cabecalho_stone(caminho):
        return "STONE"
    return None


def _tem_cabecalho_stone(caminho):
    """Confirma o Stone pelas colunas exclusivas dele na aba 'Report'."""
    try:
        with zipfile.ZipFile(caminho) as z:
            sheet_path = _sheet_path_por_nome(z, "Report")
            if sheet_path is None:
                return False
            for _rn, cells in _linhas_xml(z, sheet_path, _carregar_shared_strings(z)):
                nomes = {norm_txt(v) for v in cells.values() if v}
                return all(k in nomes for k in STONE_HEADER_OBRIGATORIAS)
    except (zipfile.BadZipFile, ET.ParseError, OSError, KeyError):
        return False
    return False


# --------------------------------------------------------------------------
# Helpers de leitura de XML de planilha (usado no GetNet)
# --------------------------------------------------------------------------
def _sheet_path_por_nome(z, nome_alvo, contem=False):
    """
    Descobre o caminho do worksheet (xl/worksheets/sheetN.xml) cuja aba tem
    o nome informado, cruzando workbook.xml (r:id) com workbook.xml.rels (Target).
    Com contem=True, aceita a primeira aba cujo nome CONTENHA o texto informado
    (usado no Cielo, cujo nome de aba varia: 'vendas_cielo_historico_detalhe1').
    """
    wb = ET.fromstring(z.read("xl/workbook.xml"))
    rid = None
    alvo = norm_txt(nome_alvo)
    for sh in wb.iter(NS_M + "sheet"):
        nome = norm_txt(sh.get("name", ""))
        if (alvo in nome) if contem else (nome == alvo):
            rid = sh.get(NS_R + "id")
            break
    if rid is None:
        return None
    rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
    for rel in rels:
        if rel.get("Id") == rid:
            target = rel.get("Target", "")
            if target.startswith("/"):
                return target.lstrip("/")
            # Targets sao relativos a xl/
            return "xl/" + target.replace("../", "")
    return None


def _col_letras(cell_ref):
    """'AB12' -> 'AB' (letras da coluna)."""
    m = re.match(r"([A-Za-z]+)\d+", cell_ref or "")
    return m.group(1).upper() if m else ""


def _carregar_shared_strings(z):
    """Le xl/sharedStrings.xml -> lista de strings (indice = posicao)."""
    try:
        data = z.read("xl/sharedStrings.xml")
    except KeyError:
        return []
    root = ET.fromstring(data)
    out = []
    for si in root.findall(NS_M + "si"):
        partes = [(te.text or "") for te in si.iter(NS_M + "t")]
        out.append("".join(partes))
    return out


def _valor_celula(c, shared=None):
    """
    Extrai o valor de uma celula <c>, tratando:
      - t='inlineStr' -> <is><t> (GetNet)
      - t='s'         -> indice em sharedStrings (Rede)
      - t='str'       -> formula string em <v>
      - demais        -> <v> literal (numero / serial de data)
    Retorna string (ou None).
    """
    t = c.get("t")
    if t == "inlineStr":
        is_el = c.find(NS_M + "is")
        if is_el is not None:
            partes = [(te.text or "") for te in is_el.iter(NS_M + "t")]
            return "".join(partes)
        return None
    v = c.find(NS_M + "v")
    if v is None:
        return None
    if t == "s" and shared is not None:
        try:
            return shared[int(v.text)]
        except (ValueError, IndexError, TypeError):
            return v.text
    return v.text


def _num_para_col(i):
    """0 -> 'A', 25 -> 'Z', 26 -> 'AA' (indice posicional -> letra de coluna)."""
    letras = ""
    i += 1
    while i > 0:
        i, resto = divmod(i - 1, 26)
        letras = chr(65 + resto) + letras
    return letras


def _linhas_xml(z, sheet_path, shared=None):
    """
    Gera (num_linha, {COL: valor}) para cada <row>, ignorando o dimension.
    Varre TODOS os <row> presentes. Resolve sharedStrings quando 'shared' e dado.

    Robustez: no OOXML os atributos 'r' de <row> e <c> sao OPCIONAIS. O xlsx do
    Stone, por exemplo, vem sem <dimension> e sem 'r' nas celulas. Quando faltam,
    usamos a POSICAO (linha sequencial / indice da celula) como referencia.
    """
    data = z.read(sheet_path)
    root = ET.fromstring(data)
    sheet_data = root.find(NS_M + "sheetData")
    if sheet_data is None:
        return
    seq = 0
    for row in sheet_data.findall(NS_M + "row"):
        seq += 1
        try:
            rn = int(row.get("r"))
        except (TypeError, ValueError):
            rn = seq  # sem 'r': usa a posicao sequencial da linha
        cells = {}
        for idx, c in enumerate(row.findall(NS_M + "c")):
            col = _col_letras(c.get("r", "")) or _num_para_col(idx)
            cells[col] = _valor_celula(c, shared)
        yield rn, cells


# --------------------------------------------------------------------------
# Leitura generica de tabela (.csv ou .xlsx) -> [[str, ...], ...]
#
# Usada pelos relatorios que nao sao de cartao (titulos, inventario). Fica
# aqui, e nao no modulo de cada rotina, porque ja sao tres modulos lendo o
# mesmo par de formatos.
# --------------------------------------------------------------------------
def ler_tabela(caminho):
    """Le .csv (latin-1/utf-8, separador ';' ou ',') ou .xlsx -> [[str, ...], ...]."""
    if caminho.lower().endswith((".xlsx", ".xlsm")):
        return _linhas_xlsx(caminho)
    return _linhas_csv(caminho)


def _linhas_csv(caminho):
    with open(caminho, "rb") as f:
        bruto = f.read()
    texto = None
    for cod in ("utf-8-sig", "latin-1"):
        try:
            texto = bruto.decode(cod)
            break
        except UnicodeDecodeError:
            continue
    if texto is None:
        texto = bruto.decode("latin-1", "replace")
    amostra = texto[:4000]
    sep = ";" if amostra.count(";") >= amostra.count(",") else ","
    # csv.reader (e nao split) porque estes relatorios tem campo com QUEBRA DE
    # LINHA dentro das aspas - quebrar por "\n" partiria o registro no meio.
    return [[(c or "") for c in linha]
            for linha in csv.reader(io.StringIO(texto), delimiter=sep)]


def _linhas_xlsx(caminho):
    linhas = []
    with zipfile.ZipFile(caminho) as z:
        shared = _carregar_shared_strings(z)
        caminho_aba = None
        try:
            wb = z.read("xl/workbook.xml")
        except KeyError:
            wb = b""
        if wb:
            m = re.search(rb'name="([^"]+)"', wb)
            if m:
                caminho_aba = _sheet_path_por_nome(
                    z, m.group(1).decode("utf-8", "replace"))
        if caminho_aba is None:
            nomes = [n for n in z.namelist()
                     if n.startswith("xl/worksheets/") and n.endswith(".xml")]
            if not nomes:
                return []
            caminho_aba = sorted(nomes)[0]
        for _rn, celulas in _linhas_xml(z, caminho_aba, shared):
            if not celulas:
                linhas.append([])
                continue
            ordenadas = sorted(celulas.items(),
                               key=lambda kv: (len(kv[0]), kv[0]))
            linhas.append([("" if v is None else str(v)) for _c, v in ordenadas])
    return linhas


def limpo(c):
    """Valor de celula sem aspas nem espacos nas pontas."""
    return str(c or "").strip().strip('"').strip()


# --------------------------------------------------------------------------
# GETNET
# --------------------------------------------------------------------------
# Cabecalho na linha 8; dados a partir da linha 9.
GETNET_HEADER_ROW = 8
GETNET_MAP = {
    "data": "DATA/HORA DA VENDA",
    "status": "STATUS DA TRANSACAO",
    "bruto": "VALOR BRUTO",
    "tarifa": "VALOR TAXA",
    "liquido": "VALOR LIQUIDO",
}


def parse_getnet(caminho):
    """Le o relatorio GetNet (aba CARTOES) direto do XML. Retorna lista de vendas."""
    with zipfile.ZipFile(caminho) as z:
        sheet_path = _sheet_path_por_nome(z, "CARTOES")
        if sheet_path is None:
            raise ValueError("Aba 'CARTOES' nao encontrada no arquivo GetNet.")

        header_cols = {}   # nome_normalizado -> letra da coluna
        vendas = []
        for rn, cells in _linhas_xml(z, sheet_path):
            if rn == GETNET_HEADER_ROW:
                for col, val in cells.items():
                    header_cols[norm_txt(val)] = col
                continue
            if rn < GETNET_HEADER_ROW or not header_cols:
                continue

            def get(campo):
                col = header_cols.get(GETNET_MAP[campo])
                return cells.get(col) if col else None

            status = norm_txt(get("status"))
            if status != "APROVADA":
                continue

            data_raw = get("data")  # "dd/mm/aaaa hh:mm"
            data_fmt = _getnet_data(data_raw)
            if not data_fmt:
                continue

            bruto = parse_numero(get("bruto"))
            tarifa = abs(parse_numero(get("tarifa")))  # VALOR TAXA vem NEGATIVO
            vendas.append({"data": data_fmt, "bruto": bruto, "tarifa": tarifa})
    return vendas


def _getnet_data(raw):
    """'dd/mm/aaaa hh:mm' -> 'dd/mm/aaaa' (pega os 10 primeiros)."""
    if raw is None:
        return None
    s = str(raw).strip()
    if not s:
        return None
    s10 = s[:10]
    if re.match(r"^\d{2}/\d{2}/\d{4}$", s10):
        return s10
    # fallback: tentar serial ou datetime
    try:
        d = _excel_serial_para_data(float(s))
        return _fmt_data(d)
    except (ValueError, TypeError):
        return None


# --------------------------------------------------------------------------
# REDE
# --------------------------------------------------------------------------
# Linha 1 = titulo; Linha 2 = cabecalho; dados a partir da linha 3.
REDE_MAP = {
    "data": "DATA DA VENDA",
    "status": "STATUS DA VENDA",
    "bruto": "VALOR DA VENDA ORIGINAL",
    "tarifa": "VALOR TOTAL DAS TAXAS DESCONTADAS (MDR+RECEBIMENTO AUTOMATICO)",
    "liquido": "VALOR LIQUIDO",
}


REDE_HEADER_ROW = 2  # Linha 1 = titulo; Linha 2 = cabecalho; dados a partir da 3.


def parse_rede(caminho):
    """
    Le o relatorio Rede (aba 'vendas') direto do XML (zipfile + ElementTree),
    resolvendo sharedStrings. Nao depende de openpyxl. Retorna lista de vendas.
    """
    with zipfile.ZipFile(caminho) as z:
        sheet_path = _sheet_path_por_nome(z, "vendas")
        if sheet_path is None:
            raise ValueError("Aba 'vendas' nao encontrada no arquivo Rede.")
        shared = _carregar_shared_strings(z)

        header_cols = {}   # nome_normalizado -> letra da coluna
        vendas = []
        for rn, cells in _linhas_xml(z, sheet_path, shared):
            if rn == REDE_HEADER_ROW:
                for col, val in cells.items():
                    header_cols[norm_txt(val)] = col
                continue
            if rn <= REDE_HEADER_ROW or not header_cols:
                continue

            def get(campo):
                col = header_cols.get(REDE_MAP[campo])
                return cells.get(col) if col else None

            status = norm_txt(get("status"))
            if status != "APROVADA":
                continue

            data_fmt = _rede_data(get("data"))
            if not data_fmt:
                continue

            bruto = parse_numero(get("bruto"))
            tarifa = abs(parse_numero(get("tarifa")))
            vendas.append({"data": data_fmt, "bruto": bruto, "tarifa": tarifa})
    return vendas


def _rede_data(v):
    """
    Data da venda da Rede -> 'dd/mm/aaaa'. Aceita:
      - datetime/date
      - serial numerico do Excel (int/float ou string "46203.0")
      - string ja formatada "dd/mm/aaaa..."
    """
    if v is None:
        return None
    if isinstance(v, (datetime, date)):
        return _fmt_data(v)
    if isinstance(v, (int, float)):
        return _fmt_data(_excel_serial_para_data(v))
    s = str(v).strip()
    if s == "":
        return None
    if re.match(r"^\d{2}/\d{2}/\d{4}", s):
        return s[:10]
    # serial do Excel armazenado como string numerica ("46203" ou "46203.0")
    if re.match(r"^\d+(\.\d+)?$", s):
        return _fmt_data(_excel_serial_para_data(s))
    return None


# --------------------------------------------------------------------------
# CIELO
# --------------------------------------------------------------------------
# Aba "vendas_cielo_historico_detalhe1". Antes do cabecalho ha um preambulo
# (dados do estabelecimento, filtros e um bloco "Totalizador"), por isso a
# linha do cabecalho NAO e fixa: e localizada procurando as colunas exigidas.
CIELO_MAP = {
    "data": "DATA DA VENDA",
    "status": "STATUS DA VENDA",
    "bruto": "VALOR BRUTO",
    "tarifa": "TAXA/TARIFA",
    "liquido": "VALOR LIQUIDO",
}
# Colunas que identificam a linha de cabecalho do detalhado.
CIELO_HEADER_OBRIGATORIAS = ("DATA DA VENDA", "VALOR BRUTO", "TAXA/TARIFA",
                             "STATUS DA VENDA")


def parse_cielo(caminho):
    """
    Le o relatorio Cielo (aba 'vendas_cielo_historico_detalhe1') direto do XML.

    Somente vendas com STATUS DA VENDA == 'Aprovada'. Entram TODAS as formas de
    pagamento do relatorio, inclusive Pix (o relatorio da Cielo traz Pix junto
    com o cartao) — assim o total confere com o proprio 'Totalizador' do arquivo.
    'TAXA/TARIFA' vem NEGATIVA -> usa o valor absoluto.
    """
    with zipfile.ZipFile(caminho) as z:
        sheet_path = _sheet_path_por_nome(z, "cielo", contem=True)
        if sheet_path is None:
            raise ValueError("Aba de vendas do Cielo nao encontrada no arquivo.")
        shared = _carregar_shared_strings(z)

        header_cols = {}
        header_row = None
        vendas = []
        for rn, cells in _linhas_xml(z, sheet_path, shared):
            # 1) localizar a linha do cabecalho (ignora o preambulo/totalizador)
            if header_row is None:
                nomes = {norm_txt(v): col for col, v in cells.items() if v}
                if all(k in nomes for k in CIELO_HEADER_OBRIGATORIAS):
                    header_cols = nomes
                    header_row = rn
                continue
            if rn <= header_row:
                continue

            def get(campo):
                col = header_cols.get(CIELO_MAP[campo])
                return cells.get(col) if col else None

            if norm_txt(get("status")) != "APROVADA":
                continue

            data_fmt = _rede_data(get("data"))  # aceita 'dd/mm/aaaa' ou serial
            if not data_fmt:
                continue

            bruto = parse_numero(get("bruto"))
            tarifa = abs(parse_numero(get("tarifa")))
            vendas.append({"data": data_fmt, "bruto": bruto, "tarifa": tarifa})

        if header_row is None:
            raise ValueError(
                "Cabecalho do relatorio Cielo nao encontrado "
                "(esperadas as colunas DATA DA VENDA / VALOR BRUTO / TAXA/TARIFA)."
            )
    return vendas


# --------------------------------------------------------------------------
# CIELO em PDF - mesmo relatorio "Detalhado de vendas Cielo", exportado sem
# passar pelo xlsx. Cada venda sai numa UNICA linha de texto:
#   "DD/MM/AAAA HH:MM <estabelecimento> <cpf/cnpj> <forma de pagamento> "
#   "<bandeira> R$<bruto> -R$<tarifa> R$<liquido> <status>"
# "Forma de pagamento" (Debito a vista / Credito parcelado loja 02x 02 / Pix)
# e "Bandeira" tem largura VARIAVEL - por isso o meio da linha nao e
# parseado campo a campo: a ANCORA e a data+hora no INICIO e os 3 valores
# monetarios (bruto, tarifa, liquido) + status no FIM, sempre nessa ordem e
# sempre nessa posicao relativa ao fim da linha.
# A tarifa vem com "-" na frente, EXCETO quando e 0,00 (sem sinal) - por
# isso o sinal e opcional no padrao, e o valor absoluto e usado de qualquer
# forma (mesma convencao do parse_cielo via xlsx).
# Conferido contra o proprio "Totalizador" do relatorio (quantidade de
# vendas, valor bruto, taxa/tarifa e valor liquido) - bate exato.
RE_CIELO_PDF_ANCORA = re.compile(r"^\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}\s")
RE_CIELO_PDF_LINHA = re.compile(
    r"^(\d{2}/\d{2}/\d{4})\s+\d{2}:\d{2}\s+.+?\s+"
    r"R\$\s*([\d.,]+)\s+-?R\$\s*([\d.,]+)\s+R\$\s*([\d.,]+)\s+(.+?)\s*$"
)


def _cielo_pdf_signature(linhas):
    """Confirma que o PDF e o relatorio 'Detalhado de vendas Cielo' antes de
    tentar o parse (evita reconhecer por engano outro PDF qualquer)."""
    texto = norm_txt(" ".join(linhas[:40]))
    return "CIELO" in texto and "TAXA/TARIFA" in texto and "VALOR BRUTO" in texto


def parse_cielo_pdf(caminho):
    """Le o relatorio 'Detalhado de vendas Cielo' em PDF (ver o comentario
    do bloco acima). Somente vendas com status 'Aprovada' entram na lista -
    mesma regra do parse_cielo (xlsx)."""
    linhas = pdftexto.linhas_do_pdf(caminho)
    if not _cielo_pdf_signature(linhas):
        raise ValueError(
            "Nao parece ser o relatorio 'Detalhado de vendas Cielo' em PDF.")

    vendas = []
    for l in linhas:
        if not RE_CIELO_PDF_ANCORA.match(l):
            continue
        m = RE_CIELO_PDF_LINHA.match(l)
        if not m:
            continue
        data, bruto, tarifa, liquido, status = m.groups()
        if norm_txt(status) != "APROVADA":
            continue
        vendas.append({"data": data, "bruto": parse_numero(bruto),
                       "tarifa": abs(parse_numero(tarifa))})

    if not vendas:
        raise ValueError(
            "Nenhuma venda 'Aprovada' encontrada no PDF da Cielo.")
    return vendas


# --------------------------------------------------------------------------
# STONE
# --------------------------------------------------------------------------
# Aba "Report", cabecalho na linha 1, dados a partir da linha 2.
# ATENCAO: o xlsx do Stone vem SEM <dimension> e SEM o atributo 'r' nas celulas
# (<c t="inlineStr">), por isso _linhas_xml usa a posicao. Ver _linhas_xml.
STONE_MAP = {
    "data": "DATA DA VENDA",
    "status": "ULTIMO STATUS",
    "bruto": "VALOR BRUTO",
    "liquido": "VALOR LIQUIDO",
    "mdr": "DESCONTO DE MDR",
    "antecipacao": "DESCONTO DE ANTECIPACAO",
    "unificado": "DESCONTO UNIFICADO",
}
STONE_HEADER_OBRIGATORIAS = ("DATA DA VENDA", "VALOR BRUTO", "ULTIMO STATUS",
                             "DESCONTO DE MDR", "DESCONTO UNIFICADO")


def parse_stone(caminho):
    """
    Le o relatorio Stone (aba 'Report') direto do XML.

    Somente 'ULTIMO STATUS' == 'Aprovada'.
    A tarifa e a soma dos TRES descontos (MDR + ANTECIPACAO + UNIFICADO), que vem
    NEGATIVOS -> usa o valor absoluto da soma. Confere: bruto - tarifa = liquido.
    'DATA DA VENDA' vem como "dd/mm/aaaa hh:mm" -> usa somente os 10 primeiros
    caracteres (a HORA e descartada, senao cada horario viraria um "dia").
    """
    with zipfile.ZipFile(caminho) as z:
        sheet_path = _sheet_path_por_nome(z, "Report")
        if sheet_path is None:
            raise ValueError("Aba 'Report' nao encontrada no arquivo Stone.")
        shared = _carregar_shared_strings(z)

        header_cols = {}
        header_row = None
        vendas = []
        for rn, cells in _linhas_xml(z, sheet_path, shared):
            if header_row is None:
                nomes = {norm_txt(v): col for col, v in cells.items() if v}
                if all(k in nomes for k in STONE_HEADER_OBRIGATORIAS):
                    header_cols = nomes
                    header_row = rn
                continue
            if rn <= header_row:
                continue

            def get(campo):
                col = header_cols.get(STONE_MAP[campo])
                return cells.get(col) if col else None

            if norm_txt(get("status")) != "APROVADA":
                continue

            data_fmt = _stone_data(get("data"))
            if not data_fmt:
                continue

            bruto = parse_numero(get("bruto"))
            tarifa = abs(parse_numero(get("mdr"))
                         + parse_numero(get("antecipacao"))
                         + parse_numero(get("unificado")))
            vendas.append({"data": data_fmt, "bruto": bruto, "tarifa": tarifa})

        if header_row is None:
            raise ValueError(
                "Cabecalho do relatorio Stone nao encontrado "
                "(esperadas as colunas DATA DA VENDA / VALOR BRUTO / ULTIMO STATUS)."
            )
    return vendas


def _stone_data(raw):
    """'dd/mm/aaaa hh:mm' -> 'dd/mm/aaaa' (descarta a hora)."""
    if raw is None:
        return None
    s = str(raw).strip()
    if not s:
        return None
    s10 = s[:10]
    if re.match(r"^\d{2}/\d{2}/\d{4}$", s10):
        return s10
    return _rede_data(s)  # fallback: datetime/serial do Excel


# --------------------------------------------------------------------------
# Dispatcher
# --------------------------------------------------------------------------
def parse_arquivo(caminho):
    """
    Detecta a operadora e faz o parse.
    Retorna (operadora, vendas).
    Lanca ValueError se o arquivo nao for reconhecido.
    """
    operadora = detectar_operadora(caminho)
    if operadora == "GETNET":
        return "GETNET", parse_getnet(caminho)
    if operadora == "REDE":
        return "REDE", parse_rede(caminho)
    if operadora == "CIELO":
        if _e_pdf(caminho):
            return "CIELO", parse_cielo_pdf(caminho)
        return "CIELO", parse_cielo(caminho)
    if operadora == "STONE":
        return "STONE", parse_stone(caminho)
    raise ValueError(
        "Arquivo nao reconhecido como GetNet, Rede, Cielo nem Stone. "
        "Esperado .xlsx com aba 'CARTOES' (GetNet), 'vendas' (Rede), "
        "'vendas_cielo...' (Cielo, xlsx ou PDF) ou 'Report' (Stone)."
    )
