# -*- coding: utf-8 -*-
"""
store.py - Cadastro MULTIEMPRESA (o que torna o sistema reutilizavel).

As contas contabeis NUNCA sao hardcoded no motor. Cada empresa tem seu proprio
arquivo em dados/empresas/<slug>.json, com seu de-para de contas (GETNET, REDE,
Clientes, Tarifa). O "estado.json" guarda qual empresa esta ativa (usada por
padrao nas telas). Para uma nova empresa, basta cadastrar em /cadastro (ou criar
o arquivo JSON direto) — o motor e os parsers nao mudam.
"""
import json
import os
import re
import unicodedata

BASE_DIR = os.path.dirname(os.path.abspath(__file__))   # pasta do CODIGO
SEED_PATH = os.path.join(BASE_DIR, "seed.json")


def pasta_dados():
    """
    Os DADOS das empresas ficam na RAIZ do projeto, um nivel acima do
    codigo (ContabilizadorCartao/dados) - assim a pasta que interessa para
    backup fica visivel e separada do sistema.

    O lugar antigo (dados/ ao lado dos .py) continua valendo: se alguem
    copiar so a pasta do sistema para outra maquina, o app acha os dados do
    mesmo jeito, em vez de comecar do zero em silencio.
    """
    raiz = os.path.join(os.path.dirname(BASE_DIR), "dados")
    antigo = os.path.join(BASE_DIR, "dados")
    if not os.path.isdir(raiz) and os.path.isdir(antigo):
        return antigo
    return raiz


DADOS_DIR = pasta_dados()
EMPRESAS_DIR = os.path.join(DADOS_DIR, "empresas")
ESTADO_PATH = os.path.join(DADOS_DIR, "estado.json")
LEGACY_CONFIG_PATH = os.path.join(DADOS_DIR, "config.json")  # formato antigo (1 empresa)

CONTAS_KEYS = ("cartao_getnet", "cartao_rede", "cartao_cielo", "cartao_stone",
               "clientes", "tarifa", "pendencia",
               # modulo FRANCESINHA BB (boletos recebidos). Ficando vazias,
               # core_francesinha usa os padroes 1054 / 47 / 385.
               "francesinha_banco", "francesinha_recebimentos", "francesinha_juros",
               # APURACAO DE ESTOQUE: as contrapartidas de RESULTADO do CMV.
               # Sao UNICAS da empresa (a conta de estoque do balancete e que
               # e' por filial, em estoque_filiais).
               "estoque_inicial", "estoque_final",
               # SISPAG (Itau): o CREDITO de todo pagamento vai sempre para a
               # mesma conta (na ML, a 735 "SISPAG FORNECEDORES ITAU"), e o
               # favorecido que nao for achado no plano de contas cai na conta
               # de RECLASSIFICAR (na ML, a 700). As duas mudam de empresa
               # para empresa - por isso sao cadastro, nunca numero fixo.
               "sispag_credito", "sispag_reclassificar",
               # EXTRATO BANCARIO:
               #   extrato_pagamento - contrapartida PADRAO de toda SAIDA que
               #     nao casar no de-para. Na maioria das empresas e a conta de
               #     pendencia; na ML o escritorio quer tudo na 735 (Sispag
               #     Fornecedores), por isso e um campo proprio - ficando vazio,
               #     o motor volta a usar 'pendencia'.
               #   transferencia - conta usada quando o lancamento e' entre
               #     contas da PROPRIA empresa (mesmo CNPJ raiz). Vale nos dois
               #     sentidos: nao e' receita nem despesa, e transferencia.
               "extrato_pagamento", "transferencia")
MODOS_VALIDOS = ("reduzido", "classificacao")


# --------------------------------------------------------------------------
# Basico: seed, normalizacao, slug
# --------------------------------------------------------------------------
def _load_seed():
    with open(SEED_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def _normalizar_config(cfg):
    """Preenche defaults ausentes usando o seed, para robustez."""
    seed = _load_seed()
    out = {
        "empresa": (cfg.get("empresa") or seed.get("empresa") or "").strip(),
        "modo_codigo": cfg.get("modo_codigo") or seed.get("modo_codigo") or "reduzido",
        "contas": {},
    }
    if out["modo_codigo"] not in MODOS_VALIDOS:
        out["modo_codigo"] = "reduzido"
    contas_in = cfg.get("contas") or {}
    contas_seed = seed.get("contas") or {}
    for key in CONTAS_KEYS:
        c_in = contas_in.get(key) or {}
        c_seed = contas_seed.get(key) or {}
        out["contas"][key] = {
            "reduzido": str(c_in.get("reduzido", c_seed.get("reduzido", "")) or "").strip(),
            "classificacao": str(c_in.get("classificacao", c_seed.get("classificacao", "")) or "").strip(),
            "nome": str(c_in.get("nome", c_seed.get("nome", "")) or "").strip(),
        }

    # --- modulo REGRA: bancos cadastrados (extrato bancario) ---
    out["bancos"] = []
    for b in (cfg.get("bancos") or []):
        conta_contabil = str(b.get("conta_contabil", "") or "").strip()
        out["bancos"].append({
            "banco": str(b.get("banco", "") or "").strip().upper(),
            "agencia": str(b.get("agencia", "") or "").strip(),
            "conta": str(b.get("conta", "") or "").strip(),
            "conta_contabil": conta_contabil,
            # Conta contabil da APLICACAO automatica ligada a esta conta
            # corrente. O banco varre o saldo para a aplicacao todo dia, e a
            # contabilidade guarda as duas coisas em contas SEPARADAS - sem
            # este campo, a auditoria tem de adivinhar qual conta de
            # aplicacao pertence a qual conta corrente (ver
            # core_auditoria_extrato._casar).
            "conta_aplicacao": str(b.get("conta_aplicacao", "") or "").strip(),
            "nome": str(b.get("nome", "") or "").strip(),
            # CODIGO DA FILIAL a que esta conta pertence. Vai numa coluna
            # propria do arquivo de importacao do Ottimizza (ver
            # core_importacao_txt) e nao sai de nenhum extrato - o plano de
            # contas do escritorio traz entre parenteses no nome da conta
            # ("BRADESCO C/C: 1428-1 (165)").
            "filial": str(b.get("filial", "") or "").strip(),
        })

    # --- modulo DE-PARA: padrao do extrato -> conta contabil ---
    out["depara"] = []
    for d in (cfg.get("depara") or []):
        padrao = str(d.get("padrao", "") or "").strip()
        if not padrao:
            continue
        out["depara"].append({
            "padrao": padrao,
            "conta": str(d.get("conta", "") or "").strip(),
            # CONTA POR SENTIDO: quando a mesma contraparte tem uma conta no
            # RECEBIMENTO e outra no PAGAMENTO. Na ML, o que entra do socio e
            # emprestimo a socios (618) e o que sai vai para o Sispag (735).
            # Ficando vazio, vale a 'conta' nos dois sentidos.
            "conta_recebimento": str(d.get("conta_recebimento", "") or "").strip(),
            "nome": str(d.get("nome", "") or "").strip(),
            "tipo": str(d.get("tipo", "") or "").strip().lower() or "fornecedor",
            # HISTORICO FIXO desta regra. Ficando vazio, o lancamento sai com
            # o padrao "PAGAMENTO/RECEBIMENTO <nome>". Preenchido, o texto vai
            # inteiro para a coluna F - serve para os lancamentos em que a
            # descricao do extrato nao ajuda ninguem ("TAR/CUSTAS COBRANCA",
            # "IOF 0285.23260-9/ C/C") e o que interessa e' dizer do que se
            # trata: "VALOR REF. A TARIFA BANCARIA".
            "historico": str(d.get("historico", "") or "").strip(),
        })

    # --- PLANO DE CONTAS: carregado de uma vez a partir do PDF/planilha do
    # escritorio (ver /depara). Usado para autocompletar o "nome" ao
    # cadastrar de-para, e para corrigir os nomes ja cadastrados de uma vez.
    out["plano_contas"] = []
    for c in (cfg.get("plano_contas") or []):
        codigo = str(c.get("codigo", "") or "").strip()
        if not codigo:
            continue
        out["plano_contas"].append({
            "codigo": codigo,
            "classificacao": str(c.get("classificacao", "") or "").strip(),
            "nome": str(c.get("nome", "") or "").strip(),
            "tipo": str(c.get("tipo", "") or "").strip().upper(),
        })

    # --- RECEITA FINANCEIRA: dados que vao no relatorio do fiscal ---
    # A planilha do fiscal identifica a empresa (razao social + CNPJ) e exige o
    # CNPJ da INSTITUICAO FINANCEIRA em cada linha de rendimento. Nada disso sai
    # dos extratos, e muda de empresa para empresa - por isso e cadastro.
    # MODELO DO HISTORICO do extrato bancario:
    #   "padrao"          -> "PAGAMENTO/RECEBIMENTO <nome> <data>"
    #   "valor_referente" -> "VALOR REFERENTE A <descricao do extrato> <data>"
    # Escritorios diferentes escrevem o razao de jeitos diferentes; a FRAGA
    # usa o segundo formato em todo o razao dela, e o lancamento importado
    # tem de ficar igual ao que ja esta la para nao virar duas convencoes na
    # mesma conta.
    #   "bruto"           -> o TEXTO DO BANCO, sem nada na frente
    # O terceiro caso e o da PRECITO: o razao e os arquivos de importacao do
    # mes anterior registram a descricao do banco como ela vem ("TARIFA
    # BANCARIA TRANSF PGTO PIX", "PIX ENVIADO DES PRECITO ATACADO IMPOR
    # 01/07"), sem prefixo e sem data acrescentada - a data do PIX ja vem
    # dentro do texto. Escrever de outro jeito criaria duas convencoes na
    # mesma conta.
    modelo = str(cfg.get("historico_extrato", "") or "").strip().lower()
    out["historico_extrato"] = (modelo if modelo in
                                ("padrao", "valor_referente", "bruto") else "padrao")

    out["cnpj"] = str(cfg.get("cnpj", "") or "").strip()
    out["razao_social"] = str(cfg.get("razao_social", "") or "").strip()
    # Identificacao da empresa na barra de selecao (inspirada no Ottimizza):
    # 'codigo' e o numero dela no sistema contabil - e por ele que o pessoal
    # do escritorio procura, nao pela razao social.
    out["codigo"] = str(cfg.get("codigo", "") or "").strip()
    out["apelido"] = str(cfg.get("apelido", "") or "").strip()
    out["instituicoes"] = []
    for i in (cfg.get("instituicoes") or []):
        nome = str(i.get("nome", "") or "").strip()
        if not nome:
            continue
        out["instituicoes"].append({
            "nome": nome,
            "cnpj": str(i.get("cnpj", "") or "").strip(),
            # Texto da coluna "NATUREZA DO RENDIMENTO" na planilha.
            "descricao": str(i.get("descricao", "") or "").strip(),
            # De onde sai o valor: 'itau', 'bradesco' ou '' (preenchido a mao).
            "origem": str(i.get("origem", "") or "").strip().lower(),
        })

    # --- modulo ESTOQUE CITEL: filial -> conta contabil do estoque ---
    # A ORDEM importa: e a ordem das abas e das linhas no consolidado.
    # 'codigo_empresa' e o codigo da filial no proprio sistema (005, 003...);
    # e por ele que o casamento e feito primeiro, porque o nome digitado da
    # filial diverge com facilidade ("SANTA ROSA" x "MATRIZ").
    out["estoque_filiais"] = []
    for f in (cfg.get("estoque_filiais") or []):
        filial = str(f.get("filial", "") or "").strip().upper()
        codigo_empresa = str(f.get("codigo_empresa", "") or "").strip()
        if not filial and not codigo_empresa:
            continue
        out["estoque_filiais"].append({
            "filial": filial,
            "codigo_empresa": codigo_empresa,
            # conta do ESTOQUE no BALANCETE (Ativo), por filial - a que fica
            # no balanco. As contrapartidas de resultado da apuracao NAO sao
            # por filial: sao unicas da empresa (contas.estoque_inicial /
            # contas.estoque_final), cadastradas no De-Para da apuracao.
            "conta": str(f.get("conta", "") or "").strip(),
            "nome": str(f.get("nome", "") or "").strip(),
        })

    # --- APLICACAO DIARIA: contas POR BANCO. Cada banco tem o seu extrato e
    # pode ter contas contabeis diferentes, por isso o de-para e' por banco
    # (e nao um conjunto so da empresa) - e assim ja cabe o layout dos
    # outros bancos conforme eles forem chegando.
    out["aplicacao_depara"] = {}
    for banco, info in (cfg.get("aplicacao_depara") or {}).items():
        banco = str(banco or "").strip().upper()
        if not banco or not isinstance(info, dict):
            continue
        out["aplicacao_depara"][banco] = {
            "aplicacao": str(info.get("aplicacao", "") or "").strip(),
            "banco": str(info.get("banco", "") or "").strip(),
            "rendimento": str(info.get("rendimento", "") or "").strip(),
            "iof": str(info.get("iof", "") or "").strip(),
            "irrf": str(info.get("irrf", "") or "").strip(),
            # texto do produto que entra no historico quando o arquivo nao o
            # traz (o Excel convertido, por exemplo, perde esse cabecalho)
            "produto": str(info.get("produto", "") or "").strip(),
        }

    # --- AUDITORIA Fiscal: cadastro de acumuladores POR FILIAL - o mesmo
    # codigo de acumulador pode apontar pra contas diferentes em cada
    # filial da empresa (ex.: 509 = matriz, 511/514 = filiais), por isso a
    # estrutura e' {filial: {acumulador: {...}}}, nunca solto. "desconsiderar"
    # marca uma combinacao filial+acumulador que NUNCA deve gerar pendencia
    # nem entrar na confrontacao (decisao do contador, nao um calculo).
    out["fiscal_acumuladores"] = {}
    for filial, acumuladores in (cfg.get("fiscal_acumuladores") or {}).items():
        filial = str(filial or "").strip()
        if not filial or not isinstance(acumuladores, dict):
            continue
        mapa = {}
        for codigo, info in acumuladores.items():
            info = info or {}
            mapa[str(codigo)] = {
                "descricao": str(info.get("descricao", "") or "").strip(),
                "conta_d": str(info.get("conta_d", "") or "").strip() or None,
                "conta_c": str(info.get("conta_c", "") or "").strip() or None,
                "desconsiderar": bool(info.get("desconsiderar")),
            }
        out["fiscal_acumuladores"][filial] = mapa

    # --- AUDITORIA Taxa Cartao: observacao manual por linha do quadro (ex.:
    # "nao bate por causa do aluguel da maquininha, ver fatura da Rede") -
    # a chave e fixa por linha (ver core_auditoria_cartao), o texto e livre e
    # digitado pelo contador; o sistema NUNCA tenta adivinhar/calcular isso.
    out["aud_cartao_obs"] = {}
    for k, v in (cfg.get("aud_cartao_obs") or {}).items():
        texto = str(v or "").strip()
        if texto:
            out["aud_cartao_obs"][str(k)] = texto

    # --- modulos HAC: as regras dos quatro relatorios tratados ---
    # Sao quatro grupos de de-para (conta do ERP, fornecedor, historico do
    # caixa, caixa por loja) mais a lista de contas do ERP que so o Banco
    # Sistema le. As chaves sao livres - os codigos do ERP e os nomes dos
    # fornecedores vem dos relatorios -, entao aqui so se garante o formato:
    # dicionario de texto para texto, lista de textos. Ver core_couto.
    out["couto"] = {}
    for chave in ("contas", "erp", "fornecedores", "caixas", "caixa_historicos"):
        mapa = (cfg.get("couto") or {}).get(chave)
        if isinstance(mapa, dict):
            out["couto"][chave] = {str(k): str(v or "").strip()
                                   for k, v in mapa.items() if str(k).strip()}
    for chave in ("erp_so_banco", "formas_lancadas"):
        lista = (cfg.get("couto") or {}).get(chave)
        if isinstance(lista, list):
            out["couto"][chave] = [str(x).strip() for x in lista if str(x).strip()]
    return out


def _slugify(nome):
    """Nome da empresa -> identificador de arquivo (maiusculo, sem acento, so A-Z0-9_)."""
    s = unicodedata.normalize("NFKD", str(nome or ""))
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_").upper()
    return s or "EMPRESA"


def _slug_unico(base):
    """Garante que o slug nao colida com uma empresa ja cadastrada."""
    slug = base
    n = 2
    while os.path.exists(os.path.join(EMPRESAS_DIR, slug + ".json")):
        slug = f"{base}_{n}"
        n += 1
    return slug


def _ensure_dirs():
    os.makedirs(EMPRESAS_DIR, exist_ok=True)


# --------------------------------------------------------------------------
# Migracao do formato antigo (1 unico dados/config.json)
# --------------------------------------------------------------------------
def _migrar_legado():
    """
    Se existir dados/config.json (formato antigo, 1 empresa so) e ainda nao
    houver nenhuma empresa cadastrada no novo formato, migra o conteudo para
    dados/empresas/<slug>.json e marca como ativa. O arquivo antigo e renomeado
    para config.json.bak (nao e apagado).
    """
    _ensure_dirs()
    if os.listdir(EMPRESAS_DIR):
        return
    if not os.path.exists(LEGACY_CONFIG_PATH):
        return
    with open(LEGACY_CONFIG_PATH, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    cfg = _normalizar_config(cfg)
    slug = _slug_unico(_slugify(cfg["empresa"]))
    _gravar_empresa_arquivo(slug, cfg)
    _salvar_estado({"empresa_ativa": slug})
    try:
        os.replace(LEGACY_CONFIG_PATH, LEGACY_CONFIG_PATH + ".bak")
    except OSError:
        pass


# --------------------------------------------------------------------------
# Leitura/gravacao de arquivos
# --------------------------------------------------------------------------
def _gravar_empresa_arquivo(slug, cfg):
    _ensure_dirs()
    with open(os.path.join(EMPRESAS_DIR, slug + ".json"), "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def _carregar_estado():
    if not os.path.exists(ESTADO_PATH):
        return {}
    with open(ESTADO_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def _salvar_estado(d):
    _ensure_dirs()
    with open(ESTADO_PATH, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)


# --------------------------------------------------------------------------
# API publica - empresas
# --------------------------------------------------------------------------
def listar_empresas():
    """
    [{"slug":..., "nome":...}, ...] ordenado por nome.
    Garante migracao do formato antigo e que exista ao menos 1 empresa
    (criada a partir do seed.json, se necessario).
    """
    _ensure_dirs()
    _migrar_legado()
    out = []
    for fn in sorted(os.listdir(EMPRESAS_DIR)):
        if not fn.endswith(".json"):
            continue
        slug = fn[:-5]
        try:
            with open(os.path.join(EMPRESAS_DIR, fn), "r", encoding="utf-8") as f:
                cfg = json.load(f)
        except (json.JSONDecodeError, OSError):
            continue
        out.append({"slug": slug, "nome": cfg.get("empresa") or slug,
                    "codigo": str(cfg.get("codigo", "") or "").strip(),
                    "cnpj": str(cfg.get("cnpj", "") or "").strip(),
                    "apelido": str(cfg.get("apelido", "") or "").strip()})

    if not out:
        cfg = _normalizar_config(_load_seed())
        slug = _slug_unico(_slugify(cfg["empresa"]))
        _gravar_empresa_arquivo(slug, cfg)
        _salvar_estado({"empresa_ativa": slug})
        out = [{"slug": slug, "nome": cfg["empresa"], "codigo": "",
                "cnpj": "", "apelido": ""}]

    # Ordena pelo CODIGO quando ele existe (e como a lista aparece no sistema
    # contabil); quem ainda nao tem codigo vai para o fim, por nome.
    def _chave(e):
        c = e["codigo"]
        return (0, int(c), "") if c.isdigit() else (1, 0, e["nome"])
    out.sort(key=_chave)
    return out


def empresa_ativa_slug():
    """Slug da empresa ativa (usada como padrao nas telas)."""
    empresas = listar_empresas()
    slugs = {e["slug"] for e in empresas}
    slug = _carregar_estado().get("empresa_ativa")
    if slug in slugs:
        return slug
    slug = empresas[0]["slug"]
    _salvar_estado({"empresa_ativa": slug})
    return slug


def definir_empresa_ativa(slug):
    slugs = {e["slug"] for e in listar_empresas()}
    if slug not in slugs:
        raise ValueError(f"Empresa '{slug}' nao encontrada.")
    _salvar_estado({"empresa_ativa": slug})


def carregar_empresa(slug=None):
    """Le o cadastro de UMA empresa. Sem slug, usa a empresa ativa."""
    if slug is None:
        slug = empresa_ativa_slug()
    caminho = os.path.join(EMPRESAS_DIR, slug + ".json")
    if not os.path.exists(caminho):
        raise ValueError(f"Empresa '{slug}' nao encontrada.")
    with open(caminho, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    return _normalizar_config(cfg)


def salvar_empresa(slug, cfg):
    """Grava o cadastro de UMA empresa existente."""
    slugs = {e["slug"] for e in listar_empresas()}
    if slug not in slugs:
        raise ValueError(f"Empresa '{slug}' nao encontrada.")
    cfg = _normalizar_config(cfg)
    _gravar_empresa_arquivo(slug, cfg)
    return cfg


def _config_em_branco(nome):
    """Cadastro novo SEM nenhuma conta pre-preenchida (o usuario digita as contas)."""
    return {
        "empresa": nome,
        "modo_codigo": "reduzido",
        "contas": {k: {"reduzido": "", "classificacao": "", "nome": ""} for k in CONTAS_KEYS},
        "bancos": [],
        "depara": [],
        "plano_contas": [],
        "estoque_filiais": [],
        "cnpj": "",
        "razao_social": "",
        "codigo": "",
        "apelido": "",
        "instituicoes": [],
    }


def so_digitos(valor):
    return re.sub(r"\D", "", str(valor or ""))


def _digito(numeros, pesos):
    soma = sum(int(n) * p for n, p in zip(numeros, pesos))
    resto = soma % 11
    return 0 if resto < 2 else 11 - resto


def documento_valido(valor):
    """
    True para CPF (11 digitos) ou CNPJ (14) com DIGITO VERIFICADOR correto.

    Conferir so o tamanho deixaria passar numero digitado errado - e o CNPJ
    errado vai parar no relatorio do fiscal, onde o erro so aparece depois.
    Sequencias iguais ('111...') passam no calculo e sao rejeitadas a parte.
    """
    n = so_digitos(valor)
    if len(n) not in (11, 14) or n == n[0] * len(n):
        return False
    if len(n) == 11:
        d1 = _digito(n[:9], range(10, 1, -1))
        d2 = _digito(n[:10], range(11, 1, -1))
    else:
        pesos = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        d1 = _digito(n[:12], pesos)
        d2 = _digito(n[:13], [6] + pesos)
    return n[-2:] == f"{d1}{d2}"


def formatar_documento(valor):
    """Formata CPF/CNPJ para exibicao. Devolve como veio se nao tiver o tamanho."""
    n = so_digitos(valor)
    if len(n) == 14:
        return f"{n[:2]}.{n[2:5]}.{n[5:8]}/{n[8:12]}-{n[12:]}"
    if len(n) == 11:
        return f"{n[:3]}.{n[3:6]}.{n[6:9]}-{n[9:]}"
    return str(valor or "").strip()


def _validar_identificacao(nome, cnpj, codigo, ignorar_slug=None):
    """
    Regras compartilhadas por criar_empresa e atualizar_identificacao.
    'ignorar_slug': ao EDITAR, a propria empresa nao conta como colisao de
    codigo com ela mesma.
    Devolve (cnpj_formatado, codigo_limpo) ou levanta ValueError.
    """
    nome = (nome or "").strip()
    if not nome:
        raise ValueError("Informe o nome da empresa.")
    cnpj = (cnpj or "").strip()
    if cnpj and not documento_valido(cnpj):
        raise ValueError("CPF ou CNPJ invalido.")
    codigo = str(codigo or "").strip()
    if codigo:
        for e in listar_empresas():
            if e["slug"] == ignorar_slug:
                continue
            if e["codigo"] and e["codigo"] == codigo:
                raise ValueError(
                    f"O codigo {codigo} ja e da empresa '{e['nome']}'.")
    return (formatar_documento(cnpj) if cnpj else ""), codigo


def criar_empresa(nome, copiar_de=None, cnpj="", codigo="", apelido=""):
    """
    Cria uma nova empresa. Se 'copiar_de' (slug) for informado, comeca com o
    de-para de contas dessa empresa (util quando varias empresas usam o mesmo
    plano). Sem 'copiar_de', comeca em BRANCO — nenhuma conta e pre-cadastrada
    automaticamente; so tem conta a empresa em que o usuario efetivamente digitar.
    Retorna {"slug":..., "nome":..., "config": cfg}.
    """
    nome = (nome or "").strip()
    cnpj, codigo = _validar_identificacao(nome, cnpj, codigo)
    if copiar_de:
        base = carregar_empresa(copiar_de)
        cfg = dict(base)
        cfg["empresa"] = nome
    else:
        cfg = _config_em_branco(nome)
    cfg["cnpj"] = cnpj
    cfg["codigo"] = codigo
    cfg["apelido"] = (apelido or "").strip()
    listar_empresas()  # garante dirs/migracao antes de checar colisao de slug
    slug = _slug_unico(_slugify(nome))
    cfg = _normalizar_config(cfg)
    _gravar_empresa_arquivo(slug, cfg)
    return {"slug": slug, "nome": nome, "config": cfg}


def atualizar_identificacao(slug, nome, cnpj="", codigo="", apelido=""):
    """
    Edita nome/CNPJ/codigo/apelido de uma empresa JA CADASTRADA - as mesmas
    regras de criar_empresa, mas sem trocar o slug (o arquivo, e tudo que ja
    foi cadastrado nela - contas, de-para, instituicoes - continua no lugar).
    Retorna a config normalizada apos salvar.
    """
    nome = (nome or "").strip()
    cnpj, codigo = _validar_identificacao(nome, cnpj, codigo, ignorar_slug=slug)
    cfg = carregar_empresa(slug)
    cfg["empresa"] = nome
    cfg["cnpj"] = cnpj
    cfg["codigo"] = codigo
    cfg["apelido"] = (apelido or "").strip()
    return salvar_empresa(slug, cfg)


def excluir_empresa(slug):
    """Remove uma empresa. Nao permite excluir a ultima restante."""
    empresas = listar_empresas()
    if len(empresas) <= 1:
        raise ValueError("Nao e possivel excluir a unica empresa cadastrada.")
    if slug not in {e["slug"] for e in empresas}:
        raise ValueError(f"Empresa '{slug}' nao encontrada.")
    os.remove(os.path.join(EMPRESAS_DIR, slug + ".json"))
    if _carregar_estado().get("empresa_ativa") == slug:
        restantes = [e for e in empresas if e["slug"] != slug]
        _salvar_estado({"empresa_ativa": restantes[0]["slug"]})


def codigo_conta(conta, modo):
    """Retorna o codigo da conta conforme o modo (reduzido | classificacao)."""
    if modo == "classificacao":
        return conta.get("classificacao") or conta.get("reduzido") or ""
    return conta.get("reduzido") or conta.get("classificacao") or ""


if __name__ == "__main__":
    for e in listar_empresas():
        print(e["slug"], "->", e["nome"])
    print("ativa:", empresa_ativa_slug())
