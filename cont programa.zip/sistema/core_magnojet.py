# -*- coding: utf-8 -*-
"""
core_magnojet.py - Tratamento e conciliacao de contas pagas e recebidas
contra o extrato bancario.

TUDO EM CENTAVOS INTEIROS. Conciliacao por igualdade de valor com float
erra: 0,1+0,2 != 0,3. Todo valor vira int de centavos na entrada e so volta
a ser decimal na hora de gravar a planilha.

CADA LINHA E USADA NO MAXIMO UMA VEZ. Toda linha do controle e toda linha do
extrato tem id proprio; ao conciliar, as duas pontas sao marcadas como
usadas. Sem isso, o mesmo credito "explicaria" dois titulos e o total
fecharia sozinho, escondendo o erro.

AS QUATRO PASSADAS, nesta ordem (da evidencia mais forte para a mais fraca):
  1. valor exato + MESMA data
  2. valor exato + data proxima (D+1, fim de semana, feriado), so quando a
     contraparte/historico combina OU o candidato e unico
  3. LIQUIDACAO AGRUPADA: um credito no banco = a soma de varios titulos
  4. PAGAMENTO FRACIONADO: um titulo = a soma de varias movimentacoes

Em 3 e 4 a combinacao tem que ser UNICA: havendo duas combinacoes possiveis
para o mesmo valor, nenhuma e' aplicada e o caso vai para revisao. Somar
subconjunto ate dar certo e' o jeito mais facil de "fechar" um numero errado.

O QUE NAO CONCILIOU:
  - movimentacao do banco sem titulo -> entra na planilha final (e dinheiro
    que passou na conta e nao esta no controle);
  - titulo sem movimentacao -> FICA na planilha (a baixa existe no controle)
    e sai listado como pendencia, para o usuario decidir.
"""
import re
import unicodedata
from itertools import combinations

# Expressoes que ELIMINAM o registro nos recebimentos (nunca nos pagamentos).
# A comparacao e' feita sobre o texto normalizado, entao "COMPENSAÇÃO",
# "COMPENSACAO" e "COMPENSAÄÃO" (codificacao corrompida) caem todas aqui.
EXCLUSOES_RECEBIMENTO = ("COMPENSACAO DE ADIANTAMENTOS", "BAIXA POR COMPENSACAO")
CAMPOS_TEXTO_EXCLUSAO = ("historico", "descricao", "motivo", "origem",
                         "natureza", "tp", "nome")

# Palavras que nao ajudam a distinguir uma empresa da outra.
RUIDO_NOME = {"LTDA", "SA", "S", "A", "ME", "EPP", "EIRELI", "CIA", "COM",
              "COMERCIO", "IND", "INDUSTRIA", "DE", "DA", "DO", "DAS", "DOS",
              "E", "EM", "REM", "DEST", "PAGTO", "TED", "PIX", "CC"}

JANELA_DIAS = 7          # diferenca de data aceita quando ha evidencia
MAX_ITENS_GRUPO = 4      # ate 4 titulos numa liquidacao agrupada
MAX_PARTES_FRACAO = 3    # ate 3 movimentacoes para um titulo

STATUS = {
    "individual": "Conciliado",
    "data": "Conciliado com diferenca de data",
    "fracionado": "Conciliado por pagamento fracionado",
    "agrupado": "Conciliado por liquidacao agrupada",
    "ausente_controle": "Ausente no controle",
    "ausente_extrato": "Ausente no extrato",
    "duvidoso": "Correspondencia duvidosa",
}


# --------------------------------------------------------------------------
# Normalizacao
# --------------------------------------------------------------------------
def norm(texto):
    """Maiusculo, sem acento, sem espaco repetido - tolerante a codificacao
    corrompida (o caractere que nao converte simplesmente cai fora)."""
    s = unicodedata.normalize("NFKD", str(texto or ""))
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = s.encode("ascii", "ignore").decode("ascii")
    return re.sub(r"\s+", " ", s).strip().upper()


def centavos(valor):
    return int(round(float(valor or 0) * 100))


def _tokens(nome):
    return {t for t in re.split(r"[^A-Z0-9]+", norm(nome))
            if len(t) >= 3 and t not in RUIDO_NOME}


def parecidos(a, b):
    """Quanto dois nomes/textos combinam: 0 a 1 pela sobreposicao de palavras."""
    ta, tb = _tokens(a), _tokens(b)
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / min(len(ta), len(tb))


def _perto(d1, d2, janela=None):
    """
    True quando as duas datas existem e estao dentro da janela.

    Existe para nao repetir `(_dias(a, b) or 99) <= JANELA`, que tem uma
    armadilha silenciosa: quando as datas sao IGUAIS, _dias devolve 0, e em
    Python `0 or 99` vale 99 - ou seja, os titulos do MESMO DIA (os mais
    provaveis de formar um grupo) eram justamente os descartados.
    """
    d = _dias(d1, d2)
    return d is not None and d <= (JANELA_DIAS if janela is None else janela)


def _dias(d1, d2):
    """Diferenca em dias entre 'dd/mm/aaaa'. None se alguma faltar."""
    import datetime
    def _p(d):
        m = re.match(r"^(\d{2})/(\d{2})/(\d{4})$", str(d or "").strip())
        return datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1))) if m else None
    a, b = _p(d1), _p(d2)
    return abs((a - b).days) if a and b else None


# --------------------------------------------------------------------------
# Exclusoes
# --------------------------------------------------------------------------
def aplicar_exclusoes(registros, fluxo):
    """
    Devolve (mantidos, excluidos). Nos pagamentos nao exclui nada - as regras
    de compensacao sao dos recebimentos (ver EXCLUSOES_RECEBIMENTO).
    Cada excluido leva o "_motivo_exclusao" com a expressao que o pegou.
    """
    if fluxo != "recebimentos":
        return list(registros), []
    mantidos, excluidos = [], []
    for r in registros:
        achou = None
        for campo in CAMPOS_TEXTO_EXCLUSAO:
            texto = norm(r.get(campo))
            for expr in EXCLUSOES_RECEBIMENTO:
                if expr in texto:
                    achou = (expr, campo)
                    break
            if achou:
                break
        if achou:
            r = dict(r)
            r["_motivo_exclusao"] = achou[0]
            r["_campo_exclusao"] = achou[1]
            excluidos.append(r)
        else:
            mantidos.append(r)
    return mantidos, excluidos


# --------------------------------------------------------------------------
# Conciliacao
# --------------------------------------------------------------------------
def _evidencia(item, mov):
    """Forca da evidencia entre um titulo e uma movimentacao (0 a 1)."""
    alvo = " ".join([mov.get("complemento", ""), mov.get("historico", "")])
    forca = parecidos(item.get("nome"), alvo)
    doc = re.sub(r"^0+", "", str(mov.get("documento") or ""))
    num = re.sub(r"^0+", "", str(item.get("numero") or ""))
    if doc and num and doc == num:
        forca = max(forca, 1.0)
    return forca


def conciliar(itens, movimentos):
    """
    itens: registros do controle, ja com "_id" e "_centavos".
    movimentos: do extrato (mesma natureza), com "id" e "valor" em centavos.
    Devolve (elos, itens_sobrando, movs_sobrando, duvidosos).
    Cada elo: {"tipo","itens":[ids],"movs":[ids],"data_extrato","diferenca_dias"}
    """
    livres_i = {i["_id"]: i for i in itens}
    livres_m = {m["id"]: m for m in movimentos}
    elos, duvidosos = [], []

    def _fechar(tipo, ids_i, ids_m, dias=0):
        data = livres_m[ids_m[0]]["data"]
        elos.append({"tipo": tipo, "itens": list(ids_i), "movs": list(ids_m),
                     "data_extrato": data, "diferenca_dias": dias})
        for x in ids_i:
            livres_i.pop(x, None)
        for x in ids_m:
            livres_m.pop(x, None)

    # ---- passada 1: valor exato + mesma data -------------------------------
    for item in sorted(itens, key=lambda r: r["_id"]):
        if item["_id"] not in livres_i:
            continue
        cand = [m for m in livres_m.values()
                if abs(m["valor"]) == item["_centavos"] and m["data"] == item.get("dt_baixa")]
        if len(cand) == 1:
            _fechar("individual", [item["_id"]], [cand[0]["id"]])
        elif len(cand) > 1:
            melhor = max(cand, key=lambda m: _evidencia(item, m))
            if _evidencia(item, melhor) >= 0.5:
                _fechar("individual", [item["_id"]], [melhor["id"]])

    # ---- passada 2: valor exato + data proxima -----------------------------
    for item in sorted(itens, key=lambda r: r["_id"]):
        if item["_id"] not in livres_i:
            continue
        cand = []
        for m in livres_m.values():
            if abs(m["valor"]) != item["_centavos"]:
                continue
            d = _dias(item.get("dt_baixa"), m["data"])
            if d is not None and d <= JANELA_DIAS:
                cand.append((d, m))
        if not cand:
            continue
        if len(cand) == 1:
            d, m = cand[0]
            _fechar("data" if d else "individual", [item["_id"]], [m["id"]], d)
            continue
        # varios candidatos: so decide com evidencia de contraparte/documento
        pontuados = sorted(cand, key=lambda dm: (-_evidencia(item, dm[1]), dm[0]))
        melhor_d, melhor_m = pontuados[0]
        if _evidencia(item, melhor_m) >= 0.5:
            _fechar("data" if melhor_d else "individual",
                    [item["_id"]], [melhor_m["id"]], melhor_d)
        else:
            # empate sem evidencia: pega o mais proximo SO se a data for unica
            por_data = sorted(cand, key=lambda dm: dm[0])
            if len(por_data) > 1 and por_data[0][0] < por_data[1][0]:
                d, m = por_data[0]
                _fechar("data" if d else "individual", [item["_id"]], [m["id"]], d)
            else:
                duvidosos.append({"item": item["_id"], "motivo":
                                  "varios lancamentos no banco com o mesmo valor "
                                  "e sem contraparte que os distinga"})

    # ---- passada 3: liquidacao agrupada (N titulos = 1 movimentacao) -------
    for mov in sorted(livres_m.values(), key=lambda m: m["id"]):
        if mov["id"] not in livres_m:
            continue
        alvo = abs(mov["valor"])
        pool = [i for i in livres_i.values()
                if _perto(i.get("dt_baixa"), mov["data"])
                and i["_centavos"] < alvo]
        if len(pool) < 2:
            continue
        achadas = []
        for n in range(2, min(MAX_ITENS_GRUPO, len(pool)) + 1):
            for combo in combinations(pool, n):
                if sum(i["_centavos"] for i in combo) == alvo:
                    achadas.append(combo)
                    if len(achadas) > 1:
                        break
            if len(achadas) > 1:
                break
        if len(achadas) == 1:
            combo = achadas[0]
            dias = max(_dias(i.get("dt_baixa"), mov["data"]) or 0 for i in combo)
            _fechar("agrupado", [i["_id"] for i in combo], [mov["id"]], dias)
        elif len(achadas) > 1:
            duvidosos.append({"mov": mov["id"], "motivo":
                              "mais de uma combinacao de titulos soma o valor "
                              "deste lancamento — nao agrupei"})

    # ---- passada 4: pagamento fracionado (1 titulo = N movimentacoes) ------
    for item in sorted(livres_i.values(), key=lambda r: r["_id"]):
        if item["_id"] not in livres_i:
            continue
        alvo = item["_centavos"]
        pool = [m for m in livres_m.values()
                if _perto(item.get("dt_baixa"), m["data"])
                and abs(m["valor"]) < alvo]
        if len(pool) < 2:
            continue
        achadas = []
        for n in range(2, min(MAX_PARTES_FRACAO, len(pool)) + 1):
            for combo in combinations(pool, n):
                if sum(abs(m["valor"]) for m in combo) == alvo:
                    achadas.append(combo)
                    if len(achadas) > 1:
                        break
            if len(achadas) > 1:
                break
        if len(achadas) == 1:
            combo = achadas[0]
            if len({m["data"] for m in combo}) == 1:
                dias = _dias(item.get("dt_baixa"), combo[0]["data"]) or 0
                _fechar("fracionado", [item["_id"]], [m["id"] for m in combo], dias)
            else:
                duvidosos.append({"item": item["_id"], "motivo":
                                  "as partes que somam este titulo estao em datas "
                                  "diferentes — deixei para revisao"})
        elif len(achadas) > 1:
            duvidosos.append({"item": item["_id"], "motivo":
                              "mais de uma combinacao de lancamentos soma este "
                              "titulo — nao concilei"})

    return elos, list(livres_i.values()), list(livres_m.values()), duvidosos
