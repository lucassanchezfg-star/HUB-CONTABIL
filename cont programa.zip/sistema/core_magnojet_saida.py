# -*- coding: utf-8 -*-
"""
core_magnojet_saida.py - Roda o fluxo de um lado (pagamentos OU recebimentos)
de ponta a ponta e monta a tabela final de 9 colunas.

    exclusoes -> conciliacao -> correcao de datas -> inclusao dos ausentes
    -> layout final -> conferencia dos totais

O motor de conciliacao em si esta em core_magnojet.py; aqui e' a montagem
da saida e o placar de conferencia.
"""
import re

from core_magnojet import (STATUS, aplicar_exclusoes, centavos, conciliar, norm)

# Cadastro de bancos: codigo -> nome. Usado SO para NOMEAR os lancamentos do
# proprio banco (tarifa, rendimento). O CODIGO nunca e' deduzido do extrato:
# vem da coluna Bco do controle financeiro ou do cadastro da empresa - jamais
# da agencia, da conta ou de um nome que apareca solto no PDF.
BANCOS = {
    "001": "BANCO DO BRASIL S.A.", "033": "BANCO SANTANDER (BRASIL) S.A.",
    "104": "CAIXA ECONOMICA FEDERAL", "237": "BANCO BRADESCO S.A.",
    "341": "ITAU UNIBANCO S.A.", "748": "BANCO COOPERATIVO SICREDI S.A.",
    "077": "BANCO INTER S.A.", "260": "NU PAGAMENTOS S.A.",
    "336": "BANCO C6 S.A.", "422": "BANCO SAFRA S.A.",
}

# Historicos que sao operacao DO BANCO: nao ha contraparte a identificar,
# quem cobrou ou pagou foi o proprio banco. Comparados como PALAVRA INTEIRA
# (\b) para "TAR" nao casar dentro de "ALTERACAO".
OPERACAO_DO_BANCO = ("TARIFA", "TAR", "RENTAB", "CESTA", "IOF", "MANUTENCAO",
                     "PACOTE", "ANUIDADE", "ENCARGOS", "COBRANCA MENSAL")
RE_OPERACAO_DO_BANCO = re.compile(
    r"\b(" + "|".join(OPERACAO_DO_BANCO) + r")\b")

# Prefixos do complemento que dizem o PAPEL de quem vem depois, nao o nome.
# Os mais longos vem primeiro para "DEST" nao ser cortado como "DE".
RE_PREFIXO_PAPEL = re.compile(r"^(REMETENTE|BENEF\w*|DEST\w*|DES|REM|FAV|PARA|DE)\b\.?:?\s*",
                              re.I)

# Frases que aparecem no complemento mas NAO sao nome de contraparte.
NAO_E_NOME = ("VALOR DISPONIVEL", "QUANDO DO REGISTRO", "CONFORME CONTRATO",
              "SALDO", "REF ", "DOC ")

# Tipos de operacao que so dizem COMO o dinheiro andou, nao QUEM recebeu.
SO_TIPO_DE_OPERACAO = ("PAGTO", "TRANSF", "TED", "PIX", "LIQUIDACAO",
                       "DEBITO", "CREDITO", "DOC ")


def nome_da_contraparte(mov, fluxo, codigo_banco):
    """
    Nome que vai na planilha para uma movimentacao que nao estava no
    controle. NUNCA INVENTA: quando o extrato nao identifica ninguem, a
    planilha diz isso com todas as letras, em vez de chutar um fornecedor.
    """
    hist = norm(mov.get("historico"))
    if RE_OPERACAO_DO_BANCO.search(hist):
        return BANCOS.get(codigo_banco, "BANCO NAO IDENTIFICADO NO EXTRATO")

    comp = str(mov.get("complemento") or "").strip()
    # "INTERNET --SIMPLES NACIONAL": antes do "--" vem o CANAL usado, depois
    # o beneficiario de verdade.
    if "--" in comp:
        comp = comp.split("--", 1)[1].strip()
    limpo = RE_PREFIXO_PAPEL.sub("", comp).strip()
    # ruido que o extrato costuma pendurar no fim do nome:
    limpo = re.sub(r"\s+\d{2}/\d{2}(/\d{2,4})?$", "", limpo).strip()   # data
    limpo = re.sub(r"[\s-]*\d{6,}$", "", limpo).strip()                # n. de referencia
    limpo = limpo.rstrip(".").strip()                                  # ponto final
    if limpo and re.search(r"[A-Za-zÀ-ÿ]{3}", limpo) \
       and not any(k in norm(limpo) for k in NAO_E_NOME):
        return limpo
    # sem complemento util, o proprio historico as vezes nomeia (ex.: o nome
    # do tributo num pagamento de guia) - mas so quando nao e' apenas o tipo
    # da operacao bancaria
    bruto = str(mov.get("historico") or "").strip()
    if bruto and not any(k in hist for k in SO_TIPO_DE_OPERACAO):
        return bruto
    return ("Cliente não identificado no extrato" if fluxo == "recebimentos"
            else "Fornecedor não identificado no extrato")


def codigo_banco_do_controle(registros, padrao=""):
    """O codigo que a MAIORIA dos lancamentos do controle traz na coluna Bco."""
    contagem = {}
    for r in registros:
        c = re.sub(r"\D", "", str(r.get("banco") or ""))
        if c:
            c = c.zfill(3)
            contagem[c] = contagem.get(c, 0) + 1
    if contagem:
        return max(contagem.items(), key=lambda kv: kv[1])[0]
    return (re.sub(r"\D", "", str(padrao or "")) or "").zfill(3) if padrao else ""


def _ordem(l):
    """Ordena pela data da baixa. Empate mantem a ordem de entrada (o sort
    do Python e estavel), como pede o layout."""
    p = str(l.get("data") or "").split("/")
    return (p[2], p[1], p[0]) if len(p) == 3 else ("9999", "99", "99")


def processar_fluxo(dados_controle, movimentos, fluxo, codigo_banco=""):
    """
    dados_controle: parsers_financeiro.ler_baixas()
    movimentos: os do extrato DESTE lado (debitos p/ pagamentos, creditos
        p/ recebimentos), de parsers_extrato_mov.
    Devolve {"linhas","resumo","log","pendencias"}.
    """
    registros = dados_controle["registros"]
    mantidos, excluidos = aplicar_exclusoes(registros, fluxo)

    itens = []
    for n, r in enumerate(mantidos, start=1):
        it = dict(r)
        it["_id"] = "CTR%04d" % n
        it["_centavos"] = centavos(r.get("total_baixado"))
        itens.append(it)

    banco = codigo_banco or codigo_banco_do_controle(registros)
    elos, sobra_i, sobra_m, duvidosos = conciliar(itens, movimentos)

    por_id = {i["_id"]: i for i in itens}
    datas_corrigidas = 0
    for elo in elos:
        rotulo = STATUS[elo["tipo"]]
        for iid in elo["itens"]:
            it = por_id[iid]
            it["_status"] = rotulo
            if it.get("dt_baixa") != elo["data_extrato"]:
                it["_data_original"] = it.get("dt_baixa")
                it["dt_baixa"] = elo["data_extrato"]
                datas_corrigidas += 1
    for it in sobra_i:
        it["_status"] = STATUS["ausente_extrato"]

    linhas = []
    for it in itens:
        linhas.append({
            "data": it.get("dt_baixa", ""), "nome": it.get("nome", ""),
            "tp": it.get("tp", ""), "numero": it.get("numero", ""),
            "valor_original": round(it.get("valor_original") or 0.0, 2),
            "juros": round((it.get("juros") or 0.0) + (it.get("correcao") or 0.0), 2),
            "descontos": round((it.get("descontos") or 0.0)
                               + (it.get("abatimentos") or 0.0), 2),
            "total_baixa": round(it.get("total_baixado") or 0.0, 2),
            "banco": banco, "_origem": "controle",
            "_status": it.get("_status", STATUS["ausente_extrato"]),
            "_id": it["_id"], "_data_original": it.get("_data_original", ""),
        })

    incluidos = 0
    for m in sorted(sobra_m, key=lambda x: (_ordem({"data": x["data"]}), x["id"])):
        valor = round(abs(m["valor"]) / 100.0, 2)
        linhas.append({
            "data": m["data"], "nome": nome_da_contraparte(m, fluxo, banco),
            "tp": "", "numero": "",
            "valor_original": valor, "juros": 0.0, "descontos": 0.0,
            "total_baixa": valor, "banco": banco,
            "_origem": "extrato", "_status": STATUS["ausente_controle"],
            "_id": m["id"], "_data_original": "",
        })
        incluidos += 1

    linhas.sort(key=_ordem)

    total_baixa = round(sum(l["total_baixa"] for l in linhas), 2)
    total_original = round(sum(l["valor_original"] for l in linhas), 2)
    alvo = round(abs(sum(m["valor"] for m in movimentos)) / 100.0, 2)

    pendencias = [{"tipo": STATUS["ausente_extrato"], "id": it["_id"],
                   "nome": it.get("nome"),
                   "valor": round(it.get("total_baixado") or 0, 2),
                   "detalhe": "baixa no controle sem movimentacao no banco"}
                  for it in sobra_i]
    pendencias += [{"tipo": STATUS["duvidoso"], **d} for d in duvidosos]

    resumo = {
        "fluxo": fluxo, "banco": banco, "banco_nome": BANCOS.get(banco, ""),
        "origem": len(registros), "excluidos": len(excluidos),
        "mantidos": len(mantidos), "incluidos": incluidos,
        "datas_corrigidas": datas_corrigidas,
        "grupos": sum(1 for e in elos if e["tipo"] == "agrupado"),
        "fracionados": sum(1 for e in elos if e["tipo"] == "fracionado"),
        "conciliados": sum(len(e["itens"]) for e in elos),
        "registros_finais": len(linhas),
        "total_valor_original": total_original,
        "total_baixa": total_baixa, "total_extrato": alvo,
        "confere": abs(total_baixa - alvo) < 0.005,
        "pendencias": len(pendencias),
    }
    log = {
        "excluidos": [{"linha": e.get("_linha"), "nome": e.get("nome"),
                       "motivo": e.get("_motivo_exclusao"),
                       "campo": e.get("_campo_exclusao")} for e in excluidos],
        "elos": elos, "duvidosos": duvidosos,
        "datas_corrigidas": [{"id": l["_id"], "de": l["_data_original"],
                              "para": l["data"], "nome": l["nome"]}
                             for l in linhas if l["_data_original"]],
    }
    return {"linhas": linhas, "resumo": resumo, "log": log,
            "pendencias": pendencias}
