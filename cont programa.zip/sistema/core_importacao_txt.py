# -*- coding: utf-8 -*-
"""
core_importacao_txt.py - Escreve o arquivo de importacao no formato de
COLUNAS ENTRE BARRAS que o escritorio ja usa (o que sai do Ottimizza, com
nome terminando em "_PAGAR.txt").

O FORMATO, tirado dos arquivos de 07/2026 da PRECITO
----------------------------------------------------
    |0000|35370064000169|
    |6000|X||||
    |6100|07/07/2026|2300|2015|5,34||TAR PIX PGTO TRANSF||165||
    |6000|X||||
    |6100|08/07/2026|2319|2015|416000,00||SISPAG FORNECEDORES||165||

    |0000|  cabecalho, uma vez, com o CNPJ da empresa so em digitos
    |6000|  abre o lote de UM lancamento (o "X" e fixo)
    |6100|  o lancamento: data | debito | credito | valor | (vazio) |
            historico | (vazio) | codigo da filial | (vazio)

Cada lancamento vem SEMPRE em par: uma linha |6000| e uma |6100|.

DECIMAL COM VIRGULA e sem separador de milhar ("416000,00"). Escrever com
ponto faria o sistema contabil ler 416000,00 como 416 mil vezes maior ou
recusar a linha.

O CODIGO DA FILIAL nao sai de extrato nenhum: e do cadastro da conta
(store, bancos[].filial). Sem ele a coluna fica vazia - o arquivo continua
valido, mas o lancamento entra sem filial, e e melhor avisar.
"""
import re

CABECALHO = "|0000|%s|"
ABRE_LOTE = "|6000|X||||"
LINHA = "|6100|%s|%s|%s|%s||%s||%s||"


def _digitos(s):
    return re.sub(r"\D", "", str(s or ""))


def _valor(v):
    """1234.5 -> '1234,50' (virgula decimal, sem separador de milhar)."""
    return ("%.2f" % round(float(v or 0.0), 2)).replace(".", ",")


def _limpar(txt):
    """
    Tira as BARRAS do texto e junta os espacos.

    A barra e o separador de coluna: um historico com "S/A" ou "C/C" dentro
    partiria a linha em duas colunas a mais e o sistema recusaria o arquivo
    (ou, pior, leria o valor na coluna errada).
    """
    t = re.sub(r"[|\r\n]+", " ", str(txt or ""))
    return re.sub(r"\s+", " ", t).strip()


def montar(lancamentos, cnpj, filial_por_conta=None):
    """
    lancamentos: [{"data","debito","credito","valor","historico"}] - a mesma
        lista que sai de core_extrato.gerar_lancamentos / core_sispag.
    cnpj: CNPJ da empresa (so os digitos entram no arquivo).
    filial_por_conta: {codigo_da_conta_do_banco: codigo_da_filial}. A filial
        de cada lancamento e a da conta do BANCO que aparece nele (debito ou
        credito), que e o criterio dos arquivos do escritorio.

    Devolve o texto do arquivo.
    """
    mapa = filial_por_conta or {}
    linhas = [CABECALHO % _digitos(cnpj)]
    for l in lancamentos:
        deb = str(l.get("debito") or "").strip()
        cre = str(l.get("credito") or "").strip()
        # A FILIAL DO PROPRIO LANCAMENTO manda. No estoque as 6 lojas usam as
        # MESMAS contas (56 contra 2402/2403) e so a filial muda - um mapa
        # conta->filial colapsaria as seis numa. No extrato bancario nao ha
        # esse campo, e ai a filial sai da conta do banco.
        filial = (str(l.get("filial") or "").strip()
                  or mapa.get(deb) or mapa.get(cre) or "")
        linhas.append(ABRE_LOTE)
        linhas.append(LINHA % (l.get("data") or "", deb, cre,
                               _valor(l.get("valor")),
                               _limpar(l.get("historico")), filial))
    return "\r\n".join(linhas) + "\r\n"


def bytes_txt(lancamentos, cnpj, filial_por_conta=None):
    """
    O arquivo em bytes, em LATIN-1 (cp1252).

    Os arquivos do escritorio vem nessa codificacao, e o sistema contabil que
    os le espera um byte por caractere; gravar em UTF-8 faria "TARIFA" passar
    e "MOVIMENTAÇÃO" virar lixo no meio do historico.
    """
    return montar(lancamentos, cnpj, filial_por_conta).encode("latin-1",
                                                              "replace")


def filiais_dos_bancos(cfg):
    """{conta contabil do banco: codigo da filial}, do cadastro da empresa."""
    out = {}
    for b in cfg.get("bancos") or []:
        cc = str(b.get("conta_contabil") or "").strip()
        if not cc:
            continue
        filial = str(b.get("filial") or "").strip()
        if not filial:
            # o plano do escritorio poe a filial no fim do nome da conta:
            # "BRADESCO C/C: 1428-1 (165)"
            m = re.search(r"\((\d{2,4})\)\s*$", str(b.get("nome") or ""))
            filial = m.group(1) if m else ""
        if filial:
            out[cc] = filial
    return out


def nome_arquivo(empresa_slug, rotulo, competencia):
    """Nome no estilo dos arquivos do escritorio, mas legivel."""
    comp = re.sub(r"[^0-9]", "-", str(competencia or "")).strip("-")
    base = re.sub(r"[^A-Za-z0-9]+", "_", "%s_%s" % (empresa_slug, rotulo)).strip("_")
    return "%s_%s_PAGAR.txt" % (base, comp or "importacao")
