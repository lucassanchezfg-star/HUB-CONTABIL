# -*- coding: utf-8 -*-
"""
core_auditoria_cartao.py - Confronta os RELATORIOS DE VENDAS DE CARTAO
(GetNet/Rede/Cielo/Stone, o mesmo parsers.py do modulo CONTABIL) com o
BALANCETE, para saber se o que os relatorios mostram bate com o que foi
lancado na contabilidade.

AS CONTAS NUNCA SAO HARDCODED: usa o MESMO cadastro que ja existe para gerar
o CSV de vendas de cartao (store.py / /cadastro) - contas["cartao_<operadora>"]
(uma "a receber" por operadora) e contas["tarifa"] (1 unica despesa de
tarifa, compartilhada entre operadoras). Nao existe cadastro paralelo -
mudar a conta aqui e em /cadastro e a MESMA coisa (grava no mesmo lugar).

DUAS COMPARACOES, contra o DEBITO da conta no periodo (nao o saldo final):
  1. VENDAS (por operadora): soma do "bruto" dos relatorios daquela
     operadora x debito lancado na conta "a receber" dela no balancete.
     Normalmente BATE exato - e o valor bruto da venda que e debitado ali.
  2. TARIFA (todas as operadoras somadas): soma do "tarifa" dos relatorios
     x debito lancado na conta de tarifa no balancete. Pode NAO bater exato
     se a conta acumula outras despesas junto (ex.: aluguel de maquininha) -
     a diferenca e mostrada, nunca escondida.
"""
import store

TOLERANCIA = 0.01

CONTA_KEY_POR_OPERADORA = {"GETNET": "cartao_getnet", "REDE": "cartao_rede",
                           "CIELO": "cartao_cielo", "STONE": "cartao_stone"}
ROTULO_OPERADORA = {"GETNET": "GetNet", "REDE": "Rede", "CIELO": "Cielo",
                    "STONE": "Stone"}


def _so_digitos(s):
    return "".join(ch for ch in str(s or "") if ch.isdigit()).lstrip("0")


def achar_conta(contas_balancete, codigo):
    """Acha a conta do balancete pelo codigo cadastrado (exato primeiro,
    depois por digitos - cobre o codigo vir com zeros a esquerda ou casar
    pela classificacao quando a empresa usa modo_codigo='classificacao')."""
    codigo = (codigo or "").strip()
    if not codigo:
        return None
    for c in contas_balancete:
        if c["codigo"].strip() == codigo:
            return c
    alvo = _so_digitos(codigo)
    if not alvo:
        return None
    for c in contas_balancete:
        if _so_digitos(c["codigo"]) == alvo or _so_digitos(c["classificacao"]) == alvo:
            return c
    return None


def _linha(chave, item, valor_relatorio, codigo_configurado, conta_bal, observacao):
    if not codigo_configurado:
        return {"chave": chave, "item": item, "relatorio": round(valor_relatorio, 2),
                "balancete": None, "diferenca": None,
                "status": "conta_nao_cadastrada", "codigo_configurado": "",
                "observacao": observacao}
    if conta_bal is None:
        return {"chave": chave, "item": item, "relatorio": round(valor_relatorio, 2),
                "balancete": None, "diferenca": None,
                "status": "conta_nao_encontrada",
                "codigo_configurado": codigo_configurado, "observacao": observacao}
    dif = round(valor_relatorio - conta_bal["debito"], 2)
    status = "bate" if abs(dif) <= TOLERANCIA else "nao_bate"
    return {"chave": chave, "item": item, "relatorio": round(valor_relatorio, 2),
            "balancete": round(conta_bal["debito"], 2), "diferenca": dif,
            "status": status, "codigo_configurado": codigo_configurado,
            "observacao": observacao}


def conciliar(resumo_por_operadora, cfg, balancete):
    """
    resumo_por_operadora: {"CIELO": {"bruto":..., "tarifa":...}, ...} - o
        mesmo formato de core_cartao.resumo_por_operadora().
    cfg: cadastro da empresa (store.carregar_empresa) - de onde saem as
        contas cadastradas e as observacoes ja anotadas (cfg["aud_cartao_obs"],
        por CHAVE de linha - ver abaixo).
    balancete: parsers_balancete.ler_balancete().

    Devolve {"quadro": [linha_venda_op1, linha_venda_op2, ..., linha_tarifa],
             "avisos": [...]}. Cada linha tem uma "chave" ESTAVEL (independe
    do rotulo/idioma) para a tela gravar a observacao digitada pelo contador
    de volta no cadastro, sempre no mesmo lugar.
    """
    modo = cfg.get("modo_codigo", "reduzido")
    contas_cfg = cfg.get("contas") or {}
    obs_cfg = cfg.get("aud_cartao_obs") or {}
    contas_bal = balancete["contas"]
    avisos = []
    quadro = []

    for operadora in sorted(resumo_por_operadora):
        resumo = resumo_por_operadora[operadora]
        chave = f"venda_{operadora}"
        conta_chave = CONTA_KEY_POR_OPERADORA.get(operadora)
        codigo_cfg = store.codigo_conta(contas_cfg.get(conta_chave) or {}, modo) if conta_chave else ""
        conta_bal = achar_conta(contas_bal, codigo_cfg)
        rotulo_op = ROTULO_OPERADORA.get(operadora, operadora)
        linha = _linha(chave, f"Vendas cartao - {rotulo_op}", resumo["bruto"],
                      codigo_cfg, conta_bal, obs_cfg.get(chave, ""))
        quadro.append(linha)
        if linha["status"] == "conta_nao_cadastrada":
            avisos.append(f"Nao ha conta 'a receber' cadastrada para {rotulo_op} "
                          f"— cadastre em /cadastro (ou no campo desta tela).")
        elif linha["status"] == "conta_nao_encontrada":
            avisos.append(f"A conta '{codigo_cfg}' ({rotulo_op}) nao foi "
                          f"encontrada no balancete.")

    codigo_tarifa = store.codigo_conta(contas_cfg.get("tarifa") or {}, modo)
    conta_tarifa_bal = achar_conta(contas_bal, codigo_tarifa)
    total_tarifa = round(sum(r["tarifa"] for r in resumo_por_operadora.values()), 2)
    linha_tarifa = _linha("tarifa", "Tarifas/despesas com cartao", total_tarifa,
                          codigo_tarifa, conta_tarifa_bal, obs_cfg.get("tarifa", ""))
    quadro.append(linha_tarifa)
    if linha_tarifa["status"] == "conta_nao_cadastrada":
        avisos.append("Nao ha conta de tarifa de cartao cadastrada — cadastre "
                      "em /cadastro (ou no campo desta tela).")
    elif linha_tarifa["status"] == "conta_nao_encontrada":
        avisos.append(f"A conta de tarifa '{codigo_tarifa}' nao foi encontrada "
                      f"no balancete.")

    return {"quadro": quadro, "avisos": avisos}


ROTULO_STATUS = {"bate": "BATE", "nao_bate": "NAO BATE",
                 "conta_nao_cadastrada": "CONTA NAO CADASTRADA",
                 "conta_nao_encontrada": "CONTA NAO ACHADA NO BALANCETE"}


def montar_planilha(resultado, empresa, periodo):
    import xlsxescreve
    from xlsxescreve import Aba, Cabecalho, Dinheiro, Negrito, Titulo

    linhas = [[Titulo(f"AUDITORIA DE TAXA DE CARTAO — {empresa}")]]
    if periodo:
        linhas.append([Negrito(f"Periodo: {periodo}")])
    linhas.append([])
    linhas.append([Cabecalho("Item"), Cabecalho("Relatorios"), Cabecalho("Balancete"),
                   Cabecalho("Diferenca"), Cabecalho("Situacao"), Cabecalho("Observacao")])
    for l in resultado["quadro"]:
        linhas.append([
            l["item"],
            Dinheiro(l["relatorio"]),
            Dinheiro(l["balancete"]) if l["balancete"] is not None else "-",
            Dinheiro(l["diferenca"]) if l["diferenca"] is not None else "-",
            ROTULO_STATUS.get(l["status"], l["status"]),
            l["observacao"] or "-",
        ])
    if resultado["avisos"]:
        linhas.append([])
        linhas.append([Negrito("Avisos")])
        for a in resultado["avisos"]:
            linhas.append([a])
    aba = Aba("AUDITORIA TAXA CARTAO", linhas,
             larguras={"A": 30, "B": 16, "C": 16, "D": 14, "E": 22, "F": 40})
    buf = __import__("io").BytesIO()
    xlsxescreve.escrever(buf, [aba])
    return buf.getvalue()


def nome_arquivo(empresa, periodo):
    partes = ["AUDITORIA TAXA CARTAO"]
    if empresa:
        partes.append(empresa)
    if periodo:
        partes.append(str(periodo).replace("/", "-"))
    return " ".join(partes) + ".xlsx"
