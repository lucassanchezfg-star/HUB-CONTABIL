# -*- coding: utf-8 -*-
"""
parsers_aplicacao.py - Le a tabela "movimentacao - aplicacoes/resgates
antecipados e vencimentos" do extrato de aplicacao automatica, tanto do
PDF quanto do Excel. E SO ESSA TABELA: o extrato consolidado traz tambem o
movimento da conta corrente e varios resumos, que nao entram aqui.

A tabela tem 7 colunas de valor (a ultima, o saldo, so aparece na ultima
linha de cada dia):

    data | aplicacoes    | valor principal  | rendimento    | IOF    | IRRF   | rendimento     | saldo de principal
         | realizadas R$ | resgat./venc. R$ | bruto pago R$ | retido | retido | liquido pago   | aplicado R$

Cada linha e ou uma APLICACAO (aplicacoes realizadas > 0) ou um RESGATE
(valor principal resgatado > 0) - nunca as duas coisas.

CONFERENCIA EMBUTIDA: o proprio relatorio fecha com uma linha "total". Ela
NAO e usada como fonte dos numeros (a soma vem das linhas lidas), e sim
comparada com essa soma - se as duas divergirem, alguma linha se perdeu na
leitura e o modulo avisa em vez de gerar lancamento faltando.

PDF e EXCEL SAO O MESMO RELATORIO: o Excel e a conversao do PDF, entao os
numeros batem. O leitor aceita os dois porque nem sempre o escritorio tem
os dois em maos.
"""
import os
import re

import parsers
import pdftexto

norm_txt = parsers.norm_txt

# Um valor da tabela: sempre com virgula e 2 casas (no PDF) - ver RE_LINHA.
RE_VALOR = r"-?\d{1,3}(?:\.\d{3})*,\d{2}"
# Linha de dado: data dd/mm + 6 valores obrigatorios + o saldo (opcional).
RE_LINHA = re.compile(
    r"^(\d{2}/\d{2})\s+" + r"\s+".join([f"({RE_VALOR})"] * 6) +
    r"(?:\s+(" + RE_VALOR + r"))?\s*$")
# Secoes que vem DEPOIS da tabela - encerram a leitura de verdade.
RE_FIM_TABELA = re.compile(r"Conta Corrente\s*\||Notas Explicativas|D[ée]bitos autom[áa]ticos", re.I)
RE_TOTAL = re.compile(r"^total\s+" + r"\s+".join([f"({RE_VALOR})"] * 6) + r"\s*$", re.I)

TITULO = "MOVIMENTACAO - APLICACOES/RESGATES"

# Cabecalho da mesma tabela no Excel (comparado sem acento/espaco/quebra).
COLUNAS_XLSX = ("DATA", "APLICACOESREALIZADAS", "VALORPRINCIPALRESGAT",
                "RENDIMENTOBRUTOPAGO", "IOFRETIDO", "IRRFRETIDO",
                "RENDIMENTOLIQUIDOPAGO")
CAMPOS = ("aplicacoes", "resgate", "rend_bruto", "iof", "irrf", "rend_liquido", "saldo")


def _chave(texto):
    return re.sub(r"[^A-Z0-9]", "", norm_txt(texto))


def _num(v):
    if isinstance(v, (int, float)):
        return round(float(v), 2)
    return round(parsers.parse_numero(v), 2)


def _competencia_pdf(linhas):
    """'resumo - mes 06/2026' e, como alternativa, o cabecalho
    'extrato mensal ... jun 2026'."""
    MES = {"JAN": 1, "FEV": 2, "MAR": 3, "ABR": 4, "MAI": 5, "JUN": 6,
           "JUL": 7, "AGO": 8, "SET": 9, "OUT": 10, "NOV": 11, "DEZ": 12}
    for l in linhas:
        m = re.search(r"resumo\s*-\s*m[êe]s\s*(\d{2})/(\d{4})", l, re.I)
        if m:
            return f"{m.group(1)}/{m.group(2)}"
    for l in linhas[:40]:
        m = re.search(r"extrato\s+mensal.*?\b([a-z]{3})\w*\s+(\d{4})", l, re.I)
        if m and _chave(m.group(1))[:3] in MES:
            return "%02d/%s" % (MES[_chave(m.group(1))[:3]], m.group(2))
    return ""


def _identificacao_pdf(linhas):
    """agencia, conta e nome do produto (que vai no historico)."""
    agencia = conta = produto = ""
    for l in linhas[:40]:
        m = re.search(r"ag\s*(\d{3,5})\s*cc\s*([\d-]+)", l, re.I)
        if m:
            agencia, conta = m.group(1), m.group(2)
            break
    # o produto vem logo antes do "resumo - mes": "Aplic Aut Mais (CDB)"
    for i, l in enumerate(linhas):
        if re.search(r"resumo\s*-\s*m[êe]s", l, re.I) and i:
            cand = linhas[i - 1].strip()
            if cand and not re.search(r"\d{2}/\d{4}", cand):
                produto = cand
                break
    return agencia, conta, produto


def _linhas_da_tabela_pdf(linhas):
    """Le SO o trecho da tabela de movimentacao. Devolve (itens, total)."""
    inicio = next((i for i, l in enumerate(linhas)
                   if TITULO in _chave(l)[:len(TITULO.replace(" ", "").replace("-", ""))]
                   or ("MOVIMENTACAO" in _chave(l) and "RESGATES" in _chave(l))), None)
    if inicio is None:
        return [], None
    itens, total = [], None
    for l in linhas[inicio + 1:]:
        m = RE_LINHA.match(l.strip())
        if m:
            g = m.groups()
            itens.append({"data": g[0],
                          **{c: _num(g[i + 1]) for i, c in enumerate(CAMPOS[:6])},
                          "saldo": _num(g[7]) if g[7] else None})
            continue
        m = RE_TOTAL.match(l.strip())
        if m:
            total = {c: _num(v) for c, v in zip(CAMPOS[:6], m.groups())}
            break
        if RE_FIM_TABELA.search(l):
            break
        # QUALQUER OUTRA LINHA E IGNORADA, nao encerra a leitura: quando a
        # tabela vira a pagina, o PDF intercala o rodape da folha, o
        # cabecalho da proxima ("extrato mensal ag ... 013|014") e repete os
        # rotulos das colunas. Uma versao anterior parava na primeira linha
        # "estranha" e truncava a tabela em silencio - no extrato de SANTOS
        # isso fazia o saldo de aplicacao sair 12.562,37 em vez de 29.737,75,
        # sem erro nenhum na tela. So a linha "total" (acima) ou o inicio de
        # outra secao encerram de verdade.
    return itens, total


def _ler_pdf(caminho, nome):
    linhas = pdftexto.linhas_do_pdf(caminho)
    itens, total = _linhas_da_tabela_pdf(linhas)
    if not itens:
        raise ValueError("nao achei a tabela 'movimentacao - aplicacoes/"
                         "resgates antecipados e vencimentos' neste PDF.")
    agencia, conta, produto = _identificacao_pdf(linhas)
    return {"arquivo": nome, "origem": "PDF", "banco": "ITAU",
            "agencia": agencia, "conta": conta, "produto": produto,
            "competencia": _competencia_pdf(linhas), "itens": itens,
            "total_relatorio": total}


def _ler_xlsx(caminho, nome):
    """
    Procura, em QUALQUER aba, a linha de cabecalho da tabela - o nome da aba
    nao serve de pista (no arquivo real ela se chama "Planilha1", enquanto a
    aba do extrato de conta corrente se chama "Table 1").
    """
    import zipfile
    with zipfile.ZipFile(caminho) as z:
        shared = parsers._carregar_shared_strings(z)
        for aba in parsers._abas_do_xlsx(caminho):
            sp = parsers._sheet_path_por_nome(z, aba)
            if not sp:
                continue
            linhas = list(parsers._linhas_xml(z, sp, shared))
            cab_row = cols = None
            for rn, cells in linhas:
                mapa = {}
                for col, val in cells.items():
                    k = _chave(val)
                    for alvo in COLUNAS_XLSX:
                        if k.startswith(alvo):
                            mapa.setdefault(alvo, col)
                if len(mapa) >= 6:
                    cab_row, cols = rn, mapa
                    break
            if cab_row is None:
                continue

            ordem = ["DATA"] + list(COLUNAS_XLSX[1:])
            itens = []
            for rn, cells in linhas:
                if rn <= cab_row:
                    continue
                data = str(cells.get(cols.get("DATA")) or "").strip()
                if not re.match(r"^\d{2}/\d{2}", data):
                    continue
                vals = [cells.get(cols.get(a)) for a in ordem[1:]]
                if all(v in (None, "") for v in vals):
                    continue
                item = {"data": data[:5]}
                for campo, v in zip(CAMPOS[:6], vals):
                    item[campo] = _num(v) if v not in (None, "") else 0.0
                item["saldo"] = None
                itens.append(item)
            if itens:
                return {"arquivo": nome, "origem": "Excel", "banco": "ITAU",
                        "agencia": "", "conta": "", "produto": "",
                        "competencia": "", "itens": itens, "total_relatorio": None}
    raise ValueError("nao achei a tabela de movimentacao de aplicacoes neste "
                     "Excel (esperava as colunas data / aplicacoes realizadas / "
                     "valor principal resgat. / rendimento bruto / IOF / IRRF).")


def detectar(caminho):
    try:
        return bool(ler_aplicacao(caminho))
    except Exception:  # noqa: BLE001
        return False


def ler_aplicacao(caminho, nome_original=""):
    """
    Devolve {"arquivo","origem","banco","agencia","conta","produto",
             "competencia","itens":[...], "total_relatorio", "totais",
             "avisos":[...]}.
    Cada item: {data, aplicacoes, resgate, rend_bruto, iof, irrf,
                rend_liquido, saldo}.
    """
    nome = nome_original or os.path.basename(caminho)
    with open(caminho, "rb") as f:
        e_pdf = f.read(5) == b"%PDF-"
    dados = _ler_pdf(caminho, nome) if e_pdf else _ler_xlsx(caminho, nome)

    somas = {c: round(sum(i[c] for i in dados["itens"]), 2) for c in CAMPOS[:6]}
    dados["totais"] = somas
    avisos = []

    tr = dados.get("total_relatorio")
    if tr:
        ROTULO = {"aplicacoes": "aplicacoes realizadas",
                  "resgate": "valor principal resgatado",
                  "rend_bruto": "rendimento bruto", "iof": "IOF",
                  "irrf": "IRRF", "rend_liquido": "rendimento liquido"}
        for c in CAMPOS[:6]:
            if abs(tr[c] - somas[c]) > 0.01:
                avisos.append(
                    "A soma de %s que li (%.2f) nao bate com a linha 'total' do "
                    "proprio relatorio (%.2f) — pode ter linha faltando."
                    % (ROTULO[c], somas[c], tr[c]))

    # rendimento bruto tem que ser IOF + IRRF + liquido, linha a linha
    for i in dados["itens"]:
        esperado = round(i["iof"] + i["irrf"] + i["rend_liquido"], 2)
        if abs(i["rend_bruto"] - esperado) > 0.01:
            avisos.append(
                "Dia %s: o rendimento bruto (%.2f) nao fecha com IOF + IRRF + "
                "liquido (%.2f)." % (i["data"], i["rend_bruto"], esperado))

    dados["avisos"] = avisos
    return dados
