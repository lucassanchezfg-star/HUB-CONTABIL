# -*- coding: utf-8 -*-
"""
core_aplicacao.py - Transforma a movimentacao de aplicacao automatica nos
lancamentos contabeis, no MESMO desenho da planilha "importar" que hoje e
montada a mao.

DUAS SITUACOES, so:

  APLICACAO (dinheiro saiu da conta corrente e virou aplicacao) - 1 linha:
      D aplicacao   C banco      pelo valor aplicado

  RESGATE (a aplicacao voltou para a conta corrente, com rendimento) -
  um lancamento de 2 linhas mais um COMPOSTO de ate 4:
      D banco       C aplicacao  pelo PRINCIPAL resgatado      [inicia lote]
      .             C rendimento pelo rendimento BRUTO         [inicia lote]
      D irrf                     pelo IRRF retido        (so se houver)
      D iof                      pelo IOF retido         (so se houver)
      D banco                    pelo rendimento LIQUIDO

  O rendimento bruto e' creditado inteiro na receita e "distribuido" em
  IOF + IRRF + liquido, que e' exatamente a conta que o extrato fecha
  (bruto = IOF + IRRF + liquido) - por isso as quatro linhas formam UM
  lancamento so, amarrado pelo marcador de lote na primeira delas.

ORDEM: todas as aplicacoes primeiro, depois todos os resgates - a mesma
ordem da planilha feita a mao, para a conferencia lado a lado ser direta.

AS CONTAS NAO SAO FIXAS: vem do De-Para por banco (store.aplicacao_depara).
Sem conta cadastrada, o modulo NAO inventa nem lanca pela metade: avisa.
"""
import io
import re

import xlsxescreve
from xlsxescreve import Aba, Cabecalho, Dinheiro, Negrito, Titulo

CABECALHO = ["DATA", "DEBITO", "CREDITO", "VALOR", "HISTORICO", "LOTE"]

# Chave interna -> rotulo na tela do De-Para.
CONTAS = (
    ("aplicacao", "Aplicacao financeira (Ativo)"),
    ("banco", "Banco / conta corrente"),
    ("rendimento", "Rendimento de aplicacao (receita)"),
    ("iof", "IOF sobre rendimento"),
    ("irrf", "IRRF a recuperar"),
)

# Bancos com layout ja implementado. Os demais entram aqui conforme os
# layouts forem chegando - o De-Para ja aceita cadastrar as contas deles.
BANCOS = ("ITAU", "BRADESCO", "SANTANDER", "BANCO DO BRASIL", "CAIXA", "SICREDI")
BANCOS_LIDOS = ("ITAU",)


def nome_produto(bruto, padrao=""):
    """'Aplic Aut Mais (CDB)' -> 'APLIC AUT MAIS - CDB' (como no historico
    escrito a mao). Sem produto no arquivo, usa o cadastrado no De-Para."""
    texto = (bruto or "").strip() or (padrao or "").strip()
    if not texto:
        return ""
    texto = re.sub(r"\s*\(([^)]*)\)\s*$", r" - \1", texto.strip())
    return re.sub(r"\s+", " ", texto).upper()


def _sufixo(produto):
    return (" - " + produto) if produto else ""


def gerar_lancamentos(dados, contas, produto_padrao=""):
    """
    dados: parsers_aplicacao.ler_aplicacao()
    contas: {"aplicacao","banco","rendimento","iof","irrf"} (codigos)
    Devolve {"lancamentos": [...], "resumo": {...}, "avisos": [...]}.
    """
    contas = contas or {}
    faltando = [rot for chave, rot in CONTAS if not (contas.get(chave) or "").strip()]
    if faltando:
        return {"lancamentos": [], "resumo": {}, "avisos": [
            "Sem estas contas no De-Para de aplicacao: " + ", ".join(faltando) +
            ". Nenhum lancamento foi gerado — cadastre e gere de novo."]}

    ano = (dados.get("competencia") or "").split("/")[-1]
    produto = nome_produto(dados.get("produto"), produto_padrao)
    suf = _sufixo(produto)
    avisos = []

    def _data(d):
        """'01/06' -> '01/06/2026' (o extrato so traz dia/mes)."""
        return f"{d}/{ano}" if ano and len(d) == 5 else d

    def _l(data, debito, credito, valor, historico, lote=""):
        return {"data": _data(data), "debito": debito, "credito": credito,
                "valor": round(valor, 2), "historico": historico, "lote": lote}

    aplicacoes, resgates = [], []
    for i in dados["itens"]:
        if i["aplicacoes"] > 0:
            aplicacoes.append(_l(i["data"], contas["aplicacao"], contas["banco"],
                                i["aplicacoes"], "APLICAÇÃO FINANCEIRA" + suf, "1"))
        if i["resgate"] > 0:
            resgates.append(_l(i["data"], contas["banco"], contas["aplicacao"],
                              i["resgate"], "RESGATE DE APLICAÇÃO FINANCEIRA" + suf, "1"))
            if i["rend_bruto"] > 0:
                resgates.append(_l(i["data"], "", contas["rendimento"], i["rend_bruto"],
                                  "RENDIMENTO SOBRE RESGATE DE APLICAÇÃO FINANCEIRA" + suf, "1"))
                if i["irrf"] > 0:
                    resgates.append(_l(i["data"], contas["irrf"], "", i["irrf"],
                                      "IRRF SOBRE RENDIMENTO DE RESGATE DE "
                                      "APLICAÇÃO FINANCEIRA" + suf))
                if i["iof"] > 0:
                    resgates.append(_l(i["data"], contas["iof"], "", i["iof"],
                                      "IOF SOBRE RENDIMENTO DE RESGATE DE "
                                      "APLICAÇÃO FINANCEIRA" + suf))
                if i["rend_liquido"] > 0:
                    resgates.append(_l(i["data"], contas["banco"], "", i["rend_liquido"],
                                      "RENDIMENTO LÍQUIDO DE RESGATE DE "
                                      "APLICAÇÃO FINANCEIRA"))
        if i["aplicacoes"] > 0 and i["resgate"] > 0:
            avisos.append("Dia %s: a linha tem aplicacao E resgate ao mesmo tempo — "
                          "gerei os dois, confira." % i["data"])

    lancamentos = aplicacoes + resgates
    t = dados["totais"]
    # Conferencia contabil: debitos e creditos tem que fechar entre si.
    deb = round(sum(l["valor"] for l in lancamentos if l["debito"]), 2)
    cre = round(sum(l["valor"] for l in lancamentos if l["credito"]), 2)
    if abs(deb - cre) > 0.01:
        avisos.append("Os debitos (%.2f) e os creditos (%.2f) nao fecharam entre "
                      "si — nao importe antes de conferir." % (deb, cre))

    resumo = {
        "aplicacoes": len(aplicacoes), "resgates": sum(1 for i in dados["itens"]
                                                       if i["resgate"] > 0),
        "lancamentos": len(lancamentos),
        "total_aplicado": t["aplicacoes"], "total_resgatado": t["resgate"],
        "rend_bruto": t["rend_bruto"], "iof": t["iof"], "irrf": t["irrf"],
        "rend_liquido": t["rend_liquido"],
        "total_debitos": deb, "total_creditos": cre, "fecha": abs(deb - cre) <= 0.01,
        "contas": dict(contas), "produto": produto,
    }
    return {"lancamentos": lancamentos, "resumo": resumo,
            "avisos": avisos + list(dados.get("avisos") or [])}


def _v(valor):
    return ("%.2f" % valor).replace(".", ",")


def montar_csv(lancamentos):
    """DATA;DEBITO;CREDITO;VALOR;HISTORICO;LOTE - as mesmas colunas, na mesma
    ordem, da planilha 'importar' feita a mao."""
    linhas = [";".join(CABECALHO)]
    for l in lancamentos:
        linhas.append(";".join([l["data"], l["debito"], l["credito"],
                                _v(l["valor"]), l["historico"], l["lote"]]))
    return "\r\n".join(linhas) + "\r\n"


def csv_bytes(lancamentos):
    return montar_csv(lancamentos).encode("utf-8-sig")


def planilha_bytes(dados, resultado):
    """Duas abas: a movimentacao lida (conferencia) e os lancamentos."""
    r = resultado["resumo"]
    mov = [[Titulo("MOVIMENTACAO DE APLICACAO — %s %s" %
                   (dados.get("banco", ""), dados.get("competencia", "")))]]
    if dados.get("produto") or r.get("produto"):
        mov.append([Negrito("Produto:"), r.get("produto") or dados.get("produto")])
    if dados.get("agencia") or dados.get("conta"):
        mov.append([Negrito("Conta:"), "ag %s cc %s" % (dados.get("agencia", ""),
                                                        dados.get("conta", ""))])
    mov.append([])
    mov.append([Cabecalho("Data"), Cabecalho("Aplicacoes"), Cabecalho("Resgate principal"),
                Cabecalho("Rendimento bruto"), Cabecalho("IOF"), Cabecalho("IRRF"),
                Cabecalho("Rendimento liquido")])
    for i in dados["itens"]:
        mov.append([i["data"], Dinheiro(i["aplicacoes"]), Dinheiro(i["resgate"]),
                    Dinheiro(i["rend_bruto"]), Dinheiro(i["iof"]), Dinheiro(i["irrf"]),
                    Dinheiro(i["rend_liquido"])])
    t = dados["totais"]
    mov.append([Negrito("TOTAL"), Dinheiro(t["aplicacoes"]), Dinheiro(t["resgate"]),
                Dinheiro(t["rend_bruto"]), Dinheiro(t["iof"]), Dinheiro(t["irrf"]),
                Dinheiro(t["rend_liquido"])])

    lanc = [[Cabecalho(c) for c in CABECALHO]]
    for l in resultado["lancamentos"]:
        lanc.append([l["data"], l["debito"], l["credito"], Dinheiro(l["valor"]),
                     l["historico"], l["lote"]])

    buf = io.BytesIO()
    xlsxescreve.escrever(buf, [
        Aba("MOVIMENTACAO", mov, larguras={"A": 12, "B": 16, "C": 18, "D": 17,
                                           "E": 12, "F": 12, "G": 18}),
        Aba("LANCAMENTOS", lanc, larguras={"A": 12, "B": 10, "C": 10, "D": 14,
                                           "E": 66, "F": 7}),
    ])
    return buf.getvalue()


def nome_arquivo(empresa_slug, banco, competencia, extensao):
    partes = ["aplicacao_diaria", empresa_slug, (banco or "").lower().replace(" ", "_"),
              (competencia or "").replace("/", "-")]
    return "_".join(p for p in partes if p) + extensao
