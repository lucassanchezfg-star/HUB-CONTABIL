# -*- coding: utf-8 -*-
"""
Cadastro do Conciliador de Cartao (editavel por empresa).
Padrao de fabrica em seed.json; regras em uso em dados/contas.json e dados/config.json.
"""
import os, json

BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
SEED_FILE   = os.path.join(BASE_DIR, 'seed.json')
DADOS_DIR   = os.path.join(BASE_DIR, 'dados')
CONTAS_FILE = os.path.join(DADOS_DIR, 'contas.json')
CONFIG_FILE = os.path.join(DADOS_DIR, 'config.json')

def _seed():
    with open(SEED_FILE, encoding='utf-8') as f:
        return json.load(f)

def seed_contas():
    return _seed()['contas']

def seed_config():
    s = _seed()
    return {'empresa': s.get('empresa', ''), 'cod_padrao': s.get('cod_padrao', 'reduzido'),
            'cartao': s['cartao']}

def _write(path, obj):
    os.makedirs(DADOS_DIR, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def _read(path):
    with open(path, encoding='utf-8') as f:
        return json.load(f)

def ensure_seed():
    os.makedirs(DADOS_DIR, exist_ok=True)
    if not os.path.exists(CONTAS_FILE):
        _write(CONTAS_FILE, seed_contas())
    if not os.path.exists(CONFIG_FILE):
        _write(CONFIG_FILE, seed_config())

def load():
    ensure_seed()
    return _read(CONTAS_FILE), _read(CONFIG_FILE)

def save(contas, config):
    _write(CONTAS_FILE, contas)
    _write(CONFIG_FILE, config)

def restaurar_padrao():
    _write(CONTAS_FILE, seed_contas())
    _write(CONFIG_FILE, seed_config())
