# Conciliador de Vendas de Cartão — CLAUDE.md

App **web local** (Flask, roda em `127.0.0.1:5001`, nada vai para a internet) que lê
**relatórios de vendas de cartão (GetNet e Rede)** e gera **CSV de lançamentos contábeis**.
Projeto **independente e reutilizável por empresa** (as contas ficam no cadastro, nunca no código).
Interface em português, valores em R$. Empresa de referência: CALLIX.

> Projeto **separado** do Integrador de extrato bancário (que fica em
> `...\EXTRATOS BANCÁRIOS\Santander\Integrador Santander\`, porta 5000). Aqui é **só cartão**.

---

## Como rodar
- Duplo-clique em **`Iniciar Conciliador.bat`** (na 1ª vez instala `flask openpyxl`).
- Abre em **http://127.0.0.1:5001**. Encerra fechando a janela preta.
- Porta 5001 de propósito, para rodar junto com o Integrador (5000) sem conflito.

---

## O que faz (fluxo)
1. **Cadastro:** aponta as contas de cartão da empresa (GetNet, Rede, Clientes, Tarifa) e o
   modo de código. Salvar.
2. **Vendas de Cartão:** arrasta os relatórios (GetNet e/ou Rede, pode vários e juntos) →
   **um CSV por relatório** (não consolida) + botão **Baixar todos (ZIP)**.

## Layout do CSV (regra fixa)
`A` Data · `B` Débito · `C` Crédito · `D` Valor · `E` (VAZIA) · `F` Histórico
- Separador `;`, valor com **vírgula** decimal, sem milhar, BOM UTF-8. Coluna **E em branco** de propósito.
- Código das contas: **reduzido** (ex.: 629) ou **classificação completa** — definido no cadastro (`cod_padrao`).

## Regras contábeis (agrupa por data da venda, só vendas aprovadas)
- **Venda bruta:** D = conta do cartão (GetNet/Rede) · C = Clientes
  · histórico `RECEBIMENTO VENDA CARTAO <BANDEIRA> <data>`.
- **Tarifa:** D = Despesa c/ tarifa bancária · C = conta do cartão
  · histórico `TARIFA CARTAO <BANDEIRA> <data>`.
- Conferência: bruto − tarifa = líquido. Ref jan/2026 CALLIX: GetNet bruto 246.969,45; Rede bruto 61.531,50.

---

## Leitura dos relatórios (`parsers.py`)
Detecta a operadora pela **aba** do Excel: `CARTÕES` → GetNet · `vendas` → Rede.
- **Rede** (openpyxl, aba *vendas*, cabeçalho linha 2): `data da venda`,
  `valor da venda original` (bruto), `valor total das taxas descontadas` (tarifa),
  filtra `status da venda = aprovada`.
- **GetNet** (aba *CARTÕES*, cabeçalho linha 8): `DATA/HORA DA VENDA`, `VALOR BRUTO`,
  `VALOR TAXA` (negativo → valor absoluto), filtra `STATUS = Aprovada`. **Lido direto do XML**
  (zip + ElementTree) porque o Excel do GetNet vem com `dimension="A1"` inválido e strings inline
  (openpyxl leria vazio).

Para **outra operadora** (Cielo, Stone…): criar `parse_<op>` retornando
`[{data, bruto, tarifa}]` e apontar a conta no cadastro. (Pedir um relatório modelo.)

---

## Reutilizar em outra empresa
Só mexer no **Cadastro** (nada de código):
1. Cadastrar o **plano de contas** da empresa.
2. Apontar **GetNet, Rede, Clientes e Tarifa** para as contas dela e escolher o modo de código.
3. Salvar. Tudo fica em `dados/contas.json` e `dados/config.json`. Padrão de fábrica em `seed.json`.

---

## Arquivos
- `app.py` — Flask (porta 5001) + API do cadastro. `/processar_cartao` gera **um CSV por arquivo** + ZIP.
- `parsers.py` — detecção + leitura GetNet/Rede → `[{data, bruto, tarifa}]`.
- `core_cartao.py` — regras contábeis + geração do CSV (`process_each` = um resultado por relatório).
- `store.py` — cadastro (seed.json → `dados/*.json`).
- `templates/` — `hub, cartao, cadastro`.html.

## Convenções para editar (para você, Claude)
- Nunca quebrar o layout do CSV (E vazia, F histórico) nem o formato BR do valor.
- Contas sempre vêm do cadastro (`store.load()`), nunca hardcode.
- Depois de mudar `app.py`, reiniciar o servidor.
- Testar com relatórios reais e conferir bruto/tarifa/líquido antes de dar por pronto.

## Histórico do que foi pedido
1. Hub separado só para conciliar vendas de cartão (sem extrato bancário), reutilizável por empresa.
2. Ler os relatórios reais do **GetNet** e da **Rede** e gerar o CSV no mesmo layout do extrato.
3. Poder jogar **vários relatórios** e receber **um CSV de cada** (sem consolidar tudo num só) + ZIP.
