@echo off
chcp 65001 >nul
title Conciliador de Cartao
cd /d "%~dp0"
echo.
echo   Iniciando o Conciliador de Cartao...
echo   Verificando dependencias (primeira vez pode demorar)...
echo.
python -m pip install --quiet --disable-pip-version-check flask openpyxl
if errorlevel 1 (
  echo.
  echo   [ERRO] Nao foi possivel instalar as dependencias.
  echo   Verifique se o Python esta instalado e com acesso a internet.
  echo.
  pause
  exit /b 1
)
python app.py
echo.
echo   Servidor encerrado.
pause
