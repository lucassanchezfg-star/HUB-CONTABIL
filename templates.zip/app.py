# -*- coding: utf-8 -*-
"""Conciliador de Vendas de Cartao - servidor web local (Flask)."""
import base64, threading, webbrowser
from flask import Flask, render_template, request, jsonify
import store, core_cartao, parsers

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 64 * 1024 * 1024

@app.route('/')
def hub():
    return render_template('hub.html')

@app.route('/cartao')
def cartao():
    return render_template('cartao.html')

@app.route('/cadastro')
def cadastro():
    return render_template('cadastro.html')

@app.route('/processar_cartao', methods=['POST'])
def processar_cartao():
    ups = request.files.getlist('arquivos')
    files = [(f.filename, f.read()) for f in ups if f and f.filename]
    if not files:
        return jsonify({'ok': False, 'erro': 'Envie o relatório de vendas do cartão.'})
    try:
        grupos, aviso = parsers.parse_cartao(files)
    except parsers.ModeloNaoConfigurado as e:
        return jsonify({'ok': False, 'erro': str(e)})
    except Exception as e:
        return jsonify({'ok': False, 'erro': 'Erro ao ler o relatório: %s' % e})
    if not any(g['vendas'] for g in grupos):
        return jsonify({'ok': False, 'erro': 'Nenhuma venda aprovada reconhecida no relatório.'})
    import io, zipfile
    resultados = core_cartao.process_each(grupos)
    zbuf = io.BytesIO()
    zf = zipfile.ZipFile(zbuf, 'w', zipfile.ZIP_DEFLATED)
    usados, out = set(), []
    for r in resultados:
        p = r['summary']['periodo']
        nome = ('Cartao %s %s_a_%s' % (r['bandeira'], p[0], p[1])).replace('/', '-')
        base_nome = nome
        i = 2
        while nome + '.csv' in usados:
            nome = '%s (%d)' % (base_nome, i); i += 1
        nome_csv = nome + '.csv'
        usados.add(nome_csv)
        conteudo = ('﻿' + r['csv']).encode('utf-8')
        zf.writestr(nome_csv, conteudo)
        out.append({'arquivo': r['fonte'], 'bandeira': r['bandeira'], 'nome_csv': nome_csv,
                    'summary': r['summary'], 'total_rows': len(r['rows']),
                    'preview': r['rows'][:20], 'csv_b64': base64.b64encode(conteudo).decode('ascii')})
    zf.close()
    return jsonify({'ok': True, 'resultados': out, 'aviso': aviso,
                    'zip_b64': base64.b64encode(zbuf.getvalue()).decode('ascii')})

# ---- cadastro ----
@app.route('/api/dados')
def api_dados():
    contas, config = store.load()
    return jsonify({'contas': contas, 'config': config})

@app.route('/api/salvar', methods=['POST'])
def api_salvar():
    body = request.get_json(force=True)
    contas = body.get('contas', {})
    config = body.get('config', {})
    refs = set()
    cart = config.get('cartao', {})
    refs.add(cart.get('getnet', {}).get('conta'))
    refs.add(cart.get('rede', {}).get('conta'))
    refs.add(cart.get('clientes'))
    refs.add(cart.get('tarifa'))
    faltando = sorted(c for c in refs if c and c not in contas)
    if faltando:
        return jsonify({'ok': False, 'erro': 'Contas de cartão apontam para contas inexistentes: ' + ', '.join(faltando)})
    store.save(contas, config)
    return jsonify({'ok': True})

@app.route('/api/restaurar', methods=['POST'])
def api_restaurar():
    store.restaurar_padrao()
    contas, config = store.load()
    return jsonify({'ok': True, 'contas': contas, 'config': config})

def _open():
    webbrowser.open('http://127.0.0.1:5001/')

if __name__ == '__main__':
    print('\n  Conciliador de Vendas de Cartao')
    print('  Abrindo em: http://127.0.0.1:5001/\n')
    threading.Timer(1.2, _open).start()
    app.run(host='127.0.0.1', port=5001, debug=False)
