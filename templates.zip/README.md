# Conciliador de Vendas de Cartão → CSV

App local (roda no seu PC) que lê os relatórios de **vendas de cartão do GetNet e da Rede**
e gera um CSV de lançamentos contábeis. Projeto **independente**, reutilizável por empresa.

## Como usar

1. Duplo-clique em **`Iniciar Conciliador.bat`** (na 1ª vez instala Flask e openpyxl).
2. Abre o navegador em `http://127.0.0.1:5001/` (porta 5001 para não conflitar com outros apps).
3. **Cadastro** → aponte as contas de cartão da empresa e o modo de código. Salvar.
4. **Vendas de Cartão** → arraste os relatórios (GetNet e/ou Rede, juntos) → **Gerar CSV** → **Baixar**.

## Layout do CSV

`A` Data · `B` Débito · `C` Crédito · `D` Valor · `E` (vazia) · `F` Histórico
(separador `;`, valor com vírgula, BOM UTF-8). A coluna **E fica em branco** de propósito.

## Contabilização (agrupa por data da venda, só vendas aprovadas)

- **Venda bruta:** D = conta do cartão (GetNet/Rede) · C = Clientes
  · `RECEBIMENTO VENDA CARTAO <BANDEIRA> <data>`
- **Tarifa:** D = Despesa c/ tarifa bancária · C = conta do cartão
  · `TARIFA CARTAO <BANDEIRA> <data>`

Conferência: bruto − tarifa = líquido.

## Reutilizar em outra empresa

Só mexer no **Cadastro** (nada de código):
1. Cadastre as contas no **Plano de contas** (reduzido + classificação + nome).
2. Aponte **GetNet, Rede, Clientes e Tarifa** para as contas dessa empresa.
3. Escolha o **modo de código** (reduzido ou classificação). Salvar.

Tudo fica em `dados/contas.json` e `dados/config.json`. Padrão de fábrica em `seed.json`.
Botão **Restaurar padrão** recarrega do `seed.json`.

## Leitura dos relatórios (parsers.py)

- Operadora detectada pela aba do Excel: `CARTÕES` → GetNet · `vendas` → Rede.
- **Rede** (openpyxl): aba *vendas*, colunas *data da venda*, *valor da venda original* (bruto),
  *valor total das taxas descontadas* (tarifa), filtrando *status = aprovada*.
- **GetNet** (lido via XML): aba *CARTÕES*, colunas *DATA/HORA DA VENDA*, *VALOR BRUTO*,
  *VALOR TAXA* (negativo → absoluto), filtrando *STATUS = Aprovada*. É lido direto do XML porque
  o Excel do GetNet vem com `dimension="A1"` inválido e strings inline (openpyxl leria vazio).

Para adicionar outra operadora (Cielo, Stone…): criar um `parse_<op>` em `parsers.py` seguindo
o mesmo retorno `[{data, bruto, tarifa}]` e mapear a conta no cadastro.

## Arquivos

- `app.py` — servidor Flask (porta 5001) + API do cadastro.
- `parsers.py` — leitura/detecção dos relatórios GetNet e Rede.
- `core_cartao.py` — regras contábeis + geração do CSV.
- `store.py` — cadastro (seed.json → dados/*.json).
- `templates/` — hub, cartão, cadastro.
