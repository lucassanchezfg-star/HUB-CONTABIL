# -*- coding: utf-8 -*-
"""
Leitura dos relatorios de venda de cartao (GetNet / Rede) -> vendas agregadas por data.

parse_cartao(files) -> (grupos, aviso)
    grupos = [{'bandeira':'getnet'|'rede', 'fonte':nome, 'vendas':[{'data','bruto','tarifa'}]}]

Deteccao automatica pela aba do xlsx:
    aba "CARTOES" -> GetNet ; aba "vendas" -> Rede.
GetNet vem com <dimension ref="A1"/> invalido + strings inline -> lido direto do XML.
"""
import io, re, zipfile, unicodedata, datetime
from xml.etree import ElementTree as ET
from collections import defaultdict

M = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'

class ModeloNaoConfigurado(Exception):
    pass

def _norm(s):
    s = ''.join(c for c in unicodedata.normalize('NFD', str(s or '')) if unicodedata.category(c) != 'Mn')
    return ' '.join(s.upper().split())

def _to_float(v):
    if v is None or v == '':
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace('R$', '').replace(' ', '')
    if ',' in s and '.' in s:
        s = s.replace('.', '').replace(',', '.')
    elif ',' in s:
        s = s.replace(',', '.')
    try:
        return float(s)
    except ValueError:
        return 0.0

# ---------------------------------------------------------------- deteccao
def _sheet_names(data):
    z = zipfile.ZipFile(io.BytesIO(data))
    wb = z.read('xl/workbook.xml').decode('utf-8', 'replace')
    return re.findall(r'<sheet[^>]*name="([^"]+)"', wb)

def _detect(data):
    names = [_norm(n) for n in _sheet_names(data)]
    if any('CARTOES' in n for n in names):
        return 'getnet'
    if any(n == 'VENDAS' for n in names):
        return 'rede'
    return None

# ---------------------------------------------------------------- leitor XML (GetNet)
def _sheet_path_by_name(z, alvo):
    wb = z.read('xl/workbook.xml').decode('utf-8', 'replace')
    rid = None
    for name, rId in re.findall(r'<sheet[^>]*name="([^"]+)"[^>]*r:id="([^"]+)"', wb):
        if _norm(name) == _norm(alvo):
            rid = rId; break
    if not rid:
        return 'xl/worksheets/sheet1.xml'
    rels = z.read('xl/_rels/workbook.xml.rels').decode('utf-8', 'replace')
    tgt = dict(re.findall(r'Id="([^"]+)"[^>]*Target="([^"]+)"', rels)).get(rid, 'worksheets/sheet1.xml')
    return 'xl/' + tgt.lstrip('/')

def _colnum(ref):
    c = re.match(r'([A-Z]+)', ref).group(1); n = 0
    for ch in c:
        n = n * 26 + (ord(ch) - 64)
    return n

def _cellval(c):
    if c.get('t') == 'inlineStr':
        isn = c.find(M + 'is')
        return ''.join(x.text or '' for x in isn.iter(M + 't')) if isn is not None else ''
    v = c.find(M + 'v')
    return '' if v is None else v.text

def _rows_xml(data, sheet_name):
    z = zipfile.ZipFile(io.BytesIO(data))
    root = ET.fromstring(z.read(_sheet_path_by_name(z, sheet_name)))
    out = []
    for row in root.find(M + 'sheetData').findall(M + 'row'):
        cells = {}
        for c in row.findall(M + 'c'):
            cells[_colnum(c.get('r'))] = _cellval(c)
        mx = max(cells) if cells else 0
        out.append([cells.get(i, '') for i in range(1, mx + 1)])
    return out

def _find_header(rows, needles):
    for i, r in enumerate(rows):
        norm = [_norm(c) for c in r]
        if all(any(nd in cell for cell in norm) for nd in needles):
            return i, norm
    return None, None

def _col(headnorm, *alts):
    for a in alts:
        for j, h in enumerate(headnorm):
            if h == a or h.startswith(a):
                return j
    return None

# ---------------------------------------------------------------- parsers
def parse_getnet(data):
    rows = _rows_xml(data, 'CARTÕES')
    hi, head = _find_header(rows, ['VALOR BRUTO', 'DATA/HORA DA VENDA', 'STATUS'])
    if hi is None:
        raise ValueError('cabecalho do GetNet nao encontrado')
    c_data = _col(head, 'DATA/HORA DA VENDA', 'DATA/HORA')
    c_stat = _col(head, 'STATUS DA TRANSACAO', 'STATUS')
    c_bru  = _col(head, 'VALOR BRUTO')
    c_tax  = _col(head, 'VALOR TAXA')
    agg = defaultdict(lambda: [0.0, 0.0])
    for r in rows[hi + 1:]:
        if c_data is None or c_data >= len(r):
            continue
        raw = str(r[c_data]).strip()
        if not re.match(r'\d{2}/\d{2}/\d{4}', raw):
            continue
        if c_stat is not None and c_stat < len(r) and _norm(r[c_stat]) != 'APROVADA':
            continue
        d = raw[:10]
        agg[d][0] += _to_float(r[c_bru]) if c_bru is not None and c_bru < len(r) else 0.0
        agg[d][1] += abs(_to_float(r[c_tax])) if c_tax is not None and c_tax < len(r) else 0.0
    return [{'data': d, 'bruto': round(b, 2), 'tarifa': round(t, 2)} for d, (b, t) in agg.items()]

def parse_rede(data):
    from openpyxl import load_workbook
    wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    ws = wb['vendas'] if 'vendas' in wb.sheetnames else wb.worksheets[0]
    rows = list(ws.iter_rows(values_only=True))
    hi, head = _find_header(rows, ['DATA DA VENDA', 'VALOR DA VENDA ORIGINAL', 'STATUS'])
    if hi is None:
        raise ValueError('cabecalho da Rede nao encontrado')
    c_data = _col(head, 'DATA DA VENDA')
    c_stat = _col(head, 'STATUS DA VENDA', 'STATUS')
    c_bru  = _col(head, 'VALOR DA VENDA ORIGINAL', 'VALOR DA VENDA ATUALIZADO')
    c_tax  = _col(head, 'VALOR TOTAL DAS TAXAS DESCONTADAS')
    agg = defaultdict(lambda: [0.0, 0.0])
    for r in rows[hi + 1:]:
        if c_data is None or c_data >= len(r) or r[c_data] is None:
            continue
        if c_stat is not None and c_stat < len(r) and _norm(r[c_stat]) != 'APROVADA':
            continue
        dv = r[c_data]
        if isinstance(dv, (datetime.datetime, datetime.date)):
            d = dv.strftime('%d/%m/%Y')
        else:
            m = re.search(r'(\d{2})/(\d{2})/(\d{4})', str(dv)) or re.search(r'(\d{4})-(\d{2})-(\d{2})', str(dv))
            if not m:
                continue
            g = m.groups()
            d = '%s/%s/%s' % (g[2], g[1], g[0]) if len(g[0]) == 4 else '%s/%s/%s' % g
        agg[d][0] += _to_float(r[c_bru]) if c_bru is not None and c_bru < len(r) else 0.0
        agg[d][1] += abs(_to_float(r[c_tax])) if c_tax is not None and c_tax < len(r) else 0.0
    return [{'data': d, 'bruto': round(b, 2), 'tarifa': round(t, 2)} for d, (b, t) in agg.items()]

def parse_cartao(files):
    grupos, avisos = [], []
    for nome, data in files:
        band = _detect(data)
        if band == 'getnet':
            vendas = parse_getnet(data)
        elif band == 'rede':
            vendas = parse_rede(data)
        else:
            raise ModeloNaoConfigurado(
                'Não reconheci "%s" como GetNet nem Rede. '
                'Envie o Excel de vendas exportado do GetNet ou da Rede.' % nome)
        bruto = sum(v['bruto'] for v in vendas)
        avisos.append('%s: %s — %d dia(s), venda bruta R$ %s'
                      % (nome, band.upper(), len(vendas), ('%.2f' % bruto).replace('.', ',')))
        grupos.append({'bandeira': band, 'fonte': nome, 'vendas': vendas})
    return grupos, ' | '.join(avisos)
