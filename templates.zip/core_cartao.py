# -*- coding: utf-8 -*-
"""
Motor de contabilizacao das vendas de cartao (self-contained).

Layout do CSV: A=Data B=Debito C=Credito D=Valor E=(vazia) F=Historico
  - Venda bruta:  D = conta do cartao   C = Clientes    "RECEBIMENTO VENDA CARTAO <BAND> <data>"
  - Tarifa:       D = Desp. tarifa       C = cartao      "TARIFA CARTAO <BAND> <data>"
Agrega por data da venda (somente vendas aprovadas, ja filtradas no parser).
"""
import io
import store

def load_rules():
    contas, config = store.load()
    return {'contas': contas, 'cartao': config.get('cartao', {}),
            'cod_padrao': config.get('cod_padrao', 'reduzido'),
            'empresa': config.get('empresa', '')}

def _dkey(d):
    dd, mm, yy = d.split('/'); return (yy, mm, dd)

def _codes(classif, rules, cod):
    red, nome = rules['contas'].get(classif, ['?', '*** CONTA NAO CADASTRADA ***'])
    return (red if cod == 'reduzido' else classif), nome

def to_csv(rows, sep=';', decimal=','):
    def fmt(v):
        s = '%.2f' % v
        return s.replace('.', ',') if decimal == ',' else s
    out = io.StringIO()
    out.write(sep.join(['Data', 'Debito', 'Credito', 'Valor', '', 'Historico']) + '\r\n')
    for r in rows:
        out.write(sep.join([r['data'], str(r['debito']), str(r['credito']),
                            fmt(r['valor']), '', r['historico']]) + '\r\n')
    return out.getvalue()

def build_rows(vendas, bandeira, rules, cod):
    cart = rules.get('cartao', {})
    if bandeira not in cart:
        raise ValueError('Bandeira nao configurada no cadastro: %s' % bandeira)
    card_acc = cart[bandeira]['conta']
    label    = cart[bandeira].get('label', bandeira.upper())
    cli_acc  = cart['clientes']
    tar_acc  = cart['tarifa']
    rows = []
    for v in sorted(vendas, key=lambda x: _dkey(x['data'])):
        data = v['data']
        bruto = round(float(v.get('bruto') or 0), 2)
        tarifa = round(float(v.get('tarifa') or 0), 2)
        if bruto:
            d, dn = _codes(card_acc, rules, cod); c, cn = _codes(cli_acc, rules, cod)
            rows.append({'data': data, 'debito': d, 'debito_nome': dn, 'credito': c, 'credito_nome': cn,
                         'valor': bruto, 'historico': 'RECEBIMENTO VENDA CARTAO %s %s' % (label, data)})
        if tarifa:
            d, dn = _codes(tar_acc, rules, cod); c, cn = _codes(card_acc, rules, cod)
            rows.append({'data': data, 'debito': d, 'debito_nome': dn, 'credito': c, 'credito_nome': cn,
                         'valor': tarifa, 'historico': 'TARIFA CARTAO %s %s' % (label, data)})
    return rows

def _summ(rows, label):
    datas = sorted({r['data'] for r in rows}, key=_dkey)
    bruto = sum(r['valor'] for r in rows if r['historico'].startswith('RECEBIMENTO'))
    tarifa = sum(r['valor'] for r in rows if r['historico'].startswith('TARIFA'))
    return {'bandeira': label, 'qtd': len(rows), 'bruto': bruto, 'tarifa': tarifa,
            'liquido': bruto - tarifa, 'periodo': (datas[0] if datas else '', datas[-1] if datas else '')}

def process_each(grupos):
    """Processa CADA relatorio separadamente. Retorna lista de resultados (um por arquivo)."""
    rules = load_rules()
    cod = rules['cod_padrao']
    resultados = []
    for g in grupos:
        band = g['bandeira']
        label = rules.get('cartao', {}).get(band, {}).get('label', band.upper())
        rows = build_rows(g['vendas'], band, rules, cod)
        resultados.append({'fonte': g.get('fonte', ''), 'bandeira': label,
                           'rows': rows, 'summary': _summ(rows, label), 'csv': to_csv(rows)})
    return resultados

def process_grupos(grupos):
    rules = load_rules()
    cod = rules['cod_padrao']
    rows, por_bandeira = [], []
    for g in grupos:
        band = g['bandeira']
        label = rules.get('cartao', {}).get(band, {}).get('label', band.upper())
        r = build_rows(g['vendas'], band, rules, cod)
        rows.extend(r)
        por_bandeira.append(_summ(r, label))
    rows.sort(key=lambda x: _dkey(x['data']))
    datas = sorted({r['data'] for r in rows}, key=_dkey)
    bruto = sum(x['valor'] for x in rows if x['historico'].startswith('RECEBIMENTO'))
    tarifa = sum(x['valor'] for x in rows if x['historico'].startswith('TARIFA'))
    summ = {'qtd': len(rows), 'bruto': bruto, 'tarifa': tarifa, 'liquido': bruto - tarifa,
            'periodo': (datas[0] if datas else '', datas[-1] if datas else ''),
            'cod': cod, 'bandeiras': [s['bandeira'] for s in por_bandeira], 'por_bandeira': por_bandeira}
    return rows, summ, to_csv(rows)
